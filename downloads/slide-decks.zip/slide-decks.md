# Slide Decks: HTML Slide Production Standards

Creating slide decks is one of the most common design tasks. This document explains how to produce excellent HTML slides — from architecture selection and per-slide design, to the complete path for PDF/PPTX export.

**Capability coverage of this skill**:
- **HTML presentation version (core deliverable, always required by default)** → each slide as an independent HTML file + `assets/deck_index.html` aggregator, keyboard navigation and full-screen presentation in the browser
- HTML → PDF export → `scripts/export_deck_pdf.mjs` / `scripts/export_deck_stage_pdf.mjs`
- HTML → editable PPTX export → `references/editable-pptx.md` + `scripts/html2pptx.js` + `scripts/export_deck_pptx.mjs` (requires HTML to follow 4 hard constraints)

> **⚠️ HTML is the foundation; PDF/PPTX are derivatives.** Regardless of the final delivery format, you **must** first produce the HTML aggregated presentation version (`index.html` + `slides/*.html`) — it is the "source" of the slide deck. PDF/PPTX are snapshots exported from HTML with a single command.
>
> **Why HTML-first**:
> - Best for live presentations (projector / screen share — go full-screen directly, keyboard navigation, no dependency on Keynote/PPT software)
> - During development, each slide can be opened individually for verification without re-running the export
> - It is the sole upstream source for PDF/PPTX export (avoids the death loop of "find an issue after export → fix HTML → re-export")
> - The deliverable can be "HTML + PDF" or "HTML + PPTX" — recipients can use whichever they prefer
>
> 2026-04-22 moxt brochure real-world test: after finishing 13 HTML slides + index.html aggregator, `export_deck_pdf.mjs` exported the PDF in one command with zero changes. The HTML version itself is a delivery-ready, browser-presentable artifact.

---

## 🛑 Confirm Delivery Format Before Starting (The Hardest Checkpoint)

**This decision comes before "single file vs. multi-file."** 2026-04-20 real-world lesson from the options strategy board meeting project: **not confirming the delivery format before starting = 2–3 hours of rework.**

### Decision Tree (HTML-first Architecture)

All deliverables start from the same HTML aggregated page (`index.html` + `slides/*.html`). The delivery format only determines **the constraints on how HTML is written** and **which export command to run**:

```
[Always default · Required] HTML aggregated presentation (index.html + slides/*.html)
   │
   ├── Browser presentation only / local HTML archive   → done here; HTML has maximum visual freedom
   │
   ├── Also need PDF (for printing / sharing / archiving) → run export_deck_pdf.mjs, one command
   │                                                         HTML has no constraints, full visual freedom
   │
   └── Also need editable PPTX (colleagues need to edit text) → write HTML under 4 hard constraints from line one
                                                                  run export_deck_pptx.mjs, one command
                                                                  sacrifice gradients / web components / complex SVG
```

### Opening Script (Copy and Use)

> Regardless of whether the final delivery is HTML, PDF, or PPTX, I will first build an HTML aggregated version that can be navigated and presented in a browser (`index.html` with keyboard navigation) — this is always the default core deliverable. On top of that, I'll ask whether you also need a PDF / PPTX snapshot.
>
> Which export format do you need?
> - **HTML only** (presentation/archive) → full visual freedom
> - **Also PDF** → same as above, plus one export command
> - **Also editable PPTX** (colleagues will edit text in PowerPoint) → I must write HTML under 4 hard constraints from the very first line, which sacrifices some visual capability (no gradients, no web components, no complex SVG).

### Why "Needing PPTX Means Following 4 Hard Constraints from the Start"

For PPTX to be editable, `html2pptx.js` must be able to translate each DOM element into a PowerPoint object. This requires **4 hard constraints**:

1. Body fixed at 960pt × 540pt (matching `LAYOUT_WIDE`, 13.333″ × 7.5″ — not 1920×1080px)
2. All text wrapped in `<p>`/`<h1>`–`<h6>` (no bare text in divs, no `<span>` as primary text container)
3. `<p>`/`<h*>` tags themselves must not have background/border/shadow (put those on an outer div)
4. `<div>` must not use `background-image` (use `<img>` tags instead)
5. No CSS gradients, no web components, no decorative complex SVGs

**This skill's default HTML has high visual freedom** — heavy use of spans, nested flex, complex SVGs, web components (such as `<deck-stage>`), CSS gradients — **almost none of it naturally satisfies html2pptx constraints** (real-world test: visually-driven HTML fed directly into html2pptx has a pass rate < 30%).

### Cost Comparison of Two Real Paths (2026-04-20 Real Incident)

| Path | Approach | Result | Cost |
|------|------|------|------|
| ❌ **Write HTML freely first, fix PPTX later** | Single-file deck-stage + heavy SVG/span decoration | Editable PPTX leaves only two options:<br>A. Hand-write hundreds of lines of hardcoded pptxgenjs coordinates<br>B. Rewrite all 17 HTML pages in Path A format | 2–3 hours of rework, and the hand-written version has **permanent maintenance debt** (change one word in HTML → manually sync PPTX again) |
| ✅ **Follow Path A constraints from step one** | Each slide as independent HTML + 4 hard constraints + 960×540pt | One command exports 100% editable PPTX, while the HTML also works for full-screen browser presentation (Path A HTML is standard browser-playable HTML) | Writing HTML costs an extra 5 minutes thinking about "how to wrap text in `<p>`" — zero rework |

### Handling Mixed Delivery

User says "I want both HTML for presenting **and** editable PPTX" — **this is not mixed**, it's PPTX requirements covering HTML requirements. HTML written under Path A constraints can be presented full-screen in a browser (just add a `deck_index.html` aggregator). **No extra cost.**

User says "I want PPTX **and** animations / web components" — **this is a real conflict.** Tell the user: choosing editable PPTX means sacrificing these visual capabilities. Let them make the tradeoff; don't silently build a hand-written pptxgenjs solution (it becomes permanent maintenance debt).

### What to Do If PPTX Is Discovered Late (Emergency Recovery)

In rare cases: HTML is already written and then PPTX is needed. Use the **fallback workflow** (full details in `references/editable-pptx.md` under "Fallback: Visual Mockup Exists but User Insists on Editable PPTX"):

1. **Preferred: export to PDF** (100% visual fidelity, cross-platform, recipients can view and print) — if the recipient's actual need is "present/archive," PDF is the ideal deliverable
2. **Second choice: AI rewrites an editable HTML version based on the visual mockup** → export editable PPTX — preserves design decisions on colors/layout/copy while sacrificing gradients, web components, complex SVGs
3. **Not recommended: hand-write pptxgenjs** — positions, fonts, and alignment all need manual tuning; high maintenance cost, and every future HTML text change requires another manual sync

Always tell the user their options and let them decide. **Never default to hand-writing pptxgenjs first** — that is a last-resort fallback.

---

## 🛑 Before Bulk Production: Build a 2-Page Showcase First to Establish the Grammar

**For any deck ≥ 5 slides, never write from page 1 straight to the end.** Correct order, validated in the 2026-04-22 moxt brochure real-world session:

1. Choose **2 page types with the greatest visual contrast** and build the showcase first (e.g., "cover" + "mood/quote page", or "cover" + "product showcase page")
2. Screenshot and get user confirmation on the grammar (masthead / typeface / color / spacing / structure / bilingual proportion)
3. Once direction is approved, batch-produce the remaining N−2 pages, reusing the established grammar throughout
4. Assemble all slides into HTML aggregator + PDF/PPTX derivatives at the end

**Why**: writing all 13 pages straight through → user says "direction is wrong" = 13 rounds of rework. Writing 2 showcase pages → direction is wrong = 2 rounds of rework. Once the visual grammar is established, the decision space for the remaining N pages narrows dramatically — only "how does the content fit in."

**Showcase page selection principle**: choose the two pages with the most different visual structure. If those two pass, everything in between will too.

| Deck Type | Recommended Showcase Page Pairing |
|-----------|---------------------|
| B2B brochure / product launch | Cover + content page (philosophy/emotional page) |
| Brand launch | Cover + product feature page |
| Data report | Full-bleed data visualization page + analysis/conclusion page |
| Tutorial / course material | Chapter opener + specific knowledge point page |

---

## 📐 Publication Grammar Template (Reusable from moxt Real-World Test)

Suitable for B2B brochures / product launch decks / long report decks. Reusing this structure across pages = 13 pages with full visual consistency and zero rework.

### Page Skeleton

```
┌─ masthead (top strip + rule line) ─────────────────────────┐
│  [logo 22–28px] · A Product Brochure          Issue · Date · URL │
├────────────────────────────────────────────────────────────┤
│                                                            │
│  ── kicker (brand-color short rule + uppercase label)      │
│  CHAPTER XX · SECTION NAME                                 │
│                                                            │
│  H1 (Chinese: Noto Serif SC 900)                           │
│  Key words highlighted in brand primary color              │
│                                                            │
│  English subtitle (Lora italic, subtitle)                  │
│  ─────────────── divider line ────────────────            │
│                                                            │
│  [Specific content: 60/40 two-column / 2×2 grid / list]   │
│                                                            │
├────────────────────────────────────────────────────────────┤
│ section name                                    XX / total │
└────────────────────────────────────────────────────────────┘
```

### Style Conventions (Copy Directly)

- **H1**: Chinese Noto Serif SC 900, font size 80–140px depending on information density, key words highlighted in brand primary color (don't color the entire text)
- **English subtitle**: Lora italic 26–46px, brand signature terms (e.g., "AI team") in bold + primary-color italic
- **Body text**: Noto Serif SC 17–21px, line-height 1.75–1.85
- **Accent highlights**: use bold primary color to mark key words in body text, no more than 3 per page (too many loses its anchoring effect)
- **Background**: warm beige #FAFAFA + very faint radial-gradient noise (`rgba(33,33,33,0.015)`) to add paper texture

### Visual Protagonist Must Be Differentiated

13 pages of "text + one screenshot" each would be monotonous. **Rotate the type of visual protagonist on each page**:

| Visual Type | Suitable for |
|---------|---------------|
| Title typography (large text + masthead + pillar) | Cover / chapter opener |
| Single character portrait (oversized single figure like momo) | Introducing a single concept/character |
| Group portrait / avatar cards in a row | Team / user case studies |
| Timeline card progression | Showing "long-term relationship" or "evolution" |
| Knowledge graph / connected node diagram | Showing "collaboration" or "flow" |
| Before/After comparison cards + center arrow | Showing "change" or "contrast" |
| Product UI screenshot + outlined device frame | Specific feature showcase |
| Big-quote half-page (large pull quote) | Emotional page / question page / citation page |
| Real headshot + quote card (2×2 or 1×4) | User testimonials / usage scenarios |
| Large-text back cover + URL oval button | CTA / ending |

---

## ⚠️ Common Pitfalls (moxt Real-World Lessons)

### 1. Emoji Not Rendering in Chromium / Playwright Export

Chromium does not include a color emoji font by default. `page.pdf()` or `page.screenshot()` renders emoji as empty boxes.

**Solution**: use Unicode text symbols (`✦` `✓` `✕` `→` `·` `—`) instead, or switch to plain text ("Email · 23" instead of "📧 23 emails").

### 2. `export_deck_pdf.mjs` Error: `Cannot find package 'playwright'`

Cause: ESM module resolution searches for `node_modules` upward from the script's location. The script is in `~/.claude/skills/huashu-design/scripts/` which has no dependencies.

**Solution**: copy the script into the deck project directory (e.g., `brochure/build-pdf.mjs`), run `npm install playwright pdf-lib` from the project root, then `node build-pdf.mjs --slides slides --out output/deck.pdf`.

### 3. Google Fonts Not Loaded Before Screenshot → Chinese Text Displays as System Default Sans-Serif

Wait at least `wait-for-timeout=3500` before Playwright screenshots/PDFs to allow webfonts to download and paint. Alternatively, self-host fonts to `shared/fonts/` to reduce network dependency.

### 4. Information Density Imbalance: Too Much Crammed into Content Pages

The moxt philosophy page in its first version had 2×2 = 4 paragraphs + 3 credos at the bottom = 7 content blocks, which felt crowded and repetitive. Changing to 1×3 = 3 paragraphs immediately restored breathing room.

**Solution**: limit each page to "1 core message + 3–4 supporting points + 1 visual protagonist." Anything beyond that: split to a new page. **Less is more** — an audience spends 10 seconds per slide; giving them 1 memorable point is easier to remember than 4.

---

## 🛑 Define Architecture First: Single File or Multi-File?

**This choice is the first step in creating a slide deck; getting it wrong leads to repeated pitfalls. Read this section fully before starting.**

### Two-Architecture Comparison

| Dimension | Single File + `deck_stage.js` | **Multi-File + `deck_index.html` aggregator** |
|------|--------------------------|--------------------------------------|
| Code structure | One HTML, all slides are `<section>` | Each slide is an independent HTML, `index.html` uses iframes to aggregate |
| CSS scope | ❌ Global — one page's styles can affect all others | ✅ Naturally isolated — each iframe is its own context |
| Validation granularity | ❌ Must use JS goTo to navigate to a specific page | ✅ Double-click any slide file to open in browser |
| Parallel development | ❌ One file — multiple agents editing causes conflicts | ✅ Multiple agents can work on different pages in parallel, zero-conflict merge |
| Debugging difficulty | ❌ One CSS error breaks the entire deck | ✅ One page's error only affects itself |
| In-deck interactivity | ✅ Sharing state across pages is easy | 🟡 Requires postMessage between iframes |
| Print to PDF | ✅ Built-in | ✅ Aggregator handles beforeprint to iterate iframes |
| Keyboard navigation | ✅ Built-in | ✅ Built into aggregator |

### Which to Choose? (Decision Tree)

```
│ Question: how many slides does this deck have?
├── ≤10 slides, needs in-deck animation or cross-slide interactivity, pitch deck → single file
└── ≥10 slides, academic lecture, course material, long deck, multi-agent parallel → multi-file (recommended)
```

**Default to the multi-file path.** It's not a "backup option" — it's **the primary path for long decks and team collaboration.** Reason: every advantage of single-file (keyboard navigation, printing, scale) is also present in multi-file, while multi-file's scope isolation and per-slide verifiability cannot be retrofitted into single-file.

### Why This Rule Is So Hard? (Real Incident Record)

Single-file architecture caused four consecutive issues in an AI Psychology lecture deck:

1. **CSS specificity override**: `.emotion-slide { display: grid }` (specificity 10) overrode `deck-stage > section { display: none }` (specificity 2), causing all slides to render stacked simultaneously.
2. **Shadow DOM slot rules suppressed by outer CSS**: `::slotted(section) { display: none }` could not block outer rule overrides — sections refused to hide.
3. **localStorage + hash navigation race condition**: after reload, it jumped to the old localStorage position instead of the hash location.
4. **High verification cost**: had to `page.evaluate(d => d.goTo(n))` to capture a specific page — twice as slow as directly `goto(file://.../slides/05-X.html)` and often threw errors.

All root causes traced back to **a single global namespace** — multi-file architecture eliminates these problems at the physical level.

---

## Path A (Default): Multi-File Architecture

### Directory Structure

```
My Deck/
├── index.html              # Copied from assets/deck_index.html, modify MANIFEST
├── shared/
│   ├── tokens.css          # Shared design tokens (color palette/font scale/common chrome)
│   └── fonts.html          # <link> imports for Google Fonts (included per page)
└── slides/
    ├── 01-cover.html       # Each file is a complete 1920×1080 HTML
    ├── 02-agenda.html
    ├── 03-problem.html
    └── ...
```

### Slide Template Skeleton

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>P05 · Chapter Title</title>
<link href="https://fonts.googleapis.com/css2?family=..." rel="stylesheet">
<link rel="stylesheet" href="../shared/tokens.css">
<style>
  /* Styles unique to this page. Any class name used here won't pollute other pages. */
  body { padding: 120px; }
  .my-thing { ... }
</style>
</head>
<body>
  <!-- 1920×1080 content (body width/height locked in tokens.css) -->
  <div class="page-header">...</div>
  <div>...</div>
  <div class="page-footer">...</div>
</body>
</html>
```

**Key constraints**:
- `<body>` is the canvas — lay out directly on it. Don't wrap in `<section>` or other wrappers.
- `width: 1920px; height: 1080px` is locked by the `body` rule in `shared/tokens.css`.
- Import `shared/tokens.css` for shared design tokens (color palette, font scale, page-header/footer, etc.).
- Each page writes its own font `<link>` (importing fonts per-page is cheap and ensures each page can be opened independently).

### Aggregator: `deck_index.html`

**Copy directly from `assets/deck_index.html`.** Only one thing needs to change — the `window.DECK_MANIFEST` array: list all slide filenames and human-readable labels in order:

```js
window.DECK_MANIFEST = [
  { file: "slides/01-cover.html",    label: "Cover" },
  { file: "slides/02-agenda.html",   label: "Agenda" },
  { file: "slides/03-problem.html",  label: "Problem Statement" },
  // ...
];
```

The aggregator includes built-in: keyboard navigation (←/→/Home/End/number keys/P for print), scale + letterbox, bottom-right page counter, localStorage memory, hash navigation, and print mode (iterates iframes to output PDF page by page).

### Per-Page Validation (The Killer Advantage of Multi-File Architecture)

Each slide is a standalone HTML file. **Open it in the browser as soon as you finish it**:

```bash
open slides/05-personas.html
```

Playwright screenshots also use direct `goto(file://.../slides/05-personas.html)` — no need for JS navigation, no interference from other pages' CSS. This makes the "change a bit, verify a bit" workflow nearly cost-free.

### Parallel Development

Break each slide into a separate task for different agents running simultaneously — HTML files are completely independent, zero merge conflicts. For long decks, this parallel approach can compress production time to 1/N.

### What Goes in `shared/tokens.css`

Only things that are **truly shared across pages**:

- CSS variables (color palette, type scale, spacing scale)
- `body { width: 1920px; height: 1080px; }` canvas lock
- `.page-header` / `.page-footer` chrome used identically across every page

**Do not** put single-page layout classes here — that degrades back to the global pollution problem of single-file architecture.

---

## Path B (Small Decks): Single File + `deck_stage.js`

For decks ≤10 pages that need shared state across slides (e.g., a React tweaks panel controlling all pages), or extremely compact pitch deck demos.

### Basic Usage

1. Read content from `assets/deck_stage.js` and embed it in the HTML `<script>` (or `<script src="deck_stage.js">`)
2. Wrap slides in `<deck-stage>` in the body
3. 🛑 **Script tag must go after `</deck-stage>`** (see hard constraint below)

```html
<body>

  <deck-stage>
    <section>
      <h1>Slide 1</h1>
    </section>
    <section>
      <h1>Slide 2</h1>
    </section>
  </deck-stage>

  <!-- ✅ Correct: script after deck-stage -->
  <script src="deck_stage.js"></script>

</body>
```

### 🛑 Script Position Hard Constraint (2026-04-20 Real Incident)

**Do not put `<script src="deck_stage.js">` in the `<head>`.** Even if it defines `customElements` in the `<head>`, the parser triggers `connectedCallback` the moment it parses the `<deck-stage>` opening tag — at that point child `<section>` elements haven't been parsed yet, `_collectSlides()` gets an empty array, counter shows `1 / 0`, and all pages render stacked simultaneously.

**Three valid approaches** (choose any one):

```html
<!-- ✅ Most recommended: script after </deck-stage> -->
</deck-stage>
<script src="deck_stage.js"></script>

<!-- ✅ Also valid: script in head with defer -->
<head><script src="deck_stage.js" defer></script></head>

<!-- ✅ Also valid: module scripts are naturally deferred -->
<head><script src="deck_stage.js" type="module"></script></head>
```

`deck_stage.js` already has a built-in `DOMContentLoaded` deferred collection defense — even if the script is in the head it won't fully break. But `defer` or placing it at the bottom of the body is still cleaner, avoiding reliance on the defense branch.

### ⚠️ CSS Traps in Single-File Architecture (Must Read)

The most common trap in single-file architecture — **the `display` property getting stolen by per-slide styles**.

Common mistake 1 (writing display: flex directly on section):

```css
/* ❌ Outer CSS specificity 2 overrides shadow DOM ::slotted(section){display:none} (also 2) */
deck-stage > section {
  display: flex;            /* All pages will render stacked simultaneously! */
  flex-direction: column;
  padding: 80px;
  ...
}
```

Common mistake 2 (section with a higher-specificity class):

```css
.emotion-slide { display: grid; }   /* Specificity: 10, even worse */
```

Both will cause **all slides to render stacked simultaneously** — the counter might show `1 / 10` as if everything is fine, but visually page 1 is underneath page 2 is underneath page 3.

### ✅ Starter CSS (Copy to Start Work, Avoid Pitfalls)

**section itself** only controls "visible/hidden"; **layout (flex/grid, etc.) goes on `.active`**:

```css
/* section only defines non-display common styles */
deck-stage > section {
  background: var(--paper);
  padding: 80px 120px;
  overflow: hidden;
  position: relative;
  /* ⚠️ Do not write display here! */
}

/* Lock "inactive = hidden" — specificity + weight double insurance */
deck-stage > section:not(.active) {
  display: none !important;
}

/* Active page gets the display + layout it needs */
deck-stage > section.active {
  display: flex;
  flex-direction: column;
  justify-content: center;
}

/* Print mode: all pages must be visible, override :not(.active) */
@media print {
  deck-stage > section { display: flex !important; }
  deck-stage > section:not(.active) { display: flex !important; }
}
```

Alternative: **put single-page flex/grid on an inner wrapper `<div>`** — section itself is always just a `display: block/none` toggle. This is the cleanest approach:

```html
<deck-stage>
  <section>
    <div class="slide-content flex-layout">...</div>
  </section>
</deck-stage>
```

### Custom Dimensions

```html
<deck-stage width="1080" height="1920">
  <!-- 9:16 portrait format -->
</deck-stage>
```

---

## Slide Labels

Both deck_stage and deck_index label each page (shown in the counter). Give them **more meaningful** labels:

**Multi-file**: write `{ file, label: "04 Problem Statement" }` in the `MANIFEST`
**Single-file**: add `<section data-screen-label="04 Problem Statement">` on the section

**Key: Slide numbering starts at 1, not 0.**

When a user says "slide 5," they mean the 5th slide — never array position `[4]`. People don't think in 0-indexed terms.

---

## Speaker Notes

**Not added by default** — only add when the user explicitly requests them.

Once speaker notes are added, you can reduce the text on slides to a minimum and focus on impactful visuals — the notes carry the full script.

### Format

**Multi-file**: in `index.html`'s `<head>`:

```html
<script type="application/json" id="speaker-notes">
[
  "Script for slide 1...",
  "Script for slide 2...",
  "..."
]
</script>
```

**Single-file**: same location.

### Notes Writing Guidelines

- **Complete**: not an outline — these are the actual words to be spoken
- **Conversational**: sounds like natural speech, not written prose
- **Aligned**: the N-th array entry corresponds to the N-th slide
- **Length**: 200–400 words is ideal
- **Emotional arc**: mark emphasis, pauses, and stress points

---

## Slide Design Patterns

### 1. Establish a System (Required)

After exploring the design context, **verbally state the system you'll use**:

```markdown
Deck system:
- Background: max 2 colors (90% white + 10% dark section dividers)
- Typeface: display uses Instrument Serif, body uses Geist Sans
- Rhythm: section dividers use full-bleed color + white text; regular slides use white background
- Images: hero slides use full-bleed photos, data slides use charts

I'll build to this system — let me know if anything needs changing.
```

Get user confirmation before proceeding.

### 2. Common Slide Layouts

- **Title slide**: solid background + large title + subtitle + author/date
- **Section divider**: colored background + section number + section title
- **Content slide**: white background + title + 1–3 bullet points
- **Data slide**: title + large chart/number + brief caption
- **Image slide**: full-bleed photo + small caption at bottom
- **Quote slide**: whitespace + large pull quote + attribution
- **Two-column**: left/right comparison (vs / before-after / problem-solution)

Use at most 4–5 layouts in a single deck.

### 3. Scale (Emphasis)

- Body text minimum **24px**, ideal 28–36px
- Headings **60–120px**
- Hero text **180–240px**
- Slides are viewed from 10 meters away — text must be large enough

### 4. Visual Rhythm

A deck needs **intentional variety**:

- Color rhythm: mostly white backgrounds + occasional colorful section dividers + occasional dark segments
- Density rhythm: some text-heavy slides + some image-heavy slides + some quote/whitespace slides
- Type size rhythm: normal headings + occasional oversized hero text

**Don't make every slide look the same** — that's a PPT template, not design.

### 5. Breathing Room (Required Reading for Data-Dense Pages)

**The most common beginner mistake**: stuffing every piece of available information onto one page.

Information density ≠ effective communication. Academic/lecture decks especially need restraint:

- List/matrix pages: don't make all N elements the same size. Use **hierarchy** — the 5 items you're discussing today get enlarged as protagonists, the remaining 16 get shrunk as background hints.
- Big-number pages: the number itself is the visual protagonist. Keep surrounding caption under 3 lines, otherwise audience eyes jump around.
- Quote pages: put whitespace between the quote and attribution — don't let them crowd together.

Apply two self-checks: "is the data the protagonist" and "is text crammed together" — keep refining until the whitespace makes you slightly uneasy.

---

## Printing to PDF

**Multi-file**: `deck_index.html` already handles the `beforeprint` event, outputting the PDF page by page.

**Single-file**: `deck_stage.js` handles the same.

Print styles are pre-written — no additional `@media print` CSS required.

---

## Exporting to PPTX / PDF (Self-Serve Scripts)

HTML-first is the primary citizen. But users often need PPTX/PDF delivery. Two general-purpose scripts are provided — **usable with any multi-file deck** — located in `scripts/`:

### `export_deck_pdf.mjs` — Export Vector PDF (Multi-File Architecture)

```bash
node scripts/export_deck_pdf.mjs --slides <slides-dir> --out deck.pdf
```

**Characteristics**:
- Text **preserved as vectors** (copyable, searchable)
- 100% visual fidelity (Playwright's embedded Chromium renders then prints)
- **No changes to any HTML required**
- Each slide gets an independent `page.pdf()`, then `pdf-lib` merges them

**Dependencies**: `npm install playwright pdf-lib`

**Limitation**: PDF text is not editable — to make changes, go back to the HTML.

### `export_deck_stage_pdf.mjs` — Single-File Deck-Stage Architecture Only ⚠️

**When to use this**: the deck is a single HTML file + `<deck-stage>` web component wrapping N `<section>` elements (i.e., Path B architecture). In this case, `export_deck_pdf.mjs`'s approach of "one `page.pdf()` per HTML file" doesn't work — this dedicated script is needed.

```bash
node scripts/export_deck_stage_pdf.mjs --html deck.html --out deck.pdf
```

**Why `export_deck_pdf.mjs` can't be reused** (2026-04-20 real incident):

1. **Shadow DOM wins over `!important`**: deck-stage's shadow CSS has `::slotted(section) { display: none }` (only the active slide gets `display: block`). Even using `@media print { deck-stage > section { display: block !important } }` in light DOM won't win — `page.pdf()` triggers print media and Chromium's final render only shows the active slide, resulting in **the entire PDF being just 1 page** (the current active slide, repeated).

2. **Looping goto per slide still only yields 1 page**: the intuitive approach of "navigate to each `#slide-N`, then `page.pdf({pageRanges:'1'})`" also fails — because the print CSS's `deck-stage > section { display: block }` rule outside shadow DOM gets overridden, the final render is always the first element in the section list (not the one you navigated to). 17 loops produces 17 copies of the P01 cover.

3. **Absolute children overflow to next page**: even if you successfully render all sections, if a section has `position: static`, its absolute-positioned `cover-footer`/`slide-footer` will be positioned relative to the initial containing block — when the section is forced to 1080px height by print, the absolute footer may get pushed to the next page (manifests as one more page than sections, with that extra page containing only orphaned footers).

**Fix strategy** (already implemented in the script):

```js
// After opening the HTML, use page.evaluate to extract sections from deck-stage slot,
// attach them directly to a plain div under body, and inline style to ensure position:relative + fixed dimensions
await page.evaluate(() => {
  const stage = document.querySelector('deck-stage');
  const sections = Array.from(stage.querySelectorAll(':scope > section'));
  document.head.appendChild(Object.assign(document.createElement('style'), {
    textContent: `
      @page { size: 1920px 1080px; margin: 0; }
      html, body { margin: 0 !important; padding: 0 !important; }
      deck-stage { display: none !important; }
    `,
  }));
  const container = document.createElement('div');
  sections.forEach(s => {
    s.style.cssText = 'width:1920px!important;height:1080px!important;display:block!important;position:relative!important;overflow:hidden!important;page-break-after:always!important;break-after:page!important;background:#F7F4EF;margin:0!important;padding:0!important;';
    container.appendChild(s);
  });
  // Last page: disable page break to avoid trailing blank page
  sections[sections.length - 1].style.pageBreakAfter = 'auto';
  sections[sections.length - 1].style.breakAfter = 'auto';
  document.body.appendChild(container);
});

await page.pdf({ width: '1920px', height: '1080px', printBackground: true, preferCSSPageSize: true });
```

**Why this works**:
- Pulling sections from shadow DOM slot to a plain div in light DOM — completely bypasses the `::slotted(section) { display: none }` rule
- Inline `position: relative` makes absolute children position relative to their section, not overflowing
- `page-break-after: always` causes the browser to print each section as an independent page
- `:last-child` doesn't break page, preventing trailing blank page

**Note when verifying with `mdls -name kMDItemNumberOfPages`**: macOS Spotlight metadata is cached. After rewriting a PDF, run `mdimport file.pdf` to force refresh; otherwise stale page counts may display. Use `pdfinfo` or count `pdftoppm` output files for the true count.

---

### `export_deck_pptx.mjs` — Export Editable PPTX

```bash
# Only mode: text boxes natively editable (fonts fall back to system fonts)
node scripts/export_deck_pptx.mjs --slides <dir> --out deck.pptx
```

How it works: `html2pptx` reads computedStyle for each element and translates the DOM into PowerPoint objects (text frames / shapes / pictures). Text becomes true text boxes — double-click to edit in PPT.

**Hard constraints** (HTML must meet these, otherwise that page is skipped — full details in `references/editable-pptx.md`):
- All text must be in `<p>`/`<h1>`–`<h6>`/`<ul>`/`<ol>` (no bare-text divs)
- `<p>`/`<h*>` tags themselves must not have background/border/shadow (put those on an outer div)
- No `::before`/`::after` pseudo-element text decorations (pseudo-elements can't be extracted)
- Inline elements (span/em/strong) must not have margin
- No CSS gradients (cannot be rendered)
- No `background-image` on divs (use `<img>`)

The script has a built-in **automatic pre-processor** that wraps "bare text inside leaf divs" in `<p>` (preserving the class). This resolves the most common violation (bare text). However, other violations (border on p, margin on span, etc.) still require compliant HTML source.

**Font fallback caveat**:
- Playwright measures text-box sizes using webfonts; PowerPoint/Keynote renders using local fonts
- When the two differ, **overflow or misalignment** occurs — visually check every page
- Recommended: install the fonts used in HTML on the target machine, or fall back to `system-ui`

**Don't take this path for visual-priority scenarios** → use `export_deck_pdf.mjs` to produce PDF instead. PDF is 100% visually faithful, vector, cross-platform, and text-searchable — it's the true home for visual-priority decks, not some "uneditable compromise."

### Make HTML Export-Friendly from the Start

For the most stable deck performance: **write HTML following the 4 editable constraints from the beginning.** This lets `export_deck_pptx.mjs` pass everything directly. The extra effort is minimal:

```html
<!-- ❌ Not good -->
<div class="title">Key Finding</div>

<!-- ✅ Good (wrapped in p, class inherited) -->
<p class="title">Key Finding</p>

<!-- ❌ Not good (border on p) -->
<p class="stat" style="border-left: 3px solid red;">41%</p>

<!-- ✅ Good (border on outer div) -->
<div class="stat-wrap" style="border-left: 3px solid red;">
  <p class="stat">41%</p>
</div>
```

### When to Choose Which

| Scenario | Recommended |
|------|------|
| For organizers / archiving | **PDF** (universal, high fidelity, searchable text) |
| For collaborators who need to tweak text | **PPTX editable** (accept font fallback) |
| For live presentation without content changes | **PDF** (vector fidelity, cross-platform) |
| HTML is the primary presentation medium | Play directly in browser — export is just a backup |

## Deep Path to Editable PPTX Export (Long-term Projects Only)

If your deck will be maintained long-term, revised repeatedly, and used in team collaboration — **write HTML under html2pptx constraints from the beginning** so `export_deck_pptx.mjs` can pass everything directly. See `references/editable-pptx.md` (4 hard constraints + HTML template + common error quick reference + fallback workflow for existing visual mockups).

---

## FAQ

**Multi-file: page inside iframe won't open / white screen**
→ Check that `file` paths in `MANIFEST` are correct relative to `index.html`. Use browser DevTools to see if the iframe's `src` is directly accessible.

**Multi-file: a page's styles conflict with another page**
→ Impossible (iframe isolation). If it feels like a conflict, it's a cache issue — Cmd+Shift+R hard refresh.

**Single-file: multiple slides rendering stacked simultaneously**
→ CSS specificity issue. See "CSS Traps in Single-File Architecture" above.

**Single-file: scaling looks wrong**
→ Check that all slides are direct `<section>` children of `<deck-stage>`. Cannot be wrapped in `<div>`.

**Single-file: want to jump to a specific slide**
→ Add hash to URL: `index.html#slide-5` jumps to the 5th slide.

**Both architectures: text position inconsistent across screens**
→ Use fixed dimensions (1920×1080) and `px` units — don't use `vw`/`vh` or `%`. Scaling is handled uniformly.

---

## Validation Checklist (Required After Finishing a Deck)

1. [ ] Open `index.html` (or main HTML) directly in the browser — no broken images, fonts loaded
2. [ ] Press → to flip through every page — no blank pages, no layout issues
3. [ ] Press P to open print preview — each page shows exactly one A4 (or 1920×1080) without cropping
4. [ ] Randomly pick 3 pages and Cmd+Shift+R hard refresh — localStorage memory works correctly
5. [ ] Playwright batch screenshots (multi-file: iterate `slides/*.html`; single-file: use goTo to navigate), visually review each one
6. [ ] Search for `TODO` / `placeholder` remnants — confirm all are cleaned up
