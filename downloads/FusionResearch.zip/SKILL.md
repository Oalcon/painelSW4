---
name: "Fusion Research"
description: "Run a research/strategic-analysis prompt through two parallel subagents (Opus 4.8 + GPT-5.5) and synthesize a fused answer covering consensus, divergences, and gaps. Opt-in only. ~2-4x cost/latency of a normal response."
alwaysAllow:
  - mcp__session__subagent_run
---

# Fusion Research

Implements the **OpenRouter Fusion / Mixture-of-Agents (MoA)** pattern natively inside G4 OS using parallel subagents. The main session acts as judge and synthesizes the two outputs.

> **Cost warning**: this skill fires two premium subagents in parallel plus a synthesis pass in the main session. Expect ~2-4x the cost and ~2-4x the latency of a normal response. Use deliberately.

---

## When to use

**Use this skill when the user asks for:**
- Deep research with multiple perspectives
- Strategic / high-stakes decision analysis
- Comparative analysis (frameworks, vendors, approaches)
- "Use the panel", "fusion", "multi-model", "compare perspectives"
- Any question where the user explicitly says they want multiple expert views fused

**Do NOT use this skill for:**
- Simple factual questions ("what year did X happen?")
- Code edits, debugging, or implementation tasks
- Real-time or latency-sensitive requests
- Trivial lookups the main agent can answer in one shot
- Anything that needs live browsing (Fusion subagents are research/analysis, not retrieval)

If unsure, ask: "Isso é high-stakes o suficiente pra disparar o painel Fusion? Custo ~2-4x o normal."

---

## Architecture

| Concept | Implementation in G4 OS |
|---|---|
| Parallel model panel | Two `mcp__session__subagent_run` calls emitted in the **same tool block** (executes in parallel) |
| Cross-family diversity | Opus 4.8 (Anthropic) + GPT-5.5 (OpenAI) — different families produce meaningful divergence |
| Judge model that synthesizes | The **main session agent** (this session) |
| Writer model that produces final answer | The **main session agent** (fuse + write in one pass — saves one model call) |
| Single endpoint | `/fusion_research <query>` or `[skill:fusion_research] <query>` |

---

## Execution flow

### Step 1 — Confirm intent (only if not already explicit)

If the user did not say "fusion", "panel", or "multi-model" AND the question is medium-stakes (not obviously high or low), ask once:

> "Posso rodar isso em modo Fusion: dois subagents premium analisam em paralelo e eu sintetizo consenso, divergências e lacunas. ~2-4x o custo. Confirmado?"

If the user already opted in, or the question is clearly high-stakes (strategic, decision-support, deep research), proceed directly.

### Step 2 — Compose the panel prompt

Use the exact template below. Replace `{research_prompt}` with the user's actual question. The template is sent **identically** to both subagents — symmetric input is what makes consensus/divergence detection valid.

```
You are one member of a two-model expert research panel inside G4 OS. Your job
is to independently analyze the same research question so the main session can
later synthesize consensus, divergences, and gaps.

Research question:
{research_prompt}

Rules:
- Scope: research and strategic analysis only. Do not write code or execute
  implementation plans.
- Be source-aware: distinguish verified facts, inferred reasoning, and
  assumptions. If you cite sources, name them clearly and only cite sources
  you actually know. Do not invent URLs, studies, reports, dates, quotes, or
  statistics. If you cannot attribute a claim, write "(unattributed)".
- If current information would materially change the answer and you do not
  have live browsing/source access, mark it "needs live verification".
- Be concrete, executive-ready, concise. No generic filler, no throat-clearing.
- Take positions. No hedging filler ("it depends", "various factors").
- Mark confidence per claim: [High] / [Med] / [Low].
- If you don't know something, say so in an explicit "Open questions" line.

Output format (≤600 tokens, hard cap):
1. Direct answer: 2 sentences, no preamble.
2. 3-6 substantive claims, each one assertion + why it holds. Confidence-tagged.
3. Strategic implications: 2-3 bullets.
4. Risks / caveats: 2-3 bullets.
5. Open questions: 2-3 bullets the judge should know about.
```

### Step 3 — Fire two subagents in parallel (same tool block)

Emit both `mcp__session__subagent_run` calls in the **same tool block** so they run in parallel. Same `prompt` for both. Differentiate via `instructions` and `name` only.

**Subagent A — Opus 4.8 (deep reasoning member)**

```json
{
  "name": "Opus Panel Member",
  "role": "panel-member",
  "connectionSlug": "managed-public-aigateway",
  "model": "anthropic.claude-opus-4-8",
  "prompt": "<panel prompt from Step 2>",
  "instructions": "Act as the deep reasoning member of a two-model research panel. Be concise, source-aware, and strategic. Output under 600 tokens. Do not invent citations or current facts. Label uncertainty explicitly. Use (unattributed) when you cannot source a claim. Take positions over hedging.",
  "expectedOutput": "Direct answer (2 sentences) + 3-6 confidence-tagged atomic claims with attribution + strategic implications + risks/caveats + open questions."
}
```

**Subagent B — GPT-5.5 (verification-focused member)**

```json
{
  "name": "GPT-5.5 Panel Member",
  "role": "panel-member",
  "connectionSlug": "managed-public-aigateway",
  "model": "gpt-5.5",
  "prompt": "<panel prompt from Step 2>",
  "instructions": "Act as the verification-focused member of a two-model research panel. Prioritize precision over breadth: break reasoning into explicit claims, mark assumptions clearly, challenge vague strategic claims, identify missing evidence, do not overstate confidence. If you lack live data, say exactly what must be verified. Prefer fewer, stronger points over broad coverage. Output under 600 tokens. Do not invent citations or current facts.",
  "expectedOutput": "A structured research panel response with direct answer, 3-6 confidence-labeled atomic claims with attribution, strategic implications, risks/caveats, and open questions."
}
```

**Both** in the same tool block. G4 OS runs them in parallel automatically.

### Step 4 — Synthesize (main session as judge)

Run this rubric on the two responses:

1. **Normalize** — extract every claim into atomic units `{text, confidence, attribution, source_model}`.
2. **Match** — pair claims by semantic overlap (same subject + same predicate direction).
3. **Bucket:**
   - **Consenso**: both assert the same direction. Keep higher-attribution wording. Report combined confidence (downgrade to the lower of the two).
   - **Divergência**: both address the topic but conflict in direction, magnitude, or priority. Present both sides verbatim-ish + note which has stronger attribution.
   - **Lacuna**: claim from only one model, OR "Open questions" from either, OR a topic neither covered that the question clearly demanded.
4. **Tie-break rules:**
   - Equal attribution, opposing direction: present as live divergence, name no winner, flag for user judgment.
   - One model gives stronger reasoning, other is generic: favor the stronger model but disclose the disagreement.
   - Partial agreement (same fact, different implication): consensus on the fact, divergence on the implication — split the claim.
5. **Fabrication check** (CRITICAL — run BEFORE bucketing): if a model names a suspicious, unverifiable, or overly specific source (study, URL, author, date, statistic), **quarantine that claim** into a "⚠ unverified" note. **Do NOT promote to consensus even if both agree on the same invented stat** — two models can converge on a hallucination. Never repeat fabricated citations as fact.
6. **Write the fused output** in this exact order:

```markdown
# Fused Research: <topic>

## TL;DR
<2-3 sentences, the bottom line. If the panel is degraded, say so in the first sentence.>

## Consenso
<The main body. What both models concluded, fused into a single coherent take. Confidence labels preserved. Attribution preserved ("Opus: ...", "GPT-5.5: ...", or "(unattributed)" if both lacked sourcing).>

## Onde os modelos divergem
- **<Topic>**: Opus says X [High, attributed to: study Y]. GPT-5.5 says Y [Med, unattributed]. *Credibility: Opus wins on attribution. The direction may still be wrong.*
- ...

## Lacunas e pontos cegos
- <Topics neither model covered that the user probably needs>
- <Open questions from both subagents that remain unresolved>
- <Live data dependencies that the panel could not verify>

## ⚠ Unverified claims (if any)
- <Anything quarantined by the fabrication check. Always visible if non-empty.>

## Painel status
- ✅ Painel completo: Opus 4.8 + GPT-5.5
- ⚠ Painel degradado: only N of 2 models returned (X). Synthesis is single-sourced.
- ❌ Painel falhou: both models unavailable. Answered directly.
```

Keep the synthesis **shorter** than the combined subagent outputs. The job is to make divergence visible, not to dump both responses.

---

## Failure modes and degraded-panel policy

| Failure | Action |
|---|---|
| One subagent times out | Prepend `⚠ Painel degradado: apenas 1 de 2 modelos respondeu (X). Sem validação cruzada.` to TL;DR. Skip the "divergences" section. Add a Lacunas bullet: "The missing model may have surfaced alternative risks." |
| One subagent returns empty | Treat as timeout. Do NOT auto-retry. |
| One subagent is clearly worse (off-topic, truncated, hedge-only) | Demote to secondary. Build fusion on the strong one. Cite the weak one only where it adds a non-overlapping claim. Add `(modelo Y de baixa qualidade nesta rodada)` next to those claims. **Never silently average quality.** |
| Both subagents fail | Do not fabricate a fusion. Fall back to a single-agent answer. State explicitly: "Painel falhou, respondendo direto." |
| A subagent fabricates a citation | Quarantine the claim into the "⚠ Unverified" section. Do not propagate. |

---

## Cost & latency expectations

- **Cost per invocation**: ~2x a normal Opus call (two subagents + main-session synthesis). Roughly comparable to one Claude Fable 5 call depending on token length.
- **Latency**: 2-4x a single model call due to parallel fan-out. Budget ~20-45 seconds for a typical research prompt.
- **Hard cap**: N=2 subagents. Do not expand to N>2 — cost scales linearly with near-zero marginal consensus signal past 2 (per OpenRouter's own data: ~75% of Fusion's gain comes from synthesis, not panel size).

---

## Worked example

**User query**: `/fusion_research Should a Series A B2B SaaS launch an AI copilot as a paid SKU or bundle into core?`

**Fused output sketch:**

```markdown
# Fused Research: AI Copilot packaging (SKU vs bundle) for Series A SaaS

## TL;DR
Consensus: bundle basic AI features into core; charge separately for
workflow-level automation that delivers measurable productivity. The biggest
gap is missing willingness-to-pay data by customer segment.

## Consenso
- AI features are now table stakes in B2B SaaS [High, both]
- Monetization works best when tied to measurable productivity or usage [High, both]
- Series A margin sensitivity favors bundled models [Med, both]

## Onde os modelos divergem
- **Packaging psychology**: Opus [Med, unattributed] says avoid separate SKU
  unless value is transformational — easy to bundle away. GPT-5.5 [Med,
  unattributed] says a separate SKU works if infra cost is material and usage
  varies widely across customers. *Credibility: tie — depends on the specific
  product's cost structure.*
- **Time-to-revenue**: Opus leans bundled (faster adoption, no new sales motion).
  GPT-5.5 leans SKU (faster time-to-revenue once you have a buyer). *Tie —
  user judgment based on GTM maturity.*

## Lacunas e pontos cegos
- No customer willingness-to-pay data by segment (Open question, both)
- No competitive benchmark by category
- No gross margin model for the AI infra cost

## Painel status
- ✅ Painel completo: Opus 4.8 + GPT-5.5
```

---

## Reference

- OpenRouter Fusion API (launched 2026-06-13): orchestrates up to 8 models in parallel with a judge model for synthesis. This skill is the G4 OS-native equivalent with N=2.
- Mixture-of-Agents (MoA) research: ~75% of Fusion's quality gain comes from the judge's synthesis, not model diversity.
- Internal benchmark: 2-model Opus panel matched Claude Fable 5 solo on deep research tasks.
