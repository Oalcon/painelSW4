# Design Philosophy Style Library: 20 Systems

> A design style library for visual design (web / PPT / PDF / infographic / illustration / App, etc.).
> Each style provides: philosophical core + defining characteristics + prompt DNA (combine with scene templates).

## Style × Scene × Execution Path Quick Reference

| Style | Web | PPT | PDF | Infographic | Cover | AI-Generated | Best Path |
|------|:---:|:---:|:---:|:-----:|:---:|:-----:|---------|
| 01 Pentagram | ★★★ | ★★★ | ★★☆ | ★★☆ | ★★★ | ★☆☆ | HTML |
| 02 Stamen Design | ★★☆ | ★★☆ | ★★☆ | ★★★ | ★★☆ | ★★☆ | Hybrid |
| 03 Information Architects | ★★★ | ★☆☆ | ★★★ | ★☆☆ | ★☆☆ | ★☆☆ | HTML |
| 04 Fathom | ★★☆ | ★★★ | ★★★ | ★★★ | ★★☆ | ★☆☆ | HTML |
| 05 Locomotive | ★★★ | ★★☆ | ★☆☆ | ★☆☆ | ★★☆ | ★★☆ | Hybrid |
| 06 Active Theory | ★★★ | ★☆☆ | ★☆☆ | ★☆☆ | ★★☆ | ★★★ | AI-Generated |
| 07 Field.io | ★★☆ | ★★☆ | ★☆☆ | ★★☆ | ★★★ | ★★★ | AI-Generated |
| 08 Resn | ★★★ | ★☆☆ | ★☆☆ | ★☆☆ | ★★☆ | ★★☆ | AI-Generated |
| 09 Experimental Jetset | ★★☆ | ★★☆ | ★★☆ | ★★☆ | ★★★ | ★★☆ | Hybrid |
| 10 Müller-Brockmann | ★★☆ | ★★★ | ★★★ | ★★★ | ★★☆ | ★☆☆ | HTML |
| 11 Build | ★★★ | ★★★ | ★★☆ | ★☆☆ | ★★★ | ★☆☆ | HTML |
| 12 Sagmeister & Walsh | ★★☆ | ★★★ | ★☆☆ | ★★☆ | ★★★ | ★★★ | AI-Generated |
| 13 Zach Lieberman | ★☆☆ | ★☆☆ | ★☆☆ | ★★☆ | ★★★ | ★★★ | AI-Generated |
| 14 Raven Kwok | ★☆☆ | ★★☆ | ★☆☆ | ★★☆ | ★★★ | ★★★ | AI-Generated |
| 15 Ash Thorp | ★★☆ | ★★☆ | ★☆☆ | ★☆☆ | ★★★ | ★★★ | AI-Generated |
| 16 Territory Studio | ★★☆ | ★★☆ | ★☆☆ | ★★☆ | ★★★ | ★★★ | AI-Generated |
| 17 Takram | ★★★ | ★★★ | ★★★ | ★★☆ | ★★☆ | ★☆☆ | HTML |
| 18 Kenya Hara | ★★☆ | ★★★ | ★★★ | ★☆☆ | ★★★ | ★☆☆ | HTML |
| 19 Irma Boom | ★☆☆ | ★★☆ | ★★★ | ★★☆ | ★★★ | ★★☆ | Hybrid |
| 20 Neo Shen | ★★☆ | ★★☆ | ★★☆ | ★★☆ | ★★★ | ★★★ | AI-Generated |

> Scene fit: ★★★ = Highly recommended / ★★☆ = Suitable / ★☆☆ = Needs adaptation
> AI-generated: ★★★ = Direct output works well / ★★☆ = Needs adjustment / ★☆☆ = Recommend HTML execution
> Best path: AI-Generated (direct image output) / HTML (code rendering, precise data) / Hybrid (HTML layout + AI-generated imagery)

**Core pattern**: styles with distinct visual elements (illustration/particles/generative art) work well with AI direct output; styles dependent on precise typography and data (grid/information architecture/whitespace) are more controllable with HTML rendering.

---

## I. Information Architecture School (01–04)
> Philosophy: "Data is not decoration — it is the building material"

### 01. Pentagram — Michael Bierut Style
**Philosophy**: Typography is language; the grid is thought
**Defining characteristics**:
- Extremely restrained color (black-white + 1 brand color)
- Modern interpretation of the Swiss grid system
- Typography as the primary visual language
- Strategic use of negative space (60%+ whitespace)

**Prompt DNA**:
```
Pentagram/Michael Bierut style:
- Extreme typographic hierarchy, Helvetica/Univers family
- Swiss grid with precise mathematical spacing
- Black/white + one accent color (#HEX)
- Information architecture as visual structure
- 60%+ whitespace ratio
- Data visualization as primary decoration
```

**Signature work**: Hillary Clinton 2016 campaign identity
**Search terms**: pentagram hillary logo system

---

### 02. Stamen Design — Data Poetics
**Philosophy**: Make data a tangible landscape
**Defining characteristics**:
- Cartographic thinking applied to information design
- Algorithm-generated organic forms
- Warm data visualization palette (ochre, sage green, deep blue)
- Interactive layered hierarchy systems

**Prompt DNA**:
```
Stamen Design aesthetic:
- Cartographic approach to data visualization
- Organic, algorithm-generated patterns
- Warm palette (terracotta, sage green, deep blues)
- Layered information like topographic maps
- Hand-crafted feel despite digital precision
- Soft shadows and depth
```

**Signature work**: COVID-19 surge map
**Search terms**: stamen covid map visualization

---

### 03. Information Architects — Content-First Principle
**Philosophy**: Design is not decoration — it is the architecture of content
**Defining characteristics**:
- Extreme clarity in content hierarchy
- System fonts only (optimized for reading)
- Committed to the blue hyperlink tradition
- Performance as aesthetics

**Prompt DNA**:
```
Information Architects philosophy:
- Content-first hierarchy, zero decorative elements
- System fonts only (SF Pro/Roboto/Inter)
- Classic blue hyperlinks (#0000EE)
- Reading-optimized line length (66 characters)
- Progressive disclosure of depth
- Text-heavy, fast-loading design
```

**Signature work**: iA Writer app
**Search terms**: information architects ia writer

---

### 04. Fathom Information Design — Scientific Narrative
**Philosophy**: Every pixel must carry information
**Defining characteristics**:
- The rigor of scientific journals combined with design elegance
- Precise visualization of quantitative data
- Calm professional palette (gray, navy blue)
- Designed annotation and citation systems

**Prompt DNA**:
```
Fathom Information Design style:
- Scientific journal aesthetic meets modern design
- Precise data visualization (charts, timelines, scatter plots)
- Neutral scheme (grays, navy, one highlight color)
- Footnote/citation design integrated into layout
- Clean sans-serif (GT America/Graphik)
- Information density without clutter
```

**Signature work**: Bill & Melinda Gates Foundation annual report
**Search terms**: fathom information design gates foundation

---

## II. Motion Poetics School (05–08)
> Philosophy: "Technology itself is a form of flowing poetry"

### 05. Locomotive — Master of Scroll Narrative
**Philosophy**: Scrolling is not browsing — it is a journey
**Defining characteristics**:
- Silky smooth parallax scrolling
- Cinematic scene-by-scene narrative
- Bold spatial whitespace
- Precise choreography of dynamic elements

**Prompt DNA**:
```
Locomotive scroll narrative style:
- Film-like scene composition with parallax depth
- Generous vertical spacing between sections
- Bold typography emerging from darkness
- Smooth motion blur effects
- Dark mode (near-black backgrounds)
- Strategic glowing accents
- Hero sections 100vh tall
```

**Signature work**: Lusion.co website
**Search terms**: locomotive scroll lusion

---

### 06. Active Theory — WebGL Poet
**Philosophy**: Making technology visible is making it understandable
**Defining characteristics**:
- 3D particle systems as core elements
- Real-time rendered data visualization
- Mouse-interaction-driven world building
- Neon and deep space color palette

**Prompt DNA**:
```
Active Theory WebGL aesthetic:
- Particle systems representing data flow
- 3D visualization in depth space
- Neon gradients (cyan/magenta/electric blue) on dark
- Mouse-reactive environment
- Depth of field and bokeh effects
- Floating UI with glassmorphism
```

**Signature work**: NASA Prospect
**Search terms**: active theory nasa webgl

---

### 07. Field.io — Algorithmic Aesthetics
**Philosophy**: Code is the designer
**Defining characteristics**:
- Generative art systems
- Dynamic graphics that differ on every visit
- Intelligent composition of abstract geometry
- Balance between technical and artistic sensibility

**Prompt DNA**:
```
Field.io generative design style:
- Abstract geometric patterns, algorithmically generated
- Dynamic composition that feels computational
- Monochromatic base with vibrant accent
- Mathematical precision in spacing
- Voronoi diagrams or Delaunay triangulation
- Clean code aesthetic
```

**Signature work**: British Council digital installations
**Search terms**: field.io generative design

---

### 08. Resn — Narrative-Driven Interaction
**Philosophy**: Every click advances the story
**Defining characteristics**:
- Gamified user journeys
- Deeply emotional design
- Deep integration of illustration and code
- Non-linear exploratory experience

**Prompt DNA**:
```
Resn interactive storytelling approach:
- Illustrative style mixed with UI elements
- Gamified exploration (progress indicators)
- Warm color palette despite tech subject
- Character-driven design
- Scroll-triggered animations
- Editorial illustration meets product design
```

**Signature work**: Resn.co.nz portfolio
**Search terms**: resn interactive storytelling

---

## III. Minimalist School (09–12)
> Philosophy: "Reduce until nothing more can be removed"

### 09. Experimental Jetset — Conceptual Minimalism
**Philosophy**: One idea = one form
**Defining characteristics**:
- A single visual metaphor runs through the entire design
- Mondrian color palette: blue/red/yellow + black and white
- Typography as graphic element
- Honest, anti-commercial design

**Prompt DNA**:
```
Experimental Jetset conceptual minimalism:
- Single visual metaphor for entire design
- Primary colors only (red/blue/yellow) + black/white
- Typography as main graphic element
- Grid-based with deliberate rule-breaking
- No photography, only type and geometry
- Anti-commercial, honest aesthetic
```

**Signature work**: Whitney Museum identity
**Search terms**: experimental jetset whitney responsive w

---

### 10. Müller-Brockmann Legacy — Swiss Grid Purism
**Philosophy**: Objectivity is beauty
**Defining characteristics**:
- Mathematically precise grid systems (8pt baseline)
- Absolute left-alignment or centered alignment
- Single- or dual-color schemes
- Functionalism above all

**Prompt DNA**:
```
Josef Müller-Brockmann Swiss modernism:
- Mathematical grid system (8pt baseline)
- Strict alignment (flush left or centered)
- Two-color maximum (black + one accent)
- Akzidenz-Grotesk or similar rationalist typeface
- No decorative elements
- Timeless, objective aesthetic
```

**Signature work**: *Grid Systems in Graphic Design*
**Search terms**: muller brockmann grid systems poster

---

### 11. Build — Contemporary Minimalist Branding
**Philosophy**: Refined simplicity is harder than complexity
**Defining characteristics**:
- Luxury-grade whitespace (70%+)
- Subtle typographic weight contrast (200–600)
- Strategic use of a single accent color
- Rhythmic breathing room

**Prompt DNA**:
```
Build studio luxury minimalism:
- Generous whitespace (70%+ of area)
- Subtle typography weight shifts (200 to 600)
- Single accent color used sparingly
- High-end product photography aesthetic
- Soft shadows and subtle gradients
- Golden ratio proportions
```

**Signature work**: Build studio portfolio
**Search terms**: build studio london branding

---

### 12. Sagmeister & Walsh — Joyful Minimalism
**Philosophy**: Beauty is the emotional dimension of function
**Defining characteristics**:
- Unexpected color bursts
- Fusion of handcrafted and digital
- Positive, optimistic visual language
- Experimental yet readable

**Prompt DNA**:
```
Sagmeister & Walsh joyful philosophy:
- Unexpected color bursts on minimal base
- Handmade elements (physical objects in digital)
- Optimistic visual language
- Experimental typography that remains legible
- Human warmth through imperfection
- Mix of analog and digital aesthetics
```

**Signature work**: The Happy Show
**Search terms**: sagmeister walsh happy show

---

## IV. Experimental Avant-Garde School (13–16)
> Philosophy: "Breaking rules is creating rules"

### 13. Zach Lieberman — Code Poetics
**Philosophy**: Programming is painting
**Defining characteristics**:
- Hand-drawn aesthetic generated by algorithm
- Real-time generative art
- Pure expression in black and white
- Visibility of the tool itself

**Prompt DNA**:
```
Zach Lieberman code-as-art style:
- Hand-drawn aesthetic generated by code
- Black and white only, no color
- Real-time generative patterns
- Sketch-like line quality
- Visible process/grid/construction lines
- Poetic interpretation of algorithms
```

**Signature work**: openFrameworks creative coding
**Search terms**: zach lieberman openframeworks generative

---

### 14. Raven Kwok — Parametric Aesthetics
**Philosophy**: The beauty of the system surpasses the beauty of the individual
**Defining characteristics**:
- Fractal and recursive forms
- High-contrast black and white
- Architectural information structures
- Algorithmic interpretation of Eastern garden aesthetics

**Prompt DNA**:
```
Raven Kwok parametric aesthetic:
- Fractal patterns and recursive structures
- High-contrast black and white
- Architectural visualization of data
- Chinese garden principles in algorithm form
- Intricate detail that rewards zooming
- Processing/Creative coding aesthetic
```

**Signature work**: Raven Kwok generative art exhibitions
**Search terms**: raven kwok processing generative art

---

### 15. Ash Thorp — Cyberpunk Poetry
**Philosophy**: The future is not cold — it is a poem of solitude
**Defining characteristics**:
- Cinema-grade light and shadow
- Warm cyberpunk aesthetic (orange/teal, not cold blue)
- Narrative concept design
- Refined industrial aesthetics

**Prompt DNA**:
```
Ash Thorp cinematic concept art:
- Film-grade lighting and atmospheric effects
- Warm cyberpunk (orange/teal, NOT cold blue)
- Industrial design meets luxury
- Narrative concept art feel
- Volumetric lighting and god rays
- Blade Runner warmth over Tron coldness
```

**Signature work**: Ghost in the Shell concept art
**Search terms**: ash thorp ghost shell concept art

---

### 16. Territory Studio — Screen Interface Fiction
**Philosophy**: Today's imagination of tomorrow's UI
**Defining characteristics**:
- Screen design for science fiction films (FUI)
- Holographic projection aesthetic
- Multi-layer overlapping data visualization
- Believable futurism

**Prompt DNA**:
```
Territory Studio FUI (Fantasy User Interface):
- Fantasy User Interface design
- Holographic projection aesthetics
- Orange/amber monochrome or cyan accents
- Multiple overlapping data layers
- Believable future technology
- Technical readouts and data streams
```

**Signature work**: Blade Runner 2049 screen graphics
**Search terms**: territory studio blade runner interface

---

## V. Eastern Philosophy School (17–20)
> Philosophy: "Whitespace is content"

### 17. Takram — Japanese Speculative Design
**Philosophy**: Technology is a medium for thinking
**Defining characteristics**:
- Elegance of conceptual prototypes
- Soft technological sensibility (rounded corners, gentle shadows)
- Charts as art
- Humble sophistication

**Prompt DNA**:
```
Takram Japanese speculative design:
- Elegant concept prototypes and diagrams
- Soft tech aesthetic (rounded corners, gentle shadows)
- Charts and diagrams as art pieces
- Modest sophistication
- Neutral natural colors (beige, soft gray, muted green)
- Design as philosophical inquiry
```

**Signature work**: NHK Fabricated City
**Search terms**: takram nhk data visualization

---

### 18. Kenya Hara — The Design of Emptiness
**Philosophy**: Design is not filling — it is emptying
**Defining characteristics**:
- Extreme whitespace (80%+)
- Digital interpretation of paper texture
- Layers of white (warm white, cool white, off-white)
- Tactility made visual

**Prompt DNA**:
```
Kenya Hara "emptiness" design:
- Extreme whitespace (80%+)
- Paper texture and tactility in digital form
- Layers of white (warm white, cool white, off-white)
- Minimal color (if any, very desaturated)
- Design by subtraction not addition
- Zen simplicity
```

**Signature work**: Muji art direction, *Designing Design*
**Search terms**: kenya hara designing design muji

---

### 19. Irma Boom — Book Architect
**Philosophy**: The physical poetry of information
**Defining characteristics**:
- Non-linear information architecture
- Play with edges and boundaries
- Unexpected color combinations (pink + red, orange + brown)
- Digital translation of craftsmanship

**Prompt DNA**:
```
Irma Boom book architecture style:
- Non-linear information structure
- Play with edges, margins, boundaries
- Unexpected color combos (pink+red, orange+brown)
- Handcraft translated to digital
- Dense information inviting exploration
- Editorial design, unconventional grid
```

**Signature work**: SHV Think Book (2136 pages)
**Search terms**: irma boom shv think book

---

### 20. Neo Shen — Eastern Light and Shadow Poetry
**Philosophy**: Technology needs human warmth
**Defining characteristics**:
- Digital interpretation of ink wash painting
- Soft luminous glow effects
- Poetic negative space
- Emotional color palette (deep blue, warm gray, soft gold)

**Prompt DNA**:
```
Neo Shen poetic Chinese aesthetic:
- Digital interpretation of ink wash painting
- Soft glow and light diffusion effects
- Poetic negative space
- Emotional palette (deep blues, warm grays, soft gold)
- Calligraphic influences in typography
- Atmospheric depth
```

**Signature work**: Neo Shen digital art series
**Search terms**: neo shen digital ink wash art

---

## Prompt Usage Guide

**Combination formula**: `[Style prompt DNA] + [Scene template (see scene-templates.md)] + [Specific content]`

### Core Principle: Describe Mood, Not Layout

The key to AI image generation: short prompts beat long prompts. Describing 3 sentences of mood and content produces better results than 30 lines of layout details.

| Prompts That Kill Diversity | Prompts That Inspire Creativity |
|----------------|----------------|
| Specify color ratios (60%/25%/15%) | Describe mood ("warm like Sunday morning") |
| Define layout positions ("title centered, image on right") | Reference specific aesthetics ("Pentagram editorial feel") |
| Constrain character poses and expressions | Let AI naturally interpret the style |
| List every visual element to include | Describe what the audience should feel |

### Good / Bad Examples

**Bad — Over-constrained (AI output comes out flat and empty):**
```
Professional presentation slide. Dark background, light text.
Title centered at top. Two columns below. Left column: bullet points.
Right column: bar chart. Colors: navy 60%, white 30%, gold 10%.
Font size: title 36pt, body 18pt. Margins: 40px all sides.
```

**Good — Mood-driven (output is diverse and has texture):**
```
A data visualization that feels like a Bloomberg Businessweek
editorial spread. The key number "28.5%" should dominate the
composition like a headline. Warm cream tones with sharp black
typography. The data tells a story of dramatic channel shift.
```

### Choosing the Execution Path

Select based on the "Best Path" column in the quick reference table:
- **AI-Generated**: styles with distinct visual elements (06/07/12/13/14/15/16/20) — use Gemini/Midjourney for direct output
- **HTML rendering**: styles that rely on precise typography (01/03/04/10/11/17/18) — code controls data and layout
- **Hybrid**: HTML for structural layout + AI-generated imagery/backgrounds (02/05/08/09/19)

### Quality Control

1. ❌ Don't write "in the style of Pentagram" directly → ✅ Describe specific design characteristics
2. Text often goes wrong in AI generation → replace text after generation
3. Proportions can distort → explicitly specify aspect ratio
4. Generate 3–5 variants first, then refine the best one

**Default aesthetic exclusions** (can be overridden per brand):
- ❌ Cyberpunk neon / dark blue backgrounds (#0D1117)
- ❌ Cover images with personal signatures/watermarks

---

**Version**: v2.1
**Last updated**: 2026-02-13
**Applicable scenarios**: all visual design including web / PPT / PDF / infographic / cover / illustration / App
**Integration with image-to-slides**: PPT scenarios can directly reference styles from this file, executed via the image-to-slides skill
