# Slide Layout Templates

Reference for all available slide layouts. Each template includes the HTML structure skeleton.

---

## 1. Cover / Title Slide

Big headline, subtitle with accent bar, badges at bottom, decorative circles.

**Use for**: Opening slide, section openers with strong visual impact.

```html
<div class="slide-container" style="background: radial-gradient(circle at 80% 20%, #1A3A5E 0%, #0A1626 60%, #050B14 100%); padding: 80px 100px; display: flex; flex-direction: column; justify-content: center;">
    <!-- Decorative circles -->
    <div style="position: absolute; border-radius: 50%; border: 1px solid rgba(255,255,255,0.05); width: 600px; height: 600px; top: -100px; right: -100px; pointer-events: none;"></div>
    <div style="position: absolute; border-radius: 50%; border: 1px solid rgba(255,255,255,0.03); width: 800px; height: 800px; top: -200px; right: -200px; pointer-events: none;"></div>

    <!-- Optional logo top-right -->
    <!-- <div style="position: absolute; top: 60px; right: 100px; z-index: 20;">...</div> -->

    <!-- Accent bar -->
    <div style="width: 80px; height: 8px; background: linear-gradient(90deg, #FF5756, #FF8A89); margin-bottom: 40px; border-radius: 4px; position: relative; z-index: 10;"></div>

    <!-- Title -->
    <h1 style="font-size: 68px; font-weight: 800; line-height: 1.1; margin-bottom: 20px; text-shadow: 0 4px 20px rgba(0,0,0,0.3); position: relative; z-index: 10;">
        Title Line 1<br>Line 2
    </h1>

    <!-- Subtitle -->
    <div style="font-size: 22px; font-weight: 300; color: #BCD6F6; line-height: 1.5; max-width: 700px; margin-bottom: 60px; border-left: 2px solid #2063AD; padding-left: 20px; position: relative; z-index: 10;">
        Subtitle text here
    </div>

    <!-- Badges -->
    <div style="display: flex; gap: 20px; position: relative; z-index: 10;">
        <div style="background: rgba(32,99,173,0.2); border: 1px solid #2063AD; padding: 10px 20px; border-radius: 30px; font-size: 14px; font-weight: 600; color: #FFFFFF; letter-spacing: 1px; text-transform: uppercase;">Highlighted Badge</div>
        <div style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); padding: 10px 20px; border-radius: 30px; font-size: 14px; font-weight: 600; color: #BCD6F6; letter-spacing: 1px; text-transform: uppercase;">Normal Badge</div>
    </div>

    <!-- Footer -->
    <div style="position: absolute; bottom: 60px; right: 100px; text-align: right; z-index: 10;">
        <div style="font-size: 12px; color: #5A7CA0; letter-spacing: 2px; text-transform: uppercase;">Footer Text</div>
    </div>
</div>
```

---

## 2. Speaker / Bio Card

Speaker photo placeholder + name + credentials.

**Use for**: Mentor or speaker introduction.

```html
<div class="slide-container" style="background: linear-gradient(135deg, #0A1626 0%, #0B182B 100%); padding: 60px 80px; display: flex; align-items: center; gap: 80px;">
    <!-- Photo placeholder -->
    <div style="flex: 0 0 300px; display: flex; flex-direction: column; align-items: center;">
        <div style="width: 240px; height: 240px; border-radius: 20px; background: linear-gradient(135deg, rgba(32,99,173,0.3), rgba(32,99,173,0.1)); border: 2px solid rgba(32,99,173,0.4); display: flex; align-items: center; justify-content: center; font-size: 80px; color: #2063AD; margin-bottom: 20px;">
            <i class="fas fa-user"></i>
        </div>
        <div style="font-size: 12px; color: #5A7CA0; text-transform: uppercase; letter-spacing: 2px;">Seu Mentor</div>
    </div>

    <!-- Bio content -->
    <div style="flex: 1;">
        <div style="width: 60px; height: 6px; background: linear-gradient(90deg, #FF5756, #FF8A89); margin-bottom: 30px; border-radius: 3px;"></div>
        <h1 style="font-size: 42px; font-weight: 700; margin-bottom: 8px;">Speaker Name</h1>
        <div style="font-size: 18px; color: #2063AD; font-weight: 600; margin-bottom: 30px;">Title / Role</div>

        <div style="display: flex; flex-direction: column; gap: 16px;">
            <div style="display: flex; align-items: center; gap: 15px;">
                <div style="width: 36px; height: 36px; background: rgba(32,99,173,0.15); border-radius: 8px; display: flex; align-items: center; justify-content: center; color: #BCD6F6; font-size: 14px;"><i class="fas fa-briefcase"></i></div>
                <span style="font-size: 15px; color: #BCD6F6;">Credential or achievement</span>
            </div>
            <!-- Repeat for more credentials -->
        </div>
    </div>
</div>
```

---

## 3. Agenda / Table of Contents

Numbered list of topics, optionally grouped into sections.

**Use for**: "O Que Vamos Ver Hoje" overview slide.

```html
<div class="slide-container" style="background: linear-gradient(135deg, #0A1626 0%, #0B182B 100%); padding: 50px 70px; display: flex; flex-direction: column;">
    <div style="margin-bottom: 30px; border-bottom: 1px solid #2063AD; padding-bottom: 15px;">
        <h1 style="font-size: 32px; font-weight: 700;">O Que Vamos Ver Hoje</h1>
        <div style="font-size: 16px; color: #BCD6F6;">Subtitle description</div>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; flex: 1; align-content: start;">
        <!-- Topic item -->
        <div style="display: flex; align-items: center; gap: 15px; padding: 14px 18px; background: rgba(255,255,255,0.02); border: 1px solid rgba(32,99,173,0.15); border-radius: 8px;">
            <div style="width: 32px; height: 32px; background: rgba(32,99,173,0.2); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 14px; font-weight: 700; color: #FFFFFF; flex-shrink: 0;">1</div>
            <div>
                <div style="font-size: 14px; font-weight: 600; color: #FFFFFF;">Topic Title</div>
                <div style="font-size: 12px; color: #5A7CA0;">Brief description</div>
            </div>
        </div>
        <!-- Repeat for each topic -->
    </div>
</div>
```

---

## 4. Section Divider

Large module number + title. Minimal, clean visual break.

**Use for**: Transitioning between major sections.

```html
<div class="slide-container" style="background: radial-gradient(circle at 50% 50%, #0F2340 0%, #0A1626 70%); display: flex; align-items: center; justify-content: center; text-align: center;">
    <!-- Large background number -->
    <div style="position: absolute; font-size: 200px; font-weight: 800; color: rgba(32,99,173,0.08); line-height: 1; pointer-events: none;">01</div>

    <div style="position: relative; z-index: 10;">
        <div style="font-size: 14px; color: #2063AD; text-transform: uppercase; letter-spacing: 4px; font-weight: 600; margin-bottom: 20px;">Módulo 1</div>
        <h1 style="font-size: 48px; font-weight: 700; line-height: 1.2; max-width: 800px;">Section Title Here</h1>
        <div style="width: 60px; height: 4px; background: linear-gradient(90deg, #FF5756, #FF8A89); margin: 30px auto 0; border-radius: 2px;"></div>
    </div>
</div>
```

---

## 5. Big Statement / Quote

One powerful sentence, large and centered. Optional attribution.

**Use for**: Key concepts, paradigm shifts, provocative questions.

```html
<div class="slide-container" style="background: linear-gradient(135deg, #0A1626 0%, #0B182B 100%); display: flex; align-items: center; justify-content: center; text-align: center; padding: 80px 120px;">
    <div>
        <!-- Optional icon -->
        <div style="font-size: 48px; color: #2063AD; margin-bottom: 30px;"><i class="fas fa-lightbulb"></i></div>

        <blockquote style="font-size: 36px; font-weight: 600; line-height: 1.4; max-width: 900px; color: #FFFFFF;">
            "The powerful statement goes here. Keep it to one or two sentences maximum."
        </blockquote>

        <!-- Optional attribution -->
        <div style="margin-top: 30px; font-size: 14px; color: #5A7CA0;">— Attribution Name</div>
    </div>
</div>
```

---

## 6. Concept Explanation (Icon + Text)

Left icon/visual area, right side with title + bullets.

**Use for**: Explaining frameworks, concepts, analogies.

```html
<div class="slide-container" style="background: linear-gradient(135deg, #0A1626 0%, #0B182B 100%); padding: 50px 70px; display: flex; align-items: center; gap: 60px;">
    <!-- Visual area -->
    <div style="flex: 0 0 350px; display: flex; align-items: center; justify-content: center;">
        <div style="width: 200px; height: 200px; background: rgba(32,99,173,0.1); border: 2px solid rgba(32,99,173,0.3); border-radius: 24px; display: flex; align-items: center; justify-content: center; font-size: 80px; color: #2063AD;">
            <i class="fas fa-brain"></i>
        </div>
    </div>

    <!-- Text area -->
    <div style="flex: 1;">
        <h1 style="font-size: 32px; font-weight: 700; margin-bottom: 10px;">Concept Title</h1>
        <div style="font-size: 16px; color: #BCD6F6; margin-bottom: 30px;">One-line subtitle or context</div>

        <div style="display: flex; flex-direction: column; gap: 18px;">
            <div style="display: flex; gap: 15px; align-items: flex-start;">
                <div style="width: 8px; height: 8px; background: #FF5756; border-radius: 50%; margin-top: 8px; flex-shrink: 0;"></div>
                <div style="font-size: 16px; color: #FFFFFF; line-height: 1.5;">Bullet point explanation text here</div>
            </div>
            <!-- Repeat bullets -->
        </div>
    </div>
</div>
```

---

## 7. Comparison / Versus

Two columns side by side with distinct styling.

**Use for**: Before/after, approach A vs B, substitution vs amplification.

```html
<div class="slide-container" style="background: linear-gradient(135deg, #0A1626 0%, #0B182B 100%); padding: 50px 60px; display: flex; flex-direction: column;">
    <div style="margin-bottom: 30px; text-align: center;">
        <h1 style="font-size: 32px; font-weight: 700;">Option A vs. Option B</h1>
        <div style="font-size: 16px; color: #BCD6F6;">Subtitle context</div>
    </div>

    <div style="display: flex; gap: 30px; flex: 1;">
        <!-- Left column -->
        <div style="flex: 1; background: rgba(255,255,255,0.02); border: 1px solid rgba(96,125,139,0.3); border-top: 4px solid #607D8B; border-radius: 8px; padding: 30px;">
            <h2 style="font-size: 20px; font-weight: 700; color: #607D8B; margin-bottom: 20px;">Option A</h2>
            <div style="display: flex; flex-direction: column; gap: 15px;">
                <!-- List items -->
            </div>
        </div>

        <!-- VS divider -->
        <div style="display: flex; align-items: center;">
            <div style="width: 50px; height: 50px; background: rgba(255,87,86,0.1); border: 2px solid #FF5756; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 14px; color: #FF5756;">VS</div>
        </div>

        <!-- Right column -->
        <div style="flex: 1; background: rgba(32,99,173,0.05); border: 1px solid rgba(32,99,173,0.3); border-top: 4px solid #2063AD; border-radius: 8px; padding: 30px;">
            <h2 style="font-size: 20px; font-weight: 700; color: #2063AD; margin-bottom: 20px;">Option B</h2>
            <div style="display: flex; flex-direction: column; gap: 15px;">
                <!-- List items -->
            </div>
        </div>
    </div>
</div>
```

---

## 8. Matrix / 2x2 Grid

Four quadrants with axis labels.

**Use for**: Prioritization matrices, categorization frameworks.

```html
<div class="slide-container" style="background: linear-gradient(135deg, #0A1626 0%, #0B182B 100%); padding: 50px 60px; display: flex; flex-direction: column;">
    <div style="margin-bottom: 25px;">
        <h1 style="font-size: 32px; font-weight: 700;">Matrix Title</h1>
        <div style="font-size: 16px; color: #BCD6F6;">Subtitle</div>
    </div>

    <div style="flex: 1; display: flex; gap: 15px;">
        <!-- Y-axis label -->
        <div style="writing-mode: vertical-rl; transform: rotate(180deg); display: flex; align-items: center; justify-content: center; font-size: 13px; color: #BCD6F6; font-weight: 600; letter-spacing: 1px;">Y-AXIS LABEL ↑</div>

        <div style="flex: 1; display: flex; flex-direction: column; gap: 10px;">
            <!-- Top row -->
            <div style="flex: 1; display: flex; gap: 10px;">
                <div style="flex: 1; background: rgba(76,175,80,0.08); border: 1px solid rgba(76,175,80,0.3); border-radius: 8px; padding: 20px;">
                    <div style="font-size: 14px; font-weight: 700; color: #4CAF50; margin-bottom: 10px;">Quadrant Label</div>
                    <div style="font-size: 14px; color: #BCD6F6; line-height: 1.4;">Description</div>
                </div>
                <div style="flex: 1; background: rgba(32,99,173,0.08); border: 1px solid rgba(32,99,173,0.3); border-radius: 8px; padding: 20px;">
                    <div style="font-size: 14px; font-weight: 700; color: #2063AD; margin-bottom: 10px;">Quadrant Label</div>
                    <div style="font-size: 14px; color: #BCD6F6; line-height: 1.4;">Description</div>
                </div>
            </div>
            <!-- Bottom row -->
            <div style="flex: 1; display: flex; gap: 10px;">
                <div style="flex: 1; background: rgba(255,152,0,0.08); border: 1px solid rgba(255,152,0,0.3); border-radius: 8px; padding: 20px;">
                    <div style="font-size: 14px; font-weight: 700; color: #FF9800; margin-bottom: 10px;">Quadrant Label</div>
                    <div style="font-size: 14px; color: #BCD6F6; line-height: 1.4;">Description</div>
                </div>
                <div style="flex: 1; background: rgba(255,87,86,0.08); border: 1px solid rgba(255,87,86,0.3); border-radius: 8px; padding: 20px;">
                    <div style="font-size: 14px; font-weight: 700; color: #FF5756; margin-bottom: 10px;">Quadrant Label</div>
                    <div style="font-size: 14px; color: #BCD6F6; line-height: 1.4;">Description</div>
                </div>
            </div>
            <!-- X-axis label -->
            <div style="text-align: center; font-size: 13px; color: #BCD6F6; font-weight: 600; letter-spacing: 1px; padding-top: 5px;">X-AXIS LABEL →</div>
        </div>
    </div>
</div>
```

---

## 9. Data Dashboard (3-Column Grid)

Header + 3 equal column cards with stats and bars.

**Use for**: Multi-metric comparisons, methodology breakdowns.

```html
<div class="slide-container" style="background: linear-gradient(135deg, #0A1626 0%, #0B182B 100%); padding: 40px 60px; display: flex; flex-direction: column;">
    <div style="margin-bottom: 30px; border-bottom: 1px solid #2063AD; padding-bottom: 15px;">
        <h1 style="font-size: 32px; font-weight: 700;">Dashboard Title</h1>
        <div style="font-size: 16px; color: #BCD6F6;">Subtitle</div>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 30px; flex: 1;">
        <!-- Column card (repeat 3x) -->
        <div style="background: rgba(255,255,255,0.02); border: 1px solid rgba(32,99,173,0.2); border-radius: 8px; padding: 25px; display: flex; flex-direction: column;">
            <!-- Card header -->
            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 25px; padding-bottom: 15px; border-bottom: 1px solid rgba(255,255,255,0.05);">
                <div style="width: 32px; height: 32px; background: rgba(32,99,173,0.2); border-radius: 6px; display: flex; align-items: center; justify-content: center; color: #BCD6F6; font-size: 14px;"><i class="fas fa-icon"></i></div>
                <div style="font-size: 14px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">Card Title</div>
            </div>

            <!-- Big stat -->
            <div style="margin-bottom: 20px;">
                <div style="font-size: 56px; font-weight: 700; line-height: 1;">70%</div>
                <div style="font-size: 14px; color: #BCD6F6; font-weight: 500;">Stat Label</div>
            </div>

            <!-- Content area (bars, text, etc.) -->
        </div>
    </div>
</div>
```

---

## 10. Chart + Insight (Split Layout)

Left insight cards + right chart area.

**Use for**: Data trends with narrative context.

```html
<div class="slide-container" style="background: linear-gradient(135deg, #0A1626 0%, #0B182B 100%); padding: 40px 60px; display: flex; flex-direction: column;">
    <div style="margin-bottom: 20px; border-bottom: 1px solid #2063AD; padding-bottom: 15px;">
        <h1 style="font-size: 32px; font-weight: 700;">Chart Title</h1>
        <div style="font-size: 16px; color: #BCD6F6;">Subtitle</div>
    </div>

    <div style="display: flex; gap: 40px; flex: 1;">
        <!-- Left: Insights -->
        <div style="flex: 0 0 280px; display: flex; flex-direction: column; justify-content: center; gap: 20px;">
            <div style="background: rgba(255,255,255,0.03); border-left: 4px solid #FF5756; padding: 20px;">
                <div style="font-size: 14px; font-weight: 700; margin-bottom: 10px; text-transform: uppercase;">Insight Title</div>
                <div style="font-size: 13px; color: #BCD6F6; line-height: 1.5;">Insight text here.</div>
            </div>
        </div>

        <!-- Right: Chart -->
        <div style="flex: 1; display: flex; flex-direction: column;">
            <!-- KPI row -->
            <div style="display: flex; gap: 20px; margin-bottom: 20px;">
                <div style="flex: 1; background: rgba(76,175,80,0.1); padding: 15px 20px; border-radius: 4px; position: relative;">
                    <div style="font-size: 12px; color: #BCD6F6; text-transform: uppercase; margin-bottom: 5px;">KPI Label</div>
                    <div style="font-size: 36px; font-weight: 700;">57%</div>
                    <div style="position: absolute; right: 0; top: 0; bottom: 0; width: 4px; background: #4CAF50;"></div>
                </div>
            </div>

            <!-- Chart canvas -->
            <div style="flex: 1; background: rgba(255,255,255,0.02); border: 1px solid rgba(32,99,173,0.2); padding: 20px; position: relative;">
                <canvas id="myChart"></canvas>
            </div>
        </div>
    </div>
</div>
```

---

## 11. Flow / Process (Horizontal)

Steps connected by arrows.

**Use for**: Processes, cause-effect chains, decision flows.

```html
<div class="slide-container" style="background: linear-gradient(135deg, #0A1626 0%, #0B182B 100%); padding: 50px 70px; display: flex; flex-direction: column;">
    <div style="margin-bottom: 30px;">
        <h1 style="font-size: 32px; font-weight: 700;">Process Title</h1>
        <div style="font-size: 16px; color: #BCD6F6;">Subtitle</div>
    </div>

    <div style="display: flex; align-items: center; justify-content: space-between; background: rgba(255,255,255,0.02); border: 1px solid rgba(32,99,173,0.2); padding: 40px 30px; flex: 1; border-radius: 8px;">
        <!-- Step -->
        <div style="flex: 1; text-align: center;">
            <div style="font-size: 40px; color: #BCD6F6; margin-bottom: 15px;"><i class="fas fa-icon"></i></div>
            <div style="font-size: 13px; color: #BCD6F6; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px;">Step Label</div>
            <div style="font-size: 16px; font-weight: 600; max-width: 180px; margin: 0 auto;">Step description</div>
        </div>

        <!-- Arrow -->
        <div style="font-size: 28px; color: #2063AD; margin: 0 15px;"><i class="fas fa-arrow-right"></i></div>

        <!-- Next step... -->
    </div>
</div>
```

---

## 12. Vertical Steps / Timeline

Top-to-bottom numbered steps.

**Use for**: Step-by-step guides, implementation roadmaps.

```html
<div class="slide-container" style="background: linear-gradient(135deg, #0A1626 0%, #0B182B 100%); padding: 50px 80px; display: flex; flex-direction: column;">
    <div style="margin-bottom: 30px;">
        <h1 style="font-size: 32px; font-weight: 700;">Steps Title</h1>
    </div>

    <div style="display: flex; flex-direction: column; gap: 0; flex: 1; justify-content: center;">
        <!-- Step -->
        <div style="display: flex; gap: 20px; align-items: flex-start;">
            <div style="display: flex; flex-direction: column; align-items: center;">
                <div style="width: 40px; height: 40px; background: #2063AD; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 16px;">1</div>
                <div style="width: 2px; height: 40px; background: rgba(32,99,173,0.3);"></div>
            </div>
            <div style="padding-top: 8px;">
                <div style="font-size: 18px; font-weight: 600; margin-bottom: 4px;">Step Title</div>
                <div style="font-size: 14px; color: #BCD6F6;">Step description</div>
            </div>
        </div>
        <!-- Repeat -->
    </div>
</div>
```

---

## 13. Key Metrics (2x2 or 1x4 Grid)

Large stat cards.

**Use for**: KPI summaries, scorecards.

```html
<div class="slide-container" style="background: linear-gradient(135deg, #0A1626 0%, #0B182B 100%); padding: 50px 70px; display: flex; flex-direction: column;">
    <div style="margin-bottom: 30px;">
        <h1 style="font-size: 32px; font-weight: 700;">Key Metrics</h1>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 25px; flex: 1; align-content: center;">
        <!-- Metric card -->
        <div style="background: rgba(32,99,173,0.1); padding: 30px; border-left: 4px solid #2063AD; border-radius: 0 8px 8px 0;">
            <div style="font-size: 12px; color: #BCD6F6; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 10px;">Metric Label</div>
            <div style="font-size: 48px; font-weight: 700; line-height: 1;">Value</div>
            <div style="font-size: 13px; color: #5A7CA0; margin-top: 8px;">Context or comparison</div>
        </div>
        <!-- Repeat 3 more -->
    </div>
</div>
```

---

## 14. Bullet List with Icons

Clean list of 4-6 points with icons.

**Use for**: Recommendations, takeaways, action items.

```html
<div class="slide-container" style="background: linear-gradient(135deg, #0A1626 0%, #0B182B 100%); padding: 50px 80px; display: flex; flex-direction: column;">
    <div style="margin-bottom: 35px;">
        <h1 style="font-size: 32px; font-weight: 700;">List Title</h1>
        <div style="font-size: 16px; color: #BCD6F6;">Subtitle</div>
    </div>

    <div style="display: flex; flex-direction: column; gap: 20px; flex: 1; justify-content: center;">
        <!-- Item -->
        <div style="display: flex; align-items: center; gap: 20px; padding: 16px 20px; background: rgba(255,255,255,0.02); border: 1px solid rgba(32,99,173,0.15); border-radius: 8px;">
            <div style="width: 40px; height: 40px; background: rgba(32,99,173,0.2); border-radius: 10px; display: flex; align-items: center; justify-content: center; color: #BCD6F6; font-size: 16px; flex-shrink: 0;"><i class="fas fa-check"></i></div>
            <div>
                <div style="font-size: 16px; font-weight: 600;">Item Title</div>
                <div style="font-size: 13px; color: #BCD6F6; margin-top: 2px;">Brief description</div>
            </div>
        </div>
        <!-- Repeat -->
    </div>
</div>
```

---

## 15. Exercise / Interactive Prompt

Hands-on activity slide for the audience.

**Use for**: Practical exercises, audience reflection, workshop moments.

```html
<div class="slide-container" style="background: linear-gradient(135deg, #0A1626 0%, #0F2340 100%); padding: 60px 80px; display: flex; flex-direction: column; align-items: center; justify-content: center;">
    <!-- Exercise badge -->
    <div style="background: rgba(255,152,0,0.15); border: 1px solid #FF9800; padding: 8px 24px; border-radius: 30px; font-size: 13px; font-weight: 700; color: #FF9800; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 30px;">
        <i class="fas fa-pencil-alt" style="margin-right: 8px;"></i>Exercício Prático
    </div>

    <h1 style="font-size: 32px; font-weight: 700; text-align: center; margin-bottom: 15px;">Exercise Title</h1>
    <div style="font-size: 16px; color: #BCD6F6; text-align: center; max-width: 700px; margin-bottom: 40px;">Brief context for why this exercise matters</div>

    <!-- Exercise box -->
    <div style="background: rgba(255,255,255,0.03); border: 2px dashed rgba(255,152,0,0.4); border-radius: 12px; padding: 35px 50px; max-width: 800px; width: 100%; text-align: center;">
        <div style="font-size: 22px; font-weight: 600; line-height: 1.5; margin-bottom: 20px;">
            The question or task prompt for the audience
        </div>
        <div style="font-size: 14px; color: #BCD6F6;">
            <i class="fas fa-clock" style="margin-right: 5px;"></i> Tempo: X minutos
        </div>
    </div>

    <!-- Optional instructions -->
    <div style="margin-top: 30px; font-size: 14px; color: #5A7CA0; text-align: center; max-width: 600px;">
        Additional instructions or guidance for the exercise
    </div>
</div>
```

---

## 16. Q&A Invitation

Clean slide inviting questions.

**Use for**: Transition to Q&A section.

```html
<div class="slide-container" style="background: radial-gradient(circle at 50% 50%, #0F2340 0%, #0A1626 70%); display: flex; align-items: center; justify-content: center; text-align: center;">
    <div>
        <div style="width: 100px; height: 100px; background: rgba(32,99,173,0.15); border: 2px solid rgba(32,99,173,0.4); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 40px; color: #2063AD; margin: 0 auto 30px;">
            <i class="fas fa-hand"></i>
        </div>
        <h1 style="font-size: 48px; font-weight: 700; margin-bottom: 15px;">Perguntas?</h1>
        <div style="font-size: 18px; color: #BCD6F6; max-width: 500px;">Agora é a sua vez. Pergunte, questione, compartilhe.</div>
    </div>
</div>
```

---

## 17. Closing / Thank You

Big message, contact info, next steps.

**Use for**: Final slide of the presentation.

```html
<div class="slide-container" style="background: radial-gradient(circle at 50% 60%, #1A3A5E 0%, #0A1626 60%, #050B14 100%); display: flex; align-items: center; justify-content: center; text-align: center; padding: 80px;">
    <!-- Decorative circles -->
    <div style="position: absolute; border-radius: 50%; border: 1px solid rgba(255,255,255,0.03); width: 600px; height: 600px; top: -100px; left: -100px; pointer-events: none;"></div>

    <div style="position: relative; z-index: 10;">
        <div style="width: 60px; height: 6px; background: linear-gradient(90deg, #FF5756, #FF8A89); margin: 0 auto 40px; border-radius: 3px;"></div>
        <h1 style="font-size: 52px; font-weight: 800; margin-bottom: 20px; line-height: 1.2;">Closing Message</h1>
        <div style="font-size: 20px; color: #BCD6F6; max-width: 600px; margin: 0 auto 40px;">Subtitle or inspiring final thought</div>

        <!-- Optional: Badges or contact -->
        <div style="display: flex; gap: 15px; justify-content: center;">
            <div style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); padding: 10px 20px; border-radius: 30px; font-size: 14px; color: #BCD6F6;">info@example.com</div>
        </div>
    </div>
</div>
```
