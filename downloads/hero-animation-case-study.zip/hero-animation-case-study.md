# Gallery Ripple + Multi-Focus · Scene Choreography Philosophy

> A **reusable visual choreography structure** distilled from the huashu-design hero animation v9 (25 seconds, 8 scenes).
> This is not an animation production pipeline — it is about **when this choreography is "correct"**.
> Real-world reference: [demos/hero-animation-v9.mp4](../demos/hero-animation-v9.mp4) · [https://www.huasheng.ai/huashu-design-hero/](https://www.huasheng.ai/huashu-design-hero/)

## One-Line Summary

> **When you have 20+ visually homogeneous assets and the scene needs to "express scale and depth," prioritize Gallery Ripple + Multi-Focus choreography over stacking layouts.**

Generic SaaS feature animations, product launch events, skill promotions, series portfolio showcases — as long as the asset count is sufficient and the style is consistent, this structure almost always delivers.

---

## What This Technique Is Actually Expressing

It's not "showing off assets" — it's telling a narrative through **two rhythm changes**:

**First beat · Ripple Expansion (~1.5s)**: 48 cards radiate out from the center, the audience is stunned by "volume" — "oh, this thing has this many outputs."

**Second beat · Multi-Focus (~8s, 4 cycles)**: while the camera slowly pans, 4 times the background dims + desaturates and one specific card zooms up to screen center — the audience shifts from "volume impact" to "quality contemplation," each cycle at a steady 1.7s rhythm.

**Core narrative structure**: **Scale (Ripple) → Contemplation (Focus × 4) → Fade Out (Walloff)**. These three beats combine to express "Breadth × Depth" — not just capable of many things, but each one worth stopping to examine.

Compare against the counter-examples:

| Approach | Audience Perception |
|------|---------|
| 48 cards in a static grid (no Ripple) | Beautiful but no narrative — looks like a grid screenshot |
| One by one fast cuts (no gallery context) | Like a slideshow — loses the "sense of scale" |
| Ripple only with no Focus | Impressed by volume but doesn't remember any specific card |
| **Ripple + Focus × 4 (this recipe)** | **First stunned by quantity, then contemplating quality, then calm fade-out — a complete emotional arc** |

---

## Prerequisites (All Must Be Met)

This choreography **is not universal** — all 4 conditions are non-negotiable:

1. **Asset count ≥ 20, ideally 30+**
   Fewer than 20 will make the Ripple look "sparse" — all 48 cells need to be in motion to feel dense. v9 used 48 cells × 32 images (cycling to fill).

2. **Asset visual style must be consistent**
   All 16:9 slide previews / all app screenshots / all cover designs — aspect ratio, tone, and layout must feel like "a set." Mixing will make the gallery look like a clipboard.

3. **Individual assets remain readable when enlarged**
   Focus zooms a card to 960px wide — if the original image becomes blurry or information-sparse at that size, the Focus beat is wasted. Reverse validation: can you pick 4 cards from the 48 that are "most representative"? If you can't, the asset quality is uneven.

4. **Scene is landscape or square, not portrait**
   The gallery's 3D tilt (`rotateX(14deg) rotateY(-10deg)`) requires horizontal expansion. Portrait orientation makes the tilt look narrow and awkward.

**Fallback paths when prerequisites are missing**:

| What's missing | Fall back to |
|-------|-----------|
| Assets < 20 | "3–5 cards in a static row + sequential focus" |
| Inconsistent style | "Cover + 3 chapter hero images" keynote-style |
| Information-sparse assets | "Data-driven dashboard" or "key quote + large text" |
| Portrait orientation (9:16) | "Vertical scroll + sticky cards" |

---

## Technical Recipe (v9 Real-World Parameters)

### 4-Layer Structure

```
viewport (1920×1080, perspective: 2400px)
  └─ canvas (4320×2520, oversized overflow) → 3D tilt + pan
      └─ 8×6 grid = 48 cards (gap 40px, padding 60px)
          └─ img (16:9, border-radius 9px)
      └─ focus-overlay (absolute center, z-index 40)
          └─ img (matches selected slide)
```

**Key**: canvas is 2.25× larger than viewport — this gives the pan a "peering into a larger world" feeling.

### Ripple Expansion (Distance-Delay Algorithm)

```js
// Each card's entry time = distance from center × 0.8s delay
const col = i % 8, row = Math.floor(i / 8);
const dc = col - 3.5, dr = row - 2.5;       // offset to center
const dist = Math.hypot(dc, dr);
const maxDist = Math.hypot(3.5, 2.5);
const delay = (dist / maxDist) * 0.8;       // 0 → 0.8s
const localT = Math.max(0, (t - rippleStart - delay) / 0.7);
const opacity = expoOut(Math.min(1, localT));
```

**Core parameters**:
- Total duration 1.7s (`T.s3_ripple: [8.3, 10.0]`)
- Maximum delay 0.8s (center appears first, corners last)
- Each card's entry duration 0.7s
- Easing: `expoOut` (explosive energy, not smooth)

**Simultaneous action**: canvas scale from 1.25 → 0.94 (zoom out to reveal) — synchronized pull-back feeling as cards appear.

### Multi-Focus (4 Cycles)

```js
T.focuses = [
  { start: 11.0, end: 12.7, idx: 2  },  // 1.7s
  { start: 13.3, end: 15.0, idx: 3  },  // 1.7s
  { start: 15.6, end: 17.3, idx: 10 },  // 1.7s
  { start: 17.9, end: 19.6, idx: 16 },  // 1.7s
];
```

**Rhythm pattern**: each focus 1.7s, 0.6s breathing gap between them. Total 8s (11.0–19.6s).

**Inside each focus cycle**:
- In ramp: 0.4s (`expoOut`)
- Hold: middle 0.9s (`focusIntensity = 1`)
- Out ramp: 0.4s (`easeOut`)

**Background changes (this is the critical part)**:

```js
if (focusIntensity > 0) {
  const dimOp = entryOp * (1 - 0.6 * focusIntensity);  // dim to 40%
  const brt = 1 - 0.32 * focusIntensity;                // brightness 68%
  const sat = 1 - 0.35 * focusIntensity;                // saturate 65%
  card.style.filter = `brightness(${brt}) saturate(${sat})`;
}
```

**Not just opacity — simultaneously desaturate + darken.** This makes the foreground overlay's color "pop out" rather than just "brightening slightly."

**Focus overlay size animation**:
- From 400×225 (on entry) → 960×540 (hold state)
- Surrounded by 3-layer shadow + 3px accent-color outline ring — creates a "framed" feeling

### Pan (Continuous Movement Prevents Static Boredom)

```js
const panT = Math.max(0, t - 8.6);
const panX = Math.sin(panT * 0.12) * 220 - panT * 8;
const panY = Math.cos(panT * 0.09) * 120 - panT * 5;
```

- Sine wave + linear drift dual-layer movement — not a pure loop; every moment's position is unique
- X/Y frequencies differ (0.12 vs 0.09) to avoid visually perceivable "regular cycling"
- Clamped to ±900/500px to prevent drifting out of bounds

**Why not pure linear pan**: with pure linear pan, the audience "predicts" where the next second will be. Sine + drift makes every second new — under 3D tilt it produces a "subtle seasickness" (the good kind) that keeps attention.

---

## 5 Reusable Patterns (Distilled from v6→v9 Iterations)

### 1. **expoOut as Primary Easing, Not cubicOut**

`easeOut = 1 - (1-t)³` (smooth) vs `expoOut = 1 - 2^(-10t)` (explosive then quickly converging).

**Why**: expoOut reaches 90% of its target in the first 30% of its duration — more like physical damping, matching the intuition of "a heavy object landing." Particularly suitable for:
- Card entrances (weight)
- Ripple expansion (shockwave)
- Brand float (landing sensation)

**When to still use cubicOut**: focus out ramp, symmetric micro-animations.

### 2. **Paper-Tone Background + Terracotta Orange Accent (Anthropic Lineage)**

```css
--bg: #F7F4EE;        /* warm paper */
--ink: #1D1D1F;       /* near-black */
--accent: #D97757;    /* terracotta orange */
--hairline: #E4DED2;  /* warm rule line */
```

**Why**: a warm background retains "breathability" after GIF compression — unlike pure white which shows as "screen glare." Terracotta orange as the only accent threads through terminal prompt, dir-card selection, cursor, brand hyphen, focus ring — all visual anchors strung together by one single color.

**v5 lesson**: added a noise overlay to simulate "paper grain," but GIF frame compression destroyed it entirely (every frame was different). v6 switched to "background color only + warm shadows" — 90% of the paper feel was retained while GIF file size shrank 60%.

### 3. **Two-Tier Shadow to Simulate Depth, Not Real 3D**

```css
.gallery-card.depth-near { box-shadow: 0 32px 80px -22px rgba(60,40,20,0.22), ... }
.gallery-card.depth-far  { box-shadow: 0 14px 40px -16px rgba(60,40,20,0.10), ... }
```

Using `sin(i × 1.7) + cos(i × 0.73)` deterministic algorithm to assign each card to near/mid/far shadow tiers — **visually creates "three-dimensional stacking," but transforms are completely unchanged every frame, zero GPU cost.**

**The cost of real 3D**: each card with a separate `translateZ` means the GPU calculates 48 transforms + shadow blurs every frame. Tried in v4 — Playwright recording at 25fps was already struggling. The two-tier shadow approach has < 5% perceptible difference but 10× lower cost.

### 4. **Font Weight Variation (font-variation-settings) Is More Cinematic Than Font Size Variation**

```js
const wght = 100 + (700 - 100) * morphP;  // 100 → 700 over 0.9s
wordmark.style.fontVariationSettings = `"wght" ${wght.toFixed(0)}`;
```

Brand wordmark transitions from Thin → Bold over 0.9s, with subtle letter-spacing adjustment (−0.045 → −0.048em).

**Why this is better than scaling up/down**:
- Scale changes are too familiar — audience expectations are fixed
- Weight change is "inner fullness" — like a balloon being inflated, not "being pushed closer"
- Variable fonts are a post-2020 feature; audiences subconsciously perceive "modern"

**Limitation**: requires fonts that support variable font (Inter/Roboto Flex/Recursive, etc.). Static fonts can only fake it (switching between a few fixed weights creates jumps).

### 5. **Corner Brand as Low-Intensity Persistent Signature**

During the gallery phase, a small `HUASHU · DESIGN` mark sits in the upper-left corner — 16% opacity, 12px type, wide letter-spacing.

**Why include this**:
- After the Ripple explosion, viewers easily "lose focus" and forget what they're watching — a light mark helps anchor attention
- More premium than a full-screen large logo — people who work in branding know: brand signatures don't need to shout
- When GIFs get screenshotted and shared, authorship attribution is still present

**Rule**: only visible during the middle section (when the frame is busy) — off at the opening (not covering the terminal), off at the ending (brand reveal is the protagonist).

---

## Counter-Examples: When Not to Use This Choreography

**❌ Product demo (needs to show features)**: gallery lets every card flash by — audiences won't remember any specific feature. Use "single-screen focus + tooltip annotations" instead.

**❌ Data-driven content**: audiences need to read numbers; gallery's fast pace doesn't allow reading time. Use "data charts + progressive reveal" instead.

**❌ Story narrative**: gallery is a "parallel" structure; stories require "cause and effect." Use keynote chapter transitions instead.

**❌ Only 3–5 assets**: Ripple density is insufficient — looks like "patches." Use "static display + one-by-one highlight" instead.

**❌ Portrait orientation (9:16)**: 3D tilt requires horizontal expansion; portrait orientation makes the tilt feel "crooked" rather than "spread out."

---

## How to Judge Whether Your Task Suits This Choreography

Three-step quick check:

**Step 1 · Asset count**: count how many same-type visual assets you have. < 15 → stop; 15–25 → stretch; 25+ → go ahead.

**Step 2 · Consistency test**: place 4 random assets side by side — do they look like "a set"? If not → unify the style first, then build; or change the plan.

**Step 3 · Narrative match**: are you trying to express "Breadth × Depth" (quantity × quality)? Or "process," "features," "story"? If not the former, don't force it.

All three are yes — fork the v6 HTML directly, change the `SLIDE_FILES` array and timeline for instant reuse. Change the palette via `--bg / --accent / --ink` — swap the skin, keep the bones.

---

## Related References

- Complete technical workflow: [references/animations.md](animations.md) · [references/animation-best-practices.md](animation-best-practices.md)
- Animation export pipeline: [references/video-export.md](video-export.md)
- Audio configuration (BGM + SFX dual-track): [references/audio-design-rules.md](audio-design-rules.md)
- Lateral reference for Apple gallery style: [references/apple-gallery-showcase.md](apple-gallery-showcase.md)
- Source HTML (v6 + audio integration): `www.huasheng.ai/huashu-design-hero/index.html`
