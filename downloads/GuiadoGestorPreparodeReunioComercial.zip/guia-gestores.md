---
name: Guia do Gestor — Preparo de Reunião Comercial
description: Como usar o workflow de preparo para All Hands, Comitê de Receita e WBR. Para gestores, sem conhecimento técnico necessário.
---

# Guia do Gestor — Preparo de Reunião Comercial

> **Em 2 minutos você tem os números da sua reunião, direto do Databricks, sem montar planilha.**

---

## Como acionar

Digite no chat do G4 OS qualquer uma dessas frases:

- `/preparo-reuniao`
- "me prepara para o All Hands"
- "preparar WBR"
- "preparar comitê"
- "me prepara para o All Hands Pré-Vendas de hoje"

Se você já souber qual reunião é, pode ir direto:

> "me prepara para o **Comitê de Receita**"

O assistente vai perguntar qual ritual se você não especificar.

---

## Rituais disponíveis

| # | Ritual | Quando usar |
|---|---|---|
| 1 | **All Hands Pré-Vendas** | Antes do All Hands semanal/quinzenal de PV |
| 2 | **Comitê de Receita** | Antes do Comitê de Receita da área de PV |
| 3 | **All Hands Vendas** | Antes do All Hands do time de Vendas |
| 4 | **WBR** | Antes da Weekly Business Review |

---

## O que cada ritual entrega

### All Hands Pré-Vendas

Visão completa da área de SDRs, do topo até cada time filho.

Para cada nível (Área → Squad → Time) você recebe:

- **Meta do mês** e **GRID** (meta proporcional ao dia de hoje)
- **Realizado** e quanto falta pro GRID e pra meta
- **MTD%** — em qual percentual do ritmo esperado o time está
- **Ligações, CR SAL→Opp e LRT** — destaque operacional de cada time
- **Top 3 SDRs** por volume de opps

**Estrutura:** 1 bloco de Área + 2 Squads (Titãs e Mavericks) + 6 Times = **9 blocos**

---

### All Hands Vendas

Mesma lógica do PV, mas para o time de AEs com foco em receita.

Para cada nível (Área → Squad → Time) você recebe:

- **Meta, GRID, Realizado** em R$
- **MTD%** e GAPs vs GRID e vs Meta
- **Opps abertas, Deals ganhos e Win Rate** — destaque operacional
- **Top 3 AEs** por receita do mês

**Estrutura:** 1 bloco de Área + 2 Squads (Pitbulls e Rottweillers) + 7 Times = **10 blocos**

---

### Comitê de Receita

Três blocos em sequência, do macro para o detalhe:

**Bloco 1 — Totais da área PV**
- Meta, GRID, Realizado, vs GRID, vs Meta
- Ritmo necessário para bater a meta + comparação com o histórico dos últimos 3 meses

**Bloco 2 — Por Área de Geração de Demanda (AGD)**
- Paid / Social / CRM / Orgânico — Meta, GRID, Realizado, MTD%, vs Meta
- Big 7 — as 7 linhas estratégicas de receita com volume realizado

**Bloco 3 — SAL × OPP**
- Por AGD: quantos SALs entraram vs esperado, CR de conversão SAL→Opp e gap
- Big 7: razão histórica SAL→Opp (média dos 3 meses anteriores) vs o que está convertendo agora

Ao final dos 3 blocos, o assistente conduz uma **sessão consultiva** com 3 a 5 provocações priorizadas por impacto.

---

### WBR

Dois blocos em sequência:

**Bloco PV**
- MQL: meta, GRID, realizado
- Opp Funil de Marketing: meta, GRID, realizado, ritmo para bater a meta
- Métricas operacionais: SALs, CR SAL→Opp, LRT médio
- Selfcheckout: opps realizadas
- Opps por grupo de receita (visão completa de onde os SDRs estão gerando opps)
- Headcount: SDRs, coordenadores e gerentes ativos + quem tem saída mapeada nos próximos 60 dias

**Bloco Vendas**
- Receita total da área (com e sem Projetos e Eventos)
- Projetos e Eventos (inclui Aniversário G4): meta, GRID, realizado
- Funil de Marketing: meta, GRID, realizado, Win Rate, ticket médio, receita por Opp
- Time de Vendas - Aquisição: mesmas métricas + ritmo para bater a meta
- Todos os grupos com receita do mês
- Top 5 AEs por receita no mês
- Headcount: AEs, coordenadores e gerentes ativos

---

## Como ler os sinais

| Sinal | Significado |
|---|---|
| `[OK]` ou `[+]` | No ritmo ou acima — sem alerta |
| `[~]` | Levemente abaixo — atenção, mas controlável |
| `[!!]` | Significativamente abaixo — ponto de destaque na reunião |

---

## Dicas de uso

**Antes do All Hands:** acione de 15 a 30 minutos antes da reunião. Os dados levam cerca de 1 a 2 minutos para carregar.

**Antes do Comitê:** acione com pelo menos 20 minutos de antecedência — são 3 scripts rodando em paralelo + a sessão consultiva no final.

**Números do dia corrente:** os dados sempre mostram o MTD até o dia anterior (dados completos). O dia de hoje aparece como "em andamento" e não é incluído.

**Se um número parecer errado:** diga ao assistente qual número está estranho. Ele consegue reexecutar a query e explicar de onde veio o dado.

---

## Fontes dos dados

| Dado | Tabela |
|---|---|
| Metas (Plano G4) | `sandbox.db_metas_g4` |
| Metas individuais (SDRs/AEs) | `sandbox.db_metas_comercial` |
| Diariação (GRID) | `sandbox.db_diarizacao_metas` |
| Realizado (Opps, SAL, Won) | `production.diamond.funil_comercial` |
| Pessoas (squads, hierarquia) | `production.gold.g4_comercial_people` |

---

## Perguntas frequentes

**O GRID é diferente da meta — por quê?**
O GRID é a meta proporcional ao dia de hoje, calculada pela curva de diariação. Comparar realizado com GRID é mais justo do que comparar com a meta cheia antes do mês acabar.

**Por que o All Hands PV e o Comitê mostram números diferentes de opps?**
São filtros diferentes. O Comitê foca no **Funil de Marketing** (a meta oficial do Plano G4). O All Hands PV mostra **todos os grupos de receita** onde os SDRs geraram opps.

**O que é o Big 7?**
São as 7 linhas estratégicas de receita do Funil de Marketing: Facebook Ads, Chat, Social DM, Instagram G4, Instagram Tallis, Instagram Outros e Google.

**O que é LRT?**
Lead Response Time — tempo médio em horas entre o MQL e o SAL. Mede a velocidade de atendimento da operação de Pré-Vendas.