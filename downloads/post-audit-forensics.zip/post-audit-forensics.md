# Post-Audit Forensics & Incident Response

When a pentest confirms a probable attack vector for a reported incident, additional forensic steps are needed beyond just fixing the vulnerability.

---

## 1. Forensic Audit Checklist (post-finding)

### For Privilege Escalation (e.g., invite hijack):

```sql
-- Cross-reference: who used invites vs who the invite was for
SELECT 
  i.token,
  i.email AS invited_email,
  i.role_id AS granted_role,
  i.used_at,
  i.used_by_user_id,
  u.email AS actual_user_email,
  CASE WHEN LOWER(i.email) != LOWER(u.email) THEN 'MISMATCH - SUSPICIOUS' ELSE 'OK' END AS status
FROM public.invites i
LEFT JOIN auth.users u ON u.id = i.used_by_user_id
WHERE i.used_at IS NOT NULL
ORDER BY i.used_at DESC;
```

### For Weak Token Window:

```sql
-- Find all invites created during vulnerable period
SELECT id, token, email, role_id, created_at, used_at, used_by_user_id
FROM public.invites
WHERE created_at BETWEEN '2025-07-12' AND '2025-07-24'
  AND LENGTH(token) <= 12;

-- Invalidate unused vulnerable tokens
UPDATE public.invites
SET expires_at = NOW(), 
    deleted_at = NOW()
WHERE created_at BETWEEN '2025-07-12' AND '2025-07-24'
  AND used_at IS NULL
  AND LENGTH(token) <= 12;
```

### For Unauthorized Admin Access:

```sql
-- Find accounts with admin role that weren't supposed to have it
SELECT p.id, p.role_id, p.updated_at, u.email, u.created_at
FROM public.profiles p
JOIN auth.users u ON u.id = p.id
WHERE p.role_id IN (SELECT id FROM roles WHERE name IN ('admin', 'master_user'))
ORDER BY p.updated_at DESC;
```

---

## 2. Credential Rotation Checklist

After confirming exploitation or high-risk findings:

| Credential | Action | Priority |
|------------|--------|----------|
| Supabase service_role key | Rotate in Dashboard | IMMEDIATE if exposed |
| Supabase anon key | Rotate if RLS was broken | HIGH |
| VITE_FRONTEND_WORKER_KEY | Rotate + change auth model | IMMEDIATE |
| Webhook secrets (Stripe, Meta, Cal.com) | Rotate in each provider | HIGH if webhook unvalidated |
| API keys (checkout, integrations) | Rotate per service | HIGH |
| DKIM keys | Rotate if email spoofing confirmed | MEDIUM |
| All user sessions | Force logout all users | HIGH if privilege escalation confirmed |

### Rotation procedure:
1. Generate new credential in target service
2. Update environment variables (NOT in .env file in repo)
3. Deploy with new credential
4. Verify old credential no longer works
5. Monitor for failed auth attempts using old credential (indicates attacker retry)
6. Document rotation timestamp in audit log

---

## 3. Session Invalidation

After privilege escalation fix:

```sql
-- Revoke all active sessions (forces re-login)
-- Supabase approach: update auth.users.banned_until temporarily
-- Or use: supabase.auth.admin.signOut(userId, 'global')

-- For targeted invalidation (suspicious users only):
SELECT auth.uid, email 
FROM auth.sessions s
JOIN auth.users u ON u.id = s.user_id
WHERE s.created_at > '{incident_start_date}'
  AND u.id IN (
    SELECT used_by_user_id FROM invites 
    WHERE LOWER(email) != LOWER((SELECT email FROM auth.users WHERE id = used_by_user_id))
  );
```

---

## 4. Evidence Preservation

Before applying fixes, preserve evidence:

1. **Database snapshot:** Export affected tables (invites, profiles, audit_logs) to timestamped backup
2. **Git state:** Tag current commit as `pre-security-fix-{date}`
3. **Logs:** Export Supabase Edge Function logs for the incident window
4. **DNS state:** Screenshot current DNS records and WHOIS before changes
5. **HTTP responses:** Save curl outputs of vulnerable endpoints as evidence files

---

## 5. Monitoring Post-Fix

### Immediate (first 72 hours):

- Monitor `auth.users` for new admin-role accounts
- Monitor rate-limit tables for spike in attempts (attacker retrying old vector)
- Monitor webhook endpoints for unsigned requests (attacker testing if fix landed)
- Monitor Edge Function logs for 401/403 spike (blocked attacks)

### Ongoing (30 days):

- Weekly review of `audit_logs` for suspicious patterns
- Alert on any new `USING (true)` policy in migrations (regression)
- Alert on any new `verify_jwt = false` without corresponding HMAC check
- Monitor DMARC reports for spoofing attempts

---

## 6. Incident Timeline Template

For the report, include a timeline connecting findings to the reported incident:

```markdown
## Incident Timeline Reconstruction

| Date | Event | Evidence |
|------|-------|----------|
| 2025-07-12 | Vulnerable token generation deployed | Migration 20250712055638 |
| 2025-07-12 to 2025-07-24 | Window: all invites used weak PRNG | ~60 bits entropy |
| 2025-07-24 | Fix deployed (gen_random_bytes) | Migration 20250724205247 |
| {incident_date} | Client reports unauthorized access | Support ticket #{N} |
| {audit_date} | Audit confirms attack vector | This report — C1 + C2 |
| {audit_date} | Forensic query identifies suspicious accounts | {N} mismatched email/invite pairs |
```

---

## 7. Reporting to Authorities (LGPD)

If PII was confirmed exposed:

1. **72-hour window:** LGPD Art. 48 requires notification to ANPD within "prazo razoavel" (interpreted as 72h)
2. **Notify:** ANPD (Autoridade Nacional de Protecao de Dados)
3. **Notify affected users:** If exposure was confirmed and data was accessible
4. **Document:** Number of affected records, types of PII exposed, period of exposure, remediation taken
5. **DPO involvement:** Ensure Data Protection Officer is informed and signs off on notification

---

## 8. Kill Chain Documentation

For complex findings, document the full attack chain:

```
1. Attacker extracts anon key from public JS bundle (trivial)
2. Attacker discovers valid invite token via:
   a. Brute-force (weak PRNG window) OR
   b. Referer leak OR
   c. sessionStorage extraction via XSS
3. Attacker creates normal account via signup
4. Attacker calls apply_invite_to_user(token, own_user_id)
   - No auth.uid() check → accepts arbitrary user_id
   - No email match check → any token works for any user
5. Attacker's profile.role_id = admin
6. Attacker now has full admin access:
   - Can create/delete invites (admin-delete-invite, no auth)
   - Can access all user data (admin RLS policies)
   - Can modify billing (Stripe integration)
   - Can impersonate users (admin-update-profile)
```

This kill chain format helps non-technical stakeholders understand the severity and makes the case for immediate remediation.
