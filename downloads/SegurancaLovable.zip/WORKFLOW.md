---
name: "Seguranca Lovable"
description: "Pentest automatizado para apps Supabase (Lovable, Bolt, etc.) — varredura API + teste de usuario real via browser"
icon: "🔒"
---

# Seguranca Lovable — Analise de Seguranca para Apps Supabase

## Proposito

Conduzir analise de seguranca **automatizada** em aplicacoes web que usam Supabase como backend (criadas no Lovable, Bolt, ou similar). Verifica RLS, autenticacao, isolamento de tenant, exposicao de dados e vetores de ataque comuns.

## Disclaimer Obrigatorio

**Apresente este disclaimer ao usuario ANTES de iniciar a analise e inclua no relatorio final:**

> **Aviso importante:** Esta e uma analise de seguranca automatizada conduzida por IA. Embora cubra os vetores de ataque mais comuns em aplicacoes Supabase (RLS, autenticacao, isolamento de tenant, escrita anonima), ela **pode deixar passar vulnerabilidades** que um pentest manual profissional identificaria — como falhas de logica de negocio, timing attacks, vulnerabilidades em edge functions complexas, ou problemas de infraestrutura.
>
> **Recomendacao:** Para aplicacoes em producao com dados sensiveis, envolva um time profissional de ciberseguranca para uma auditoria completa. Esta analise automatizada e um excelente primeiro passo para identificar problemas obvios, mas nao substitui um pentest conduzido por especialistas.

## Input

Pergunte ao usuario:

1. **Qual a URL da sua aplicacao?** — ex: `https://app.exemplo.com`
2. **Que tipo de analise voce quer?**
   - **Rapida (Nivel 1):** Verifica se os dados da sua aplicacao estao expostos na internet. Leva alguns minutos, usa pouco credito.
   - **Completa (Nivel 2):** Tudo do Nivel 1 + cria uma conta real na sua app e testa como se fosse um usuario tentando acessar dados de outros. Mais profundo, mas **consome mais creditos e leva mais tempo.**

Se o usuario nao souber qual escolher, recomende: "Se voce so quer saber se tem dados expostos, vai de Rapida. Se quer um teste completo de seguranca, vai de Completa."

Se o usuario escolher Nivel 2, rode o Nivel 1 primeiro, apresente os findings intermediarios para discussao, e depois execute o Nivel 2.

## Principios Criticos — O Que NAO Fazer

Estes principios vem de experiencia real de pentesting em Supabase e DEVEM ser seguidos:

### 1. Tabela vazia NAO e vulnerabilidade
Supabase views herdam RLS das tabelas subjacentes. Uma view visivel mas sem dados (HTTP 200, `[]`) esta funcionando como esperado. So marque como finding quando **dados sensiveis reais** forem retornados.

### 2. Schema OpenAPI exposto e by design
Todo Supabase expoe nomes de tabelas via `/rest/v1/`. Isso NAO e uma vulnerabilidade. Nao inclua no relatorio como finding.

### 3. Anon key publica e by design
A anon key do Supabase e projetada para ser publica em SPAs. A seguranca vem do RLS, nao do sigilo da key. Nao trate a key exposta como finding.

### 4. Classificar findings com rigor
- **🔴 Confirmado**: Dados sensiveis vazaram, escrita nao-autorizada funcionou, bypass de auth comprovado. Evidencia concreta, sem discussao.
- **🟡 Precisa clarificacao**: Pode ser problema ou pode ser by design. Apresente os fatos e PERGUNTE ao usuario antes de classificar. Ex: "Encontrei X. Pode ser um problema por Y, mas preciso validar com voce."
- **✅ Protegido**: Testado e funcionando como esperado.

### 5. NAO assuma que esta errado
Antes de flagar algo, pergunte-se: "Isso e realmente uma vulnerabilidade ou e comportamento padrao do Supabase?" Na duvida, classifique como 🟡 e pergunte.

---

## Nivel 1 — Analise API-Only

### Step 1.1: Reconhecimento

1. Acesse a URL da aplicacao via `WebFetch` ou browser
2. Extraia do JavaScript publico:
   - **Supabase URL** (formato: `https://{ref}.supabase.co`)
   - **Anon key** (JWT no codigo)
3. Decodifique o JWT para confirmar o project ref:
   ```bash
   echo "{jwt_payload}" | base64 -d 2>/dev/null | python3 -m json.tool
   ```
4. Identifique o metodo de autenticacao do frontend (OTP, email+password, OAuth, magic link)
5. **CRITICO — Verifique se a `service_role` key esta exposta no JS.** A service_role key bypassa TODO o RLS. Se estiver no frontend, e 🔴 CRITICO imediato — pare a analise e alerte o usuario. Busque por patterns como `service_role`, `serviceRole`, `SUPABASE_SERVICE_KEY` no JS.

### Step 1.2: Enumeracao de Tabelas

1. Consulte o schema OpenAPI:
   ```bash
   curl -s "https://{ref}.supabase.co/rest/v1/" \
     -H "apikey: {ANON_KEY}" | python3 -m json.tool | head -100
   ```
2. Extraia a lista de todas as tabelas/views exposta no schema
3. **Lembrete:** A exposicao do schema em si NAO e finding — e by design

### Step 1.3: Teste de Leitura Anonima (RLS Check)

Para cada tabela encontrada, teste leitura com anon key:

```bash
curl -s "https://{ref}.supabase.co/rest/v1/{TABELA}?select=*&limit=3" \
  -H "apikey: {ANON_KEY}" \
  -H "Authorization: Bearer {ANON_KEY}"
```

**Classificacao dos resultados:**
| Resultado | Classificacao |
|-----------|---------------|
| HTTP 200 + dados sensiveis retornados (PII, emails, telefones, deals) | 🔴 Confirmado — RLS ausente, dados expostos |
| HTTP 200 + dados nao-sensiveis (config, enums, status) | 🟡 Avaliar se deveria ser publico |
| HTTP 200 + array vazio `[]` | ✅ Provavel RLS funcionando (view vazia ou sem dados) |
| HTTP 401/403 | ✅ Acesso negado corretamente |

**IMPORTANTE:** Para tabelas que retornam dados, colete APENAS 1-3 registros como amostra de evidencia. NAO faca extracao em massa.

**EVIDENCIAS VISUAIS PARA PUBLICO NAO-TECNICO:** A maioria dos usuarios deste workflow NAO e tecnica. Para cada finding, mostre evidencias concretas que qualquer pessoa entenda o risco:
- **Dados expostos?** Mostre exemplos reais (parcialmente redactados): `"email": "jo***@empresa.com", "telefone": "55119****5432"` — o usuario precisa VER que os dados estao acessiveis
- **Escrita anonima?** Mostre o antes/depois: "Qualquer pessoa na internet pode mudar o status de 'operational' para 'degraded' — sem login"
- **Quantifique o impacto:** "83.606 registros de leads com nome, email e telefone acessiveis" e muito mais claro que "tabela sem RLS"
- **Use linguagem direta:** "Alguem sem login consegue ver os dados de todos os seus clientes" > "A tabela nao tem RLS habilitado"
- Redacte parcialmente dados pessoais reais (mostre estrutura + primeiros/ultimos caracteres), mas mostre o SUFICIENTE para que o risco fique obvio

### Step 1.4: Teste de Escrita Anonima

Para tabelas que retornaram dados ou parecem criticas, teste INSERT:

```bash
curl -s "https://{ref}.supabase.co/rest/v1/{TABELA}" -X POST \
  -H "apikey: {ANON_KEY}" \
  -H "Authorization: Bearer {ANON_KEY}" \
  -H "Content-Type: application/json" \
  -H "Prefer: return=representation" \
  -d '{"campo_teste": "PENTEST_PROBE_DELETE_ME"}'
```

Se INSERT funcionar, teste UPDATE e DELETE tambem. **Limpe todos os dados de teste apos cada verificacao.**

### Step 1.5: Teste de Signup

Teste se o endpoint de signup esta aberto:

```bash
curl -s "https://{ref}.supabase.co/auth/v1/signup" -X POST \
  -H "apikey: {ANON_KEY}" \
  -H "Content-Type: application/json" \
  -d '{"email": "pentest-probe@test.invalid", "password": "TestPassword123!"}' | python3 -m json.tool
```

Verifique:
- Signup retorna token? (`access_token` presente = auto-confirm habilitado)
- `email_confirmed_at` preenchido sem verificacao de email?
- Rate limit existe? (tente 3 signups em sequencia rapida)

**Se auto-confirm estiver habilitado:** Classifique como 🟡 — pode ser intencional, pergunte ao usuario.

### Step 1.6: Teste Autenticado (se signup funcionou)

Com o token obtido via signup, repita os testes de leitura em todas as tabelas:

```bash
curl -s "https://{ref}.supabase.co/rest/v1/{TABELA}?select=*&limit=3" \
  -H "apikey: {ANON_KEY}" \
  -H "Authorization: Bearer {TOKEN}"
```

Compare resultados anonimo vs autenticado para cada tabela — isso revela se RLS depende de autenticacao.

### Step 1.7: Teste de Storage Buckets

Supabase Storage pode ter buckets publicos com arquivos sensiveis. Teste:

```bash
# Listar buckets
curl -s "https://{ref}.supabase.co/storage/v1/bucket" \
  -H "apikey: {ANON_KEY}" \
  -H "Authorization: Bearer {ANON_KEY}"

# Se encontrar buckets, listar arquivos
curl -s "https://{ref}.supabase.co/storage/v1/object/list/{BUCKET_NAME}" \
  -H "apikey: {ANON_KEY}" \
  -H "Authorization: Bearer {ANON_KEY}" \
  -H "Content-Type: application/json" \
  -d '{"prefix": "", "limit": 10}'
```

**Classificacao:**
- Bucket publico com documentos sensiveis (contratos, IDs, dados pessoais) = 🔴
- Bucket publico com assets genericos (logos, imagens de UI) = ✅ Normal
- Buckets nao-listaveis = ✅ Protegido

### Step 1.8: Teste de Cross-Tenant

Se existirem multiplos workspaces/tenants, tente acessar dados de outro tenant:

```bash
# Tente filtrar por UUID de workspace que nao e seu
curl -s "https://{ref}.supabase.co/rest/v1/{TABELA}?workspace_id=eq.{UUID_OUTRO}" \
  -H "apikey: {ANON_KEY}" \
  -H "Authorization: Bearer {TOKEN}"
```

Se retornar dados de outro usuario/tenant = 🔴 Confirmado.
Se retornar vazio ou erro = ✅ Protegido.

### Step 1.9: Relatorio Intermediario

Apresente os findings ao usuario ANTES de prosseguir:

```
## Resultados Nivel 1 — {app_url}

### 🔴 Confirmados (X findings)
[lista com evidencia]

### 🟡 Precisa Clarificacao (Y items)
[lista com contexto — perguntar ao usuario]

### ✅ Protegido (Z items)
[resumo]
```

Se o usuario escolheu Nivel 1, gere o relatorio final (ver Step 3).
Se o usuario escolheu Nivel 2, discuta os findings 🟡 e prossiga para o Nivel 2.

---

## Nivel 2 — Analise Completa (API + Browser)

**Pre-requisito:** Nivel 1 ja executado e findings intermediarios discutidos com usuario.

### Step 2.1: Criacao de Conta Real

1. Pergunte ao usuario qual email usar para criar a conta de teste:
   - Email pessoal que o usuario tem acesso (para receber OTP/verificacao)
   - Ou criar email temporario (Proton Mail, etc.) — avisar que demora mais
2. Use o browser interno para acessar a URL da aplicacao
3. Siga o fluxo de signup REAL do frontend (nao use API direta)
4. Complete a verificacao de email (OTP, magic link, etc.)
5. Salve o token de autenticacao para os testes subsequentes

**Dica:** Se a aplicacao usar OTP e voce precisar alternar entre abas, pode ser mais eficiente verificar o OTP via API do Supabase (`/auth/v1/verify`) em vez de navegar no browser:
```bash
curl -s "https://{ref}.supabase.co/auth/v1/verify" -X POST \
  -H "apikey: {ANON_KEY}" \
  -H "Content-Type: application/json" \
  -d '{"type": "email", "token": "{OTP_CODE}", "email": "{EMAIL}"}'
```

### Step 2.2: Navegacao e Uso Real

Use o browser para navegar pela aplicacao como usuario normal:
- Crie registros (tarefas, projetos, items — o que a app oferecer)
- Explore todas as telas disponiveis
- Observe quais dados sao carregados e quais APIs sao chamadas

### Step 2.3: Testes Autenticados Profundos

Com o token de usuario real, execute:

1. **Re-teste de todas as tabelas** — comparar resultados anonimo vs autenticado vs real-user
2. **Privilege escalation:**
   ```bash
   # Tentar auto-atribuir admin
   curl -s "https://{ref}.supabase.co/rest/v1/user_roles" -X POST \
     -H "Authorization: Bearer {TOKEN}" ...
   ```
3. **Cross-tenant access:** Tentar acessar workspaces/dados de outros usuarios por UUID
4. **Edge functions:** Testar endpoints de funcoes serverless com e sem auth
5. **AI billing attack (se aplicavel):** Se a app tiver funcoes que consomem APIs pagas (OpenAI, etc.), testar se consegue invocar com credenciais proprias em massa

### Step 2.4: Validacao de Findings do Nivel 1

Revisite TODOS os findings 🔴 e 🟡 do Nivel 1 usando a conta real:
- O que era 🔴 ainda e reproduzivel como usuario real?
- O que era 🟡 agora pode ser classificado com mais certeza?
- Algum finding foi um falso positivo?

---

## Step 3: Relatorio Final

Gere o relatorio completo e salve como arquivo markdown no working directory do usuario.

### Estrutura do Relatorio

```markdown
# Relatorio de Seguranca — {app_url}
**Data:** {data}
**Tipo:** Analise de seguranca automatizada — Supabase misconfiguration
**Supabase Project:** `{ref}`
**Nivel:** {1 ou 2}

> **Aviso:** Esta e uma analise de seguranca automatizada conduzida por IA. Cobre os vetores de ataque mais comuns em aplicacoes Supabase, mas pode deixar passar vulnerabilidades que um pentest manual profissional identificaria. Para aplicacoes em producao com dados sensiveis, recomendamos envolver um time profissional de ciberseguranca para uma auditoria completa.

---

## Metodologia
{Descrever fases executadas, ferramentas usadas, conta de teste}

---

## Score de Seguranca

{Atribua um score visual baseado nos findings:}

- **🟢 SEGURO** — Nenhum finding 🔴. RLS funciona, dados protegidos. Pode ter 🟡 para revisar.
- **🟡 ATENCAO** — 1-2 findings 🔴 de baixo impacto (ex: tabela de config sem RLS, sem dados sensiveis). Corrigir em breve.
- **🔴 CRITICO** — Dados sensiveis expostos (PII, financeiros), ou multiplos findings 🔴. Corrigir IMEDIATAMENTE.

{Inclua uma frase resumo para nao-tecnicos. Ex: "Sua aplicacao tem 1 problema serio: qualquer pessoa na internet pode ver os dados dos seus clientes. Recomendamos corrigir hoje."}

---

## Sumario Executivo

| # | Finding | Classificacao | Status |
|---|---------|---------------|--------|
{tabela resumo}

---

## {Cada finding detalhado com evidencia, impacto e fix recomendado}

---

## Itens que NAO sao vulnerabilidades (by design do Supabase)
{Listar explicitamente para evitar confusao}

---

## Artefatos de Teste (para cleanup)
{Contas criadas, dados inseridos, o que precisa ser deletado}
```

### Regras do Relatorio

1. **Cada finding 🔴 deve ter:** evidencia reproduzivel (curl command), impacto descrito em linguagem acessivel, amostras de dados reais (parcialmente redactados), quantificacao do impacto (ex: "X registros expostos"), e fix SQL recomendado
2. **Cada finding 🟡 deve ter:** o que foi encontrado, por que pode ser by design, por que pode ser problema, e as perguntas para o usuario
3. **Nunca inflacionar findings.** Se so encontrou 1 problema real, o relatorio tem 1 finding. Nao adicione "potenciais" ou "teoricos" como findings.
4. **Incluir secao de "NAO e vulnerabilidade"** — educar o usuario sobre comportamentos padrao do Supabase
5. **Incluir artefatos de teste** — toda conta, dado ou registro criado durante o teste deve ser listado para cleanup posterior
6. **Mostrar comparacao anonimo vs autenticado** — quando relevante, mostrar a diferenca de acesso
7. **Evidencias visiveis e concretas.** Para cada finding, inclua um bloco "O que isso significa na pratica" com linguagem nao-tecnica. Ex: "Qualquer pessoa com acesso a internet pode ver os nomes, emails e telefones de 83 mil leads — sem precisar de login ou senha."
8. **Incluir disclaimer de analise automatizada** — o bloco de aviso deve aparecer logo apos o cabecalho do relatorio

### Nome do Arquivo

`projects/active/security-report-{dominio}-{data}.md`

Exemplo: `projects/active/security-report-app-exemplo-com-2026-04-15.md`

---

## Checklist de Qualidade (antes de entregar)

- [ ] Todos os findings 🔴 tem evidencia reproduzivel?
- [ ] Nenhuma tabela vazia foi marcada como vulnerabilidade?
- [ ] Schema OpenAPI NAO esta listado como finding?
- [ ] Anon key NAO esta listada como finding?
- [ ] Findings 🟡 tem perguntas claras para o usuario?
- [ ] Secao "NAO e vulnerabilidade" esta presente?
- [ ] Artefatos de teste estao listados para cleanup?
- [ ] Dados de teste foram limpos apos cada verificacao?
- [ ] O relatorio usa classificacao de 3 niveis (🔴/🟡/✅) consistentemente?
- [ ] Disclaimer de analise automatizada esta presente no inicio do relatorio?
- [ ] Cada finding 🔴 tem amostras de dados reais (parcialmente redactados) como evidencia?
- [ ] Cada finding 🔴 tem um bloco "O que isso significa na pratica" em linguagem acessivel?
- [ ] Impacto esta quantificado (numero de registros, tipo de dados expostos)?

---

## Erros Comuns a Evitar

1. **Nao confunda tabela vazia com dado exposto.** HTTP 200 + `[]` com anon key pode significar RLS funcionando (view sem dados para anon role).
2. **Nao faca extracao em massa.** Limite a 1-3 registros por tabela para evidencia.
3. **Nao assuma que auto-confirm e bug.** Pergunte ao usuario — pode ser intencional.
4. **Nao ignore rate limits.** Teste de forma controlada, nao dispare centenas de requests.
5. **Limpe apos testar.** DELETE os registros de teste, documente as contas criadas.
6. **Nao misture severidades.** DoS visual (api_status) != vazamento de PII de 83k leads. Calibre.