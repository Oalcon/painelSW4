# G4 OS Design — Visual Reference Gallery

> Use this file when the user has not provided a design reference, style preference, or brand context.
> Every file listed here exists on disk in this `examples/` folder. Read the images, show them as options, or use them as design DNA for the task at hand.

---

## How to Use This File

1. **User provides no style reference** → Jump to the matching output type below, pick the style closest to their content, show them the image, get a yes/no.
2. **User asks "what styles are available?"** → Show the three style families (Pentagram / Build / Takram) and let them choose.
3. **User has a brand context** → Use these as structural references only (layout rhythm, information hierarchy), replace colors/fonts with the brand spec.
4. **User wants to see demos in motion** → Point to the GIF files in this folder.

---

## The Three Core Style Families

These are the three design systems used across all showcase outputs. Each is a coherent, production-tested approach. Choose one per deliverable — don't blend.

---

### Style A — Pentagram (Information Architecture)
**DNA:** Rational, editorial, grid-locked. Monumental typography + high-contrast black/red + hairline rules. Feels like a serious design studio or financial publication.

- Background: white `#FFFFFF` or near-white
- Primary accent: vivid red `#E8232A` (or brand equivalent)
- Typography: display = bold grotesque (Neue Haas Grotesk, Aktiv Grotesk) at very large sizes (80–200px); body = geometric sans at small, precise sizes
- Grid: strict columns, mathematical spacing, text aligned to invisible structure
- Signature: large ghosted number or letter as background element; black footer bar with small-caps labels; kicker in ALL CAPS tracked out
- Mood: authoritative, professional, data-forward

**Reference images in this folder:**
- `showcases/cover-pentagram.png` — article cover with "Agent / **Parallel**" headline, red accent, ghosted "8" background
- `showcases/infographic-pentagram.png` — vertical infographic with 93KB→22KB data story, section numbers, horizontal rules
- `showcases/ppt-pentagram.png` — benchmark data dashboard with large red numerals, 4-column bar chart layout

---

### Style B — Build (Warm Minimalism)
**DNA:** Quiet luxury. Warm beige backgrounds, text-first composition, generous whitespace, thin lines as the only ornament. Feels like a high-end product studio or editorial magazine.

- Background: warm off-white `#F5F0E8` to `#FAFAF7`
- Accent: terracotta/rust `#D97757` or amber `#C8935A` — used sparingly (1–2 elements max)
- Typography: display = elegant sans or serif, normal weight (300–400), large but not aggressive; body = same font, small, tracked
- Grid: centered or left-justified, extreme whitespace as design element
- Signature: thin horizontal rule as divider; small rotated labels on margin edges; numbers as typographic accent not data
- Mood: calm, refined, trustworthy, premium

**Reference images in this folder:**
- `showcases/cover-build.png` — "Agent / Parallel Workflow" cover, centered serif headline, warm white, vertical bar chart as abstract element
- `showcases/infographic-build.png` — tall infographic with large light-weight numbers, dotted flow diagram, warm background
- `showcases/saas-build.png` — SaaS landing page "Turn data into *decisions*", mixed serif/italic headline, real dashboard mockup on right

---

### Style C — Takram (Eastern Minimalism + Systems)
**DNA:** Poetic precision. Warm neutral palette, Chinese-English bilingual typography when appropriate, diagrammatic system maps, restrained color with purpose. Feels like a Tokyo or Singapore design consultancy.

- Background: warm sand `#F0EDE6` or cream `#EDE8DF`
- Accent: muted sage/olive `#8A9E7A` or dusty rose — minimal, semantic only
- Typography: bilingual pairing works beautifully — Chinese serif (Noto Serif SC) + Latin sans (Inter Light), both at medium weights
- Grid: asymmetric with clear structure; system diagrams use rounded rectangles with connector lines
- Signature: small figure labels ("Fig. 01"), version stamps, delicate node-and-edge diagrams; rotated sidebar labels
- Mood: contemplative, systematic, globally sophisticated

**Reference images in this folder:**
- `showcases/cover-takram.png` — "协作智能体 / Parallel Workflow" cover, agent network diagram on right, warm beige, sage accent
- `showcases/homepage-takram.png` — personal homepage "Building tools at the intersection of AI and creativity", serif headline, circular placeholder avatar, generous whitespace

---

## Output Type Reference

### Covers / Article Headers

| Style | File | What it shows |
|---|---|---|
| Pentagram | `showcases/cover-pentagram.png` | Bold grotesque headline, red accent, ghosted background numeral, black footer stats bar |
| Build | `showcases/cover-build.png` | Quiet centered composition, large light-weight serif, warm white, abstract vertical bar element |
| Takram | `showcases/cover-takram.png` | Bilingual headline, agent network diagram, warm sand background, sage accent |

**When to use which:**
- Scientific / technical / data-heavy content → Pentagram
- Personal brand / product launch / creative work → Build
- System architecture / AI / multi-component topics → Takram

---

### Infographics (Vertical, Print-Quality)

| Style | File | What it shows |
|---|---|---|
| Pentagram | `showcases/infographic-pentagram.png` | High-contrast data story with numbered sections, bar charts, 2×2 grid layout, bold red stats |
| Build | `showcases/infographic-build.png` | Airy vertical layout, large light numerals, flow diagram, warm palette |
| Takram | `showcases/infographic-takram.png` | System diagram with organic connectors, bilingual labels, muted palette |

---

### Slide Decks / PPT Data Pages

| Style | File | What it shows |
|---|---|---|
| Pentagram | `showcases/ppt-pentagram.png` | Benchmark report style: large model name in top left, 4-column comparison layout, vivid red bars |
| Build | `showcases/ppt-build.png` | Single-data-point focus, warm background, thin rule separators, editorial rhythm |
| Takram | `showcases/ppt-takram.png` | Structured taxonomy grid, warm background, muted accents |

---

### Website — Homepage / Portfolio

| Style | File | What it shows |
|---|---|---|
| Pentagram | `showcases/homepage-pentagram.png` | High-contrast editorial hero, grid-based |
| Build | `showcases/homepage-build.png` | Clean product landing page layout |
| Takram | `showcases/homepage-takram.png` | Personal portfolio, serif headline mixing italic+bold, warm beige, stat counters, bio card |

---

### Website — SaaS Landing Page

| Style | File | What it shows |
|---|---|---|
| Pentagram | `showcases/saas-pentagram.png` | Enterprise / B2B feel, structured comparison |
| Build | `showcases/saas-build.png` | "Meridian" SaaS — hero + dashboard split, serif/italic headline mix, amber accent, social proof logos |
| Takram | `showcases/saas-takram.png` | Softer SaaS with system-diagram product explanation |

---

### Website — AI Navigation / Tool Landing

| Style | File | What it shows |
|---|---|---|
| Pentagram | `showcases/ainav-pentagram.png` | Card grid with strong typographic hierarchy |
| Build | `showcases/ainav-build.png` | Warm, editorial AI tool directory |
| Takram | `showcases/ainav-takram.png` | Node-graph inspired layout |

---

### Website — Developer Documentation

| Style | File | What it shows |
|---|---|---|
| Pentagram | `showcases/devdocs-pentagram.png` | Terminal-inspired, dense information, precise hierarchy |
| Build | `showcases/devdocs-build.png` | Clean docs layout, readable, warm |
| Takram | `showcases/devdocs-takram.png` | Structured reference with system-diagram annotations |

---

## Capability Demos

Two formats available for each demo — use the HTML for the real interactive experience, GIF for a quick preview.

### Interactive HTML Demos (`demos/` folder)

These are the actual deliverable files — fully self-contained, open in any browser by double-clicking. No server needed.

| File | Capability | What it demonstrates |
|---|---|---|
| `demos/c1-ios-prototype-en.html` | iOS App prototype | Multi-screen Pomodoro timer: wireframe → home → timer (animated ring) → stats (bar chart) → settings. iPhone 15 Pro frame, terracotta accent, dark mode |
| `demos/c2-slides-pptx-en.html` | HTML slides → editable PPTX | Browser window with HTML deck → split-screen with PowerPoint editor → `html2pptx.js` connector → live text editing |
| `demos/c3-motion-design-en.html` | Stage+Sprite animation engine | Timeline playhead over API capsules (useTime, Easing, interpolate, useSprite) + 4 live visualizations: clock, morphing shape, bezier curves, sprite grid cascade |
| `demos/c4-tweaks-en.html` | Real-time design Tweaks | 3D card in perspective + 3 sliders → palette (warm #F6EFE6 → cool #0E1620), typography (serif → sans), density (sparse → dense) |
| `demos/c5-infographic-en.html` | JSON → print-quality infographic | Syntax-highlighted JSON → animated pipe → infographic with masthead, large serif numbers, bar charts |
| `demos/c6-expert-review-en.html` | 5-dimension expert critique | Subject frame with "live" indicator → 5 critique cards illuminate one by one → scoring reveal |
| `demos/w1-brand-protocol-en.html` | Core Asset Protocol | 5-step chain: Ask → Identify → Create → Refine → Deliver, each card illuminates with glowing border, connecting line draws |
| `demos/w2-junior-designer-en.html` | Junior Designer mode | Split before/after: rough first pass (dark red) vs polished final — "show early, then refine" |
| `demos/w3-fallback-advisor-en.html` | Design Direction Advisor | Three design direction cards in parallel, each with distinct visual personality |
| `demos/hero-animation-v10-en.html` | Hero brand animation | 25s cinematic: terminal → 4 directions → gallery ripple → 4 focus points → brand reveal |

### Animated GIF Previews (`../` folder — same examples/ directory)

Quick-view previews of the same demos, useful for README or marketplace listing thumbnail.

| File | Capability |
|---|---|
| `c1-ios-prototype.gif` | iOS App prototype |
| `c2-slides-pptx.gif` | HTML slides → editable PPTX |
| `c3-motion-design.gif` | Stage+Sprite animation engine |
| `c4-tweaks.gif` | Real-time design Tweaks |
| `c5-infographic.gif` | JSON → print-quality infographic |
| `c6-expert-review.gif` | 5-dimension expert critique |
| `w1-brand-protocol.gif` | Core Asset Protocol |
| `w2-junior-designer.gif` | Junior Designer mode |
| `w3-fallback-advisor.gif` | Design Direction Advisor |

---

## Shared Design System (All Outputs)

These values appear consistently across all demos and can serve as default starting points when the user provides zero brand context:

### Color palette
```css
/* Backgrounds */
--bg-dark: #000000;
--bg-warm: #F5F4F0;       /* default light surface */
--bg-beige: #F5F0E8;      /* warm alternative */

/* Primary accent (pick one per project) */
--accent-terracotta: #D97757;    /* warm, human, creative */
--accent-red: #E8232A;           /* editorial, authoritative */
--accent-sage: #8A9E7A;          /* calm, systematic */

/* Typography */
--ink-primary: #0A0A0A;
--ink-secondary: #6B6B6B;
--ink-tertiary: #9E9E9E;
```

### Typography stack
```css
/* Display (headlines) */
font-family: 'Source Serif 4', 'Noto Serif SC', Georgia, serif;  /* editorial/warm */
font-family: 'Neue Haas Grotesk', 'Inter', system-ui, sans-serif; /* editorial/bold */

/* Body */
font-family: -apple-system, 'Inter', system-ui, sans-serif;

/* Monospace (code/terminal) */
font-family: 'JetBrains Mono', 'SF Mono', monospace;
```

### Spacing rhythm
- Card padding: `24–32px`
- Section gap: `48–80px`
- Max content width: `1200px` (web), `960×540pt` (slides)
- Font size scale: display `80–160px`, H2 `36–56px`, H3 `24–32px`, body `16–20px`, label/kicker `11–13px` uppercase tracked

### Animation signature
- Primary easing: `cubic-bezier(0.16, 1, 0.3, 1)` (expoOut — fast start, soft brake)
- Stagger between elements: `60–100ms`
- Reveal duration: `400–600ms`
- Brand finale: beige panel slides up from bottom to cover full frame — "Created by G4 OS Design" watermark bottom-right

---

## Quick Decision Guide

```
User has no style preference and task is...
│
├─ Data-heavy, numbers, benchmarks, reports → PENTAGRAM
│    Black/white/red · bold grotesque · strict grid
│
├─ Product launch, portfolio, SaaS, creative → BUILD
│    Warm white · terracotta accent · generous whitespace
│
├─ AI system, architecture, technical concept → TAKRAM
│    Sand background · diagrammatic · bilingual-friendly
│
└─ User wants to see all 3 → Show cover-*.png side by side
   using design_canvas.jsx
```
