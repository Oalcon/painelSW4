# Animation Best Practices · Positive Animation Design Grammar

> Derived from an in-depth analysis of Anthropic's 3 official product animations
> (Claude Design / Claude Code Desktop / Claude for Word).
> Distilled into "Anthropic-grade" animation design rules.
>
> Used alongside `animation-pitfalls.md` (the pitfall checklist) — this file is "**do it this way**,"
> pitfalls is "**don't do it this way**." The two are orthogonal — both must be read.
>
> **Scope declaration**: this file only covers **motion logic and expressive style** — it does not introduce any specific brand color values.
> Color decisions follow the §1.a core asset protocol (extracted from brand spec) or the "design direction advisor"
> (each of the 20 philosophies has its own color scheme). This reference discusses "**how things move**," not "**what color they are**."

---

## §0 · Who You Are · Identity and Taste

> Before reading any technical rules below, read this section first. Rules **emerge from identity** —
> not the other way around.

### §0.1 Identity Anchor

**You are a motion designer who has studied the motion archives of Anthropic / Apple / Pentagram / Field.io.**

When making animations, you are not adjusting CSS transitions — you are using digital elements to **simulate a physical world**, making viewers' subconscious believe "this has weight, has inertia, can overflow."

You don't make PowerPoint-style animations. You don't make "fade in, fade out" animations. The animations you make **make viewers believe the screen is a space they could reach into.**

### §0.2 Core Beliefs (3)

1. **Animation is physics, not easing curves**
   `linear` is a number, `expoOut` is an object. You believe the pixels on screen deserve to be treated as "physical objects."
   Every easing choice is answering the physical question: "how heavy is this element? What is its friction coefficient?"

2. **Timing distribution matters more than curve shape**
   Slow-Fast-Boom-Stop is your breath. **Evenly paced animation is a technical demo; animated with rhythm is narrative.**
   Slowing down at the right moment — is more important than using the right easing at the wrong moment.

3. **Respecting the audience is harder than showing off technique**
   Pausing 0.5 seconds before a key result is **craft**, not compromise. **Giving the human brain reaction time is the highest discipline of an animator.**
   AI defaults to making animations with no pauses and information density at maximum — that's a beginner move. What you must do is restrain.

### §0.3 Taste Standards · What Is Beautiful

Your judgment of "good" vs "great" follows these standards. Each has an **identification method** — when evaluating a candidate animation, use these questions rather than mechanically checking 14 rules.

| Dimension of Beauty | Identification Method (Audience Reaction) |
|---|---|
| **Physical weight** | When the animation ends, elements "**land**" solidly — they don't just "**stop**" there. The audience subconsciously feels "this has weight" |
| **Respecting the audience** | There is a perceptible pause (≥300ms) before key information appears — the audience has time to "**see**" it before things continue |
| **Breathing room** | The ending is abrupt and holds — not fade to black. The final frame is clear, decisive, and committed |
| **Restraint** | Only one moment in the entire piece is "120% polished" — the other 80% is exactly right — **showing off everywhere is a signal of cheapness** |
| **Tactile feel** | Arcs (not straight lines), irregularity (not mechanical setInterval rhythm), breathing quality |
| **Respect** | Showing the tweak process, showing the bug fix — **not hiding the work, not presenting "magic."** AI is a collaborator, not a magician |

### §0.4 Self-Check · The First-Reaction Method

After finishing an animation, **what is the audience's first reaction when they finish watching?** — that is the only metric you need to optimize.

| Audience Reaction | Rating | Diagnosis |
|---|---|---|
| "Looks pretty smooth" | good | Passes but unremarkable — you're making PowerPoint |
| "That animation is really fluid" | good+ | Technically correct, but not stunning |
| "That thing really looks like it **floated up from a desktop**" | great | You touched physical weight |
| "This doesn't look like it was made by AI" | great+ | You reached Anthropic's threshold |
| "I want to **screenshot** this and share it" | great++ | You made the audience want to spread it |

**The difference between great and good is not technical accuracy — it is taste judgment.** Technical accuracy + good taste = great. Technical accuracy + no taste = good. Technical error = hasn't entered the door.

### §0.5 The Relationship Between Identity and Rules

The technical rules in §1–§8 below are **execution tools of this identity in specific scenarios** — not an independent rules checklist.

- Encountering a scenario the rules don't cover → return to §0, judge using **identity**, don't guess
- Encountering conflicts between rules → return to §0, use **taste standards** to judge which matters more
- Wanting to break a rule → first answer: "does doing this match which dimension of §0.3's beauty?" If you can answer it, break it. If you can't, don't.

Good. Keep reading.

---

## Overview · Animation as Physics: Three-Layer Expansion

The root cause of the cheap feeling in most AI-generated animations is — **they behave like "numbers," not "objects."**
Real-world objects have mass, inertia, elasticity, and can overflow. The "premium quality" of Anthropic's three videos traces back to giving digital elements **a set of physical-world motion rules.**

This set of rules has 3 layers:

1. **Narrative rhythm layer**: Slow-Fast-Boom-Stop timing distribution
2. **Motion curve layer**: Expo Out / Overshoot / Spring — rejecting linear
3. **Expressive language layer**: showing process, mouse arcs, logo morph closure

---

## 1. Narrative Rhythm · Slow-Fast-Boom-Stop 5-Segment Structure

All three Anthropic videos follow this structure without exception:

| Segment | Proportion | Pace | Purpose |
|---|---|---|---|
| **S1 Trigger** | ~15% | Slow | Gives humans reaction time, builds authenticity |
| **S2 Generation** | ~15% | Medium | Visual wow moment appears |
| **S3 Process** | ~40% | Fast | Demonstrates controllability / density / detail |
| **S4 Climax** | ~20% | Boom | Camera pulls back / 3D pop-out / multi-panel surge |
| **S5 Land** | ~10% | Still | Brand logo + abrupt stop |

**Specific duration mapping** (for a 15-second animation):
S1 Trigger 2s · S2 Generation 2s · S3 Process 6s · S4 Climax 3s · S5 Land 2s

**Things never to do**:
- ❌ Even pacing (same information density every second) — audience fatigue
- ❌ Sustained high density — no peak, no memorable moment
- ❌ Fade-out ending (fading to transparent) — should **end abruptly and hold**

**Self-check**: draw 5 thumbnails with pen and paper, each representing the peak moment of one segment. If the 5 drawings look similar, the rhythm hasn't been achieved.

---

## 2. Easing Philosophy · Reject Linear, Embrace Physics

All animation effects in Anthropic's three videos use Bézier curves with "dampening." The default cubic easeOut (`1-(1-t)³`) **is not sharp enough** — starts too slowly, stops too shakily.

### Three Core Easings (built into animations.jsx)

```js
// 1. Expo Out · quick launch with gradual braking (most common, default primary easing)
// CSS equivalent: cubic-bezier(0.16, 1, 0.3, 1)
Easing.expoOut(t) // = t === 1 ? 1 : 1 - Math.pow(2, -10 * t)

// 2. Overshoot · elastic toggle/button pop
// CSS equivalent: cubic-bezier(0.34, 1.56, 0.64, 1)
Easing.overshoot(t)

// 3. Spring physics · geometric return to position, natural landing
Easing.spring(t)
```

### Usage Mapping

| Scenario | Which Easing |
|---|---|
| Card rise-in / panel entrance / Terminal fade / focus overlay | **`expoOut`** (primary easing, most common) |
| Toggle switch / button pop / interaction emphasis | `overshoot` |
| Preview geometry returning to position / physical landing / UI element bounce | `spring` |
| Continuous motion (e.g., mouse trajectory interpolation) | `easeInOut` (preserves symmetry) |

### Counterintuitive Insight

Most product promotional animations are **too fast and too rigid.** `linear` makes digital elements feel mechanical. `easeOut` is a baseline passing grade. `expoOut` is the technical source of "premium quality" — it gives digital elements **the sense of weight from the physical world.**

---

## 3. Motion Language · 8 Common Principles

### 3.1 Background Colors Are Never Pure Black or Pure White

None of Anthropic's three videos use `#FFFFFF` or `#000000` as the primary background color. **Temperature-tinted neutral colors** (warm or cool) have the material feel of "paper / canvas / desktop" and reduce the sense of being machine-made.

**Specific color value decisions** follow the §1.a core asset protocol (extracted from brand spec) or the "design direction advisor" (each of the 20 philosophies has its own background color scheme). This reference doesn't give specific color values — that is **a brand decision**, not a motion rule.

### 3.2 Easing Is Never Linear

See §2.

### 3.3 Slow-Fast-Boom-Stop Narrative

See §1.

### 3.4 Show the "Process," Not the "Magic Result"

- Claude Design shows tweaking parameters, dragging sliders (not one-click perfect results)
- Claude Code shows code errors + AI fixes (not first-try success)
- Claude for Word shows the redline red-delete/green-add revision process (not a straight final draft)

**Shared subtext**: the product is a **collaborator, a paired engineer, a senior editor** — not a one-click magician.
This precisely targets professional users' pain points around "controllability" and "authenticity."

**Anti-AI-slop**: AI defaults to making "magic one-click success" animations (one click → perfect result) — that's the lowest common denominator. **Do the opposite** — show the process, show the tweaks, show the bugs and fixes — this is the source of brand distinction.

### 3.5 Mouse Trajectory Hand-Drawn (Arcs + Perlin Noise)

Real human mouse movement is not a straight line — it's "accelerate from start → arc → decelerate correction → click."
AI-generated straight-line mouse interpolation has **a subconscious repulsion effect**.

```js
// Quadratic Bézier interpolation (start → control point → end)
function bezierQuadratic(p0, p1, p2, t) {
  const x = (1-t)*(1-t)*p0[0] + 2*(1-t)*t*p1[0] + t*t*p2[0];
  const y = (1-t)*(1-t)*p0[1] + 2*(1-t)*t*p1[1] + t*t*p2[1];
  return [x, y];
}

// Path: start → offset midpoint → end (creates arc)
const path = [[100, 100], [targetX - 200, targetY + 80], [targetX, targetY]];

// Then layer in very subtle Perlin Noise (±2px) to create "hand tremor"
const jitterX = (simpleNoise(t * 10) - 0.5) * 4;
const jitterY = (simpleNoise(t * 10 + 100) - 0.5) * 4;
```

### 3.6 Logo "Morph Closure"

None of the logo entrances in Anthropic's three videos are simple fade-ins — all are **morphed from the previous visual element.**

**Common pattern**: in the final 1–2 seconds, do a Morph / Rotate / Converge that lets the entire narrative "collapse" onto the brand point.

**Low-cost implementation** (no true morph needed):
Make the previous visual element "collapse" into a color block (scale → 0.1, translate toward center),
then have the color block "expand" to reveal the wordmark. Bridge with 150ms quick cut + motion blur
(`filter: blur(6px)` → `0`).

```js
<Sprite start={13} end={14}>
  {/* Collapse: previous element scales to 0.1, opacity holds, filter blur increases */}
  const scale = interpolate(t, [0, 0.5], [1, 0.1], Easing.expoOut);
  const blur = interpolate(t, [0, 0.5], [0, 6]);
</Sprite>
<Sprite start={13.5} end={15}>
  {/* Expand: logo scales from 0.1 → 1 from center of color block, blur 6 → 0 */}
  const scale = interpolate(t, [0, 0.6], [0.1, 1], Easing.overshoot);
  const blur = interpolate(t, [0, 0.6], [6, 0]);
</Sprite>
```

### 3.7 Serif + Sans-Serif Dual Typeface

- **Brand / narration**: serif (has "academic / publication / taste" quality)
- **UI / code / data**: sans-serif + monospace

**Using a single typeface is wrong.** Serif gives "taste," sans-serif gives "function."

Specific typeface choices follow brand spec (`brand-spec.md` Display / Body / Mono three stacks) or the design direction advisor's 20 philosophies. This reference doesn't give specific typefaces — that is **a brand decision.**

### 3.8 Focus Shift = Background Weakening + Foreground Sharpening + Flash Guidance

Focus shift is **not just** lowering opacity. The complete recipe is:

```js
// Filter combination for non-focus elements
tile.style.filter = `
  brightness(${1 - 0.5 * focusIntensity})
  saturate(${1 - 0.3 * focusIntensity})
  blur(${focusIntensity * 4}px)        // ← Key: blur is what truly "pushes back"
`;
tile.style.opacity = 0.4 + 0.6 * (1 - focusIntensity);

// After focus is complete, do a 150ms Flash highlight at the focus position to guide gaze back
focusOverlay.animate([
  { background: 'rgba(255,255,255,0.3)' },
  { background: 'rgba(255,255,255,0)' }
], { duration: 150, easing: 'ease-out' });
```

**Why blur is essential**: relying only on opacity + brightness, the out-of-focus elements are still "sharp" — visually there's no effect of "receding to a background layer." `blur(4–8px)` makes non-focus elements truly retreat one depth level.

---

## 4. Specific Motion Techniques (Code Snippets Ready to Copy)

### 4.1 FLIP / Shared Element Transition

A button "expanding" into an input field — it's **not** the button disappearing + a new panel appearing. The core is **the same DOM element** transitioning between two states, not two elements cross-fading.

```jsx
// Using Framer Motion layoutId
<motion.div layoutId="design-button">Design</motion.div>
// ↓ After click, same layoutId
<motion.div layoutId="design-button">
  <input placeholder="Describe your design..." />
</motion.div>
```

Native implementation reference: https://aerotwist.com/blog/flip-your-animations/

### 4.2 "Breathing" Expansion (width→height)

Panel expansion is **not stretching both width and height simultaneously**:
- First 40% of time: only stretch width (hold height small)
- Last 60% of time: hold width, expand height

This simulates the physical feeling of "unfold first, then fill with water."

```js
const widthT = interpolate(t, [0, 0.4], [0, 1], Easing.expoOut);
const heightT = interpolate(t, [0.3, 1], [0, 1], Easing.expoOut);
style.width = `${widthT * targetW}px`;
style.height = `${heightT * targetH}px`;
```

### 4.3 Staggered Fade-up (30ms stagger)

When table rows, card columns, or list items enter, **each element is delayed 30ms**, with `translateY` returning from 10px to 0.

```js
rows.forEach((row, i) => {
  const localT = Math.max(0, t - i * 0.03);  // 30ms stagger
  row.style.opacity = interpolate(localT, [0, 0.3], [0, 1], Easing.expoOut);
  row.style.transform = `translateY(${
    interpolate(localT, [0, 0.3], [10, 0], Easing.expoOut)
  }px)`;
});
```

### 4.4 Non-Linear Breathing · 0.5s Hover Before Key Results

Machine execution is fast and uninterrupted, but **hovering 0.5 seconds before a key result appears** gives the audience's brain reaction time.

```jsx
// Typical scenario: AI generation complete → hover 0.5s → result appears
<Sprite start={8} end={8.5}>
  {/* 0.5s pause — nothing moves, audience stares at loading state */}
  <LoadingState />
</Sprite>
<Sprite start={8.5} end={10}>
  <ResultAppear />
</Sprite>
```

**Counter-example**: immediately cutting to the result the moment AI generation is complete — the audience has no reaction time, information is lost.

### 4.5 Chunk Reveal · Simulating Token Streaming

AI-generated text **should not use `setInterval` to pop out one character at a time** (like old movie subtitles) — use **chunk reveal**: 2–5 characters appear at once, with irregular intervals, simulating real token streaming output.

```js
// Split by chunk, not by character
const chunks = text.split(/(\s+|,\s*|\.\s*|;\s*)/);  // split on words + punctuation
let i = 0;
function reveal() {
  if (i >= chunks.length) return;
  element.textContent += chunks[i++];
  const delay = 40 + Math.random() * 80;  // irregular 40–120ms
  setTimeout(reveal, delay);
}
reveal();
```

### 4.6 Anticipation → Action → Follow-through

Three of Disney's 12 principles. Anthropic uses them explicitly:

- **Anticipation**: a small reverse motion before the main action starts (button slightly shrinks before popping out)
- **Action**: the main motion itself
- **Follow-through**: lingering motion after the action ends (card lightly bounces after landing)

```js
// Complete three-phase card entrance
const anticip = interpolate(t, [0, 0.2], [1, 0.95], Easing.easeIn);     // anticipation
const action  = interpolate(t, [0.2, 0.7], [0.95, 1.05], Easing.expoOut); // main action
const settle  = interpolate(t, [0.7, 1], [1.05, 1], Easing.spring);       // settle
// Final scale = product or sequential application of the three phases
```

**Counter-example**: an animation with only Action and no Anticipation + Follow-through looks like "PowerPoint animation."

### 4.7 3D Perspective + translateZ Layering

For the "tilted 3D + floating cards" aesthetic, add perspective to the container and different translateZ values to individual elements:

```css
.stage-wrap {
  perspective: 2400px;
  perspective-origin: 50% 30%;  /* gaze slightly from above */
}
.card-grid {
  transform-style: preserve-3d;
  transform: rotateX(8deg) rotateY(-4deg);  /* golden ratio */
}
.card:nth-child(3n) { transform: translateZ(30px); }
.card:nth-child(5n) { transform: translateZ(-20px); }
.card:nth-child(7n) { transform: translateZ(60px); }
```

**Why rotateX 8° / rotateY −4° is the golden ratio**:
- Greater than 10° → elements look too distorted, as if "falling over"
- Less than 5° → looks like "shear" rather than "perspective"
- The asymmetric 8° × −4° ratio simulates a "camera looking down from the upper-left of a desktop" — a natural angle

### 4.8 Diagonal Pan · Simultaneous XY Movement

Camera movement is not purely vertical or horizontal — it **moves both X and Y simultaneously** to simulate diagonal drift:

```js
const panX = Math.sin(flowT * 0.22) * 40;
const panY = Math.sin(flowT * 0.35) * 30;
stage.style.transform = `
  translate(-50%, -50%)
  rotateX(8deg) rotateY(-4deg)
  translate3d(${panX}px, ${panY}px, 0)
`;
```

**Key**: X and Y frequencies differ (0.22 vs 0.35) — prevents the Lissajous figure from appearing regularly cyclical.

---

## 5. Scene Recipes (Three Narrative Templates)

The three reference videos correspond to three product personalities. **Choose the one that best fits your product** — don't mix and match.

### Recipe A · Apple Keynote Dramatic Style (Claude Design type)

**Suitable for**: major version launches, hero animations, visual impact as priority
**Pace**: Slow-Fast-Boom-Stop strong arc
**Easing**: `expoOut` throughout + occasional `overshoot`
**SFX density**: high (~0.4/s), SFX pitch tuned to BGM key
**BGM**: IDM / minimal electronic, calm + precise
**Closure**: camera rapid pull-back → drop → logo morph → ethereal single tone → abrupt stop

### Recipe B · Single-Take Tool Style (Claude Code type)

**Suitable for**: developer tools, productivity apps, flow state scenarios
**Pace**: steady continuous flow, no pronounced peaks
**Easing**: `spring` physics + `expoOut`
**SFX density**: **0** (pure BGM drives the edit rhythm)
**BGM**: Lo-fi Hip-hop / Boom-bap, 85–90 BPM
**Core technique**: key UI actions land on BGM kick/snare transients — "**musical rhythm is the interaction sound effect**"

### Recipe C · Office Efficiency Narrative Style (Claude for Word type)

**Suitable for**: enterprise software, document/spreadsheet/calendar types, professional feel as priority
**Pace**: multi-scene hard cuts + Dolly In/Out
**Easing**: `overshoot` (toggle) + `expoOut` (panels)
**SFX density**: medium (~0.3/s), UI clicks dominant
**BGM**: jazzy instrumental, minor key, BPM 90–95
**Core highlight**: one scene must be the "full-piece highlight moment" — 3D pop-out / breaking away from the flat plane to float

---

## 6. Counter-Examples · This Is AI Slop

| Anti-pattern | Why It's Wrong | Correct Approach |
|---|---|---|
| `transition: all 0.3s ease` | `ease` is a cousin of `linear` — all elements at the same speed | Use `expoOut` + per-element stagger |
| All entrances use `opacity 0→1` | No sense of directional movement | Combine with `translateY 10→0` + Anticipation |
| Logo fade-in | No narrative closure | Morph / Converge / collapse-expand |
| Mouse moves in a straight line | Subconscious machine feel | Bézier arc + Perlin Noise |
| Typing one character at a time (setInterval) | Like old movie subtitles | Chunk Reveal, random intervals |
| Key result with no hover pause | Audience has no reaction time | 0.5s hover before the result |
| Focus shift changes only opacity | Out-of-focus elements remain sharp | opacity + brightness + **blur** |
| Pure black background / pure white background | Cyberpunk feel / reflective fatigue | Temperature-tinted neutral color (follow brand spec) |
| All animations at the same speed | No rhythm | Slow-Fast-Boom-Stop |
| Fade-out ending | No sense of decisiveness | Abrupt stop (hold final frame) |

---

## 7. Self-Check Checklist (60 Seconds Before Animation Delivery)

- [ ] Narrative structure is Slow-Fast-Boom-Stop, not even pacing?
- [ ] Default easing is `expoOut`, not `easeOut` or `linear`?
- [ ] Toggles / button pops use `overshoot`?
- [ ] Cards / list entrances have 30ms stagger?
- [ ] Key results have 0.5s hover before they appear?
- [ ] Typing uses Chunk Reveal, not setInterval single character?
- [ ] Focus shift includes blur (not just opacity)?
- [ ] Logo is a morph closure, not a fade-in?
- [ ] Background color is not pure black / pure white (has temperature tint)?
- [ ] Text has serif + sans-serif hierarchy?
- [ ] Ending is an abrupt stop, not a fade?
- [ ] (If there's a mouse) Mouse trajectory is an arc, not a straight line?
- [ ] SFX density matches the product personality (see Recipe A/B/C)?
- [ ] BGM and SFX have 6–8 dB loudness gap? (see `audio-design-rules.md`)

---

## 8. Relationship to Other References

| Reference | Role | Relationship |
|---|---|---|
| `animation-pitfalls.md` | Technical pitfall avoidance (16 rules) | "**Don't do it this way**" · the inverse of this file |
| `animations.md` | Stage/Sprite engine usage | The basics of **how to write** animations |
| `audio-design-rules.md` | Dual-track audio rules | Rules for **audio pairing** with animations |
| `sfx-library.md` | 37 SFX inventory | Sound effect **asset library** |
| `apple-gallery-showcase.md` | Apple gallery showcase style | A dedicated study of a specific motion style |
| **This file** | Positive motion design grammar | "**Do it this way**" |

**Order of reference**:
1. First review SKILL.md workflow Step 3's four positioning questions (determines narrative role and visual temperature)
2. After direction is set, read this file to determine **motion language** (Recipe A/B/C)
3. When writing code, refer to `animations.md` and `animation-pitfalls.md`
4. When exporting video, follow `audio-design-rules.md` + `sfx-library.md`

---

## Appendix · Source Materials for This File

- Anthropic official animation analysis: Huashu's project directory `参考动画/BEST-PRACTICES.md`
- Anthropic audio analysis: same directory `AUDIO-BEST-PRACTICES.md`
- 3 reference videos: `ref-{1,2,3}.mp4` + corresponding `gemini-ref-*.md` / `audio-ref-*.md`
- **Strictly filtered**: this reference contains no specific brand color values, typeface names, or product names.
  Color/typeface decisions follow §1.a core asset protocol or the 20 design philosophies.
