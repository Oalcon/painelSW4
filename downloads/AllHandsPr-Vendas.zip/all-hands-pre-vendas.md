---
name: All Hands Pré-Vendas
description: Preparo completo para o All Hands de Pré-Vendas. Cobre Overview Área (Sérgio) + squads Titãs e Mavericks + 3 times filhos de cada, com métricas de meta, GRID, realizado, GAP e destaque operacional.
---

# Ritual: All Hands Pré-Vendas

## Execução — Script Python

Este ritual é executado via script Python pré-validado. **Não montar queries manualmente.**

```bash
python "{workflow-dir}/rituais/all_hands_pv.py"
```

O script executa H1, H2, M1, M2, M3, M4 em paralelo, monta a hierarquia dinamicamente e entrega os 9 blocos formatados (Área + 2 Squads + 6 Times). Apresentar o output ao usuário exatamente como retornado.

---

## Estrutura de Entrega

```
1. Overview Área — Sérgio Alonso
2. Overview Squad — Titãs (Ana Costa)
   2.1 Time filho 1 + destaque operacional
   2.2 Time filho 2 + destaque operacional
   2.3 Time filho 3 + destaque operacional
3. Overview Squad — Mavericks (Lucas Kassai)
   3.1 Time filho 1 + destaque operacional
   3.2 Time filho 2 + destaque operacional
   3.3 Time filho 3 + destaque operacional
```

Total: **9 blocos** (1 área + 2 squads + 6 times).

---

## Guardrails

1. **GRID < Meta mensal** — se GRID ≥ meta, fração de diariação está errada, reexecutar M1
2. **Setor sem hífen** — `'Pré Vendas Aquisição'`, não `'Pré-Vendas Aquisição'`
3. **Meta de squad** — soma das metas dos coordenadores, não dos SDRs individuais
4. **Realizado via `funil_comercial`** — usar `event='Oportunidade'` sem filtro de `grupo_de_receita`
5. **Squads desconhecidos** (ex: "The GOATs") — ignorar no roll-up; logar como aviso
6. **Normalização de nomes em Python** — nomes com acento exigem `unicodedata.normalize` antes de lookups