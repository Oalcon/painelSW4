---
name: Slides
description: Create and edit professional HTML presentation slides — outline-first workflow with human review at every stage
icon: "🎞️"
---

# HTML Slide Creator

Create professional presentation slides as self-contained HTML files. Each slide is a standalone 1280x720 (16:9) HTML page that renders in browsers and can be referenced in chat with `html-preview`.

## When to Use

- User says `/slides` or asks to create a presentation
- User provides content (transcript, report, data) and wants slides built from it
- User wants to edit or iterate on an existing slide deck

## Phase 1: Understand the Request

**Goal**: Know exactly what to build before touching any code.

### Step 1 — Read the Input

If the user provides source material (transcript, document, data file, brief), read it **fully** before doing anything else. Use Task sub-agents (`model: "sonnet"`) to process large files if needed.

### Step 2 — Extract Context

From the input and conversation, determine:

| Parameter | What to Figure Out | Default if Not Specified |
|-----------|-------------------|-------------------------|
| **Topic** | What the presentation is about | Infer from source material |
| **Audience** | Who will see this (executives, students, team, public) | General business audience |
| **Slide count** | How many slides | 15-20 for standard, 25-30 for deep content |
| **Tone** | Formal, educational, inspirational, data-driven | Match source material |
| **Theme** | Dark or light | Dark (default) |
| **Brand** | Custom colors/logo or default G4 palette | Default G4 dark palette |
| **Language** | Portuguese or English | Match user's language |
| **Speaker notes** | Whether to generate notes alongside slides | No, unless requested |
| **Output directory** | Where to save files | Session slides dir: `{session-path}/slides/{slug}/` |

### Step 3 — Confirm Scope

Briefly summarize what you understood and confirm with the user. **One message, one question.** Don't over-ask — infer from context and move fast.

If everything is clear from the input, skip straight to Phase 2.

---

## Phase 2: Draft the Outline

**Goal**: Agree on structure before building anything.

### Step 4 — Analyze the Content

Before writing the outline, think through:

1. **Key messages** — What are the 3-5 core takeaways?
2. **Narrative arc** — What story does this tell?
   - Hook → Context → Frameworks → Application → Practice → Synthesis
3. **Data points** — What numbers, stats, or comparisons are available?
4. **Quotes/Statements** — Any powerful phrases worth highlighting?
5. **Exercises** — If requested, where do interactive moments fit?

### Step 5 — Present the Numbered Outline

Present the full slide structure. For each slide:

```
## Slide Outline: {Presentation Title}

### Seção 1: {Section Name}

1. **{Slide Title}** — [{Layout Template}]
   {One-line description of content + the key message}

2. **{Slide Title}** — [{Layout Template}]
   {One-line description of content + the key message}

---

### Seção 2: {Section Name}

3. **{Slide Title}** — [Section Divider]
   {Transition to this module}

4. **{Slide Title}** — [{Layout Template}]
   {One-line description of content + the key message}

...
```

Layout template names come from `knowledge/layout-templates.md`. Indicate which template each slide uses.

### Step 6 — Wait for Approval

Ask: *"Quer ajustar algo no roteiro antes de eu construir os slides?"*

Do NOT proceed to building until the user confirms. They may want to:
- Reorder slides
- Add/remove topics
- Change emphasis
- Split or merge slides

---

## Phase 3: Build Slides

**Goal**: Generate all slides as HTML files with inline previews.

### Step 7 — Set Up Output Directory

Create the output directory **inside the current session** so slides are tied to the conversation and accessible via G4 OS. Use the `sessionPath` from `<session_state>` to determine the session directory:
```
{sessionPath}/slides/{project-slug}/
```

The `sessionPath` is available in the `<session_state>` tag. This ensures slides are shareable within the session context and can be referenced with filecards.

If the user explicitly requests a different path, use that instead.

### Step 8 — Build Slides with Sub-Agents

**CRITICAL: Use Task sub-agents** to build slides. This keeps the main context clean and enables parallel generation.

**Dispatch pattern:**
1. Split the outline into batches of **3-5 slides**
2. For each batch, launch a **Task agent** with:
   - `subagent_type: "general-purpose"`
   - `model: "sonnet"` (fast, high-quality HTML/CSS — do NOT use Opus for slide generation)
3. Launch **all batches in parallel** (multiple Task calls in one message)
4. After all agents complete, verify files exist and preview 1-2 slides for quality

**Each sub-agent prompt must include:**
- The **output directory** path and exact filenames to write
- The **slide outline entries** for that batch (titles, content descriptions, layout templates)
- The **source material** relevant to those slides (quotes, data, key points)
- Instructions to **read the knowledge files** before building:
  - `{workflow-dir}/knowledge/design-system.md` — colors, fonts, base CSS
  - `{workflow-dir}/knowledge/layout-templates.md` — HTML skeleton for each layout
  - `{workflow-dir}/knowledge/components.md` — reusable patterns
- The **quality rules** from Step 9 below

**Sub-agent prompt template:**
```
You are building HTML presentation slides.

FIRST, read these design reference files:
- {workflow-dir}/knowledge/design-system.md
- {workflow-dir}/knowledge/layout-templates.md
- {workflow-dir}/knowledge/components.md

Then build the following slides as self-contained HTML files.
Each slide is exactly 1280x720, uses Montserrat font, and follows
the dark theme from the design system. Write each file using the
Write tool.

Output directory: {output-dir}

Slides to build:
{slide-outline-entries-with-content}

Source material for reference:
{relevant-excerpts}
```

**Example parallel dispatch for a 15-slide deck:**
```
Task A (sonnet): Slides 1-5  → writes slide-01 through slide-05
Task B (sonnet): Slides 6-10 → writes slide-06 through slide-10
Task C (sonnet): Slides 11-15 → writes slide-11 through slide-15
```

All three run simultaneously. Main context receives only file paths back, not HTML content.

**After all agents complete:**
1. Verify all files were written (`ls` or `Glob`)
2. Output one `html-preview` block with `items` (first 2-3 slide files) so chat preview has built-in arrow navigation:
   ````
   ```html-preview
   {
     "title": "Slides Preview",
     "items": [
       {"src":"/absolute/path/to/slide-01-title.html","label":"Slide 01"},
       {"src":"/absolute/path/to/slide-02-topic.html","label":"Slide 02"},
       {"src":"/absolute/path/to/slide-03-topic.html","label":"Slide 03"}
     ]
   }
   ```
   ````
3. If quality is good, proceed to Phase 5 (packaging)
4. If issues found, re-dispatch only the affected slides

> **Preview behavior**:
> - `html-preview` renders local HTML files in sandboxed iframes
> - JavaScript does **not** execute in `html-preview` (Chart.js/JS animations may not render)
> - Use browser open (`open index.html`) to validate interactive or JS-dependent slides
> - For shared-session compatibility, include `html` fallback content when possible (otherwise shared URLs show an explicit unavailable message for local paths)

**File naming:**
```
slide-01-{slug}.html
slide-02-{slug}.html
...
```

### Step 9 — Build Quality Rules

Before saving each slide, verify:
- [ ] Fixed 1280x720 container — no responsive layouts
- [ ] All text readable with sufficient contrast
- [ ] No content overflow beyond 720px height — split if needed
- [ ] Google Fonts link present (Montserrat)
- [ ] Font Awesome link present (if icons used)
- [ ] Chart.js + datalabels loaded (if charts used)
- [ ] Colors strictly from the design system
- [ ] Consistent typography hierarchy across slides
- [ ] Every slide is 100% self-contained (inline CSS, all CDN links in head)

**Reference files during build:**
- `knowledge/design-system.md` — Colors, fonts, base CSS
- `knowledge/layout-templates.md` — HTML structure for each layout type
- `knowledge/components.md` — Reusable component patterns

---

## Phase 4: Refine with Feedback

**Goal**: Polish until the user is happy.

### Step 10 — Accept Edit Requests

The user can request changes to any slide by referencing its number or title:
- *"No slide 7, aumenta o número principal"*
- *"Troca a cor do gráfico no slide de receita"*
- *"Adiciona um slide entre o 12 e o 13"*

For each edit:
1. Use the **Edit** tool to modify the specific HTML file
2. Re-render the updated slide with an `html-preview` block using the file `src`
3. Confirm the change

### Step 11 — Handle Additions/Removals

If slides are added or removed mid-deck:
- Renumber files to maintain sequence
- Update the navigator page if already generated

---

## Phase 5: Package & Deliver

**Goal**: Final deliverables.

### Step 12 — Generate Navigators (via Sub-Agent)

After all slides are finalized, **delegate navigator generation to a sub-agent** to avoid flooding the main context with HTML.

Launch a **single Task agent** with:
- `subagent_type: "general-purpose"`
- `model: "sonnet"`

The sub-agent should:
1. Read `knowledge/components.md` for the navigator templates
2. Read all slide HTML files from the output directory
3. Build the navigator file:

#### A. `index.html` — Browser navigator (iframe-based)

For opening in the browser via `open index.html`. Uses nested `<iframe src="slide-01.html">` to load individual slide files. Features:
- Iframe-based slide viewer that scales to viewport
- Left/Right arrow key navigation
- Dot indicators for current position
- Slide counter (e.g., "5 / 28")
- Fullscreen with "F" key
- Speaker notes panel with "N" key

After the sub-agent completes:
- Output one `html-preview` block using `items` (2-3 slides) for inline navigation in chat.
- Run `open index.html` for full interactive validation (JS, charts, animations, notes).

### Step 13 — Speaker Notes (if requested)

Generate `speaker-notes.md` with:
```markdown
# Speaker Notes: {Presentation Title}

## Slide 1: {Title}
**Key message**: {The one thing the audience should remember}
**Talking points**:
- Point 1
- Point 2
**Transition to next**: {How to bridge to the next slide}
**Timing**: ~{X} minutes

---
```

### Step 14 — Summary & Handoff

Present the final package:

1. **Preview inline (static)** — Output one `html-preview` block for a representative slide file. If useful, include an `items` list with 2-3 key slides.

2. **Open in browser** — Also open the iframe-based navigator so the user has the full-featured version:
```bash
open "{output-dir}/index.html"
```

3. **Shared-session note** — Mention that shared viewer URLs cannot load local slide file paths and will show a fallback message. Include the slide manifest (`slide-XX-*.html` paths) in the summary for traceability.

4. Then present the summary:
```
## Apresentação Pronta

**Slides**: {count} slides
**Preview inline** — static file-backed preview via `html-preview`
**Aberta no browser** — versão completa com fullscreen e notes
**Notes**: `speaker-notes.md` (se solicitado)
**Shared URL**: local slide previews show fallback; use local app/browser to open files

Para editar qualquer slide, me diga o número e o que quer mudar.
```

---

## Content Design Principles

### One Message Per Slide
Every slide has ONE clear takeaway. The title communicates the takeaway — not just labels the topic.

**Bad**: "Dados sobre IA"
**Good**: "Apenas 5% das Empresas Extraem Valor Real da IA"

### Visual Hierarchy
- **One hero element per slide** — a big number, chart, diagram, or statement. Never compete for attention.
- **Progressive disclosure** — build complexity across slides, don't front-load.
- **Breathing room** — generous padding. Dark space is intentional design, not wasted space.

### Data Presentation
- Contextualize numbers: "57% — mais da metade" > just "57%"
- Show comparisons: vs. previous year, vs. benchmark, vs. expectation
- Color semantically: green = growth, red = alert, blue = neutral/info

### Slide Pacing
- **Never more than 6 bullet points** on a single slide
- **Alternate density**: follow a data-heavy slide with a statement or quote slide
- **Section dividers** give the audience a mental breather — use them between major topics

---

## Anti-Patterns — DO NOT DO THESE

These are mistakes from real sessions. Follow these rules strictly.

### NEVER create a single-file presentation as the primary output
Do NOT put all slides inside one HTML file with JavaScript show/hide logic as the **primary output**. This causes:
- Click-handler conflicts (click-to-advance fires when user clicks content)
- CSS transition repaints and flickering between slides
- Overlapping animations when navigating quickly
- Massive file that's hard to edit incrementally

**Always** create one HTML file per slide as the source of truth. The `index.html` navigator uses iframes to display them.

### NEVER use click-to-advance navigation
Click handlers on the slide body cause accidental navigation when users interact with content. Use **arrow keys + swipe only** in the navigator.

### NEVER use a different font than Montserrat
The design system uses Montserrat. Do not substitute Inter, Roboto, or any other font. The entire color palette and typography scale is calibrated for Montserrat.

### NEVER use colors outside the design system
Read `knowledge/design-system.md` before building. Do not use indigo, purple, teal, or any other color not in the palette. The palette is: navy backgrounds, blue accents (#2063AD), light blue text (#BCD6F6), red highlights (#FF5756), green for positive (#4CAF50), orange for warnings (#FF9800).

### NEVER use responsive/fluid layouts
Every slide is exactly 1280x720. No `max-width`, no `%` widths on the container, no media queries. The navigator scales the iframe to fit the viewport — the slides themselves are fixed.

### NEVER skip the outline phase
Even if the user seems eager to build, present the outline first. The cost of rebuilding 20 slides because the structure was wrong is much higher than 30 seconds of review.

### NEVER overflow the 720px height
If content doesn't fit, split into two slides. Do not reduce font sizes below the typography scale minimums. Do not remove padding to cram more content. Split instead.

### NEVER build without reading the knowledge files
Before generating any HTML, read:
1. `knowledge/design-system.md` — for colors, fonts, base CSS
2. `knowledge/layout-templates.md` — for the HTML skeleton of the layout you're using
3. `knowledge/components.md` — for reusable patterns

This ensures consistency across all slides and prevents ad-hoc styling that drifts from the design system.
