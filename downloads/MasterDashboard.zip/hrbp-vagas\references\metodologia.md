# Metodologia de Descoberta — 7 Etapas

## Etapa 1 — Entendimento da Necessidade

**Objetivo:** Compreender o problema de negócio que originou a contratação.

**Perguntas possíveis:**
- O que motivou esta contratação?
- É uma reposição ou expansão?
- Qual problema esta pessoa ajudará a resolver?
- O que acontece se esta vaga não for preenchida nos próximos 3 meses?
- Qual resultado o negócio espera gerar com esta contratação?

**Hipóteses de apoio (oferecer se o usuário hesitar):**
- Crescimento da operação
- Aumento de demanda
- Reestruturação
- Nova unidade de negócio
- Substituição de colaborador
- Ganho de eficiência
- Escalabilidade operacional

---

## Etapa 2 — Definição da Posição

**Coletar:**
- Cargo
- Área / Squad / Time
- Gestor responsável
- Senioridade

**Guia de senioridade (oferecer se houver dúvida):**

| Nível | Perfil típico |
|-------|-------------|
| Júnior | 0–2 anos, executa com supervisão próxima |
| Pleno | 2–5 anos, executa com autonomia moderada |
| Sênior | 5+ anos, autonomia total, pode mentorear |
| Especialista | Profundo em uma disciplina específica |
| Coordenador | Lidera pequenos times ou projetos |
| Gerente | Gestão de time e resultados da área |
| Head | Liderança estratégica de função ou vertical |

---

## Etapa 3 — Escopo da Função

**Investigar:**
- Principais responsabilidades (top 5)
- Entregas esperadas nos primeiros 90 dias
- Projetos prioritários do semestre
- Interfaces internas (com quem vai trabalhar)
- Interfaces externas (clientes, fornecedores, parceiros)
- Grau de autonomia na tomada de decisão

**Exemplo de apoio consultivo:**
> Para um Product Manager, normalmente vemos responsabilidades relacionadas a discovery, roadmap, priorização e métricas de produto. Isso se aproxima da sua necessidade?

---

## Etapa 4 — Competências Técnicas

**Obrigatórias:**
- Conhecimentos técnicos mínimos
- Ferramentas essenciais
- Metodologias
- Certificações (se realmente necessárias)
- Idiomas

**Desejáveis:**
- Diferenciais competitivos
- Experiências complementares que agregam mas não são bloqueadoras

**Postura consultiva:**
- Sempre diferenciar "obrigatório" de "desejável"
- Sugerir requisitos normalmente esperados para o cargo
- Questionar pilhas de tecnologia excessivas

---

## Etapa 5 — Competências Comportamentais

**Investigar:**
- Como é a cultura do time?
- Qual perfil comportamental tende a ter sucesso aqui?
- O que NÃO funciona neste ambiente?

**Menu de competências (sugerir conforme contexto):**
- Ownership / Dono do problema
- Comunicação clara e objetiva
- Influência sem autoridade
- Colaboração e trabalho em equipe
- Adaptabilidade em ambientes de mudança
- Resolução de problemas complexos
- Visão estratégica
- Orientação a resultados e dados
- Inteligência emocional
- Proatividade

---

## Etapa 6 — Critérios de Sucesso

**Pergunta principal:**
> Como você sabrá que essa contratação foi um sucesso após 6 ou 12 meses?

**Transformar respostas subjetivas em indicadores mensuráveis:**

| Entrada do usuário | Tradução consultiva |
|--------------------|--------------------|
| "Organizar a operação comercial" | Reduzir retrabalho; aumentar previsibilidade do pipeline; implementar governança; melhorar SLA entre áreas |
| "Melhorar o time" | Reduzir turnover; aumentar eNPS; estruturar plano de desenvolvimento |
| "Entregar o produto" | Lançar X funcionalidades; atingir Y de adoção; reduzir Z de bugs críticos |

Sempre converta em: **resultado mensurável + prazo**.

---

## Etapa 7 — Condições da Vaga

**Coletar (sem bloquear se não souber):**
- Modelo de trabalho: Presencial / Híbrido / Remoto
- Localização / praça (se aplicável)
- Tipo de contratação: CLT / PJ / Estágio
- Faixa salarial (range mínimo-máximo)
- Benefícios principais
- Estrutura de remuneração variável (bônus, PLR, comissão)

> Se o usuário não souber a faixa salarial, registre como "a definir" e sinalize como gap no HRI.