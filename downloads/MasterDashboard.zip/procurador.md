---
name: Procurador de Skills
description: Vasculha a biblioteca inteira de skills do npx skills, encontra as corretas e as instala de forma automatizada no workspace.
trigger: /procurador
---

Sempre que o usuário solicitar para procurar e instalar skills via `/procurador`, execute o seguinte fluxo estruturado:

1. **Entenda o Objetivo**: Identifique a necessidade atual do projeto ou as 4 skills principais mencionadas pelo usuário para instalação.
2. **Pesquisa e Busca**:
   - Utilize a ferramenta de busca do CLI executando `npx skills find <termo_de_busca>` no terminal para pesquisar na biblioteca pública de skills.
   - Alternativamente, consulte a internet ou repositórios como `vercel-labs/skills` para encontrar repositórios de terceiros relevantes.
3. **Instalação das Outras 4 Skills**:
   - Se o contexto exigir a instalação das "outras 4 skills principais" da Vercel/comunidade, identifique as mais comuns e úteis para o projeto atual e execute o comando `npx skills add <owner/repo>` para cada uma delas no workspace.
4. **Verificação**:
   - Após a instalação, liste as skills presentes no projeto rodando `npx skills list` ou verificando a pasta `.skills/` / `.agents/` para confirmar que a instalação foi concluída corretamente.
5. **Relatório final**:
   - Apresente um resumo claro com as skills encontradas, quais foram instaladas com sucesso e como o usuário pode ativá-las ou utilizá-las no fluxo de trabalho.
