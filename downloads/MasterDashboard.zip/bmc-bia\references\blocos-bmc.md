# Blocos do Business Model Canvas — G4 Imersão Traction

Referência completa dos 9 blocos, com definições, perguntas provocativas e dicas de refinamento.

---

## Bloco 1 — Segmentos de Clientes

**Definição:** Os diferentes grupos de pessoas ou organizações que a empresa busca alcançar e atender. O modelo de negócios pode definir um ou vários segmentos. A empresa deve decidir conscientemente quais segmentos servir e quais ignorar.

**Perguntas provocativas:**
1. Para quem você resolve um problema? Descreva esse cliente em detalhes — quem é, o que faz, o que sente.
2. Existem grupos diferentes de clientes com necessidades distintas? (ex: usuário final vs. pagador vs. influenciador da compra)
3. Qual segmento é o mais crítico para a sobrevivência do negócio hoje?

**Dicas de refinamento:**
- Evite "todo mundo" — quanto mais específico o segmento, mais eficaz a proposta de valor.
- Separe segmentos quando possuem necessidades, canais ou disposição a pagar diferentes.

---

## Bloco 2 — Proposta de Valor

**Definição:** O conjunto de produtos e serviços que criam valor para um segmento de clientes específico. É a razão pela qual os clientes escolhem uma empresa em vez da concorrência. Resolve um problema ou satisfaz uma necessidade do cliente.

**Perguntas provocativas:**
1. Qual dor ou problema concreto você resolve para o cliente? O que ele deixa de sofrer com você?
2. O que você entrega que seus concorrentes não entregam — ou entregam pior?
3. Se o cliente fosse recomendar seu produto para um amigo em uma frase, o que ele diria?

**Dicas de refinamento:**
- Proposta de valor não é descrição de produto — é o benefício percebido pelo cliente.
- Teste: o cliente pagaria mais caro por isso? Se sim, é valor real.

---

## Bloco 3 — Canais

**Definição:** Como a empresa se comunica e alcança seus segmentos de clientes para entregar a proposta de valor. Os canais cobrem as fases de awareness, avaliação, compra, entrega e pós-venda.

**Perguntas provocativas:**
1. Como seus clientes descobrem que você existe hoje? (orgânico, pago, indicação, parceiros?)
2. Onde acontece a conversão — onde o cliente decide comprar? Online, presencial, via vendedor?
3. Como você entrega o produto/serviço e garante a experiência pós-venda?

**Dicas de refinamento:**
- Canais próprios (site, app, equipe de vendas) têm mais margem mas exigem mais investimento.
- Canais de parceiros (distribuidores, marketplaces) têm maior alcance mas dividem a margem.

---

## Bloco 4 — Relacionamento com Clientes

**Definição:** Os tipos de relacionamento que a empresa estabelece com cada segmento de clientes. Pode variar de pessoal a automatizado. Impacta aquisição, retenção e crescimento de receita.

**Perguntas provocativas:**
1. Após a venda, como você se relaciona com o cliente? Há contato contínuo ou é transacional?
2. O cliente precisa de suporte humano para usar o produto, ou consegue se virar sozinho?
3. Como você faz o cliente voltar a comprar ou recomendar?

**Dicas de refinamento:**
- Relacionamento influencia diretamente o CAC (custo de aquisição) e o LTV (lifetime value).
- Self-service escala melhor; relacionamento pessoal constrói fidelidade mais profunda.

---

## Bloco 5 — Fluxos de Receita

**Definição:** O dinheiro que a empresa gera a partir de cada segmento de clientes. Cada fluxo pode ter mecanismos de precificação diferentes. Representa o valor que os clientes estão dispostos a pagar.

**Perguntas provocativas:**
1. Como exatamente o dinheiro entra no caixa? (venda única, assinatura, taxa de uso, licença, comissão?)
2. Cada segmento de cliente paga da mesma forma, ou há modelos diferentes por perfil?
3. Qual fluxo de receita tem a maior margem? Qual tem o maior volume?

**Dicas de refinamento:**
- Receitas recorrentes (assinaturas, contratos) são mais previsíveis e aumentam o valor da empresa.
- Avalie se há receitas adjacentes ainda não exploradas (upsell, cross-sell, dados, serviços).

---

## Bloco 6 — Recursos-chave

**Definição:** Os ativos mais importantes necessários para fazer o modelo de negócios funcionar. Podem ser físicos, intelectuais (marcas, patentes, dados), humanos ou financeiros.

**Perguntas provocativas:**
1. O que seria devastador perder no seu negócio hoje — tecnologia, time, dados, marca, capital?
2. Quais recursos são difíceis de replicar pelos concorrentes?
3. O que você precisa ter (ou construir) para entregar a proposta de valor com consistência?

**Dicas de refinamento:**
- Recursos-chave devem sustentar a proposta de valor e as atividades-chave.
- Separe o que é "nice to have" do que é realmente crítico para operar.

---

## Bloco 7 — Atividades-chave

**Definição:** As ações mais importantes que a empresa deve realizar para fazer o modelo de negócios funcionar. São as tarefas críticas que criam e entregam a proposta de valor.

**Perguntas provocativas:**
1. Quais são as 3 atividades que, se pararem, o negócio para?
2. O que consome mais tempo e energia da equipe hoje? Isso é realmente estratégico?
3. Quais atividades diferenciam você da concorrência — onde você precisa ser excelente?

**Dicas de refinamento:**
- Atividades-chave variam por tipo de negócio: produção (manufatura), resolução de problemas (consultoria), plataforma (gestão de rede).
- Questione o que pode ser terceirizado sem perder vantagem competitiva.

---

## Bloco 8 — Parceiros-chave

**Definição:** A rede de fornecedores e parceiros que colocam o modelo de negócios para funcionar. Parcerias são criadas para otimizar recursos, reduzir riscos ou adquirir capacidades.

**Perguntas provocativas:**
1. Quem são os fornecedores ou parceiros sem os quais você não consegue operar?
2. Existem empresas complementares com quem você poderia criar valor compartilhado?
3. O que você está fazendo internamente que um parceiro faria melhor ou mais barato?

**Dicas de refinamento:**
- Parcerias estratégicas permitem focar no core e terceirizar o resto.
- Cuidado com dependência excessiva de um único parceiro — avalie o risco de concentração.

---

## Bloco 9 — Estrutura de Custos

**Definição:** Todos os custos envolvidos na operação do modelo de negócios. Descreve os custos mais importantes incorridos para criar e entregar valor, manter relacionamentos e gerar receita. Os custos devem ser subtraídos da receita para gerar lucro.

**Perguntas provocativas:**
1. Quais são os maiores custos do seu negócio hoje — fixos e variáveis?
2. Quais recursos e atividades-chave são os mais caros de manter?
3. O modelo é orientado a custo (máxima eficiência) ou a valor (premium, diferenciação)? Isso está refletido na precificação?

**Dicas de refinamento:**
- Custos fixos existem independente do volume (aluguel, salários); custos variáveis escalam com o negócio.
- Economias de escala e escopo reduzem custo unitário — avalie se o modelo permite isso.
- Lembrete essencial: **Lucro = Receita − Custos**. O canvas só é saudável quando essa equação é positiva e sustentável.