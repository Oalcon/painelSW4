# Scores — HRI e Quality Score

## Hiring Readiness Index (HRI)

Avalia o nível de maturidade e clareza da contratação. Guia a conversa — continue coletando até atingir ≥ 80.

### Componentes e Pesos

| Critério | Peso | Como avaliar |
|----------|------|--------------|
| Clareza do problema de negócio | 20 | 0 = não informado; 10 = vago; 20 = claro com impacto |
| Objetivos da contratação | 15 | 0 = ausente; 8 = parcial; 15 = objetivos claros |
| Escopo da função | 20 | 0 = ausente; 10 = genérico; 20 = responsabilidades definidas |
| Perfil ideal definido | 15 | 0 = ausente; 8 = parcial; 15 = técnico + comportamental mapeado |
| Critérios de sucesso | 15 | 0 = ausente; 8 = subjetivo; 15 = indicadores mensuráveis |
| Condições da vaga | 15 | 0 = ausente; 8 = parcial; 15 = modelo, local, tipo e faixa definidos |

### Interpretação

| Faixa | Status |
|-------|--------|
| 0–25 | Necessidade pouco definida — continue coletando |
| 26–50 | Objetivo parcialmente claro — gaps críticos a preencher |
| 51–75 | Boa definição com ajustes necessários |
| 76–90 | **Pronto para recrutamento** |
| 91–100 | Vaga extremamente bem estruturada |

---

## Quality Score da Vaga

Avalia a qualidade final do Job Description gerado. Calculado apenas no Resultado Final.

### Componentes e Pesos

| Critério | Peso | Como avaliar |
|----------|------|--------------|
| Clareza do problema de negócio | 20 | Contexto de negócio claro na vaga |
| Definição do escopo | 20 | Responsabilidades objetivas e realistas |
| Competências técnicas | 15 | Requisitos proporcionais e justificados |
| Competências comportamentais | 10 | Perfil comportamental alinhado à cultura |
| Critérios de sucesso | 15 | Indicadores mensuráveis incluídos |
| Consistência dos requisitos | 10 | Senioridade ↔ escopo ↔ salário alinhados |
| Atratividade da vaga | 10 | Linguagem atrativa, missão clara, diferenciais |

### Interpretação

| Faixa | Classificação |
|-------|---------------|
| 0–59 | Baixa qualidade — revisar antes de publicar |
| 60–79 | Boa qualidade |
| 80–89 | Muito boa qualidade |
| 90–100 | **Excelente** — publicar |

---

## Riscos Padrão a Avaliar

1. **Escopo excessivamente amplo** — uma pessoa não consegue entregar tudo
2. **Senioridade incompatível** — responsabilidades de sênior com título/salário de pleno
3. **Faixa salarial desalinhada ao mercado** — risco de pool de candidatos ruim
4. **Dependência de competências raras** — combinação de skills difícil de encontrar
5. **Excesso de requisitos obrigatórios** — elimina candidatos qualificados desnecessariamente
6. **Acúmulo de responsabilidades conflitantes** — ex: estratégia + operação ao mesmo tempo
7. **Critérios de sucesso ausentes** — contratação sem forma de medir impacto