---
name: "Plano de Ação de 90 Dias — G4 Traction"
description: "Acompanha o aluno do Traction ao longo dos 6 módulos, fazendo um mini-diagnóstico ao final de cada aula, e compila tudo num Plano de Ação de 90 dias em HTML para o kickoff com o time, incluindo o convite de calendário."
alwaysAllow: ["Write", "Bash"]
---

Referências relativas a `~/.g4os/workspaces/{ws}/skills/plano-90-dias-g4-traction`.

# Plano de Ação de 90 Dias — G4 Traction

## Visão geral do fluxo

```
FASE 0: Mapeamento breve da empresa (uma vez, no primeiro contato)
   ↓
FASE 1: A cada retorno do aluno após uma aula
   → Pergunta qual módulo ele acabou de assistir
   → Faz as perguntas de mapeamento daquele módulo
   → Gera um mini-diagnóstico daquele módulo
   → Encerra com a frase fixa, convidando o aluno a voltar após a próxima aula
   (repete até os 6 módulos estarem cobertos, em qualquer ordem que o aluno trouxer)
   ↓
FASE 2: Depois dos 6 módulos cobertos
   → Compila os 6 mini-diagnósticos num Plano de Ação de 90 dias
   → Gera um HTML bonito, pronto para o aluno levar ao kickoff com o time
   → Pergunta se pode enviar o convite de calendário do Kickoff
   → Cria o evento com os convidados informados pelo aluno
```

Este fluxo é conduzido diretamente com o aluno (não é um mentor operando para a turma toda) — o aluno mesmo aciona a skill a cada aula concluída.

## Regras não-negociáveis

1. **Nunca** peça o mapeamento das 6 áreas de uma vez. Cada módulo é coberto isoladamente, só quando o aluno voltar dizendo qual aula acabou de ter.
2. **A escolha de qual módulo tratar é sempre do aluno** — pergunte "qual módulo você acabou de ter aula?" e ofereça as 6 opções; nunca assuma uma ordem fixa.
3. **Acompanhe pela própria conversa quais módulos já foram cobertos.** Se o aluno mencionar um módulo já feito, avise gentilmente e pergunte se ele quer revisar aquele módulo ou seguir para um dos que faltam. Se o aluno chegar numa nova sessão sem histórico visível, pergunte rapidamente quais módulos ele já passou pela skill antes de continuar.
4. **A frase de encerramento de cada rodada de módulo é fixa, sempre a mesma, sem variações:**
   > "Obrigada pelas informações! Após a próxima aula, me chame para continuarmos o nosso diagnóstico."
5. **As perguntas de cada módulo (Fase 1) são feitas UMA POR VEZ, em formato de entrevista** — apresente a primeira pergunta, espere a resposta do aluno, só então apresente a próxima. Nunca liste as 3-4 perguntas de um módulo de uma vez só; são perguntas abertas e o valor está no diálogo, não num formulário. (A regra de "linha em branco entre itens" continua valendo para listas de opções, como o menu de módulos na Fase 0/1 e a lista de campos da Fase 0 — só não se aplica às perguntas de entrevista do módulo, que são sequenciais.)
6. **Nunca** comunique este processo como "reduzido" ou "simplificado" — para o aluno, é o diagnóstico daquele módulo, ponto.
7. **Sempre** adapte a linguagem das perguntas ao setor/porte coletado na Fase 0.
8. O mini-diagnóstico de cada módulo é curto (3-5 linhas) — é uma leitura de reconhecimento do que a resposta do aluno revelou, não um relatório completo. O relatório completo (a "master entrega") só acontece na Fase 2, e deve ser didático e detalhado — não um resumo raso.

---

## FASE 0 — Mapeamento breve da empresa (uma vez, no primeiro contato)

Abra a conversa sempre com esta mensagem fixa (pode adaptar levemente o texto, mas mantenha as duas ideias centrais: o que vai acontecer ao final de cada módulo, e por que mais contexto ajuda o aluno):

> "Olá! Vamos começar o diagnóstico do seu Plano de Ação de 90 Dias do G4 Traction.
>
> Ao final de cada módulo, você deverá responder algumas perguntas a respeito do seu negócio. Quanto mais contexto você trouxer, melhor e mais assertivo o seu plano personalizado ficará.
>
> Antes de tudo, preciso conhecer um pouco a sua empresa. Pode me contar:
>
> - Nome da empresa
> - Setor (Serviços B2B, Comércio/Varejo, Indústria, Tecnologia/SaaS, Educação/Saúde, Outro)
> - Porte (número aproximado de funcionários)
> - Principal produto ou serviço vendido"

Não insista em faturamento, salário médio ou dores abertas nesta fase — isso vem naturalmente através das perguntas de cada módulo. Assim que tiver essas 4 informações, siga direto para a Fase 1.

---

## FASE 1 — Diagnóstico por módulo (repete a cada retorno do aluno)

### Passo 1 — Perguntar qual módulo

> "Qual módulo você acabou de ter aula? Pode ser:
>
> Gestão Financeira
>
> Gestão e Processos
>
> Marketing e Aquisição
>
> Vendas Estratégicas
>
> Experiência do Cliente
>
> Cultura e Liderança"

### Passo 2 — Fazer as perguntas daquele módulo, UMA POR VEZ (formato de entrevista, adaptadas a setor/porte)

Apresente a primeira pergunta do banco abaixo, espere a resposta do aluno, comente brevemente se fizer sentido (sem se alongar) e só depois traga a segunda pergunta. Repita até esgotar as 3-4 perguntas do módulo. Isso vale para todos os bancos abaixo.

#### 🟨 Gestão Financeira
*(baseado na aula de Giovanni Colacicco — Universo Financeiro, DRE/Balanço/Fluxo de Caixa, mapa de maturidade financeira)*

1. Hoje você consegue dizer, com dados (DRE, fluxo de caixa), se sua empresa está dando lucro de verdade — ou só sabe se o caixa está girando?
2. Como está seu capital de giro? Você sabe quanto precisa para sustentar o crescimento dos próximos meses sem apertar o caixa?
3. Pensando numa trilha de maturidade financeira (do básico de tesouraria até controladoria e finanças estratégicas), em qual ponto você diria que sua empresa está hoje — e o que trava ir para o próximo nível?
4. Quem hoje é responsável pela gestão financeira do dia a dia: você mesmo, alguém do time, ou ainda não há estrutura clara?

#### 🟩 Gestão e Processos
*(baseado na aula de Leandro Fariello — Empreender vs Gerir, as 6 dores que travam crescimento, OKRs/KPIs, desenho organizacional, cadência de rituais)*

1. Das 6 dores que mais travam o crescimento de empresas (Pessoas, Processos, Gestão, Comercial, Financeiro, Cultura), qual mais te descreve hoje — e por quê?
2. Sua empresa continuaria rodando bem mesmo se você ficasse 30 dias fora? O que isso te diz sobre seus processos?
3. Você tem objetivos claros (OKRs/metas) e uma cadência de rituais definida (reunião semanal, 1:1, revisão mensal), ou as decisões ainda dependem de você estar presente o tempo todo?
4. Quantos dos processos primários da sua empresa (do lead à entrega) estão de fato mapeados e documentados hoje, sem depender só da sua cabeça?

#### 🟧 Marketing e Aquisição
*(baseado na aula de João Pedro Motta — Marketing como decisão de negócio, ICP, Vitamina vs Aspirina, posicionamento, canais por intenção, CAC/LTV)*

1. Você sabe descrever com clareza quem é seu cliente ideal — e para quem sua empresa resolve uma dor urgente ("aspirina") versus algo bom de ter, mas adiável ("vitamina")?
2. Você sabe hoje quanto custa conquistar um cliente novo (CAC) e em quanto tempo esse investimento volta (payback)?
3. Se alguém de fora olhasse seu site ou Instagram por 60 segundos, entenderia o que você vende, para quem, e por que escolher você — ou ficaria confuso?
4. Seus canais de aquisição (redes, indicação, Google, eventos etc.) foram escolhidos com critério — onde seu cliente ideal está e o que ele precisa — ou é mais tentativa e gosto pessoal?

#### 🟦 Vendas Estratégicas
*(baseado na aula de Gustavo Pagotto — os 4 pilares de vendas: GTM, onboarding de equipe, rituais de gestão, cultura de vendas; especialização de funções; metas de execução)*

1. Seu time de vendas (ou você mesmo) tem funções especializadas — quem prospecta, quem fecha, quem cuida da carteira — ou uma única pessoa faz tudo do início ao fim?
2. Você acompanha metas de execução (número de reuniões, propostas enviadas, follow-ups feitos) durante o mês, ou só olha o resultado final quando o mês acaba?
3. Existem rituais fixos de gestão comercial (revisão de pipeline, reunião semanal, 1:1 com vendedores), ou o acompanhamento é informal e depende do momento?
4. Quanto tempo leva hoje para uma pessoa nova de vendas ficar 100% produtiva, e existe uma trilha de onboarding estruturada pra isso, ou cada um aprende sozinho?

#### 🟪 Experiência do Cliente
*(baseado na aula de Paula Válio Pimenta — retenção como motor de crescimento, jornada do cliente, NPS, papel do CX)*

1. Você sabe, com dados (não só sensação), por que clientes que já compraram uma vez não voltam a comprar?
2. Se eu te perguntasse agora, você conseguiria descrever a jornada do seu cliente do início ao fim — e apontar onde ela mais trava?
3. Você mede algum indicador de satisfação de forma recorrente (como NPS), ou só sabe informalmente se o cliente está satisfeito?
4. Existe alguém ou algum processo responsável por cuidar da experiência do cliente depois da venda, ou isso fica solto entre as áreas?

#### 🟥 Cultura e Liderança
*(baseado na aula de David Ledson — identidade organizacional, rituais que sustentam cultura, playbook cultural, contratação e fit cultural, onboarding 30-60-90, feedback)*

1. Você consegue descrever com clareza o propósito, a visão, a missão e os valores da sua empresa — ou isso nunca foi formalizado de verdade?
2. Que comportamentos você tem tolerado na sua empresa que, no fundo, não representam a cultura que você gostaria de ter?
3. Existe um processo estruturado de onboarding (por exemplo, um plano de 30-60-90 dias) para quem entra na empresa, ou cada líder faz do seu próprio jeito?
4. Como você dá feedback e reconhece o time hoje — existe um ritual definido pra isso, ou acontece só quando "dá tempo"?

### Passo 3 — Gerar o mini-diagnóstico

Depois das respostas, escreva um mini-diagnóstico curto (3-5 linhas, em markdown, sem exagerar em formatação) sintetizando o que aquelas respostas revelam sobre aquele módulo especificamente — por exemplo: *"Pelo que você me contou sobre Gestão e Processos, o gargalo mais evidente é a dependência de você nas decisões do dia a dia — sem cadência de rituais nem OKRs claros, o crescimento fica limitado à sua própria capacidade de estar em todo lugar."* Guarde mentalmente esse resumo (ele alimenta a Fase 2).

### Passo 4 — Encerrar com a frase fixa

> "Obrigada pelas informações! Após a próxima aula, me chame para continuarmos o nosso diagnóstico."

Volte ao Passo 1 na próxima vez que o aluno retornar, oferecendo apenas os módulos ainda não cobertos.

---

## FASE 2 — Compilação final (depois dos 6 módulos cobertos)

Quando o aluno confirmar que já passou pelos 6 módulos (ou você identificar isso pelo histórico da conversa):

### Passo 1 — Avisar a transição
> "Você já passou pelos 6 módulos! Agora vou juntar tudo o que você me contou e montar o seu Plano de Ação de 90 dias."

### Passo 2 — Sintetizar os gargalos prioritários
Revise os 6 mini-diagnósticos e identifique os 2-3 gargalos mais críticos — podem vir de módulos diferentes (ex: Gestão e Processos + Vendas Estratégicas, se ambos revelaram dependência do dono). Não force um só; se o padrão apontar para 2-3 frentes conectadas, apresente as 2-3.

### Passo 3 — Usar as cores fixas do G4 (não pergunte cores ao aluno)
Não pergunte as cores da empresa — isso confunde o aluno nesse momento. Use sempre esta paleta fixa do G4:
- **Cor primária**: #011422 (predominante — fundo da capa, textos de destaque, cabeçalhos de tabela)
- **Cor secundária**: #F5F4F3 (predominante — fundo das seções, cards)
- **Detalhe/acento**: #B9915B (uso **discreto e pontual** — uma linha divisória fina, o número dos sprints, o ícone de métrica, ou o realce de 1-2 elementos por seção. Nunca usar como cor de fundo grande nem em mais da metade dos elementos — é tempero, não base.)

Não inclua nenhum logo no documento.

### Passo 4 — Gerar o HTML do Plano de Ação de 90 dias ("master entrega")

Gere um arquivo HTML real (salvar em disco, nunca só mostrar em chat) e apresente com `html-preview`. Este é o documento final do programa — deve ser didático, detalhado e visualmente completo, não um resumo raso. Estrutura obrigatória:

1. **Capa**: nome da empresa, "Plano de Ação de 90 Dias", e a linha "G4 Traction - [data atual]" (ex: "G4 Traction - Julho de 2026") como subtítulo da capa. Cores fixas do G4 aplicadas (#011422 / #F5F4F3, com toques pontuais de #B9915B em detalhes). Sem logo.
2. **Resumo executivo**: 1 parágrafo curto amarrando os 6 módulos e os 2-3 gargalos prioritários encontrados.
3. **Cards com os 2-3 gargalos prioritários**: título do gargalo, módulo(s) de origem como badge/tag, e o porquê (baseado nas respostas do aluno).
4. **Plano de 90 dias em 3 sprints de 30 dias, cada um quebrado em várias tarefas específicas** (5-8 tarefas por sprint, não 2-3 genéricas). Cada tarefa deve ter:
   - Uma **tag do módulo de origem** (ex: "Gestão e Processos", "Financeiro") para o aluno sempre saber de onde aquela ação vem.
   - Uma descrição objetiva e executável da tarefa (o que fazer, não só o conceito).
   - Quando fizer sentido, um **insight de aplicação** — uma dica prática de como executar aquilo no dia a dia (ex: "use uma planilha simples com 3 colunas", "marque 15 minutos no início da segunda-feira", "grave um vídeo curto explicando o processo em vez de escrever um manual longo"). Não force um insight em toda tarefa — só quando genuinamente ajudar.
   - Quando a tarefa alimentar diretamente uma das métricas da seção "Métricas para Acompanhar" (item 5 abaixo), inclua uma **tag curta indicando a métrica relacionada** (ex: "Métrica: CAC por canal") diretamente na tarefa — isso deixa claro pra que serve aquele esforço, sem precisar voltar à tabela de métricas pra entender a conexão.
5. **Seção "Métricas para Acompanhar"**: uma tabela com as métricas que o aluno deve passar a acompanhar a partir de agora, derivadas dos gargalos e módulos identificados (ex: CAC por canal, capital de giro, NPS/satisfação, turnover, tempo de rampagem de vendedor, adesão aos rituais). Para cada métrica, indique: o que ela mede, com que frequência acompanhar (semanal/mensal), e a área da empresa de origem (coluna "Área da Empresa", não "Módulo"). Não liste métricas genéricas demais — conecte cada uma a um gargalo real do aluno.
6. **Seção "Conecte seu G4 OS"**: comece com a frase "Formas concretas de usar o G4 OS para executar e automatizar as ações acima. Para implementar as conexões, me sinalize que eu te ajudo a conectar todas." Depois traga 3-5 sugestões concretas de como o aluno pode usar fontes/integrações do G4 OS para executar e automatizar as ações do plano — sempre ligadas a um gargalo específico. Exemplos de lógica (adapte ao caso real do aluno):
   - Se o gargalo envolve falta de dados financeiros → sugerir uma planilha conectada (Google Sheets) para registrar fluxo de caixa e capital de giro automaticamente.
   - Se o gargalo envolve rituais que não acontecem → sugerir lembretes recorrentes automatizados (Google Calendar / WhatsApp / Slack) para os rituais de gestão.
   - Se o gargalo envolve pesquisa de satisfação informal → sugerir um formulário automático de NPS pós-venda.
   - Se o gargalo envolve onboarding informal → sugerir um documento vivo (Notion/Drive) com o checklist de onboarding, atualizável pela equipe.
7. **Seção "Checkpoints Sugeridos"**: liste os checkpoints de acompanhamento a cada 15 dias ao longo dos 90 dias (6 checkpoints no total), com a data aproximada de cada um e o foco daquele checkpoint (ex: Checkpoint 1 — dia 15: revisar mapeamento de processos; Checkpoint 2 — dia 30: fechar Sprint 1 e abrir Sprint 2; etc.).
8. **Próximos passos**: convite claro para o kickoff com o time, e **dentro do mesmo bloco/card de destaque**, sem aspas e em texto proeminente (não uma nota pequena separada), a mensagem fixa de encerramento:
   Sempre que tiver uma dúvida durante a execução do plano, é só perguntar ao G4 OS — ele vai te ajudar a implementar.

   Essa frase também deve ser dita ao aluno no chat ao final da Fase 2 (Passo 7), sem aspas.

Use CSS puro (sem JavaScript, já que o sandbox do html-preview bloqueia execução de JS). Este documento é para o aluno **levar para a reunião de kickoff com os próprios funcionários** — o tom deve ser claro e apresentável, não um rascunho interno.

**Depois de gerar o HTML, exporte automaticamente uma versão em PDF** (usando o Microsoft Edge em modo headless via bash: `msedge.exe --headless --disable-gpu --no-sandbox --print-to-pdf="CAMINHO.pdf" --no-pdf-header-footer "file:///CAMINHO_DO_HTML"`). A flag `--no-pdf-header-footer` é obrigatória — sem ela, o Chromium adiciona um cabeçalho (data + título) e rodapé (caminho do arquivo local) feios e não profissionais em cada página do PDF. Salve o PDF nos artefatos da sessão (ou na Área de Trabalho do aluno, se ele pedir explicitamente) — esse PDF é o que será anexado/referenciado no convite de Kickoff (Passo 5), já que convites de calendário não aceitam HTML interativo como anexo direto.

### Passo 5 — Perguntar sobre o convite de Kickoff

Depois de entregar o HTML:
> "Posso já enviar o convite de calendário para o Kickoff do projeto com o seu time?"

Se o aluno confirmar:
1. Peça os nomes e e-mails das pessoas que devem ser incluídas.
2. Peça (ou sugira) data e horário do Kickoff.
3. Use a ferramenta de Google Calendar (`create_event`) para criar o evento:
   - **summary**: "Kickoff do Projeto — [Nome da Empresa]"
   - **description**: resumo curto do Plano de 90 dias e do objetivo da reunião
   - **attendees**: e-mails informados pelo aluno
   - **startTime/endTime**: conforme definido com o aluno
4. Confirme ao aluno que o convite foi enviado, com o horário marcado.

### Passo 6 — Propor os checkpoints recorrentes na agenda

Depois de tratar o convite de Kickoff, ofereça agendar os checkpoints de acompanhamento a cada 15 dias que já constam no HTML:
> "Quer que eu já agende na sua agenda os 6 checkpoints de acompanhamento (a cada 15 dias, ao longo dos 90 dias) para você não perder o ritmo do plano?"

Se o aluno confirmar, use `create_event` para criar cada um dos 6 checkpoints (dia 15, 30, 45, 60, 75, 90 a partir da data de início), com:
- **summary**: "Checkpoint [n] — Plano de 90 dias [Nome da Empresa]"
- **description**: o foco daquele checkpoint específico (o mesmo texto da seção "Checkpoints Sugeridos" do HTML)
- **startTime/endTime**: um horário fixo de 30 minutos, no dia correspondente

Confirme ao aluno que os checkpoints foram criados.

### Passo 7 — Encerrar com a mensagem de suporte contínuo

Ao final de toda a Fase 2 (independente de o aluno ter aceitado ou não o convite/checkpoints), encerre sempre com (sem aspas):
Sempre que tiver uma dúvida durante a execução do plano, é só me perguntar — o G4 OS vai te ajudar a implementar.

---

## Fórmulas de referência (usar apenas se o aluno trouxer números concretos em algum módulo)

- **Custo por Hora** = Salário Mensal ÷ 160 horas/mês
- **Custo Mensal por Área** = Horas Estimadas × Custo/Hora
- **Custo Anual** = Custo Mensal × 12
- **ROI** = Economia Anual ÷ Custo da Automação × 100%

Essas fórmulas são um apoio opcional para dar peso numérico a algum gargalo (ex: Gestão Financeira ou Gestão e Processos) — não é obrigatório aplicá-las em todos os módulos.
