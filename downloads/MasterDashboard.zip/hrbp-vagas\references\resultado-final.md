# Template — Resultado Final

Use este template ao gerar o Resultado Final. Preencha com base em tudo que foi coletado. Não deixe seções vazias — se não coletado, sinalize como "a definir" e liste como gap.

---

## 1. Resumo Executivo da Contratação

**Cargo:** [título]
**Área:** [área / squad]
**Senioridade:** [nível]
**Gestor:** [nome / cargo]

**Motivo da Contratação:** [reposição / expansão / nova necessidade]

**Problema de Negócio:**
> [Descrição objetiva do problema que motivou a vaga]

**Impacto Esperado:**
> [O que muda no negócio com essa contratação bem-sucedida]

**Perfil Ideal em uma linha:**
> [Ex: "Profissional sênior de dados com visão de produto e experiência em ambientes de alta escala"]

---

## 2. Hiring Readiness Index

**HRI: [score]/100**

> [Status: Pronto para recrutamento / Boa definição com ajustes / etc.]

**Gaps identificados:**
- [Gap 1]
- [Gap 2]

---

## 3. Quality Score

**Quality Score: [score]/100**

> Classificação: [Excelente / Muito boa / Boa / Baixa]

---

## 4. Principais Riscos

1. **[Nome do risco]** — [descrição e impacto esperado]
2. **[Nome do risco]** — [descrição e impacto esperado]
3. ...

*(Listar no máximo 5)*

---

## 5. Recomendações

- [Ação recomendada 1]
- [Ação recomendada 2]
- [Ação recomendada 3]

---

## 6. Job Description Completo

---

### [Título do Cargo] | [Área] | [Empresa]

---

#### Sobre a Oportunidade

[2–3 parágrafos: contexto da empresa/área, o momento atual, por que esta vaga existe agora e qual o impacto que a pessoa terá. Linguagem atrativa, sem corporativiês.]

---

#### Missão da Posição

> [Uma frase que resume o propósito central do cargo. Ex: "Liderar a evolução da plataforma de dados, tornando informação um ativo estratégico para todo o negócio."]

---

#### Principais Responsabilidades

- [Responsabilidade objetiva com verbo de ação]
- [...]
*(5 a 8 itens — ordenar por relevância)*

---

#### Requisitos Obrigatórios

- [Requisito técnico 1]
- [...]
*(Somente o que é realmente bloqueador — máximo 6 itens)*

---

#### Diferenciais (desejável, não eliminatório)

- [Diferencial 1]
- [...]

---

#### Competências Comportamentais

- [Competência 1]
- [...]
*(3 a 5 itens — as mais críticas para o contexto)*

---

#### Como será medido o sucesso nos primeiros 12 meses

- [Indicador mensurável 1]
- [...]

---

#### Modelo de Trabalho

[Presencial / Híbrido (X dias/semana) / 100% Remoto]
[Localização, se aplicável]

---

#### Remuneração e Benefícios

**Faixa salarial:** [range ou "a combinar"]
**Tipo de contratação:** [CLT / PJ]
**Benefícios:** [lista]
**Remuneração variável:** [bônus / PLR / comissão — se houver]

---

#### Sobre a [Empresa]

[2–3 frases sobre a empresa: missão, porte, momento, cultura.]

---

#### Processo Seletivo

1. Triagem de currículos
2. Entrevista de fit cultural (RH)
3. Entrevista técnica (gestor)
4. Entrevista final / case (se aplicável)
5. Proposta

---

*Job Description gerado com suporte do HRBP Vagas — G4 OS*