---
name: Master Dashboard
description: Sincroniza relatórios HTML com o Google Drive local e insere o código no Master Dashboard.
trigger: /dash
---

Sempre que o usuário solicitar para gerar ou atualizar um novo relatório, planejamento ou roteiro de reunião em HTML, execute este fluxo:

1. Identifique o nome do cliente.
2. Acesse a pasta correspondente no Google Drive local:
   `G:\Meu Drive\VENDA+ TECH\CLIENTES VENDA+ TECH\ANDAMENTO\CLIENTE DR. <NOME_DO_CLIENTE>\`
3. Salve o HTML do relatório individual nessa pasta.
4. Abra o arquivo `master_dashboard.html` localizado na pasta principal: `G:\Meu Drive\VENDA+ TECH\`.
5. Localize a tag `<textarea id="data-<nome_do_arquivo>">` e injete todo o código HTML atualizado do arquivo gerado no lugar do conteúdo anterior, mantendo a tag de fechamento `</textarea>` íntegra.
6. Certifique-se de que a formatação e métricas no roteiro individual correspondam exatamente às que estão no painel consolidado.
