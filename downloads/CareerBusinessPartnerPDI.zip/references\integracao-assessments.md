# Integração de Assessments no PDI

## Os 4 Assessments

1. **Âncoras de Carreira** — Motivações profundas e núcleo de valores
2. **Wingfinder** — Forças comportamentais em ação
3. **Big Five OCEAN** — Traços de personalidade estáveis
4. **16 Personalities** — Tipo cognitivo-comportamental

---

## 1. Âncoras de Carreira → Clareza de Objetivo

Responde: "Para onde essa pessoa deveria ir?"

| Âncora | Gaps Prováveis | O Que Desenvolver |
|---|---|---|
| TF | Visibilidade, comunicação executiva | Vender ideias, construir reputação fora da área |
| GG | Inteligência política, gestão de pessoas | Escuta ativa, gestão de conflitos, visão sistêmica |
| AI | Colaboração, gestão de expectativas | Trabalhar dentro de restrições sem perder a essência |
| SE | Tolerância à ambiguidade, iniciativa | Agir sem garantias, assumir riscos calculados |
| CE | Execução, disciplina de processos | Equilibrar criatividade com entrega consistente |
| SD | Comunicação de impacto, influência | Conectar resultados de negócio com propósito |
| PD | Consistência, projetos de longo prazo | Criar estrutura para sustentar entregas pós-desafio |
| EV | Comunicação de limites, proatividade | Articular prioridades sem perder oportunidades |

---

## 2. Wingfinder → Mapa de Competências Comportamentais

| Dimensão | Alto | Baixo |
|---|---|---|
| Connections | Gap: assertividade, feedbacks difíceis | Gap: influência, visibilidade, construção de aliados |
| Thinking | Gap: execução rápida, decisão incompleta | Gap: análise crítica, pensamento estratégico |
| Drive | Gap: delegação, paciência estratégica | Gap: iniciativa, visibilidade, comprometimento público |
| Resilience | Gap: reconhecer limites, pedir suporte | Gap: tolerância à ambiguidade, performance sob pressão |

---

## 3. Big Five OCEAN → Competências + Risco de Execução

| Traço | Alto | Baixo |
|---|---|---|
| O | Gap: foco, consistência em projetos longos | Gap: adaptabilidade, pensamento criativo |
| C | Gap: velocidade, delegação, tolerância ao caos | Gap: disciplina de execução, confiabilidade |
| E | Gap: escuta ativa, comunicação bidirecional | Gap: visibilidade, influência em grupos |
| A | Gap: assertividade, feedback difícil, limites | Gap: colaboração, gestão de relacionamento |
| N | Gap: equilíbrio emocional, performance sob pressão | Gap: senso de urgência |

**C alto + J no 16P → Alta capacidade de execução no CRI (score 4–5)**
**C baixo + P no 16P → Risco de execução → incluir sistemas de accountability no PDI**

---

## 4. 16 Personalities → Estilo de Trabalho e Aprendizagem

| Dimensão | Tipo | Gap Frequente |
|---|---|---|
| Mind | I | Visibilidade, networking proativo, comunicação executiva |
| Mind | E | Escuta ativa, reflexão antes de agir |
| Energy | N | Execução, atenção a detalhes operacionais |
| Energy | S | Pensamento estratégico, visão de longo prazo |
| Nature | T | Inteligência emocional, liderança de pessoas |
| Nature | F | Assertividade, decisão fria, feedback crítico |
| Tactics | J | Flexibilidade, tolerância ao caos, pivô rápido |
| Tactics | P | Disciplina de entrega, gestão de projetos |
| Identity | -T | Equilíbrio emocional, autocompaixão produtiva |
| Identity | -A | Senso de urgência, busca ativa de desafios |

---

## Tabela de Cruzamentos

| Combinação | Perfil | Desenvolver |
|---|---|---|
| GG + C alto | Líder executor estruturado | Delegação real, tolerância à imperfeição |
| TF + IN** | Especialista invisível | Comunicação executiva, visibilidade estratégica |
| Drive alto + N alto | Motor ansioso | Regulação emocional, autocompaixão produtiva |
| AI + **P | Autonomia sem estrutura | Rituais de execução, comprometimento com deadlines |
| A alto + **F | Conector empático | Assertividade, liderança corajosa |
| CE alta + O alto | Empreendedor conceitual | Execução disciplinada, foco e priorização |
| SE alta + **J | Executor conservador | Tolerância ao risco calculado, iniciativa |

---

## Protocolo de Uso dos Assessments

**4 assessments disponíveis:** Cruzar usando tabela de combinações. Calibrar CRI com objetividade.
**Apenas alguns assessments:** Prioridade: Âncoras → Big Five → Wingfinder → 16P
**Nenhum assessment:** Construir PDI com base na conversa. Sinalizar que assessments agregariam profundidade e precisão ao diagnóstico.