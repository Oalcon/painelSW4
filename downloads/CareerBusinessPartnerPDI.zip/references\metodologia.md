# Metodologia de PDI — Career Business Partner

## 1. Career Readiness Index (CRI)

Mede o grau de prontidão do profissional para executar um PDI eficaz.

### Componentes e Pesos

| Componente | Peso | Score 1-5 |
|---|---|---|
| Clareza dos Objetivos | 20 pts | Vago (1) → Específico com trade-offs (5) |
| Competências Técnicas | 20 pts | Sem mapeamento (1) → Preciso e autocrítico (5) |
| Competências Comportamentais | 20 pts | Sem consciência (1) → Alta maturidade (5) |
| Consistência do Plano | 15 pts | Desconexo (1) → Alta consistência (5) |
| Ações Definidas | 15 pts | Nenhuma (1) → Priorizadas com prazo (5) |
| Capacidade de Execução | 10 pts | Histórico de abandono (1) → Alta disciplina (5) |

**Fórmula:** `CRI = Σ (score_i / 5) × peso_i`

### Interpretação

| Faixa | Classificação | Ação |
|---|---|---|
| 0–25 | Imaturo | Focar em clareza antes do PDI |
| 26–50 | Em Formação | PDI simplificado, 1–2 objetivos |
| 51–75 | Preparado | PDI completo com revisão em 90 dias |
| 76–90 | Maduro | PDI ambicioso, 12 meses |
| 91–100 | Excelente | PDI como aceleração estratégica |

---

## 2. Development Quality Score (DQS)

Avalia a qualidade do PDI produzido. Calculado apenas no Resultado Final.

| Critério | Peso |
|---|---|
| Clareza dos objetivos | 20 pts |
| Priorização correta | 15 pts |
| Metas SMART | 20 pts |
| Ações práticas | 15 pts |
| Indicadores definidos | 10 pts |
| Viabilidade do plano | 10 pts |
| Alinhamento com carreira | 10 pts |

| Faixa | Classificação |
|---|---|
| 0–59 | Fraco — retrabalhar |
| 60–79 | Bom |
| 80–89 | Muito Bom |
| 90–100 | Excelente |

---

## 3. Framework 70-20-10

```
70% → Experiências práticas no trabalho
20% → Aprendizagem social (pessoas)
10% → Aprendizagem formal (conteúdo estruturado)
```

**70% — Exemplos:** Liderar projeto novo, assumir entrega crítica, job rotation, gestão de crise, mentorear alguém, apresentar para C-level.

**20% — Exemplos:** Mentoria formal, coaching, feedback 360, shadowing de liderança, comunidades de prática.

**10% — Exemplos:** Cursos online, certificações, livros, MBA, workshops, conferências.

**Regra prática:** Para cada meta, definir pelo menos 1 ação de cada categoria (70/20/10).

---

## 4. Metas SMART

**Template:** `[VERBO] + [OBJETO ESPECÍFICO] + [CRITÉRIO MENSURÁVEL] + [PRAZO] + [RELEVÂNCIA]`

**Checklist SMART:** Specific · Measurable · Achievable · Relevant · Time-bound

**Transformação de objetivos genéricos:**

| Genérico | SMART |
|---|---|
| "Melhorar comunicação" | "Até set/2026, conduzir 3 apresentações para diretoria com feedback ≥8/10 de 2 stakeholders" |
| "Quero ser líder melhor" | "Até dez/2026, implementar 1:1s semanais, atingir NPS interno ≥8 e ter 1 pessoa do time promovida" |
| "Aprender dados" | "Até ago/2026, concluir formação SQL (40h) e entregar 1 dashboard em produção usado semanalmente" |

---

## 5. Roadmap Padrão por Horizonte

**30 dias — Fundação:**
- Documentar e compartilhar PDI
- Estabelecer rituais de desenvolvimento
- Iniciar ação mais urgente
- Mapear 3 stakeholders-chave

**90 dias — Execução Inicial:**
- Completar primeira ação formal de aprendizagem
- Receber feedback estruturado em entrega relevante
- Assumir responsabilidade stretch
- Reavaliar CRI

**6 meses — Tração:**
- Entregar projeto stretch com resultado documentado
- Consolidar novos comportamentos
- Expandir visibilidade em novo contexto
- Conversa de carreira com liderança

**12 meses — Consolidação:**
- Atingir ≥80% das metas SMART
- Evidências concretas de desenvolvimento
- Conversa de progressão formal
- DQS retroativo para próximo ciclo