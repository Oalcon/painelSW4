# Editable PPTX Export: HTML Hard Constraints + Size Decisions + Common Errors

This document covers the path of **translating HTML element-by-element into truly editable PowerPoint text boxes using `scripts/html2pptx.js` + `pptxgenjs`** — the only path supported by `export_deck_pptx.mjs`.

> **Core prerequisite**: To take this path, the HTML must be written following the 4 constraints below from the very first line. **Do not write first and convert later** — retrofitting will trigger 2–3 hours of rework (confirmed by the 2026-04-20 options board project).
>
> For scenarios where visual fidelity takes priority (animations / web components / CSS gradients / complex SVG), use the PDF path instead (`export_deck_pdf.mjs` / `export_deck_stage_pdf.mjs`). **Do not** expect the PPTX export to deliver both visual fidelity and editability — this is a physical constraint of the PPTX file format itself (see "Why the 4 Constraints are Physical Constraints, Not Bugs" at the end).

---

## Canvas Size: Use 960×540pt (LAYOUT_WIDE)

PPTX units are **inches** (physical dimensions), not px. The decision principle: the body's computedStyle dimensions must **match the presentation layout's inch dimensions** (±0.1", enforced by `html2pptx.js`'s `validateDimensions` check).

### 3 candidate sizes compared

| HTML body | Physical size | Corresponding PPT layout | When to use |
|---|---|---|---|
| **`960pt × 540pt`** | **13.333″ × 7.5″** | **pptxgenjs `LAYOUT_WIDE`** | ✅ **Default recommendation** (modern PowerPoint 16:9 standard) |
| `720pt × 405pt` | 10″ × 5.625″ | Custom | Only when the user specifies a "legacy PowerPoint Widescreen" template |
| `1920px × 1080px` | 20″ × 11.25″ | Custom | ❌ Non-standard size; fonts appear abnormally small after projection |

**Don't think of HTML dimensions as resolution.** PPTX is a vector document — the body dimensions determine **physical size**, not clarity. A large body (20″×11.25″) will not make text sharper — it will only make font sizes appear smaller relative to the canvas, looking worse when projected or printed.

### Three equivalent body declarations (pick one)

```css
body { width: 960pt;  height: 540pt; }    /* Clearest, recommended */
body { width: 1280px; height: 720px; }    /* Equivalent, px convention */
body { width: 13.333in; height: 7.5in; }  /* Equivalent, inch intuition */
```

Corresponding pptxgenjs code:

```js
const pptx = new pptxgen();
pptx.layout = 'LAYOUT_WIDE';  // 13.333 × 7.5 inch, no custom definition needed
```

---

## 4 Hard Constraints (Violations Will Cause Direct Errors)

`html2pptx.js` translates the HTML DOM element-by-element into PowerPoint objects. PowerPoint's format constraints projected onto HTML = the 4 rules below.

### Rule 1: Text inside a DIV must be wrapped in `<p>` or `<h1>`–`<h6>` — not placed directly

```html
<!-- ❌ Wrong: text directly inside div -->
<div class="title">Q3 Revenue Up 23%</div>

<!-- ✅ Correct: text inside <p> or <h1>-<h6> -->
<div class="title"><h1>Q3 Revenue Up 23%</h1></div>
<div class="body"><p>New users are the primary driver</p></div>
```

**Why**: PowerPoint text must exist inside a text frame, which corresponds to HTML block-level elements (p/h*/li). A bare `<div>` has no corresponding text container in PPTX.

**`<span>` cannot carry primary text either** — span is an inline element and cannot independently align as a text box. Spans should only appear **nested inside p/h\*** for local styling (bold, color changes).

### Rule 2: No CSS gradients — only solid colors

```css
/* ❌ Wrong */
background: linear-gradient(to right, #FF6B6B, #4ECDC4);

/* ✅ Correct: solid color */
background: #FF6B6B;

/* ✅ If multiple colors are needed, use flex child elements with individual solid colors */
.stripe-bar { display: flex; }
.stripe-bar div { flex: 1; }
.red   { background: #FF6B6B; }
.teal  { background: #4ECDC4; }
```

**Why**: PowerPoint's shape fill only supports solid/gradient-fill, but pptxgenjs's `fill: { color: ... }` only maps to solid. Supporting PowerPoint's native gradient requires a different structure that the current toolchain does not support.

### Rule 3: Backgrounds/borders/shadows belong on DIVs — not on text tags

```html
<!-- ❌ Wrong: <p> has a background color -->
<p style="background: #FFD700; border-radius: 4px;">Key content</p>

<!-- ✅ Correct: outer div carries the background/border, <p> handles text only -->
<div style="background: #FFD700; border-radius: 4px; padding: 8pt 12pt;">
  <p>Key content</p>
</div>
```

**Why**: In PowerPoint, a shape (rectangle/rounded rectangle) and a text frame are two separate objects. An HTML `<p>` only translates to a text frame — backgrounds/borders/shadows belong to the shape and must be written on the **div that wraps the text**.

### Rule 4: No `background-image` on DIVs — use `<img>` tags instead

```html
<!-- ❌ Wrong -->
<div style="background-image: url('chart.png')"></div>

<!-- ✅ Correct -->
<img src="chart.png" style="position: absolute; left: 50%; top: 20%; width: 300pt; height: 200pt;" />
```

**Why**: `html2pptx.js` only extracts image paths from `<img>` elements — it does not parse CSS `background-image` URLs.

---

## Path A HTML Template Skeleton

One independent HTML file per slide, with isolated scopes (avoids CSS pollution in single-file decks).

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    width: 960pt; height: 540pt;           /* ⚠️ Must match LAYOUT_WIDE */
    font-family: system-ui, -apple-system, "PingFang SC", sans-serif;
    background: #FEFEF9;                    /* Solid color — no gradients */
    overflow: hidden;
  }
  /* DIV handles layout / backgrounds / borders */
  .card {
    position: absolute;
    background: #1A4A8A;                    /* Background on the DIV */
    border-radius: 4pt;
    padding: 12pt 16pt;
  }
  /* Text tags handle font styles only — no backgrounds or borders */
  .card h2 { font-size: 24pt; color: #FFFFFF; font-weight: 700; }
  .card p  { font-size: 14pt; color: rgba(255,255,255,0.85); }
</style>
</head>
<body>

  <!-- Title area: outer div for positioning, inner text tags for content -->
  <div style="position: absolute; top: 40pt; left: 60pt; right: 60pt;">
    <h1 style="font-size: 36pt; color: #1A1A1A; font-weight: 700;">Use a declarative statement for the title, not a topic word</h1>
    <p style="font-size: 16pt; color: #555555; margin-top: 10pt;">Subtitle provides supplementary context</p>
  </div>

  <!-- Content card: div handles background, h2/p handle text -->
  <div class="card" style="top: 130pt; left: 60pt; width: 240pt; height: 160pt;">
    <h2>Key Point One</h2>
    <p>Brief explanatory text</p>
  </div>

  <!-- List: use ul/li — do not add bullet symbols manually -->
  <div style="position: absolute; top: 320pt; left: 60pt; width: 540pt;">
    <ul style="font-size: 16pt; color: #1A1A1A; padding-left: 24pt; list-style: disc;">
      <li>First bullet point</li>
      <li>Second bullet point</li>
      <li>Third bullet point</li>
    </ul>
  </div>

  <!-- Illustration: use <img> tag — not background-image -->
  <img src="illustration.png" style="position: absolute; right: 60pt; top: 110pt; width: 320pt; height: 240pt;" />

</body>
</html>
```

---

## Common Error Reference

| Error message | Cause | Fix |
|---------|------|---------|
| `DIV element contains unwrapped text "XXX"` | Bare text directly in div | Wrap text in `<p>` or `<h1>`–`<h6>` |
| `CSS gradients are not supported` | linear/radial-gradient used | Change to solid color, or use flex child elements for segments |
| `Text element <p> has background` | `<p>` tag has a background color | Wrap with outer `<div>` for the background; `<p>` handles text only |
| `Background images on DIV elements are not supported` | div uses background-image | Change to `<img>` tag |
| `HTML content overflows body by Xpt vertically` | Content exceeds 540pt | Reduce content or font sizes, or use `overflow: hidden` to clip |
| `HTML dimensions don't match presentation layout` | body dimensions don't match the presentation layout | Use `960pt × 540pt` with `LAYOUT_WIDE`; or use defineLayout to customize |
| `Text box "XXX" ends too close to bottom edge` | Large-font `<p>` is less than 0.5 inch from the bottom of body | Move it up — leave adequate bottom margin; PPT itself clips some of the bottom area |

---

## Basic Workflow (3 Steps to PPTX)

### Step 1: Write each slide as an independent HTML file following the constraints

```
My Deck/
├── slides/
│   ├── 01-cover.html    # Each file is a complete 960×540pt HTML document
│   ├── 02-agenda.html
│   └── ...
└── illustration/        # All images referenced by <img> tags
    ├── chart1.png
    └── ...
```

### Step 2: Write build.js to call `html2pptx.js`

```js
const pptxgen = require('pptxgenjs');
const html2pptx = require('../scripts/html2pptx.js');  // This skill's script

(async () => {
  const pres = new pptxgen();
  pres.layout = 'LAYOUT_WIDE';  // 13.333 × 7.5 inch, matches HTML's 960×540pt

  const slides = ['01-cover.html', '02-agenda.html', '03-content.html'];
  for (const file of slides) {
    await html2pptx(`./slides/${file}`, pres);
  }

  await pres.writeFile({ fileName: 'deck.pptx' });
})();
```

### Step 3: Open and verify

- Open the exported PPTX in PowerPoint / Keynote
- Double-clicking any text should allow direct editing (if it shows as an image, Rule 1 was violated)
- Verify overflow: each page should fit within the body bounds with nothing clipped

---

## This Path vs Other Options (When to Use What)

| Need | Use |
|------|------|
| Colleagues will edit text in the PPTX / sending to non-technical people to continue editing | **This document's path** (editable — HTML must be written from the start following the 4 constraints) |
| Only for presentation / archiving, no further editing needed | `export_deck_pdf.mjs` (multi-file) or `export_deck_stage_pdf.mjs` (single-file deck-stage) — outputs vector PDF |
| Visual fidelity is priority (animations, web components, CSS gradients, complex SVG), non-editable is acceptable | **PDF** (same as above) — PDF is both faithful and cross-platform, more appropriate than "image PPTX" |

**Never run html2pptx on a visually-driven HTML** — in practice, pass rate for visual-first HTML is <30%, and fixing the remaining issues per page is slower than rewriting. Use PDF for this scenario, not a forced PPTX.

---

## Fallback: Existing Visual Draft but User Insists on Editable PPTX

You may occasionally encounter this: you/the user has already written a visually-driven HTML (gradients, web components, complex SVG all used), PDF would be ideal, but the user explicitly says "no, it must be editable PPTX."

**Do not run `html2pptx` and expect it to pass** — in practice, visually-driven HTML has a <30% pass rate with html2pptx, and the remaining 70% will either error or look wrong. The correct fallback is:

### Step 1 · Communicate limitations first (transparent communication)

In one message, tell the user three things clearly:

> "Your current HTML uses [list specifically: gradients / web components / complex SVG / ...], which will fail to convert to editable PPTX. I have two options:
> - A. **Export PDF** (recommended) — 100% visual fidelity, recipients can view and print but cannot edit text
> - B. **Rewrite an editable version based on the visual draft** (preserving the design decisions around color/layout/copy, but restructuring the HTML following the 4 hard constraints, **sacrificing** gradients, web components, complex SVG, and similar visual capabilities) → then export editable PPTX
>
> Which would you prefer?"

Don't downplay option B — clearly state **what will be lost**. Let the user make the trade-off.

### Step 2 · If the user chooses B: the AI rewrites — don't ask the user to do it themselves

The doctrine here is: **the user provides design intent; you are responsible for translating it into a compliant implementation**. Do not ask the user to learn the 4 hard constraints and rewrite it themselves.

Principles for rewriting:
- **Preserve**: color system (primary/secondary/neutral colors), information hierarchy (title/subtitle/body/annotations), core copy, layout skeleton (top-middle-bottom / left-right split / grid), page rhythm
- **Downgrade**: CSS gradients → solid colors or flex segments; web components → block-level HTML; complex SVG → simplified `<img>` or solid geometry; shadows → removed or reduced to minimal; custom fonts → fallback to system fonts
- **Rewrite**: bare text → wrapped in `<p>` / `<h*>`; `background-image` → `<img>` tag; background/border on `<p>` → moved to outer div

### Step 3 · Provide a before/after reference (transparent delivery)

After rewriting, give the user a before/after comparison so they know which visual details were simplified:

```
Original design → Editable version adjustments
- Title area purple gradient → Primary color #5B3DE8 solid background
- Data card shadow → Removed (replaced with 2pt border for separation)
- Complex SVG line chart → Simplified to <img> PNG (screenshot from HTML)
- Hero web component animation → Static first frame (web component cannot be translated)
```

### Step 4 · Export & deliver both formats

- `editable` HTML → run `scripts/export_deck_pptx.mjs` to export editable PPTX
- **Recommended to also retain** original visual draft → run `scripts/export_deck_pdf.mjs` for high-fidelity PDF
- Deliver both formats to user: PDF of the visual draft + editable PPTX — each serving its purpose

### When to outright decline option B

In certain scenarios the rewrite cost is too high and you should advise the user to abandon the editable PPTX:
- The core value of the HTML is animation or interactivity (after rewriting, only a static first frame remains — information loss of 50%+)
- More than 30 slides — rewrite cost exceeds 2 hours
- Visual design deeply depends on precise SVG / custom filters (after rewriting, the result is nearly unrelated to the original)

In these cases, tell the user: "The rewrite cost for this deck is too high — I recommend a PDF instead of PPTX. If the recipient specifically requires the PPTX format, be prepared to accept significant visual simplification — would you like to switch to PDF?"

---

## Why the 4 Constraints are Physical Constraints, Not Bugs

These 4 rules are not the result of the `html2pptx.js` author cutting corners — they are the constraints of **the PowerPoint file format (OOXML) itself** projected onto HTML:

- Text in PPTX must be in a text frame (`<a:txBody>`), which corresponds to block-level HTML elements
- In PPTX, a shape and a text frame are two separate objects — you cannot both draw a background and write text on the same element
- PPTX shape fill support for gradients is limited (only certain preset gradients; arbitrary CSS angle gradients are not supported)
- PPTX picture objects must reference real image files, not CSS properties

Once you understand this, **don't expect the tool to become smarter** — the HTML writing approach must adapt to the PPTX format, not the other way around.
