# Wingfinder — 60 Perguntas do Assessment

> Escala: 1=Discordo totalmente | 2=Discordo | 3=Neutro | 4=Concordo | 5=Concordo totalmente

## CONNECTIONS (1–15)

1. Consigo perceber facilmente quando alguém está desconfortável, mesmo que não diga nada.
2. Quando alguém me conta um problema, meu primeiro impulso é entender como ele está se sentindo antes de oferecer soluções.
3. Percebo rapidamente as mudanças de humor das pessoas com quem convivo.
4. Consigo me colocar no lugar de pessoas com visões de mundo muito diferentes da minha.
5. As pessoas costumam me procurar quando precisam ser ouvidas ou compreendidas.
6. Me sinto à vontade ao conhecer pessoas novas em ambientes profissionais ou sociais.
7. Entrar em uma sala com pessoas que não conheço não me gera ansiedade ou desconforto significativo.
8. Consigo iniciar conversas com facilidade, mesmo com pessoas muito diferentes de mim.
9. Apresentar minhas ideias para grupos — pequenos ou grandes — é algo com que me sinto confortável.
10. Tenho facilidade em me adaptar ao estilo de comunicação de diferentes pessoas.
11. Consigo persuadir pessoas a adotarem meu ponto de vista sem precisar pressionar ou impor.
12. Quando defendo uma ideia, as pessoas tendem a me ouvir com atenção e abertura.
13. Tenho facilidade em mobilizar outras pessoas em torno de um objetivo comum.
14. Consigo identificar o que motiva cada pessoa e usar isso para engajá-las.
15. Quando preciso de apoio para um projeto ou ideia, raramente tenho dificuldade em conquistar aliados.

## THINKING (16–30)

16. Quando enfrento um problema complexo, busco dados e evidências antes de tirar conclusões.
17. Tenho facilidade em identificar inconsistências ou falhas lógicas em argumentos e planos.
18. Prefiro entender a causa raiz de um problema a tratar apenas seus sintomas.
19. Consigo decompor problemas grandes em partes menores e resolver cada parte sistematicamente.
20. Ao tomar decisões importantes, naturalmente considero múltiplos cenários e suas consequências.
21. Frequentemente gero ideias ou soluções que as outras pessoas ainda não tinham considerado.
22. Sinto prazer em explorar conexões entre áreas ou assuntos aparentemente sem relação.
23. A ambiguidade e a falta de definição me energizam mais do que me paralisam.
24. Tenho facilidade em pensar "fora da caixa" quando as soluções convencionais não funcionam.
25. As pessoas ao meu redor reconhecem minha capacidade de propor abordagens criativas e originais.
26. Aprendo novos conceitos e habilidades com mais velocidade do que a maioria das pessoas que conheço.
27. Me adapto bem quando preciso trabalhar em áreas ou projetos que não dominava antes.
28. Tenho curiosidade genuína por temas variados — é comum que eu explore áreas fora da minha especialidade.
29. Quando enfrento um novo desafio, me sinto energizado pela oportunidade de aprender, não intimidado.
30. Consigo absorver e aplicar conhecimentos novos de forma rápida e prática.

## DRIVE (31–45)

31. Estabeleço metas ambiciosas para mim mesmo, mesmo quando ninguém está me exigindo isso.
32. Tenho dificuldade em me contentar com resultados mediocres — sempre busco superar meu próprio desempenho anterior.
33. Sinto motivação genuína em alcançar objetivos difíceis, não apenas os fáceis.
34. Quando atinjo uma meta, rapidamente direciono energia para o próximo desafio.
35. Meu padrão de qualidade é alto — me incomoda entregar algo abaixo do que sei que posso fazer.
36. Sob pressão intensa, minha capacidade de tomar decisões se mantém estável ou melhora.
37. Prazos apertados tendem a me energizar mais do que me paralisar.
38. Consigo manter clareza e foco mesmo quando há muitas variáveis fora do meu controle.
39. Em situações de crise, as pessoas costumam me ver como alguém que mantém a calma e direciona o grupo.
40. Meu nível de performance não cai significativamente em períodos de alta demanda ou estresse.
41. Identifico oportunidades de melhoria e ajo sobre elas sem precisar que alguém me solicite.
42. Prefiro iniciar ações e ajustar no caminho a esperar por todas as informações antes de começar.
43. Quando vejo um problema que precisa ser resolvido, assumo a responsabilidade mesmo que não seja "meu dever".
44. Tenho histórico de transformar ideias em projetos concretos por iniciativa própria.
45. Me sinto incomodado quando estou em um ambiente onde não posso agir com autonomia e proatividade.

## RESILIENCE (46–60)

46. Recupero-me de situações frustrantes ou decepcionantes com relativa rapidez.
47. Eventos estressantes do dia raramente me tiram do eixo por períodos prolongados.
48. Consigo separar críticas ao meu trabalho de críticas à minha identidade ou valor como pessoa.
49. Em situações de conflito, consigo manter equilíbrio emocional e não reagir por impulso.
50. As pessoas ao meu redor me descrevem como alguém emocionalmente estável e previsível.
51. Mesmo diante de resultados negativos ou fracassos, mantenho a crença de que as coisas podem melhorar.
52. Encaro os obstáculos como parte natural do caminho, não como sinais de que algo está fundamentalmente errado.
53. Tenho uma perspectiva genuinamente positiva sobre o futuro — não por ingenuidade, mas por convicção.
54. Quando algo dá errado, meu foco vai naturalmente para o que posso aprender ou fazer diferente.
55. As pessoas ao meu redor sentem que meu otimismo é autêntico e contagiante, não forçado.
56. Continuo perseguindo objetivos importantes mesmo quando o progresso é lento ou os resultados demoram.
57. Diante de rejeições repetidas, meu comprometimento com o objetivo não diminui significativamente.
58. Tenho histórico de concluir projetos longos e difíceis que outras pessoas desistiram no meio.
59. Quando enfrento um obstáculo que bloqueia meu caminho, busco ativamente alternativas em vez de desistir.
60. Minha determinação em alcançar algo que considero importante é difícil de ser desgastada por circunstâncias externas.