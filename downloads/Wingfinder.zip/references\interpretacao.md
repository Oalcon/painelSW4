# Wingfinder — Guia de Interpretação

## Por Dimensão

### CONNECTIONS Alta (≥70%)
Socialmente fluente. Lê ambientes, constrói vínculos autenticamente, mobiliza pessoas. Ambiente ideal: liderança, parcerias, vendas consultivas, gestão de stakeholders.
Atenção: alta empatia pode gerar sobrecarga; harmonia pode conflitar com decisões difíceis.

### CONNECTIONS Baixa (<55%)
Força em desenvolvimento. Interações demandam mais energia consciente. Estratégia: profundidade em poucas relações; preparação prévia para reuniões importantes.

### THINKING Alta (≥70%)
Processa com rigor e originalidade. Faz perguntas que ninguém fez, vai à raiz dos problemas, aprende novos domínios com rapidez. Ambiente ideal: estratégia, P&D, consultoria, arquitetura de sistemas.
Atenção: pode levar a paralisia analítica; dificuldade em comunicar para públicos não-técnicos.

### THINKING Baixa (<55%)
Força em desenvolvimento. Funciona melhor com frameworks claros e menos ambiguidade. Estratégia: usar times com Thinking alto para diagnóstico.

### DRIVE Alta (≥70%)
Motor próprio. Age sem estímulo externo, mantém foco sob pressão, estabelece padrões altos. Ambiente ideal: liderança executiva, empreendedorismo, projetos de alto impacto.
Atenção: pode gerar burnout sem Resilience correspondente; atrito com perfis contemplativos.

### DRIVE Baixa (<55%)
Força em desenvolvimento. Motivação mais situacional. Estratégia: conectar tarefas a impacto real; criar rituais de energia.

### RESILIENCE Alta (≥70%)
Robustez psicológica. Fracassos não paralisam, adversidades não destroem longo prazo. Ambiente ideal: alta volatilidade, empreendedorismo, crises, projetos de transformação.
Atenção: pode mascarar esgotamento legítimo; pode normalizar contextos disfuncionais.

### RESILIENCE Baixa (<55%)
Força em desenvolvimento. Recuperação emocional demanda mais esforço consciente. Estratégia: criar estrutura de recuperação intencional; reduzir ambiguidade nos projetos.

---

## Combinações de Forças

- **CONNECTIONS + DRIVE** = Líder Inspirador — mobiliza times com autenticidade e metas claras
- **THINKING + RESILIENCE** = Analista Estratégico — pensa com rigor, sustenta projetos de longo prazo
- **DRIVE + RESILIENCE** = Empreendedor Resiliente — executa e absorve fracassos, não para
- **CONNECTIONS + THINKING** = Consultor Criativo — soluções sofisticadas comunicadas de forma que as pessoas abraçam
- **DRIVE + THINKING** = Arquiteto de Resultados — ambição por resultados + capacidade de pensar bem
- **CONNECTIONS + RESILIENCE** = Líder de Equilíbrio — porto seguro, presença confiável
- **THINKING + DRIVE** = Inovador Executivo — pensa grande e faz acontecer
- **RESILIENCE + CONNECTIONS** = Âncora Relacional — cria vínculos duráveis, permanece presente em crise

---

## Próximos Passos por Perfil Dominante

| Dominante | Ação Recomendada |
|---|---|
| CONNECTIONS | Mapear top 5 relações de maior alavancagem. Investir intencionalmente este trimestre |
| THINKING | Identificar problema complexo não resolvido. Dedicar tempo estruturado para atacá-lo |
| DRIVE | Revisar metas atuais — estão calibradas para desafiar de verdade? Ajustar o que ficou fácil |
| RESILIENCE | Mapear onde está "aguentando" em vez de "mudando". Há algo a confrontar, não só suportar? |