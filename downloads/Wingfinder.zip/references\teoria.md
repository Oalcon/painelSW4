# Wingfinder — Framework Teórico

## Contexto e Origem

Desenvolvido pela Red Bull em parceria com psicólogos do King's College London. Objetivo: identificar forças comportamentais de alta performance. Base científica: psicologia positiva (Seligman), psicometria comportamental e teoria dos traços.

## As 4 Dimensões

### CONNECTIONS — Inteligência Social (Qs 1–15)

Subdimensões:
- **Empathy (1–5):** Perceber e compreender emoções, perspectivas e necessidades dos outros
- **Social Confidence (6–10):** Conforto em interações sociais — de conversas informais a apresentações
- **Influence (11–15):** Persuadir, inspirar e mobilizar pessoas

### THINKING — Capacidade Cognitiva (Qs 16–30)

Subdimensões:
- **Analytical Thinking (16–20):** Raciocínio lógico, decomposição de problemas, conclusões fundamentadas
- **Creative Thinking (21–25):** Ideias originais, conexões não-óbvias, conforto com ambiguidade
- **Learning Agility (26–30):** Velocidade de absorção de novos conhecimentos e adaptação

### DRIVE — Motivação e Propósito (Qs 31–45)

Subdimensões:
- **Achievement Orientation (31–35):** Foco em metas, desempenho e superação de padrões anteriores
- **Resilience Under Pressure (36–40):** Performance e clareza em situações de alta pressão
- **Initiative (41–45):** Proatividade e ação sem direcionamento externo

### RESILIENCE — Força Mental (Qs 46–60)

Subdimensões:
- **Emotional Stability (46–50):** Regulação emocional, equilíbrio diante de flutuações externas
- **Optimism (51–55):** Perspectiva positiva sobre futuro, capacidades e resolubilidade
- **Persistence (56–60):** Esforço sustentado diante de obstáculos e rejeições

## Mapeamento de Perguntas

| Dimensão | Perguntas |
|---|---|
| CONNECTIONS | 1–15 |
| THINKING | 16–30 |
| DRIVE | 31–45 |
| RESILIENCE | 46–60 |

## Interpretação de Scores

| % | Classificação |
|---|---|
| 85–100% | Força Excepcional |
| 70–84% | Força Sólida |
| 55–69% | Força Presente |
| 40–54% | Em Desenvolvimento |
| <40% | Força Latente |