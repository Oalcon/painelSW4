# Prompts do Exercício — Estratégia de Canais de Aquisição

Cada prompt corresponde a uma etapa do exercício. Use o texto do aluno para preencher as lacunas `[...]` e execute a análise pedida, respondendo exatamente com os itens listados em "Entregar" de cada etapa.

## Contexto da Empresa (antes do Prompt 1)

Colete do aluno, se ainda não tiver:
1. Qual produto/serviço ele vende?
2. Quem foram os 3 melhores clientes nos últimos 6 meses?
3. O que esses clientes têm em comum? (segmento, porte, dor)
4. Liste 3 clientes atuais para entrevistar e validar hipóteses.

## Prompt 1 — ICP e Concorrência

Template do aluno:
> Esse é meu negócio: [...]. Esses são meus produtos: [...]. Esses são meus melhores clientes hoje: [...]. Monte meu ICP completo e compare com meus 3 principais concorrentes.

Entregar:
- ICP completo (segmento, porte, cargo do decisor, dor, contexto de compra)
- O que esse ICP valoriza, dores, desejos e objeções
- Quais canais funcionam melhor para esse ICP
- Como o aluno está posicionado versus a concorrência
- Oportunidades rápidas de diferenciação

## Prompt 2 — Diagnóstico de Funil

Template do aluno:
> Meu funil está assim: Leads = X, Oportunidades = Y, Propostas = Z, Vendas = W.

Entregar:
- Onde está o gargalo (qual etapa tem a maior perda percentual)
- Por que isso provavelmente acontece
- O que criar no TOPO, MEIO e FUNDO de funil
- 5 ações para aumentar conversão em 7 dias

## Prompt 3 — Matriz de Canais (ROI x Velocidade)

Template do aluno:
> Aqui estão meus canais atuais e métricas: [...].

Entregar:
- Matriz ROI x Velocidade dos canais informados
- Canal principal (core)
- 2 canais secundários
- Por que esses canais funcionam para o ICP definido no Prompt 1
- Onde está desperdiçando verba
- O que ajustar imediatamente

## Prompt 4 — Go-to-Market

Usa como insumo o ICP (Prompt 1) + Funil (Prompt 2) + Canais prioritários (Prompt 3).

Entregar:
- Estratégia de Go-to-Market ideal (lançamento, evergreen, always-on, ou misto) com justificativa
- Como integrar oferta + prova social + urgência
- Calendário de 45 dias
- Uma campanha que pode rodar já na semana seguinte

## Prompt 5 — Plano de 90 Dias

Entregar um plano estruturado assim:

**Fase 1 — Ativação (45 dias)**
- Ajustes no funil
- Implementação do canal principal
- Ações de aumento de conversão
- Metas semanais

**Fase 2 — Escala (45 dias)**
- Ampliação de campanhas
- Canais secundários
- Otimizações
- Metas de ROI e CAC

Ao final, gerar um quadro (tabela) com colunas: **Objetivo | Ação | KPI | Risco**, cobrindo as duas fases.
