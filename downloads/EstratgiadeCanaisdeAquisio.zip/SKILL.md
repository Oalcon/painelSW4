---
name: "Estratégia de Canais de Aquisição"
description: "Conduz, bloco a bloco, o exercício de aula 'Estratégia de Canais de Aquisição' do G4 Marketing & Growth: ICP, diagnóstico de funil, matriz de canais (ROI x Velocidade), Go-to-Market e plano de 90 dias. A aula é conduzida pela mentora em momentos separados — cada bloco pode ser acionado isoladamente conforme ela libera o conteúdo, sem precisar rodar o exercício inteiro numa única vez. Ative quando o aluno/mentora disser '@estrategiacanaisaquisicao', 'exercício de estratégia de canais de aquisição', 'montar meu ICP e comparar com concorrentes', 'onde está o gargalo do meu funil', 'montar minha matriz de canais ROI x velocidade', 'qual estratégia de go-to-market', 'montar meu plano de 90 dias de aquisição', ou colar qualquer um dos prompts do slide de canais de aquisição."
alwaysAllow: ["Read", "Write"]
---

# Estratégia de Canais de Aquisição

Exercício guiado da aula de G4 Marketing & Growth, conduzido pela **mentora em blocos ao vivo**: ela avança o conteúdo e libera um prompt por vez para a turma. A skill deve executar **um bloco isolado por chamada**, não a sequência inteira — o aluno normalmente vai invocar a skill de novo, em momentos diferentes da aula, uma vez por bloco liberado.

Os prompts completos (com a lista exata de itens a entregar em cada bloco) estão em [references/prompts.md](references/prompts.md). Leia esse arquivo e identifique qual bloco foi acionado antes de responder.

## Como identificar o bloco acionado

Detecte o bloco pelo que o aluno colou/disse, sem exigir que os blocos anteriores tenham rodado nesta mesma conversa:

| Bloco | Como reconhecer |
|---|---|
| **0 — Contexto da empresa** | Aluno responde às 4 perguntas de contexto (produto/serviço, 3 melhores clientes, o que têm em comum, 3 clientes para entrevistar) sem colar nenhum prompt de análise. |
| **1 — ICP e Concorrência** | Aluno colou o texto "Esse é meu negócio... Monte meu ICP completo e compare com meus 3 principais concorrentes" ou pede ICP/comparação com concorrentes. |
| **2 — Diagnóstico de Funil** | Aluno colou números de funil (Leads/Oportunidades/Propostas/Vendas) ou pede para achar o gargalo do funil. |
| **3 — Matriz de Canais** | Aluno colou canais atuais + métricas ou pede matriz ROI x Velocidade. |
| **4 — Go-to-Market** | Aluno pede estratégia de GTM, calendário de 45 dias ou campanha da semana. |
| **5 — Plano de 90 dias** | Aluno pede o plano de 90 dias, fases de Ativação/Escala ou o quadro final. |

Se a mensagem não deixar claro qual bloco é, pergunte objetivamente: "Qual bloco da aula a mentora liberou agora — Contexto, ICP, Funil, Canais, GTM ou Plano de 90 dias?"

## Como executar cada bloco

1. **Rode só o bloco identificado.** Não avance sozinho para o próximo nem repita blocos já feitos.
2. **Peça apenas os dados daquele bloco.** Se um input de bloco anterior for necessário (ex.: bloco 4 precisa do ICP do bloco 1) e não estiver disponível nesta conversa nem no histórico da sessão, peça um resumo rápido desse input antes de continuar — não peça para refazer o bloco inteiro.
3. **Entregue exatamente os itens listados em `prompts.md`** para aquele bloco, nem mais nem menos.
4. **Ao fim de cada bloco**, feche com uma linha curta indicando o próximo passo esperado, ex.: "Pronto — quando a mentora liberar o próximo bloco (Diagnóstico de Funil), traga os números do seu funil."

## Formato de resposta

- Use markdown estruturado (headers, bullets, tabelas quando fizer sentido — ex.: matriz de canais como tabela markdown ou `datatable`).
- Responda só com o conteúdo do bloco atual, sem antecipar os blocos seguintes.
- **Apenas no Bloco 5 (Plano de 90 dias)**, além da resposta no chat, salve o plano consolidado como arquivo `.md` na pasta de artefatos da sessão (nomeie `plano-90-dias-canais-aquisicao-{nome-ou-empresa}.md`) — reunindo, se disponíveis no histórico da sessão, os outputs dos blocos 1–4; caso não estejam disponíveis, monte o plano com o que o aluno fornecer nesse bloco e sinalize quais inputs anteriores faltaram.

## Quando faltar dado

Se o bloco atual não tiver informação suficiente para uma entrega específica, sinalize a lacuna, entregue o que for possível com o que já tem, e peça só o dado faltante — sem travar a entrega do bloco por causa disso.

## Entregável visual (JPG) do Bloco 5

Após fechar o Bloco 5 (Plano de 90 dias), ofereça ao aluno gerar um canvas visual em JPG com o resumo final. O template já traz uma marca d'água fixa "Imersão G4 Marketing & Growth" (diagonal de fundo + rodapé) — não remova nem edite essa marca. Se o aluno topar gerar o JPG:

1. Reúna os dados dos blocos anteriores (ICP, gargalo do funil + números, canal core + 2 secundários, resumo de GTM, quadro final de 90 dias).
2. Leia [assets/canvas-base.html](assets/canvas-base.html) e substitua as variáveis `{{...}}`:
   - `{{EMPRESA}}`, `{{DATA}}`, `{{ALUNO}}`
   - `{{ICP_RESUMO}}` — 2-3 linhas do ICP
   - `{{POSICIONAMENTO_ITEMS}}` — `<li>` por concorrente comparado
   - `{{GTM_RESUMO}}` — estratégia de GTM + campanha da semana
   - `{{FUNNEL_STEPS}}` — um bloco por etapa: `<div class="funnel-step"><div class="n">{valor}</div><div class="l">{etapa}</div><div class="c">{conversão}</div></div>`
   - `{{GARGALO}}` — etapa + causa provável
   - `{{CANAL_CORE}}`, `{{CANAL_SEC_1}}`, `{{CANAL_SEC_2}}`, `{{CANAIS_JUSTIFICATIVA}}`
   - `{{QUADRO_ROWS}}` — uma `<tr><td>...</td><td>...</td><td>...</td><td>...</td></tr>` por linha do quadro
3. Salve o HTML preenchido na pasta de artefatos da sessão como `canvas-canais-aquisicao-{nome-ou-empresa}.html`.
4. Renderize e exporte como JPG usando o browser tool:
   - `navigate file:///{caminho-absoluto-do-html}`
   - `window-resize 1280 900`
   - `screenshot`
   - Salve o base64 retornado como `.jpg` na mesma pasta, com nome `canvas-canais-aquisicao-{nome-ou-empresa}.jpg`
5. Entregue com um bloco `filecard` apontando para o JPG.
