# Detection Commands Reference

Quick-reference commands for identifying vulnerabilities during SAST audits.

---

## 1. Secrets & Configuration

```bash
# Find all .env files
find . -name ".env*" -not -path "./.git/*"

# Check if .env is in .gitignore
grep -n "\.env" .gitignore

# Secrets in git history
git log -p --all -- ".env*" 2>/dev/null | grep -E "(SERVICE_ROLE|sk_live|PRIVATE_KEY|SECRET|PASSWORD)" | head -20
git log -p --all -S "SERVICE_ROLE_KEY" --oneline 2>/dev/null
git log -p --all -S "sk_live" --oneline 2>/dev/null

# VITE_ or NEXT_PUBLIC_ secrets (exposed in bundle)
grep -rn "VITE_.*KEY\|VITE_.*SECRET\|VITE_.*TOKEN\|VITE_.*PASSWORD" --include="*.env*" .
grep -rn "NEXT_PUBLIC_.*KEY\|NEXT_PUBLIC_.*SECRET" --include="*.env*" .

# Hardcoded credentials in code
grep -rn "password.*['\"].*['\"]" --include="*.ts" --include="*.js" .
grep -rn "sk_live\|sk_test" --include="*.ts" --include="*.js" .
grep -rn "const.*UUID\|const.*USER_ID" --include="*.ts" --include="*.js" . | grep -i "admin\|system"
```

---

## 2. Supabase Config & Edge Functions

```bash
# Count verify_jwt distribution
grep -c "verify_jwt = false" supabase/config.toml 2>/dev/null
grep -c "verify_jwt = true" supabase/config.toml 2>/dev/null

# List all functions with verify_jwt = false
grep -B2 "verify_jwt = false" supabase/config.toml | grep "\[functions\."

# Find functions using service_role without auth
for dir in supabase/functions/*/; do
  if grep -ql "SERVICE_ROLE\|service_role" "$dir"*.ts 2>/dev/null; then
    func=$(basename "$dir")
    if ! grep -ql "getUser\|verifyAdmin\|Bearer\|x-api-key\|signature" "$dir"*.ts 2>/dev/null; then
      echo "VULN: $func uses service_role without auth"
    fi
  fi
done

# CORS patterns
grep -rn "Access-Control-Allow-Origin.*\*" supabase/functions/ 2>/dev/null | wc -l
grep -rn "secureCors\|isOriginAllowed" supabase/functions/ 2>/dev/null | wc -l

# Origin bypass check
grep -A5 "isOriginAllowed\|checkOrigin" supabase/functions/_shared/ 2>/dev/null | grep "!origin\|origin.*null\|return true"
```

---

## 3. RLS Audit

```bash
# Permissive policies
grep -rn "USING (true)" supabase/migrations/
grep -rn "USING(true)" supabase/migrations/

# Count total policies vs permissive
grep -c "CREATE POLICY" supabase/migrations/*.sql 2>/dev/null
grep -c "USING (true)\|USING(true)" supabase/migrations/*.sql 2>/dev/null

# Tables without RLS
grep -l "CREATE TABLE" supabase/migrations/*.sql | while read f; do
  tables=$(grep -oP "CREATE TABLE (?:IF NOT EXISTS )?\K\S+" "$f")
  for t in $tables; do
    if ! grep -q "ENABLE ROW LEVEL SECURITY ON $t\|ALTER TABLE $t ENABLE" supabase/migrations/*.sql 2>/dev/null; then
      echo "NO RLS: $t (in $f)"
    fi
  done
done

# FOR ALL without WITH CHECK
grep -B1 -A3 "FOR ALL" supabase/migrations/ | grep -v "WITH CHECK"

# SECURITY DEFINER functions
grep -rn "SECURITY DEFINER" supabase/migrations/
```

---

## 4. Authentication & Authorization

```bash
# Functions accepting user_id parameter
grep -rn "p_user_id\|user_id.*UUID\|userId.*uuid" supabase/migrations/ | grep -i "function\|DEFINER"

# Check if auth.uid() is validated in SECURITY DEFINER functions
grep -A20 "SECURITY DEFINER" supabase/migrations/*.sql | grep -B20 "p_user_id" | grep "auth.uid()"

# Token generation
grep -rn "random()\|Math.random" supabase/migrations/ --include="*.sql"
grep -rn "gen_random_bytes\|crypto.randomUUID\|crypto.getRandomValues" .

# Case-insensitive token comparison
grep -rn "UPPER\|LOWER\|toLowerCase\|toUpperCase" supabase/migrations/ | grep -i "token"

# Rate-limit analysis
grep -rn "rate.limit\|rateLimit\|rate_limit" --include="*.ts" --include="*.js" .
grep -rn "fail.*open\|catch.*return.*true\|catch.*allow" --include="*.ts" .

# Open redirect vectors
grep -rn "redirectTo\|redirect_to\|returnUrl\|return_url" --include="*.ts" .
```

---

## 5. XSS & Injection

```bash
# dangerouslySetInnerHTML
grep -rn "dangerouslySetInnerHTML" --include="*.tsx" --include="*.jsx" .

# innerHTML direct assignment
grep -rn "\.innerHTML\s*=" --include="*.ts" --include="*.tsx" .

# DOMPurify usage (check for inconsistent configs)
grep -rn "DOMPurify\|sanitize\|createSafeHTML" --include="*.ts" --include="*.tsx" .

# eval and Function constructor
grep -rn "eval(\|new Function(" --include="*.ts" --include="*.js" .

# rehype-raw (allows raw HTML in markdown)
grep -rn "rehype-raw\|rehypeRaw" --include="*.ts" --include="*.tsx" .

# SQL concatenation in PL/pgSQL (injection risk)
grep -rn "EXECUTE.*||" supabase/migrations/*.sql
grep -rn "EXECUTE format" supabase/migrations/*.sql | grep -v "%I\|%L"
```

---

## 6. Webhook Security

```bash
# Find all webhook handlers
grep -rn "webhook" supabase/functions/ --include="*.ts" -l

# Check for signature validation per service
for webhook in $(find supabase/functions -name "*.ts" -path "*webhook*"); do
  echo "=== $webhook ==="
  # Stripe
  grep -l "constructEvent\|stripe-signature" "$webhook" 2>/dev/null && echo "  [OK] Stripe HMAC" || true
  # WhatsApp/Meta
  grep -l "x-hub-signature\|hub.signature" "$webhook" 2>/dev/null && echo "  [OK] Meta HMAC" || true
  # Cal.com
  grep -l "x-cal-signature\|cal-signature" "$webhook" 2>/dev/null && echo "  [OK] Cal HMAC" || true
  # Hubla
  grep -l "x-hubla-signature\|hubla.*signature" "$webhook" 2>/dev/null && echo "  [OK] Hubla HMAC" || true
  # Resend/Svix
  grep -l "svix\|wh.verify" "$webhook" 2>/dev/null && echo "  [OK] Svix HMAC" || true
  # Generic check
  grep -l "timingSafeEqual\|crypto.subtle.verify\|createHmac" "$webhook" 2>/dev/null && echo "  [OK] Generic HMAC" || true
done

# Default/hardcoded verify tokens
grep -rn "verify.*token.*||.*['\"]" --include="*.ts" supabase/functions/
grep -rn "VERIFY_TOKEN.*=.*['\"]" --include="*.ts" supabase/functions/
```

---

## 7. Storage & Upload

```bash
# Public buckets
grep -rn "public.*true\|public: true" --include="*.ts" . | grep -i "bucket\|storage"

# Upload MIME validation
grep -rn "file.type\|contentType\|mime\|magic" --include="*.ts" --include="*.tsx" . | grep -i "upload\|image\|file"

# Storage bucket creation
grep -rn "createBucket\|create_bucket" --include="*.ts" .
```

---

## 8. Mass Assignment

```bash
# Object spread to database operations
grep -rn "\.update(\s*{.*\.\.\." --include="*.ts" .
grep -rn "\.insert(\s*{.*\.\.\." --include="*.ts" .
grep -rn "\.upsert(\s*{.*\.\.\." --include="*.ts" .

# Request body passed directly
grep -rn "req.body\|request.body\|body\." --include="*.ts" supabase/functions/ | grep -i "update\|insert\|upsert"
```

---

## 9. Token & Session Storage

```bash
# Tokens in browser storage
grep -rn "sessionStorage\|localStorage" --include="*.ts" --include="*.tsx" . | grep -i "token\|key\|secret"

# Tokens in URL path
grep -rn "/:token\|/:code\|/:invite" --include="*.ts" --include="*.tsx" . | grep -i "route\|path"

# console.log with sensitive data
grep -rn "console.log\|console.error" --include="*.ts" supabase/functions/ | grep -i "token\|email\|phone\|password"
```

---

## 10. CSP & Security Headers

```bash
# Find CSP configuration
find . -name "_headers" -o -name "vercel.json" -o -name "netlify.toml" -o -name "next.config.*" | xargs grep -l "Content-Security-Policy\|CSP" 2>/dev/null

# Check for unsafe directives
grep -rn "unsafe-inline\|unsafe-eval" . 2>/dev/null | grep -v node_modules | grep -v ".git"

# Security headers Edge Function (exists but not applied?)
find . -name "*security*header*" -o -name "*headers*" | grep -v node_modules
```

---

## 11. Inventory & Stats

```bash
# Codebase size
find . -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" | grep -v node_modules | xargs wc -l 2>/dev/null | tail -1

# Migration count
ls supabase/migrations/*.sql 2>/dev/null | wc -l

# Edge Function count
ls -d supabase/functions/*/ 2>/dev/null | wc -l

# Integration detection
grep -rn "stripe\|hubla\|calcom\|cal.com\|whatsapp\|resend\|sendgrid\|twilio\|openai\|anthropic" --include="*.ts" . | grep -v node_modules | grep -oP "stripe|hubla|calcom|cal\.com|whatsapp|resend|sendgrid|twilio|openai|anthropic" | sort | uniq -c | sort -rn
```

---

## 12. Git Intelligence

```bash
# Recent security-related changes
git log --all --oneline --since="3 months ago" -- "**/auth*" "**/security*" "**/rls*" "**/invite*" | head -20

# Who touches security code
git log --all --format="%an" -- "**/auth*" "**/security*" | sort | uniq -c | sort -rn

# Files that changed most (higher complexity = higher risk)
git log --all --format= --name-only | sort | uniq -c | sort -rn | head -20

# Detect force-pushes or rewritten history (suspicious)
git reflog --all | grep "forced-update\|reset" | head -10
```
