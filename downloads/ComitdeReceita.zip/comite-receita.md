---
name: Comitê de Receita
description: Preparo para o Comitê de Receita. Visão de área de Pré-Vendas — Meta Plano G4, GRID diariação, Realizado MTD, falta para o GRID, falta para a meta e ritmo necessário por dia útil restante.
---

# Ritual: Comitê de Receita

## Contexto

Visão consolidada da área de Pré-Vendas Aquisição para o Comitê de Receita.
Não quebra por squad — apresenta apenas os números totais da área.

**Métricas entregues:**
- Meta (Plano G4), GRID = meta × fração diariada, Realizado MTD, vs GRID, vs Meta, ritmo necessário
- Breakdown por AGD (Paid, Social, CRM, Orgânico)
- SAL × OPP Esperada × OPP Real por AGD e Big 7
- Big 7 com razão histórica de conversão SAL→Opp (últimos 3 meses)

---

## Execução — Scripts Python

Este ritual usa **3 scripts** pré-validados. **Não montar queries manualmente.**

```bash
python "{workflow-dir}/rituais/comite_receita.py"
python "{workflow-dir}/rituais/comite_receita_agd.py"
python "{workflow-dir}/rituais/comite_receita_sal_opp.py"
```

Executar os **3 scripts** e apresentar os outputs em sequência: Script 1 → Script 2 → Script 3.

---

## Fase 4 — Sessão Consultiva

Após os 3 outputs, gerar **3 a 5 provocações priorizadas por impacto**:

1. **Ritmo acima do bench histórico** → alertar sobre meta em risco
2. **AGD com CR OPP abaixo de 70%** → questionar se é problema de volume ou conversão
3. **Linha Big 7 com maior gap negativo** → investigar desvio operacional
4. **AGD acima do GRID** → destacar como ponto positivo
5. **Opps fora do Funil de Marketing** → oferecer contexto separado para a diretoria

---

## Guardrails

1. **Meta = Plano G4** — usar `categoria_meta = 'Plano G4'` em `db_metas_g4`
2. **Realizado filtra `grupo_de_receita = 'Funil de Marketing'`** — sem esse filtro, +519 opps indevidas em mai/26 (+32%)
3. **`status = 'Ativo'` não é suficiente para SDRs** — usar `data_saida IS NULL OR data_saida >= início do mês`
4. **`grupo_receita` vs `grupo_de_receita`** — sandbox: sem `_de_`; funil_comercial: com `_de_`
5. **`area_geracao_demanda = 'Não Definido'`** existe como string literal — nunca usar `COALESCE`
6. **SAL no Script 3 não usa JOIN de SDR** — SAL é gerado pelo Marketing; filtrar por `grupo_de_receita` diretamente