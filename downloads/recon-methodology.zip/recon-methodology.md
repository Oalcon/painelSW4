# Infrastructure Reconnaissance Methodology

Passive OSINT approach for infrastructure reconnaissance when a domain is known. No active scanning, no exploitation.

---

## Data Sources

| Source | Purpose |
|--------|---------|
| DNS intelligence platforms | Subdomain enumeration, historical DNS, WHOIS historical, associations |
| Certificate Transparency logs | TLS certificates issued for domain and variants |
| Live DNS queries | Current A, AAAA, MX, NS, TXT, CAA, DMARC, DKIM records |
| HTTP fingerprinting | Server, X-Powered-By, X-Vercel-Id, cf-ray, redirects |
| WHOIS (v4/v5) | Registrar, contacts, age, status |

---

## Phase 1: Subdomain Inventory

### Classify each subdomain:
- **prod** — production services
- **app** — application endpoints
- **payments** — payment processing
- **www** — web frontend
- **dev** — development/staging (HIGH RISK if public)
- **admin** — administrative panels (HIGH RISK without Zero Trust)
- **beta/preview** — pre-release

### For each subdomain record:
| Host | A/IP | CNAME | Provider/ISP | HTTP Code | Tech Stack | Tag |
|------|------|-------|-------------|-----------|------------|-----|

### Key indicators:
- Non-Cloudflare hosts (direct IP exposure)
- HTTP 200 on admin panels without auth challenge
- HTTP 000 (no response) on dev hosts = potentially vulnerable but not WAF-protected
- Stale CNAME to discontinued service = subdomain takeover risk

---

## Phase 2: Keyword Discovery

### TLD Sweep
For keyword `{brand}`, check all common TLDs:
- `.ai`, `.com`, `.com.br`, `.io`, `.net`, `.me`, `.xyz`, `.online`, `.club`, `.dev`, `.pro`, `.site`, `.tech`, `.app`, `.co`

### Typo Variations
- Character removal: `brandnal` vs `brandname`
- Character duplication: `brandnamme`
- Character swap: `bramdname`
- Missing vowel: `brndname`
- Common misspelling patterns

### Classification:
| Classification | Meaning | Action |
|---------------|---------|--------|
| LEGITIMATE | Client-owned or authorized partner | Verify ownership |
| TYPOSQUAT ATIVO | Live impersonation/phishing | CRITICAL — immediate takedown |
| TYPOSQUAT INATIVO | Registered but not serving content | Monitor |
| THIRD-PARTY | Unrelated entity with similar name | Monitor |
| UNREGISTERED | Available for registration | Defensive registration opportunity |

---

## Phase 3: Email Security Posture

| Control | Good | Bad |
|---------|------|-----|
| SPF | `v=spf1 include:_spf.google.com -all` (hard fail) | `~all` (soft fail) or missing |
| DMARC | `p=reject` or `p=quarantine` | `p=none` (monitor only) |
| DKIM | Published and validated | Not found in DNS |
| CAA | Restricts to known CAs | Absent (any CA can issue) |
| MTA-STS | Published | Not observed |

### DMARC Evolution Path:
1. `p=none` (collect data, 14+ days)
2. `p=quarantine` (start blocking, 14+ days)
3. `p=reject` (full enforcement)

**Common finding:** DMARC at `p=none` with `rua` pointing to third-party (e.g., `dmarcreports@third-party.dev`) = client doesn't control their own email security reporting.

---

## Phase 4: Certificate Analysis

- Count distinct certificates by CN
- Distribution by CA (Google Trust Services, Let's Encrypt, DigiCert, etc.)
- Check for expired certs in active records
- **Recommendation:** Publish CAA records restricting issuance to observed CAs only

Example CAA:
```
target-domain.com. CAA 0 issue "letsencrypt.org"
target-domain.com. CAA 0 issue "pki.goog"
target-domain.com. CAA 0 iodef "mailto:security@target-domain.com"
```

---

## Phase 5: Historical DNS Analysis

Track changes over time:
- IP migrations (indicates infrastructure changes)
- NS changes (registrar/hosting migrations)
- New TXT records (new integrations, verification tokens)
- MX changes (email provider changes)

---

## Phase 6: Third-Party Brand Presence

Identify `{brand}` appearing on third-party domains:
- `brand.thirdparty.com` — partner integration
- `adm.brand.partner.com` — administrative panel on partner infra

For each: verify DPA/LGPD compliance, validate legitimate business relationship.

---

## Finding Severity for Recon

| Finding | Severity |
|---------|----------|
| Active typosquat with cloned content (phishing) | CRITICAL |
| DMARC p=none (spoofing possible) | HIGH |
| Dev/staging environments in public DNS without Zero Trust | HIGH |
| No CAA records (any CA can issue certs) | HIGH |
| Admin panels accessible without access protection | MEDIUM |
| Available typosquat TLDs (not yet registered by attacker) | MEDIUM |
| Third-party dependencies without inventory | MEDIUM |
| Stale DNS (NXDOMAIN, 404 Vercel) | LOW |
| WHOIS privacy inconsistencies | LOW |
| SPF correctly configured (informational positive) | INFO |

---

## Remediation Priority

1. **Immediate:** Active phishing takedown (Cloudflare Trust & Safety, registrar abuse)
2. **Urgent:** DMARC escalation to p=quarantine/reject; dev environments behind VPN/Zero Trust
3. **High:** CAA records; confirm defensive registrations; registry lock
4. **Medium:** Defensive TLD registration; admin panels behind Cloudflare Access; TPRM inventory
5. **Low:** DNS hygiene (remove stale records); WHOIS consistency
6. **Ongoing:** CT log monitoring for brand keyword (weekly automated alert)
