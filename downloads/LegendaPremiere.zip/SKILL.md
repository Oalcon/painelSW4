---
name: "Legenda Premiere"
description: "Generates AI subtitles as .SRT files for Adobe Premiere Pro using Whisper transcription + semantic segmentation. Cross-platform (macOS + Windows). Trigger with /legenda-premiere or when the user says: 'legenda premiere', 'srt para premiere', 'gerar srt', 'criar legenda pro premiere', 'subtitle for premiere', or any subtitle generation request for a Premiere project."
alwaysAllow: ["Bash", "Write", "Read"]
---

# Legenda Premiere

Full pipeline: Whisper transcription → semantic segmentation → .SRT output for Adobe Premiere Pro.

**Key differences from legenda-reel (DaVinci):**
- Output: `.SRT` file (not SQLite injection)
- No DaVinci dependency — only Whisper + ffmpeg
- No FieldsBlob — style is applied manually in Premiere
- Cross-platform: macOS + Windows
- User provides audio/video files directly (no DaVinci audio export)

## Step 1 — Verify Whisper Environment

Before anything else, check silently:

### macOS / Linux:

```bash
bash -c 'cd /tmp && ls ~/.davinci-env/bin/python 2>/dev/null && ~/.davinci-env/bin/python -c "import whisper; print(\"WHISPER_OK\")" 2>/dev/null || echo "NO_WHISPER_ENV"'
```

### Windows:

```bash
bash -c 'cd /tmp && ls "$USERPROFILE/.davinci-env/Scripts/python.exe" 2>/dev/null && "$USERPROFILE/.davinci-env/Scripts/python.exe" -c "import whisper; print(\"WHISPER_OK\")" 2>/dev/null || echo "NO_WHISPER_ENV"'
```

**If `WHISPER_OK`:** proceed silently.

**If `NO_WHISPER_ENV`:** Check if `python3` has whisper:

```bash
bash -c 'cd /tmp && python3 -c "import whisper; print(\"WHISPER_SYSTEM_OK\")" 2>/dev/null || echo "NO_WHISPER"'
```

- **`WHISPER_SYSTEM_OK`:** use `python3` instead of `~/.davinci-env/bin/python`
- **`NO_WHISPER`:** tell the user:
  > "O Whisper não está instalado. Rode **/davinci-setup** para configurar o ambiente, ou instale manualmente: `pip install openai-whisper ffmpeg-python`"

Also check ffmpeg:

```bash
bash -c 'which ffmpeg 2>/dev/null && echo "FFMPEG_OK" || echo "NO_FFMPEG"'
```

If `NO_FFMPEG`: instruct installation:
- macOS: `brew install ffmpeg`
- Windows: `choco install ffmpeg` or download from ffmpeg.org

## Step 2 — Collect Info + Transcribe

### 2A — Ask the User

Use `mcp__session__request_user_input` with one question:

```json
[
  {
    "id": "audio_path",
    "header": "Arquivos de áudio/vídeo",
    "question": "Onde estão os arquivos de áudio ou vídeo para legendar? (caminho completo da pasta ou arquivo)"
  }
]
```

Then ask orientation and font case together:

```json
[
  {
    "id": "orientation",
    "header": "Orientação do vídeo",
    "question": "O vídeo é horizontal ou vertical?",
    "options": [
      {"label": "Horizontal (16:9)", "description": "Margens laterais 10%, inferior 10% — max 42 chars/linha"},
      {"label": "Vertical (9:16)", "description": "Margens laterais 15%, exclusão sup/inf 20% — max 28 chars/linha"}
    ]
  },
  {
    "id": "font_case",
    "header": "Caixa do texto",
    "question": "Qual formato de caixa para a legenda?",
    "options": [
      {"label": "ALL CAPS", "description": "TODAS AS LETRAS MAIÚSCULAS"},
      {"label": "Lowercase", "description": "todas as letras minúsculas"},
      {"label": "Title Case", "description": "Primeira Letra De Cada Palavra Maiúscula"}
    ]
  }
]
```

### 2B — Convert to MP3 + Transcribe

If the user provided a video or non-MP3 audio, convert first:

```bash
bash -c 'cd /tmp && ffmpeg -y -i "INPUT_FILE" -codec:a libmp3lame -qscale:a 2 /tmp/legenda_premiere_audio/audio.mp3 2>&1 | tail -5'
```

Then transcribe:

```bash
bash -c 'cd /tmp && PYTHON_BIN /path/to/skills/legenda-premiere/scripts/transcribe.py /tmp/legenda_premiere_audio/audio.mp3 --lang pt --model small --out /tmp/legenda_premiere_audio/words.json'
```

Where `PYTHON_BIN` is `~/.davinci-env/bin/python` or `python3` (from Step 1).

The script path is relative to this skill's directory. Find it with:
```bash
find ~/.g4os-public -name "transcribe.py" -path "*/legenda-premiere/*" 2>/dev/null
```

**Multiple files:** process in sequence, generating `words_1.json`, `words_2.json`, etc.

### 2C — Transcription Review

After Whisper runs, display all words with timestamps for review:

```bash
bash -c 'cd /tmp && python3 -c "
import json
words = json.load(open(\"/tmp/legenda_premiere_audio/words.json\"))
for i, w in enumerate(words):
    print(f\"[{i:3d}] {w[\"start\"]:.2f}s - {w[\"end\"]:.2f}s : {w[\"word\"]}\")
"'
```

**Flag suspicious words** — common Whisper errors in Portuguese:
- "metal" vs "mental"
- "deputos" vs "débitos"
- "que" vs "quer"
- "mais" vs "mas"
- "tá" vs "está"
- Words out of context in the surrounding phrase

Present flagged words to the user with surrounding context (2-3 words before/after).

**If `small` produces too many errors**, suggest re-running with `medium`:

```bash
bash -c 'cd /tmp && PYTHON_BIN /path/to/scripts/transcribe.py /tmp/legenda_premiere_audio/audio.mp3 --lang pt --model medium --out /tmp/legenda_premiere_audio/words.json'
```

**Manual corrections** (only text — timestamps preserved):

```bash
bash -c 'cd /tmp && python3 - <<PYEOF
import json

words = json.load(open("/tmp/legenda_premiere_audio/words.json"))

corrections = [
    # (index, "corrected word"),
]

for idx, new_word in corrections:
    old = words[idx]["word"]
    words[idx]["word"] = new_word
    print(f"Corrected [{idx}]: \"{old}\" -> \"{new_word}\" (timestamps preserved)")

json.dump(words, open("/tmp/legenda_premiere_audio/words.json", "w"), indent=2, ensure_ascii=False)
print(f"Saved {len(corrections)} corrections.")
PYEOF'
```

Confirm with user before proceeding.

## Step 3 — Segmentation + Card Review

### 3A — Run Segmentation

```bash
bash -c 'cd /tmp && PYTHON_BIN /path/to/skills/legenda-premiere/scripts/segment-srt.py \
  --words /tmp/legenda_premiere_audio/words.json \
  --out /tmp/legenda_premiere_audio/output.srt \
  --orientation ORIENTATION \
  --font-case FONT_CASE'
```

Replace `ORIENTATION` with `horizontal` or `vertical` and `FONT_CASE` with `upper`, `lower`, or `title` (from Step 2A).

For multiple files with `--start-time` / `--end-time`:

```bash
bash -c 'cd /tmp && PYTHON_BIN /path/to/scripts/segment-srt.py \
  --words /tmp/legenda_premiere_audio/words.json \
  --out /tmp/legenda_premiere_audio/output_N.srt \
  --orientation ORIENTATION \
  --start-time START_SEC --end-time END_SEC'
```

The script path:
```bash
find ~/.g4os-public -name "segment-srt.py" -path "*/legenda-premiere/*" 2>/dev/null
```

### 3B — Card Review

After segmentation, display all cards for review:

```bash
bash -c 'cd /tmp && python3 - <<PYEOF
import json, re

srt_path = "/tmp/legenda_premiere_audio/output.srt"
with open(srt_path, encoding="utf-8-sig") as f:
    content = f.read()

blocks = content.strip().split("\n\n")
issues = []
prev_end = 0

for block in blocks:
    lines = block.strip().split("\n")
    if len(lines) < 3:
        continue
    idx = lines[0].strip()
    times = lines[1].strip()
    text_lines = lines[2:]

    # Parse times
    match = re.match(r"(\d{2}:\d{2}:\d{2},\d{3}) --> (\d{2}:\d{2}:\d{2},\d{3})", times)
    if not match:
        continue

    def parse_srt_time(t):
        parts = t.replace(",", ".").split(":")
        return float(parts[0]) * 3600 + float(parts[1]) * 60 + float(parts[2])

    start = parse_srt_time(match.group(1))
    end = parse_srt_time(match.group(2))
    dur = end - start

    card_issues = []
    for j, line in enumerate(text_lines):
        if len(line) > 42:
            card_issues.append(f"Line {j+1}: {len(line)} chars (>42)")

    if dur < 0.833:
        card_issues.append(f"Duration too short ({dur:.3f}s)")
    if start < prev_end - 0.001:
        card_issues.append(f"Overlaps with previous")

    status = " ⚠" if card_issues else ""
    text = " / ".join(text_lines)
    print(f"[{idx:>3s}] {times} ({dur:.2f}s){status}")
    for line in text_lines:
        print(f"      | {line} [{len(line)}ch]")
    for iss in card_issues:
        print(f"      ⚠ {iss}")

    prev_end = end

print(f"\n--- Total: {len(blocks)} cards ---")
PYEOF'
```

### 3C — Punctuation Review (Mandatory)

Before finalizing, review ALL cards and add punctuation:
- **Vírgulas**: enumerações, vocativos, orações subordinadas, apostos
- **Pontos finais**: último card de cada frase
- **Interrogações/Exclamações**: quando adequado ao tom
- **Reticências**: pausas dramáticas ou frases incompletas

O Whisper frequentemente omite pontuação — esta revisão é **obrigatória**.

After validation and punctuation review, proceed to delivery.

## Step 4 — Delivery

### 4A — Save SRT

Save the `.srt` in the same directory as the original audio (or where the user requests):

```bash
bash -c 'cp /tmp/legenda_premiere_audio/output.srt "TARGET_DIR/FILENAME.srt"'
```

The SRT is encoded as **UTF-8 with BOM** (`utf-8-sig`) for maximum compatibility with Premiere Pro on both macOS and Windows.

### 4B — Summary

```
✓ Arquivos processados: {N}
✓ Orientação: {horizontal/vertical} ({16:9 / 9:16})
✓ Max chars/linha: {max_chars}
✓ Cards gerados: {total_cards}
✓ Caixa: {font_case}
✓ Arquivo SRT: {output_path}

Para importar no Premiere:
1. File > Import (ou Ctrl/Cmd+I)
2. Selecione o arquivo .SRT
3. Arraste para a timeline
4. Ajuste fonte, cor, tamanho e posição no painel Essential Graphics
```

Then ask: **"A legenda foi importada corretamente no Premiere?"**
- **Sim** → delete cache: `rm -rf /tmp/legenda_premiere_audio`
- **Não** → keep cache, diagnose

## Semantic Segmentation Logic

The segmentation follows professional film subtitling standards (Netflix TTSG, BBC Guidelines), adapted for PT-BR.

### Parameters

| Parameter | Value | Reference |
|-----------|-------|-----------|
| Max lines per card | 2 | Netflix TTSG |
| Max chars/line (16:9) | 42 | Netflix standard |
| Max chars/line (9:16) | 28 | Adjusted for vertical |
| Max CPS | 17 | Netflix PT-BR |
| Min duration | 833ms | Netflix TTSG |
| Max duration | 7000ms | Netflix/BBC |
| Min gap between cards | 80ms | Netflix TTSG |
| Line format | Bottom-heavy | Netflix "pyramid shape" |

### Card Break Hierarchy

```
PRIORITY 1:  Sentence boundary (. ! ? followed by new sentence)
PRIORITY 2:  Coordinating conjunction boundary (e, mas, ou, porém, contudo)
PRIORITY 3:  Subordinating conjunction boundary (que, porque, quando, se, embora)
PRIORITY 4:  Before prepositional phrase modifying whole sentence
PRIORITY 5:  Before adverbial phrase
PRIORITY 6:  Between verb and direct object noun phrase
PRIORITY 7:  Any word boundary not in the forbidden list
FORBIDDEN:   Break within syntactic units listed below
```

### Syntactic Units That Must NEVER Be Separated

| Unit | Wrong | Correct |
|------|-------|---------|
| Article + Noun | `a /` `casa` | `a casa` together |
| Noun + Adjective | `casa /` `bonita` | `casa bonita` together |
| Adjective + Noun | `bela /` `casa` | `bela casa` together |
| Subject pronoun + Verb | `ela /` `correu` | `ela correu` together |
| Verb + Auxiliary | `tinha /` `sido` | `tinha sido` together |
| Verb + Reflexive | `se /` `levantou` | `se levantou` together |
| Negation + Verb | `não /` `fui` | `não fui` together |
| Verb + Preposition (regency) | `gostar /` `de` | `gostar de` together |
| Preposition + object | `com /` `vocês` | `com vocês` together |
| Compound name | `Maria /` `Silva` | `Maria Silva` together |
| Compound tenses | `vai /` `ter sido` | `vai ter sido` together |
| Clitic + Verb | `me /` `disse` | `me disse` together |
| Verb + Enclitic | `disse /` `-me` | `disse-me` together |
| Contractions | Never separate: `no`, `na`, `do`, `da`, `pelo` | Single token |

### Line Break Hierarchy (within a 2-line card)

1. After punctuation (`. , ; : ! ? …`)
2. Before conjunction (`e`, `mas`, `ou`, `porque`, `porém`)
3. Before preposition (`em`, `no`, `na`, `com`, `para`, `de`, `por`, `sem`, `até`)
4. Before relative pronoun (`que`, `quem`, `onde`, `como`, `quando`)
5. Between verb and direct object (last resort)

**Bottom-heavy format (pyramid):**
```
WRONG:       EU QUERIA FALAR COM VOCÊS
             SOBRE ISSO

CORRECT:     EU QUERIA FALAR
             COM VOCÊS SOBRE ISSO
```
Bottom line must be >= top line length.

### Timing Rules

1. Min duration = 833ms — cards shorter than 833ms are extended
2. Max duration = 7s — cards longer are split
3. Max CPS = 17 — if `(chars / duration_sec) > 17`, split the card
4. Min gap = 80ms between cards
5. Gap 80ms-500ms → normalize to exactly 80ms
6. Gap >= 500ms → keep as-is (natural speaker pause)
7. Start time → align to first audio frame of the word
8. End time → extend 500ms after audio end when no next card follows

## Adapted Rules

1. **NEVER alter transcription words** — only reposition breaks and add punctuation
2. **NEVER use model `base`** — default is `small`. Use `medium` for noisy or long audio
3. **Always review and add punctuation** (mandatory before generating SRT)
4. **Scripts run via `~/.davinci-env/bin/python`** (or `python3` if env doesn't exist)
5. **Cross-platform**: paths with `os.path.expanduser`, separators with `os.path.join`
6. **Output .SRT uses UTF-8 with BOM** (Windows Premiere compatibility)
7. **Respect break hierarchy**: NEVER separate forbidden syntactic units
8. **Cards bottom-heavy**: bottom line >= top line
9. **Max CPS 17 for PT-BR** (Netflix standard)
10. **Min gap 80ms between cards**

## SRT Format Reference

```
1
00:00:01,000 --> 00:00:03,500
TEXTO DA LEGENDA

2
00:00:04,000 --> 00:00:06,200
SEGUNDA LEGENDA
EM DUAS LINHAS

```

- Index starts at 1
- Time format: `HH:MM:SS,mmm` (comma for milliseconds, NOT dot)
- Blank line separates cards
- Max 2 lines per card
- UTF-8 with BOM encoding