#!/usr/bin/env python3
# IMPORTANT: always run as: bash -c 'cd /tmp && ~/.davinci-env/bin/python <path>/transcribe.py ...'
"""
Transcribe audio to per-word timestamps using Whisper.
Usage: python transcribe.py <audio_file> [--lang pt] [--model small]
Output: /tmp/legenda_premiere_audio/words.json

Pre-processes audio to MP3 via ffmpeg if the input is not already .mp3.
"""
import sys, os, json, argparse, subprocess, shutil

def convert_to_mp3(src, dst):
    """Convert any audio/video file to MP3 via ffmpeg. Returns dst path."""
    if src.lower().endswith(".mp3") and os.path.exists(src):
        return src
    print(f"Converting {os.path.basename(src)} → MP3 via ffmpeg...")
    result = subprocess.run(
        ["ffmpeg", "-y", "-i", src, "-codec:a", "libmp3lame", "-qscale:a", "2", dst],
        capture_output=True, text=True
    )
    if result.returncode != 0 or not os.path.exists(dst):
        raise RuntimeError(f"ffmpeg conversion failed:\n{result.stderr[-800:]}")
    size_mb = os.path.getsize(dst) / 1_000_000
    print(f"Converted: {dst} ({size_mb:.1f} MB)")
    return dst

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("audio", help="Path to audio file")
    parser.add_argument("--lang", default="pt", help="Language code (pt, en, auto)")
    parser.add_argument("--model", default="small", help="Whisper model: tiny/base/small/medium (never use base — use small minimum)")
    parser.add_argument("--out", default="/tmp/legenda_premiere_audio/words.json")
    args = parser.parse_args()

    import whisper
    os.makedirs(os.path.dirname(args.out), exist_ok=True)

    # Pre-process: ensure we have an MP3 (smaller, faster, compatible)
    mp3_path = "/tmp/legenda_premiere_audio/audio.mp3"
    audio_file = convert_to_mp3(args.audio, mp3_path)

    if args.model == "base":
        print("WARNING: model 'base' is forbidden (regra absoluta #2). Upgrading to 'small'.")
        args.model = "small"

    print(f"Loading Whisper model '{args.model}'...")
    # CRITICAL: always device="cpu" — MPS has NaN bug on macOS ARM
    model = whisper.load_model(args.model, device="cpu")

    lang = None if args.lang == "auto" else args.lang
    print(f"Transcribing {audio_file} (lang={lang or 'auto'})...")

    result = model.transcribe(
        audio_file,
        word_timestamps=True,
        language=lang,
        verbose=False
    )

    words = []
    for seg in result["segments"]:
        for w in seg.get("words", []):
            words.append({
                "word": w["word"],
                "start": round(w["start"], 3),
                "end":   round(w["end"],   3)
            })

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(words, f, ensure_ascii=False, indent=2)

    duration = words[-1]["end"] if words else 0
    print(f"Words: {len(words)}  Duration: {duration:.1f}s  Saved: {args.out}")

if __name__ == "__main__":
    main()
