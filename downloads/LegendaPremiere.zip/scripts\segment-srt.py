#!/usr/bin/env python3
# IMPORTANT: always run as: bash -c 'cd /tmp && ~/.davinci-env/bin/python <path>/segment-srt.py ...'
# Or: bash -c 'cd /tmp && python3 <path>/segment-srt.py ...'
"""
Semantic segmentation of Whisper words into subtitle cards — SRT output for Adobe Premiere.
Usage: python segment-srt.py [--words words.json] [--out output.srt] [--orientation horizontal|vertical]

Text case is configurable (--font-case: upper, lower, title). Default: upper (ALL CAPS).
Font/color/size are applied manually in Premiere after importing the SRT.
Applies Netflix TTSG / BBC subtitle segmentation rules adapted for PT-BR.
"""
import sys, os, json, re, argparse

WORDS_DEFAULT = "/tmp/legenda_premiere_audio/words.json"
OUT_DEFAULT   = "/tmp/legenda_premiere_audio/output.srt"

# ── Orientation-based parameters ──
ORIENTATION_PARAMS = {
    "horizontal": {"max_chars": 42, "label": "16:9"},
    "vertical":   {"max_chars": 28, "label": "9:16"},
}

# ── Font case (configurable via --font-case) ──
FONT_CASE = "UPPER"  # default, overridden by CLI arg

# ── Timing constants (Netflix TTSG) ──
MIN_DUR       = 0.833   # 5/6 second — minimum card duration
MAX_DUR       = 7.0     # 7 seconds — maximum card duration
MAX_CPS       = 17      # characters per second (Netflix PT-BR)
MIN_GAP       = 0.080   # 80ms ≈ 2 frames at 24fps
NATURAL_GAP   = 0.500   # gaps >= 500ms are kept as-is (natural pause)
END_EXTEND    = 0.500   # extend last card's end by 500ms if no next card

MIN_WORDS     = 2
MAX_WORDS_PER_CARD = 8

# ── Portuguese natural break tokens ──
NATURAL = {
    'E', 'MAS', 'OU', 'QUE', 'PORQUE', 'QUANDO', 'SE', 'ENTÃO',
    'DE', 'DO', 'DA', 'DOS', 'DAS', 'EM', 'NO', 'NA', 'NOS', 'NAS',
    'POR', 'PARA', 'PRA', 'PRO', 'COM', 'SEM', 'ATÉ', 'AO', 'À',
    'A', 'O', 'AS', 'OS', 'UM', 'UMA',
    'ELE', 'ELA', 'EU', 'SE', 'ISSO', 'ESSE', 'ESSA',
    'JÁ', 'AÍ', 'AQUI', 'ALI', 'ONDE', 'COMO', 'NÃO'
}

# ── Syntactic units that must NEVER be separated ──
INSEPARABLE_PAIRS = [
    (r'^(O|A|OS|AS|UM|UMA|UNS|UMAS)$', None),
    (r'^(NÃO|NEM|NUNCA|JAMAIS)$', None),
    (r'^(ME|TE|SE|NOS|VOS|LHE|LHES)$', None),
    (r'^(DE|DO|DA|DOS|DAS|EM|NO|NA|NOS|NAS|POR|PELO|PELA|PELOS|PELAS|COM|SEM|PARA|PRA|PRO|ATÉ|AO|À|AOS|ÀS|ENTRE|SOBRE|SOB)$', None),
]


def clean(w):
    """Remove non-word chars EXCEPT meaningful punctuation (.,!?…% and internal hyphens)."""
    trail = ""
    stripped = w.strip()
    while stripped and stripped[-1] in ".,!?…%":
        trail = stripped[-1] + trail
        stripped = stripped[:-1]
    core = re.sub(r"[^\w\sÀ-ÿ\-]", "", stripped).strip()
    core = core.strip("-")
    return core + trail if core else trail


def apply_case(text):
    if FONT_CASE == "LOWER":
        return text.lower()
    elif FONT_CASE == "TITLE":
        return text.title()
    return text.upper()


def is_inseparable_preceding(token_upper):
    """Check if this token should NOT be the last token before a break."""
    for pattern, _ in INSEPARABLE_PAIRS:
        if re.match(pattern, token_upper):
            return True
    return False


def make_card(words_slice, newline_at=None):
    tokens = [apply_case(clean(w["word"])) for w in words_slice]
    tokens = [t for t in tokens if t]

    if newline_at and 0 < newline_at < len(tokens):
        l1 = " ".join(tokens[:newline_at])
        l2 = " ".join(tokens[newline_at:])
        text = l1 + "\n" + l2
    else:
        text = " ".join(tokens)

    start = words_slice[0]["start"]
    end = words_slice[-1]["end"]
    dur = end - start
    if dur < MIN_DUR:
        end = start + MIN_DUR

    return {"text": text, "start": round(start, 3), "end": round(end, 3)}


def auto_wrap(words_slice, max_chars):
    """Wrap into ≤2 lines using best semantic split point. Bottom-heavy (pyramid)."""
    tokens = [apply_case(clean(w["word"])) for w in words_slice]
    tokens = [t for t in tokens if t]
    full = " ".join(tokens)

    if len(full) <= max_chars:
        return make_card(words_slice)

    best_score = 9999
    best_i = None

    for i in range(1, len(tokens)):
        l1 = " ".join(tokens[:i])
        l2 = " ".join(tokens[i:])
        if len(l1) > max_chars or len(l2) > max_chars:
            continue

        preceding_tok = tokens[i - 1].upper().rstrip(".,!?…%")
        if is_inseparable_preceding(preceding_tok):
            continue

        balance = abs(len(l1) - len(l2))
        bonus = -4 if tokens[i].upper().rstrip(".,!?…%") in NATURAL else 0
        pyramid_penalty = 3 if len(l1) > len(l2) else 0
        line_bonus = 0
        next_tok_upper = tokens[i].upper().rstrip(".,!?…%")
        prev_tok = tokens[i - 1].rstrip()
        if prev_tok.endswith((".", ",", ";", ":", "!", "?", "…")):
            line_bonus = -6
        elif next_tok_upper in ("E", "MAS", "OU", "PORQUE", "PORÉM"):
            line_bonus = -5
        elif next_tok_upper in ("EM", "NO", "NA", "COM", "PARA", "DE", "POR", "SEM", "ATÉ"):
            line_bonus = -4
        elif next_tok_upper in ("QUE", "QUEM", "ONDE", "COMO", "QUANDO"):
            line_bonus = -3

        score = balance + bonus + pyramid_penalty + line_bonus
        if score < best_score:
            best_score = score
            best_i = i

    return make_card(words_slice, newline_at=best_i)


def segment(words, max_chars):
    """Greedy segmentation with semantic break hierarchy."""
    cards = []
    i = 0
    n = len(words)

    while i < n:
        best_end = min(i + MIN_WORDS, n)

        for j in range(i + MIN_WORDS, min(i + MAX_WORDS_PER_CARD + 1, n + 1)):
            tokens = [apply_case(clean(w["word"])) for w in words[i:j] if clean(w["word"])]
            full = " ".join(tokens)
            if len(full) <= max_chars:
                best_end = j
            else:
                can_wrap = False
                for k in range(1, len(tokens)):
                    l1 = " ".join(tokens[:k])
                    l2 = " ".join(tokens[k:])
                    if len(l1) <= max_chars and len(l2) <= max_chars:
                        can_wrap = True
                        best_end = j
                        break
                if not can_wrap:
                    break

        chunk = words[i:best_end]
        if not chunk:
            i += 1
            continue

        card = auto_wrap(chunk, max_chars)
        cards.append(card)
        i = best_end

    return cards


def enforce_cps(cards):
    """Split cards that exceed MAX_CPS (17 chars/sec for PT-BR)."""
    result = []
    for card in cards:
        text_len = len(card["text"].replace("\n", " "))
        dur = card["end"] - card["start"]
        if dur <= 0:
            result.append(card)
            continue
        cps = text_len / dur
        if cps <= MAX_CPS or dur <= MIN_DUR:
            result.append(card)
        else:
            words_text = card["text"].replace("\n", " ").split()
            mid = len(words_text) // 2
            if mid > 0:
                l1 = " ".join(words_text[:mid])
                l2 = " ".join(words_text[mid:])
                mid_time = card["start"] + dur * (len(l1) / text_len)
                result.append({"text": l1, "start": card["start"], "end": round(mid_time, 3)})
                result.append({"text": l2, "start": round(mid_time, 3), "end": card["end"]})
            else:
                result.append(card)
    return result


def enforce_max_duration(cards):
    """Split cards longer than MAX_DUR (7s)."""
    result = []
    for card in cards:
        dur = card["end"] - card["start"]
        if dur <= MAX_DUR:
            result.append(card)
        else:
            words_text = card["text"].replace("\n", " ").split()
            mid = len(words_text) // 2
            if mid > 0:
                l1 = " ".join(words_text[:mid])
                l2 = " ".join(words_text[mid:])
                mid_time = card["start"] + dur / 2
                result.append({"text": l1, "start": card["start"], "end": round(mid_time, 3)})
                result.append({"text": l2, "start": round(mid_time, 3), "end": card["end"]})
            else:
                result.append(card)
    return result


def normalize_gaps(cards):
    """Normalize gaps between cards: <500ms → 80ms, >=500ms → keep as-is."""
    for i in range(1, len(cards)):
        gap = cards[i]["start"] - cards[i - 1]["end"]
        if gap < 0:
            cards[i - 1]["end"] = round(cards[i]["start"] - MIN_GAP, 3)
        elif 0 < gap < NATURAL_GAP:
            cards[i - 1]["end"] = round(cards[i]["start"] - MIN_GAP, 3)

    if cards:
        cards[-1]["end"] = round(cards[-1]["end"] + END_EXTEND, 3)

    return cards


def format_srt_time(seconds):
    """Format seconds as HH:MM:SS,mmm (SRT format)."""
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = seconds % 60
    ms = int(round((s - int(s)) * 1000))
    return f"{h:02d}:{m:02d}:{int(s):02d},{ms:03d}"


def write_srt(cards, path):
    """Write cards to SRT file with UTF-8 BOM (Windows Premiere compatibility)."""
    with open(path, "w", encoding="utf-8-sig") as f:
        for i, card in enumerate(cards, 1):
            f.write(f"{i}\n")
            f.write(f"{format_srt_time(card['start'])} --> {format_srt_time(card['end'])}\n")
            f.write(f"{card['text']}\n")
            f.write("\n")


def write_json(cards, path):
    """Write cards as JSON (for debugging/review)."""
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cards, f, ensure_ascii=False, indent=2)


def validate_cards(cards, max_chars):
    issues = []
    prev_end = 0
    for i, card in enumerate(cards):
        for j, line in enumerate(card["text"].split("\n")):
            if len(line) > max_chars:
                issues.append(f"Card {i + 1}: line {j + 1} too long ({len(line)} > {max_chars}ch): {repr(line)}")
        dur = card["end"] - card["start"]
        if dur < MIN_DUR - 0.05:
            issues.append(f"Card {i + 1}: duration {dur:.3f}s < min {MIN_DUR}s")
        if dur > 0:
            text_len = len(card["text"].replace("\n", " "))
            cps = text_len / dur
            if cps > MAX_CPS + 1:
                issues.append(f"Card {i + 1}: CPS {cps:.1f} > max {MAX_CPS}")
        if card["start"] < prev_end - 0.001:
            issues.append(f"Card {i + 1}: overlaps with previous (starts {card['start']:.3f}s, prev ends {prev_end:.3f}s)")
        prev_end = card["end"]
    return issues


def main():
    parser = argparse.ArgumentParser(description="Segment Whisper words into SRT subtitles for Adobe Premiere")
    parser.add_argument("--words", default=WORDS_DEFAULT, help="Path to words.json from Whisper")
    parser.add_argument("--out", default=OUT_DEFAULT, help="Output file path (.srt or .json)")
    parser.add_argument("--orientation", choices=["horizontal", "vertical"], default="horizontal",
                        help="Video orientation: horizontal (16:9, max_chars=42) or vertical (9:16, max_chars=28)")
    parser.add_argument("--format", choices=["srt", "json"], default="srt",
                        help="Output format (default: srt)")
    parser.add_argument("--start-time", type=float, default=None,
                        help="Filter words starting from this time (seconds)")
    parser.add_argument("--end-time", type=float, default=None,
                        help="Filter words up to this time (seconds)")
    parser.add_argument("--max-chars", type=int, default=None,
                        help="Override max chars per line (overrides orientation default)")
    parser.add_argument("--font-case", choices=["upper", "lower", "title"], default="upper",
                        help="Text case: upper (ALL CAPS), lower (all lowercase), title (Title Case)")
    args = parser.parse_args()

    # Set global font case from CLI arg
    global FONT_CASE
    FONT_CASE = args.font_case.upper()

    # Load words
    with open(args.words, encoding="utf-8") as f:
        words = json.load(f)

    # Filter by time range
    if args.start_time is not None or args.end_time is not None:
        original_count = len(words)
        words = [w for w in words
                 if (args.start_time is None or w["start"] >= args.start_time)
                 and (args.end_time is None or w["end"] <= args.end_time)]
        print(f"Time filter: {len(words)}/{original_count} words "
              f"(range: {args.start_time or 0:.2f}s - {args.end_time or 'end'}s)")

    if not words:
        print("ERROR: No words to segment.")
        sys.exit(1)

    # Determine max_chars
    orientation = args.orientation
    params = ORIENTATION_PARAMS[orientation]
    max_chars = args.max_chars or params["max_chars"]

    case_labels = {"UPPER": "ALL CAPS", "LOWER": "lowercase", "TITLE": "Title Case"}
    print(f"Orientation: {orientation} ({params['label']}) | max_chars: {max_chars} | case: {case_labels.get(FONT_CASE, FONT_CASE)}")

    # Segment
    cards = segment(words, max_chars)

    # Post-processing
    cards = enforce_max_duration(cards)
    cards = enforce_cps(cards)
    cards = normalize_gaps(cards)

    # Validate
    issues = validate_cards(cards, max_chars)

    # Determine output format
    out_format = args.format
    if args.out.lower().endswith(".json"):
        out_format = "json"
    elif args.out.lower().endswith(".srt"):
        out_format = "srt"

    # Write output
    if out_format == "srt":
        write_srt(cards, args.out)
    else:
        write_json(cards, args.out)

    print(f"Cards: {len(cards)} | Max chars/line: {max_chars} | Issues: {len(issues)}")
    for iss in issues:
        print(f"  WARNING: {iss}")
    print(f"Saved: {args.out}")

    # Print first 5 cards as preview
    print("\n--- Preview (first 5 cards) ---")
    for i, card in enumerate(cards[:5], 1):
        dur = card["end"] - card["start"]
        print(f"[{i}] {format_srt_time(card['start'])} --> {format_srt_time(card['end'])} ({dur:.2f}s)")
        for line in card["text"].split("\n"):
            print(f"    {line} [{len(line)}ch]")


if __name__ == "__main__":
    main()
