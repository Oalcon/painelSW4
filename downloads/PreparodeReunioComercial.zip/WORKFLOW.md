---
name: Preparo de Reunião Comercial
description: Gera análise estruturada do cenário comercial antes de rituais recorrentes — All Hands, WBR, Comitê de Receita — com dados ao vivo do Databricks, sem consolidação manual.
icon: "🎯"
---

# Workflow: Preparo de Reunião Comercial

Prepara o gestor comercial para rituais recorrentes com leitura confiável do cenário em poucos minutos, direto das fontes oficiais (Databricks).

**Guia para gestores:** `{workflow-dir}/knowledge/guia-gestores.md`
**Outputs de referência:** `{workflow-dir}/knowledge/outputs-referencia.md`

---

## Passo 1 — Identificar o Ritual

**Se o ritual já vier especificado no acionamento** (ex: "me prepara para o All Hands Vendas"), ir direto ao Passo 2.

**Se não**, perguntar:

> "Qual ritual você quer preparar hoje?
>
> **Pré-Vendas**
> 1. All Hands Pré-Vendas
> 2. Comitê de Receita (Pré-Vendas)
>
> **Vendas**
> 3. All Hands Vendas
> 4. Comitê de Receita (Vendas)
> 5. WBR (Weekly Business Review)
>
> Me diga o número ou o nome."

Aguardar resposta antes de prosseguir.

---

## Passo 2 — Roteamento para o Ritual

Ler o arquivo do ritual e executar o(s) script(s) indicados:

| Ritual | Arquivo de instruções | Script(s) | Status |
|---|---|---|---|
| All Hands Pré-Vendas | `{workflow-dir}/rituais/all-hands-pre-vendas.md` | `all_hands_pv.py` | ✅ |
| Comitê de Receita (PV) | `{workflow-dir}/rituais/comite-receita.md` | `comite_receita.py` + `comite_receita_agd.py` + `comite_receita_sal_opp.py` | ✅ |
| All Hands Vendas | `{workflow-dir}/rituais/all-hands-vendas.md` | `all_hands_vendas.py` | ✅ |
| Comitê de Receita (Vendas) | `{workflow-dir}/rituais/comite-receita-vendas.md` | `comite_receita_vendas.py` | ✅ |
| WBR | `{workflow-dir}/rituais/wbr.md` | `wbr_pre_vendas.py` + `wbr_vendas.py` | ✅ |
| Reunião Semanal de Pessoas | — | — | 🔜 Em breve |
| 1:1 com liderança | — | — | 🔜 Em breve |

Se o ritual estiver marcado como **🔜 Em breve**:
> "Esse ritual ainda não está configurado. Posso preparar o **All Hands Pré-Vendas**, **All Hands Vendas**, o **Comitê de Receita** ou a **WBR** agora. Qual você prefere?"

---

## Passo 3 — Execução

> ⚠️ **Todos os rituais são executados via script Python pré-validado.**
> Nunca montar queries manualmente — os scripts já têm os guardrails, deduplicações e filtros corretos.

**Path base:** `{workflow-dir}/rituais/`
Substituir `{workflow-dir}` pelo diretório real do WORKFLOW.md em execução.

### Como executar cada script

```bash
python "{workflow-dir}/rituais/<nome_do_script>.py"
```

- Apresentar o output **exatamente como retornado** pelo script.
- Para rituais com múltiplos scripts (Comitê de Receita, WBR), executar em sequência e apresentar cada output separadamente.
- Após os outputs, conduzir a **sessão consultiva** se o ritual indicar (Comitê de Receita).

### Se o script falhar

1. Verificar se o Databricks está acessível — tentar novamente.
2. Se persistir, informar o usuário: qual script falhou e qual bloco de dados está ausente.
3. Nunca substituir um script com queries avulsas sem antes ler o arquivo `.md` do ritual para entender os guardrails.

---

## Knowledge base

| Arquivo | Conteúdo |
|---|---|
| `knowledge/tech-databricks.md` | Host, warehouse, padrões de execução, errata técnica |
| `knowledge/hierarquia-pv.md` | Hierarquia de referência Pré-Vendas (squads e coordenadores) |
| `knowledge/outputs-referencia.md` | Exemplos reais de output de cada ritual (mai/26) |
| `knowledge/guia-gestores.md` | Guia de uso para gestores — como acionar e interpretar |

---

## Acionamento

- `/preparo-reuniao`
- "preparar reunião"
- "me prepara para o [ritual]"
- "análise para a reunião de [ritual]"
- "preparar all hands", "preparar WBR", "preparar comitê"