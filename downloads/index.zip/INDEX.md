# Design Philosophy Showcases — Sample Asset Index

> 8 scenarios × 3 styles = 24 pre-built design samples
> Used during Phase 3 design direction recommendations to directly show "what this style looks like when built"

## Style Descriptions

| Code | School | Style Name | Visual Character |
|------|--------|-----------|-----------------|
| **Pentagram** | Information Architecture | Pentagram / Michael Bierut | Black-and-white restraint, Swiss grid, strong typographic hierarchy, #E63946 red accent |
| **Build** | Minimalism | Build Studio | Luxury-grade whitespace (70%+), subtle font weights (200-600), #D4A574 warm gold, refined |
| **Takram** | Eastern Philosophy | Takram | Soft tech feel, natural colors (beige/grey/green), rounded corners, charts as art |

## Scenario Quick Reference

### Content Design Scenarios

| # | Scenario | Size | Pentagram | Build | Takram |
|---|----------|------|-----------|-------|--------|
| 1 | WeChat Article Cover | 1200×510 | `cover/cover-pentagram` | `cover/cover-build` | `cover/cover-takram` |
| 2 | PPT Data Slide | 1920×1080 | `ppt/ppt-pentagram` | `ppt/ppt-build` | `ppt/ppt-takram` |
| 3 | Vertical Infographic | 1080×1920 | `infographic/infographic-pentagram` | `infographic/infographic-build` | `infographic/infographic-takram` |

### Website Design Scenarios

| # | Scenario | Size | Pentagram | Build | Takram |
|---|----------|------|-----------|-------|--------|
| 4 | Personal Homepage | 1440×900 | `website-homepage/homepage-pentagram` | `website-homepage/homepage-build` | `website-homepage/homepage-takram` |
| 5 | AI Directory Site | 1440×900 | `website-ai-nav/ainav-pentagram` | `website-ai-nav/ainav-build` | `website-ai-nav/ainav-takram` |
| 6 | AI Writing Tool | 1440×900 | `website-ai-writing/aiwriting-pentagram` | `website-ai-writing/aiwriting-build` | `website-ai-writing/aiwriting-takram` |
| 7 | SaaS Landing Page | 1440×900 | `website-saas/saas-pentagram` | `website-saas/saas-build` | `website-saas/saas-takram` |
| 8 | Developer Docs | 1440×900 | `website-devdocs/devdocs-pentagram` | `website-devdocs/devdocs-build` | `website-devdocs/devdocs-takram` |

> Each entry has both a `.html` (source) and a `.png` (screenshot) file

## Usage Guide

### Referencing During Phase 3 Recommendations
After recommending a design direction, show the pre-built screenshot for the corresponding scenario:
```
"Here is the Pentagram style applied to a WeChat article cover → [show cover/cover-pentagram.png]"
"The Takram style applied to a PPT data slide looks like this → [show ppt/ppt-takram.png]"
```

### Scenario Matching Priority
1. The scenario requested by the user has an exact match → show the corresponding scenario directly
2. No exact match but similar type → show the closest scenario (e.g. "product website" → show SaaS landing page)
3. Completely no match → skip pre-built samples, go directly to Phase 3.5 live generation

### Side-by-Side Comparison Display
The 3 styles for the same scenario are well suited for side-by-side display to help users visually compare:
- "Here is the same WeChat article cover implemented in 3 different styles"
- Display order: Pentagram (rational restraint) → Build (luxurious minimalism) → Takram (soft warmth)

## Content Details

### WeChat Article Cover (cover/)
- Content: Claude Code Agent Workflow — 8 parallel agent architecture
- Pentagram: Giant red "8" + Swiss grid lines + data bars
- Build: Ultra-light weight "Agent" floating in 70% whitespace + warm gold hairline
- Takram: 8-node radial flowchart as artwork + beige background

### PPT Data Slide (ppt/)
- Content: GLM-4.7 open-source model coding capability breakthrough (AIME 95.7 / SWE-bench 73.8% / τ²-Bench 87.4)
- Pentagram: 260px "95.7" anchor + red/grey/light-grey contrast bar chart
- Build: Three sets of 120px ultra-light numbers floating + warm gold gradient contrast bars
- Takram: SVG radar chart + three-color overlay + rounded data cards

### Vertical Infographic (infographic/)
- Content: AI memory system CLAUDE.md optimized from 93KB to 22KB
- Pentagram: Giant "93→22" numbers + numbered blocks + CSS data bars
- Build: Extreme whitespace + soft-shadow cards + warm gold connector lines
- Takram: SVG ring chart + organic curve flowchart + frosted-glass cards

### Personal Homepage (website-homepage/)
- Content: Independent developer Alex Chen's portfolio homepage
- Pentagram: 112px large name + Swiss grid columns + editorial numbers
- Build: Glass-effect navigation + floating stat cards + ultra-light font weight
- Takram: Paper texture + small circular avatar + hairline dividers + asymmetric layout

### AI Directory Site (website-ai-nav/)
- Content: AI Compass — 500+ AI tools directory
- Pentagram: Square search box + numbered tool list + uppercase category labels
- Build: Rounded search box + refined white tool cards + pill-shaped labels
- Takram: Organic offset card layout + soft category labels + chart-style connections

### AI Writing Tool (website-ai-writing/)
- Content: Inkwell — AI writing assistant
- Pentagram: 86px large headline + wireframe editor mockup + grid feature columns
- Build: Floating editor card + warm gold CTA + luxurious writing experience
- Takram: Poetic serif headline + organic editor + flowchart

### SaaS Landing Page (website-saas/)
- Content: Meridian — business intelligence analytics platform
- Pentagram: Black-and-white split layout + structured dashboard + 140px "3x" anchor
- Build: Floating dashboard cards + SVG area chart + warm gold gradient
- Takram: Rounded bar chart + flow nodes + soft earth tones

### Developer Docs (website-devdocs/)
- Content: Nexus API — unified AI model gateway
- Pentagram: Left sidebar navigation + square code blocks + red string highlighting
- Build: Centered floating code card + soft shadow + warm gold icons
- Takram: Beige code blocks + flowchart connections + dashed feature cards

## File Statistics

- HTML source files: 24
- PNG screenshots: 24
- Total assets: 48 files

---

**Version**: v1.0
**Created**: 2026-02-13
**For use with**: design-philosophy skill Phase 3 recommendation stage
