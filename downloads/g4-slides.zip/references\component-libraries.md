# Component Libraries — when the 20 G4 templates aren't enough

> The 20 canonical G4 templates cover ~80% of slide patterns we use at G4. This reference is the escalation path for the other 20%.
>
> **Universal rule:** any third-party component must be **re-wrapped in a G4 `<article class="slide">`** so it inherits canvas, palette, footer, and 1-accent discipline. Never let a shadcn/Tailwind/Material theme leak through.

## Decision tree

```
Need a chart?            → Recharts (default) or Visx (custom)
Need a complex table?    → shadcn/ui Table component, restyled to G4
Need a process flow?     → Mermaid, render to SVG, inline
Need an architecture?    → Mermaid or hand-authored SVG
Need a custom diagram?   → Excalidraw JSON → SVG, or hand-authored SVG
Need an illustration?    → GPT Image 2 or Gemini Image
Need an icon?            → react-icons + sharp
Need a KPI tile?         → stick with template 10-stats
Need a data table?       → stick with template, or plain <table> with G4 tokens
```

## Recharts (default for charts)

Install: `npm install recharts`. Bar color `var(--fg)` default, `var(--accent)` for highlighted bar. One bar = one accent. Wrap in `<article class="slide">`.

## Visx (when Recharts is too constrained)

Install: `npm install @visx/group @visx/shape @visx/scale @visx/axis d3-array`. Use only for Sankey, treemap, force, geographic, or custom charts.

## shadcn/ui (tables, dialogs, complex UI)

Copy the component source and restyle to G4 CSS vars — never ship raw Tailwind classes. Tables use hairline dividers, header row uses 2px top border, no fill.

## Mermaid (process flows, architecture, decision trees)

Apply G4 palette via `themeVariables`. Use `classDef` to mark at most 1 node as accent. Keep node count ≤6.

## Excalidraw (hand-drawn diagrams)

Draw, export as SVG, inline as static asset. Override default colors to G4 palette.

## D3 (when nothing else fits)

Overkill for slides in 90% of cases. Reach for it only for genuinely custom viz or animated transitions.

## Icons (react-icons + sharp)

One icon family per deck. Standardize strokeWidth. One accent color (gold), everything else ink.

## Image generation

Tools: `mcp__gpt-image-2__generate_image`, `mcp__nano-banana__generate_image`. Prompt discipline: navy+gold+paper, editorial/restrained mood, no emoji/rainbow/AI-purple-gradient. Always re-wrap in `<article class="slide">` with eyebrow+h1+lede.

## What NOT to reach for

- Don't use Chart.js — Recharts is better for React+G4.
- Don't use Material UI/Chakra/Bootstrap — will fight G4 tokens.
- Don't use D3 for things Recharts does.
- Don't invent a new icon family per slide.
- Don't use Mermaid for hierarchies with >6 nodes — split into multiple slides.
