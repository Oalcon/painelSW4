---
name: "g4-slides"
version: v7
description: "Build G4-branded HTML slide decks (navy + gold + paper, 1600×900) using the Core-Slides-G4 design system. Use when user asks to create, edit, or publish a G4 slide deck, aula, workshop deck, G4 OS presentation, or custom visual framework. Wraps the three official Órbita libraries (`templates-short-deck/` 52 + `templates-expanded-deck/` 109 + `deck-frameworks/` 18 specialized), the 11-phase Every pipeline, and a daily-sync preflight. One slide at a time, validate visually, then next. Defaults to HTML; PPTX is the legacy exception. v7: replaced with Joao Vitor's canonical SKILL.md content (AULA vs VENDA triage, daily git-sync preflight, templates-short-deck/expanded-deck/deck-frameworks libraries) — supersedes all prior reconstructed versions."
globs: ["**/slides/**/*.html", "**/templates/*.html", "**/deck*.html", "**/aula*.html"]
---

# G4 Slides — HTML-first, Core-Slides-G4 backed, Every 11-phase pipeline

> **You are reading the entry point.** The design system, templates, style.css, AGENTS.md, and build script live in **`~/Documents/GitHub/Core-Slides-G4`** (referenced live — this skill does not copy them).
>
> **Quick navigation:**
> - Hard rules & 11-phase pipeline → below
> - Catálogo dos decks atuais → `core-slides-path/templates-short-deck/` (52) e `core-slides-path/templates-expanded-deck/` (109)
> - Frameworks visuais customizáveis → `core-slides-path/deck-frameworks/` + `GUIA.md`
> - Catálogo do acervo v4 (legacy) → `core-slides-path/templates-legacy/` (48)
> - G4 design tokens, typography, palette → `core-slides-path/AGENTS.md` (live)
> - Prosa, flow, bug patterns → `core-slides-path/playbook.md` (live)
> - Component library escalation → `references/component-libraries.md`
> - Every article lessons → `references/every-pptx-article.md` + `references/every-pptx-pipeline.webp`

**Resolved source path (this workspace):** `~/Documents/GitHub/Core-Slides-G4` (alias: `<CORE_SLIDES>`).

---

## 0. Before you start — ask these 3 questions

Before doing any work, surface the stakes and pick the mode:

1. **Stakes**
   - **Workshop / internal / training** — AI-assisted OK, polish at the end. Expect 5-10 iteration rounds.
   - **Client pitch / sales / product launch** — Blueprint-first, single source of truth, expect 20+ rounds.
   - **Executive offsite / C-Suite / billion-dollar audience** — **AI as rehearsal only. Final pass manual.** See Every article: "the first time we presented to the entire C-Suite of a billion-dollar company, I made the slides by hand."

**1a. AULA vs VENDA — não confunda (erro comum)**

Pergunte explicitamente ao usuário ANTES de comecar:

- **Deck de AULA / WORKSHOP / CONTEUDO** — tom didatico, agenda, secoes conceituais, "nesta aula vamos ver…", CTA = "proximo slide" ou "exercicio".
- **Deck de VENDA / PITCH / PRODUTO** — tom de pitch, problema→solucao→prova→preco→CTA, "IA rodando na sua operacao em 90 dias", numeros, comparativos, garantia, CTA = "agende o diagnostico" / "fale com vendas".

Se o usuario nao disse explicitamente, **pergunte**. Tratar um pitch como aula (ou vice-versa) gera copy que precisa ser refeita inteira. Erro documentado na sessao `260702-first-plateau` (2026-07-02): entreguei 5 slides de "aula inaugural" antes do usuario corrigir.

Mesmo deck pode ter mistura: se for **deck de venda com conteudo educacional dentro** (ex: "Academia de IA para empresas"), pergunte qual e o peso — se for > 70% venda, trate como venda desde o slide 1.

2. **Mode**
   - **`mode: g4-html` (default)** — use Core-Slides-G4 templates, navy + gold + paper, 1600×900, publish via g4os-pages.
   - **`mode: g4-html + framework`** — use `deck-frameworks/` when the visual model itself is the content: cycles, systems, layers, decision maps, strategic tools.
   - **`mode: g4-html + new-template`** — same, but you need a new template pattern. Follow `core-slides-path/docs/CUSTOMIZE.md`.
   - **`mode: pptx-legacy`** — only when the user hands you a `.pptx` to edit or the recipient is locked to PowerPoint. Delegate to the **`pptx`** skill (separate).

3. **Distribution**
   - **g4os-pages** (default) — single self-contained HTML, ≤5MB, shareable URL.
   - **PDF export** — Chrome headless, 1 slide at a time, no merging. See §10.
   - **Local-only** — no publish, just generate the slide files.

If stakes are C-Suite AND mode is HTML, **explicitly tell the user** you'll use AI for the rehearsal and they'll polish the final pass manually.

---

## 0.5 Preflight — validate template location + sync repo (max 1x per day)

**This section runs at the top of EVERY skill invocation.** It validates that the local `Core-Slides-G4` repo exists at the expected path AND that the templates inside are up to date with the GitHub remote. It runs at most **once per day per session** to keep latency low (no `git fetch` mid-iteration).

### Step 1 — Locate `<CORE_SLIDES>`

```bash
CORE_SLIDES="$HOME/Documents/GitHub/Core-Slides-G4"

if [ ! -d "$CORE_SLIDES" ]; then
  echo "Core-Slides-G4 not found at $CORE_SLIDES"
  echo "Ask the user: 'Onde esta o repo? Ou clonar do GitHub em ~/Documents/GitHub/Core-Slides-G4?'"
fi
```

**Do not auto-clone.** Just because the canonical path is empty doesn't mean the user has the repo elsewhere. Ask them.

### Step 2 — Validate the three official libraries are present

```bash
for d in templates-short-deck templates-expanded-deck deck-frameworks; do
  if [ ! -d "$CORE_SLIDES/$d" ]; then
    echo "$d is missing — the local clone is incomplete. Re-clone or restore the folder."
  fi
done

test -f "$CORE_SLIDES/deck-frameworks/GUIA.md" || echo "missing deck-frameworks/GUIA.md"
```

**Optional folders (not required, just tolerated):** `templates-legacy/`, `templates-column/`.

### Step 3 — Daily self-update (max 1x/day)

The skill stays in sync with the GitHub remote via a **timestamp gate**: only fetch/pull on the first invocation of the day.

```bash
SYNC_MARKER="$HOME/.cache/g4-slides/last-sync.txt"
TODAY=$(date "+%Y-%m-%d")
LAST_SYNC=$(cat "$SYNC_MARKER" 2>/dev/null || echo "1970-01-01")

if [ "$TODAY" != "$LAST_SYNC" ]; then
  cd "$CORE_SLIDES" && git fetch origin main 2>&1 | tail -3
  BEHIND=$(git rev-list --count HEAD..origin/main 2>/dev/null || echo 0)
  if [ "$BEHIND" -gt 0 ]; then
    git pull --ff-only origin main 2>&1 | tail -5
  fi
  mkdir -p "$(dirname "$SYNC_MARKER")"
  echo "$TODAY" > "$SYNC_MARKER"
fi
```

**Rules for the sync:**

- **Fast-forward only** (`--ff-only`). If diverged, **STOP and ask the user**.
- **Never auto-push.** Only pulls.
- **One fetch per day max.**
- **If `git fetch` fails**, warn the user but continue with what's on disk.

### Step 4 — Surface the version in the response

After the preflight, the first assistant response should include: `Core-Slides-G4 @ <branch> <short-sha> (synced <date>)`. If local is behind remote by more than 5 commits, flag it.

### Step 5 — Decide deck-pick

**Default sensato:** `templates-short-deck/` (52 slides) — covers 90% of projects.

**Promote to `templates-expanded-deck/`** when the user needs: DRE, fluxo de caixa, orcamento, cenarios, mapa de riscos, case study, mockup de produto, arquitetura, heatmap, gantt, pitch de vendas completo, programa de 2 dias, hub radial ou galeria de retratos.

**Switch to `deck-frameworks/`** when the framework itself is the content: cycles, systems, layers, maps, decision models, strategic tools, custom geometry, a reusable visual model that should remain editable in HTML/CSS/SVG.

Do not use `deck-frameworks/` for ordinary charts, tables, agendas, quotes, or generic lists. Read `deck-frameworks/GUIA.md` before choosing or creating a framework.

---

## 1. The 4 hard-won rules (from Every article)

1. **One slide at a time.** Copy template → edit → validate visually → next. AGENTS.md calls this "Regra de ouro."
2. **200K token context rot.** HTML is cheaper than .pptx XML.
3. **80% right is worse than 0%.** The bar for "AI helps" is near-zero defect.
4. **Verification metrics ≠ visual QA.** You have to look.

---

## 2. The 11-phase pipeline (Every article, mapped to G4)

| # | Phase | What happens | Tools |
|---|---|---|---|
| **0** | Brief & stakes | Ask 3 questions above. | Conversation |
| **1** | Template preparation | Pick closest G4 template (see §3). `cp <CORE_SLIDES>/templates-short-deck/NN-name.html` into work dir. | bash, read |
| **2** | Framing | Build outline: agenda → narrative spine → per-slide visual direction. **Wait for approval.** | Markdown outline |
| **3** | Research & decision-making | Sequential steps. | subagent_run |
| **4** | Content research (parallel) | Fan out N subagents if brief is large. | subagent_run |
| **5** | Front-of-deck (parallel) | Capa → agenda → key messages → opening. | Edit HTML |
| **6** | Back-of-deck (parallel) | Analysis → data → appendices. | subagent_run |
| **7** | Narrative polish | Read titles in order. **No new content.** | Markdown review |
| **8** | Visual assets | Charts, icons. 1-accent rule. | recharts/visx/mermaid |
| **9** | Assembly | Edit slide HTML. | Edit tool |
| **10** | Review (bug-hunt loop) | Open in browser. Look. | Browser |
| **11** | Handover | (a) index.html passador. (b) build-deck-inlined.py → ≤5MB. (c) republish_page. | bash, g4os-pages |

**If any phase breaks, isolate and re-run only that phase.**

**2a. Antes da Fase 0 — escolha o `index.html` BASE correto (erro comum)**

O `<CORE_SLIDES>` tem **3 bibliotecas oficiais** e 2 acervos opcionais:

- **`templates-short-deck/`** — 52 slides na linguagem "Orbita". Use como padrao.
- **`templates-expanded-deck/`** — 109 slides, mesma linguagem + layouts de case, financeiro, pitch, produto e aulas.
- **`deck-frameworks/`** — biblioteca especializada em ciclos, sistemas, camadas, mapas, modelos de decisao.
- **`templates-legacy/`** — 48 templates v4 hairline (acervo congelado).
- **`templates-column/`** — 52 slides pele visual Column (fintech institucional).

**Bibliotecas oficiais vao no `git clone`**: `templates-short-deck/`, `templates-expanded-deck/`, `deck-frameworks/`. **Acervos local-only (gitignored)**: `templates-legacy/`, `templates-column/`.

**Qual biblioteca usar?**

1. **Default:** `templates-short-deck/` (90% dos projetos).
2. **Promova para `templates-expanded-deck/`** quando precisar de DRE, fluxo de caixa, mapa de riscos, mockup, arquitetura, heatmap, case completo, pitch completo, programa de 2 dias, hub radial.
3. **Use `deck-frameworks/`** quando a relacao espacial for a mensagem.
4. Em `deck-frameworks/`, abra `index.html`, leia `GUIA.md`, escolha a geometria mais proxima.
5. **`templates-legacy/`** so pra estilo hairline v4; **`templates-column/`** so quando pedirem estetica fintech.

**`index.html` (passador) do deck final:**

- Fica DENTRO da biblioteca escolhida: `templates-short-deck/index.html`, `templates-expanded-deck/index.html` ou `deck-frameworks/index.html`.
- O passador antigo (canonico, 2 colunas, sem logo G4) esta em `<CORE_SLIDES>/examples/index.html` — use SO pra decks do acervo v4.
- A versao customizada v5 Orbita (3 colunas, logo G4 + Playfair, cards arredondados, hud pill, `--gold: #C9A05C`) esta em `<WORKSPACE_ROOT>/founder-ia-conteudo-V2/index.html`. NAO escreva `index.html` do zero — copie e troque so `<title>`, `<h1>`, `<div class="meta">`, array `slides`, contador.

**Pulo comum:** usar `examples/index.html` (v4) num deck Orbita. Resultado: passador sem logo G4, sem Playfair, 2 colunas. **Sempre confira qual `index.html` esta aberto antes da versao final.**

---

## 3. The 20 canonical G4 templates (+ 14 custom variants)

Live in `<CORE_SLIDES>/templates-legacy/` (48 v4), `<CORE_SLIDES>/templates-short-deck/` (52 Orbita, padrao), `<CORE_SLIDES>/templates-expanded-deck/` (109 Orbita, completo), `<CORE_SLIDES>/deck-frameworks/` (modelos especializados).

| # | Template | When to use | Mode |
|---|---|---|---|
| 01 | capa | First slide | dark |
| 02 | palestrante | Bio + portrait | light |
| 03 | quote-com-imagem | Quote attributed | light |
| 04 | quote-sem-imagem | Generic quote | light |
| 05 | grafico-horizontal | Bar chart 2-5 cat | light |
| 06 | texto-focado | Strong thesis | light |
| 07 | timeline | 3-5 events | light |
| 08 | divisor | Section separator | dark |
| 09 | comparacao | Before/after | light |
| 10 | stats | 4 metrics | light |
| 11 | agenda | 3-6 stages | light |
| 12 | imagem-legenda | Case study | light |
| 13 | lista-numerada | 3-7 items | light |
| 14 | tres-pilares | Manifesto | light |
| 15 | encerramento | Last slide | light |
| 16 | grafico-vertical | Volume + insight | light |
| 17 | a-vs-b | Split 50/50 | light |
| 18 | bento | 4-6 blocks | light |
| 19 | stepper | 4-5 stages | light |
| 20 | quote-hero | Large quote | dark |
| 21-25 | custom patterns | 2-boxes, mixed-grid, custom-2col, pergunta-cta, hero-logo-g4 | light/dark |
| 26 | quote-galeria-split | Quote + 50/50 gallery-mat image | light+dark |
| 27 | mentor-hero | Bio + giant name 140px + hairline blocks | light |
| 28 | transicao-aceleradores | Transition + 4-item strip | light |
| 29 | bento-comparativo | Dual bento A vs B | light |
| 30 | grid-ferramentas | 4-col tool grid | light |
| 31 | narrativa-numerica | 3-col hero-num grid | light |
| 32 | bento-metricas | 3x3 asymmetric bento | light |
| 33 | tres-pilares-percent-dark | 3 pillars + giant % | dark |
| 34 | encerramento-quote-dark | Closing giant quote + CTA | dark |

**When to use what** (playbook.md §5): >6 categorias → 16 nao 05 · 3+ opcoes → 22 nao 17 · quote+portrait → 03 nao 04 · 4-6 KPIs → 10 nao 05 · processo+output → 19 nao 11.

### 3a. `deck-frameworks/` — specialized visual models

Use only when the geometry explains the idea. Open `deck-frameworks/index.html`, read `GUIA.md`.

| # | Framework | Start here when… |
|---|---|---|
| 01 | Ciclos interdependentes | two loops exchange info via critical handoff |
| 02 | Escolha de proposta de valor | central decision surrounded by 6 territories |
| 03 | Espectro de proposta de valor | model moves broad layers → specific actions |
| 04 | Alavancas de criacao de valor | parallel dimensions compared |
| 05 | Builder de proposta de valor | tool built in circular 6-part sequence |
| 06 | Canvas de proposta de valor | value map + customer profile fit |
| 07 | Mapa de valor x perfil | offer/need bowtie |
| 08 | Pentagono de co-criacao | 5 movements orbit central principle |
| 09 | Branding/identidade/marca | intention → expression → perception |
| 10 | Processo de marca | 5 sequential stages |
| 11 | Marca e negocio | business + brand strategy connect |
| 12 | Mercado ao nicho | market narrows to niche |
| 13 | Mapa de stakeholders | interest groups orbit org |
| 14 | Intersecoes (Venn) | overlapping territories |
| 15 | Elementos estrategia de marca | 4 dims surround core |
| 16 | Piramide de ressonancia | hierarchy toward resonance |
| 17 | Modelo de branding | identity/expression/perception/mgmt circuit |
| 18 | Painel execucao de marca | stages+progress+priorities in 1 panel |

**Custom framework workflow:** 1) state relationship in 1 sentence, 2) list entities/connections/hierarchy/gold protagonist, 3) copy closest framework (dont modify official), 4) replace copy first, change geometry after, 5) recalculate radii/angles/coords, 6) keep editable HTML/CSS/SVG, 7) validate in browser 1 slide at a time, 8) add to catalog only if reusable.

Do not use for ordinary charts/tables/agendas/quotes/lists.

---

## 4. Hard G4 design rules (from AGENTS.md)

1. **1 accent per slide.** Gold `#B9915B` max 1x (eyebrow excluded).
2. **Italic + weight, never font swap.** Serif (Cormorant Garamond) only capa+dark dividers+dark questions.
3. **No card/sombra/glass.** Hierarchy via `border-top: 1-2px solid var(--ink)`.
4. **No emoji.**
5. **Hex colors explicit.** Gold `#B9915B`, navy-600 `#001A2D`.
6. **1 slide at a time, validate, next.**
7. **No vw/vh on `.slide`.** Fixed 1600x900, transform scale.

**Palette (read live from library's style.css):** `--bg` paper `#F5F4F3` / navy-600 `#001A2D` dark. `--fg` ink `#0F1419` / navy-50 `#E6EEF3` dark. `--accent` gold `#B9915B` both.

**Typography (3 families):** Space Grotesk (display) · IBM Plex Sans (body) · IBM Plex Mono (labels). Hierarchy by italic+weight, NEVER font swap.

---

## 5. Canvas invariants

`<article class="slide" data-section="...">` is the only canvas. `<div class="stage">` centers — don't touch. `fit()` script mandatory. No slide-count footer.

---

## 6. Common bug patterns

Grid invades title (reserve top:380+) · max-width conflicts with rail · list padding excessive · flex:1 vacuum (justify-content:space-between) · video too big (ffmpeg compress) · srcdoc breaks (setAttribute not interpolation) · CSS in iframe srcdoc (inline style.css).

---

## 7. Sub-agent rules

Redesign/visual review → subagent opus-4-7. Audit 5+ slides → subagent code-only. NEVER subagent for 1 simple slide.

---

## 8. Iteration expectations

Best case: 5-10 rounds. Average: 15-25 rounds. Realistic AI best (Every): 40 rounds/$62/deck. C-Suite: manual final pass.

---

## 9. Publish path (g4os-pages)

`republish_page(slug, html)`. Limits: 5MB/file, 1 file/page, no SSR. Binaries use `contentBase64`, NEVER `__READ_FILE__`. Always same slug on update.

---

## 10. PDF export

Chrome headless, 1 slide at a time. Never merge before printing.

---

## 11. When to NOT use this skill

.pptx to edit → `pptx` skill. Non-G4 deck → `taste-design`/`imagegen-frontend-web`. Single image → `gpt-image-2`/`nano-banana`. Quick markdown → just write it.

---

## 12. Local setup

`git clone https://github.com/joaovitor2763/Core-Slides-G4.git` at `~/Documents/GitHub/`. Never copy into skill dir — always reference live clone. From 1st use, §0.5 preflight handles the rest.

---

## Cross-references

- Preflight + daily sync — §0.5
- Source of truth — `~/Documents/GitHub/Core-Slides-G4/AGENTS.md`
- Catalogo deck curto (52) — `templates-short-deck/`
- Catalogo deck expandido (109) — `templates-expanded-deck/`
- Frameworks visuais — `deck-frameworks/`
- Acervo v4 — `templates-legacy/`
- Component library escalation — `references/component-libraries.md`
- Every article lessons — `references/every-pptx-article.md`
- Legacy .pptx — skill `pptx`
