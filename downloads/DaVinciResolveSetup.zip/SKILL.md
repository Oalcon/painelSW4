---
name: "DaVinci Resolve Setup"
description: "Sets up the full DaVinci Resolve + Whisper AI integration environment on any computer. Trigger with /davinci-setup or when a user says they want to integrate DaVinci Resolve with G4 OS, set up the subtitle pipeline, install Whisper for DaVinci, or configure the DaVinci scripting environment. Handles macOS (arm64/x86), Windows, and Linux automatically."
alwaysAllow: ["Bash", "Write", "Read"]
---

# DaVinci Resolve Setup

You are setting up a complete DaVinci Resolve + Whisper AI integration environment. This is the foundation for the `/legenda-reel` subtitle generation pipeline.

## Step 1 — Detect OS and Architecture

Run the detection script immediately, before asking anything:

```python
import platform, sys, os
print(platform.system())       # Darwin / Windows / Linux
print(platform.machine())      # arm64 / x86_64 / AMD64
print(sys.version)
print(os.path.expanduser("~"))
```

Classify into one of:
- `macos-arm` — Darwin + arm64 (Apple Silicon)
- `macos-x86` — Darwin + x86_64 (Intel Mac)
- `windows` — Windows (any arch)
- `linux` — Linux (any arch)

All subsequent steps adapt to this classification. Read [references/os-paths.md](references/os-paths.md) for exact paths and commands per OS.

## Step 2 — Verify DaVinci Resolve is Installed

Check that the DaVinci scripting module exists at the expected path (see references/os-paths.md). If not found:
- Tell the user DaVinci Resolve must be installed first
- Point them to: blackmagicdesign.com/products/davinciresolve
- Stop and wait — do not proceed without the module

## Step 3 — Install Python

Check if `python3` (macOS/Linux) or `python` (Windows) is available and is version 3.10–3.12.

- **macOS**: If missing or wrong version, install via `brew install python@3.12`. If Homebrew is missing, install it first.
- **Windows**: Download Python 3.12 from python.org (provide the direct .exe URL). Guide the user to run it and check "Add to PATH".
- **Linux**: `sudo apt install python3.12 python3.12-venv python3-pip` (Debian/Ubuntu) or equivalent.

## Step 4 — Create Virtual Environment

Create an isolated environment at the standard path for the OS:

- **macOS/Linux**: `python3.12 -m venv ~/.davinci-env`
- **Windows**: `python -m venv %USERPROFILE%\.davinci-env`

Activate it:
- **macOS/Linux**: `source ~/.davinci-env/bin/activate`
- **Windows**: `%USERPROFILE%\.davinci-env\Scripts\activate.bat`

## Step 5 — Install Python Packages

Install packages in this order inside the venv. **CRITICAL**: torch install command varies by OS — see [references/os-paths.md](references/os-paths.md) for exact pip commands.

1. Upgrade pip: `pip install --upgrade pip`
2. Install torch (CPU-only — exact command varies by OS)
3. Install Whisper: `pip install openai-whisper`
4. Install numpy: `pip install "numpy<2"`

**CRITICAL for macOS ARM**: torch must be CPU-only version. MPS (Metal) has a NaN bug that corrupts Whisper transcriptions silently. Always force `device="cpu"` in all Whisper calls.

Verify installation:
```bash
python -c "import whisper, torch; print('torch:', torch.__version__); m=whisper.load_model('base'); print('Whisper OK')"
```

## Step 6 — Configure DaVinci Scripting Path

Add the DaVinci scripting module to PYTHONPATH permanently.

**macOS/Linux** — append to `~/.zshrc` (or `~/.bashrc`):
```bash
export PYTHONPATH="$PYTHONPATH:/Library/Application Support/Blackmagic Design/DaVinci Resolve/Developer/Scripting/Modules"
export RESOLVE_SCRIPT_API="/Library/Application Support/Blackmagic Design/DaVinci Resolve/Developer/Scripting"
export RESOLVE_SCRIPT_LIB="/Applications/DaVinci Resolve/DaVinci Resolve.app/Contents/Libraries/Fusion/fusionscript.so"
```

**Windows** — set via `setx` (permanent user env vars):
```cmd
setx PYTHONPATH "%PYTHONPATH%;C:\ProgramData\Blackmagic Design\DaVinci Resolve\Support\Developer\Scripting\Modules"
setx RESOLVE_SCRIPT_API "C:\ProgramData\Blackmagic Design\DaVinci Resolve\Support\Developer\Scripting"
setx RESOLVE_SCRIPT_LIB "C:\Program Files\Blackmagic Design\DaVinci Resolve\fusionscript.dll"
```

Also add the module path directly in the venv's `sitecustomize.py` so it works without env vars:
```python
# Write to: {venv}/lib/pythonX.X/site-packages/sitecustomize.py
import sys
DAVINCI_MODULES = "<os-specific-path>"
if DAVINCI_MODULES not in sys.path:
    sys.path.insert(0, DAVINCI_MODULES)
```

See [references/os-paths.md](references/os-paths.md) for all exact paths.

## Step 7 — Test Connection

Ask the user to **open DaVinci Resolve** before running this step.

Run the connection test:

```python
import sys
sys.path.insert(0, "<davinci-modules-path>")
import DaVinciResolveScript as dvr
resolve = dvr.scriptapp("Resolve")
if not resolve:
    print("ERROR: Could not connect. Is DaVinci Resolve open?")
    exit(1)
pm = resolve.GetProjectManager()
project = pm.GetCurrentProject()
print(f"Connected! Current project: {project.GetName() if project else 'None'}")
projects = pm.GetProjectListInCurrentFolder()
print(f"Projects available: {projects}")
```

If connection succeeds: confirm setup is complete.
If it fails: check [references/os-paths.md](references/os-paths.md) troubleshooting section.

Optionally offer to close DaVinci: `resolve.Quit()`.

## Step 8 — Summary Report

After successful setup, report:

```
✓ OS detected: {os}
✓ Python: {version} at {path}
✓ Virtual env: {venv_path}
✓ Packages: torch {version}, whisper {version}, numpy {version}
✓ DaVinci module: found at {module_path}
✓ PYTHONPATH: configured
✓ Connection test: {result}

Next step: /legenda-reel — generate subtitles for any DaVinci timeline
```

## Important Caveats

- **Never edit SQLite Project.db while DaVinci is open** — always close DaVinci first
- **Whisper device**: always `device="cpu"` — never `"mps"` or `"cuda"` unless on Linux with verified CUDA
- **word_timestamps=True** is required for the subtitle pipeline
- **venv activation**: remind the user to activate the venv (`source ~/.davinci-env/bin/activate`) in every new terminal session, or use the full path `~/.davinci-env/bin/python`
