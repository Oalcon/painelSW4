# OS-Specific Paths and Commands

## Path Reference Table

| Resource | macOS arm64 | macOS x86_64 | Windows | Linux |
|---|---|---|---|---|
| DaVinci modules | `/Library/Application Support/Blackmagic Design/DaVinci Resolve/Developer/Scripting/Modules` | same as arm64 | `C:\ProgramData\Blackmagic Design\DaVinci Resolve\Support\Developer\Scripting\Modules` | `/opt/resolve/Developer/Scripting/Modules` or `/home/$USER/resolve/Developer/Scripting/Modules` |
| RESOLVE_SCRIPT_API | `/Library/Application Support/Blackmagic Design/DaVinci Resolve/Developer/Scripting` | same | `C:\ProgramData\Blackmagic Design\DaVinci Resolve\Support\Developer\Scripting` | `/opt/resolve/Developer/Scripting` |
| RESOLVE_SCRIPT_LIB | `/Applications/DaVinci Resolve/DaVinci Resolve.app/Contents/Libraries/Fusion/fusionscript.so` | same | `C:\Program Files\Blackmagic Design\DaVinci Resolve\fusionscript.dll` | `/opt/resolve/libs/Fusion/fusionscript.so` |
| venv path | `~/.davinci-env` | `~/.davinci-env` | `%USERPROFILE%\.davinci-env` | `~/.davinci-env` |
| venv python | `~/.davinci-env/bin/python` | same | `%USERPROFILE%\.davinci-env\Scripts\python.exe` | `~/.davinci-env/bin/python` |
| venv activate | `source ~/.davinci-env/bin/activate` | same | `%USERPROFILE%\.davinci-env\Scripts\activate.bat` | `source ~/.davinci-env/bin/activate` |
| sitecustomize.py | `~/.davinci-env/lib/python3.12/site-packages/sitecustomize.py` | same | `%USERPROFILE%\.davinci-env\Lib\site-packages\sitecustomize.py` | `~/.davinci-env/lib/python3.12/site-packages/sitecustomize.py` |
| Project.db location | `~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Resolve Disk Database/...` or Dropbox | same | `%APPDATA%\Blackmagic Design\DaVinci Resolve\...` | `~/.local/share/DaVinciResolve/...` |
| Shell config | `~/.zshrc` (default) or `~/.bashrc` | same | N/A (use setx) | `~/.bashrc` or `~/.bash_profile` |

---

## pip Install Commands — torch (CPU only)

### macOS arm64 (Apple Silicon)
```bash
pip install torch torchvision torchaudio
```
Note: PyTorch ships CPU+MPS on macOS arm64 by default. MPS is available but **must not be used for Whisper** (NaN bug). Always pass `device="cpu"` explicitly.

### macOS x86_64 (Intel)
```bash
pip install torch torchvision torchaudio
```

### Windows (CPU only)
```bash
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
```

### Linux (CPU only)
```bash
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
```

---

## Full Install Sequence (copy-paste per OS)

### macOS (arm64 or x86)
```bash
# 1. Install Homebrew if missing
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# 2. Install Python 3.12
brew install python@3.12

# 3. Create venv
python3.12 -m venv ~/.davinci-env

# 4. Activate
source ~/.davinci-env/bin/activate

# 5. Install packages
pip install --upgrade pip
pip install torch torchvision torchaudio
pip install openai-whisper
pip install "numpy<2"

# 6. Configure PYTHONPATH (add to ~/.zshrc)
echo 'export PYTHONPATH="$PYTHONPATH:/Library/Application Support/Blackmagic Design/DaVinci Resolve/Developer/Scripting/Modules"' >> ~/.zshrc
echo 'export RESOLVE_SCRIPT_API="/Library/Application Support/Blackmagic Design/DaVinci Resolve/Developer/Scripting"' >> ~/.zshrc
echo 'export RESOLVE_SCRIPT_LIB="/Applications/DaVinci Resolve/DaVinci Resolve.app/Contents/Libraries/Fusion/fusionscript.so"' >> ~/.zshrc
source ~/.zshrc
```

### Windows
```cmd
REM 1. Create venv (after installing Python 3.12 from python.org)
python -m venv %USERPROFILE%\.davinci-env

REM 2. Activate
%USERPROFILE%\.davinci-env\Scripts\activate.bat

REM 3. Install packages
pip install --upgrade pip
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
pip install openai-whisper
pip install "numpy<2"

REM 4. Set env vars permanently
setx PYTHONPATH "%PYTHONPATH%;C:\ProgramData\Blackmagic Design\DaVinci Resolve\Support\Developer\Scripting\Modules"
setx RESOLVE_SCRIPT_API "C:\ProgramData\Blackmagic Design\DaVinci Resolve\Support\Developer\Scripting"
setx RESOLVE_SCRIPT_LIB "C:\Program Files\Blackmagic Design\DaVinci Resolve\fusionscript.dll"
```

### Linux (Ubuntu/Debian)
```bash
# 1. Install Python 3.12
sudo apt update && sudo apt install python3.12 python3.12-venv python3-pip -y

# 2. Create venv
python3.12 -m venv ~/.davinci-env

# 3. Activate
source ~/.davinci-env/bin/activate

# 4. Install packages
pip install --upgrade pip
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
pip install openai-whisper
pip install "numpy<2"

# 5. Configure PYTHONPATH
echo 'export PYTHONPATH="$PYTHONPATH:/opt/resolve/Developer/Scripting/Modules"' >> ~/.bashrc
echo 'export RESOLVE_SCRIPT_API="/opt/resolve/Developer/Scripting"' >> ~/.bashrc
echo 'export RESOLVE_SCRIPT_LIB="/opt/resolve/libs/Fusion/fusionscript.so"' >> ~/.bashrc
source ~/.bashrc
```

---

## sitecustomize.py — Venv-Embedded Path Config

Write this file so the module is always in sys.path when using the venv, regardless of shell env vars:

**macOS/Linux** — write to `~/.davinci-env/lib/python3.12/site-packages/sitecustomize.py`:
```python
import sys
DAVINCI_MODULES = "/Library/Application Support/Blackmagic Design/DaVinci Resolve/Developer/Scripting/Modules"
if DAVINCI_MODULES not in sys.path:
    sys.path.insert(0, DAVINCI_MODULES)
```

**Windows** — write to `%USERPROFILE%\.davinci-env\Lib\site-packages\sitecustomize.py`:
```python
import sys
DAVINCI_MODULES = r"C:\ProgramData\Blackmagic Design\DaVinci Resolve\Support\Developer\Scripting\Modules"
if DAVINCI_MODULES not in sys.path:
    sys.path.insert(0, DAVINCI_MODULES)
```

**Linux** — same pattern with `/opt/resolve/Developer/Scripting/Modules`.

---

## Troubleshooting

### "No module named DaVinciResolveScript"
- Verify DaVinci Resolve is installed (not just downloaded)
- Check the module path exists: `ls "/Library/Application Support/Blackmagic Design/DaVinci Resolve/Developer/Scripting/Modules"`
- Check sitecustomize.py was written correctly
- Try adding path manually: `sys.path.insert(0, "<modules-path>")`

### "Could not connect to Resolve" / resolve returns None
- DaVinci Resolve must be **open and running** during the connection test
- On macOS: check System Preferences > Security > Accessibility — DaVinci may need permission
- On macOS: check that "External scripting using network" is enabled in DaVinci Preferences > System > General
- On Windows: run the terminal as Administrator if permission errors occur

### "Enable External Scripting" (macOS/Windows)
In DaVinci Resolve: **Preferences > System > General > External scripting using** → set to **"Network"** (or "Local" on older versions).

### torch NaN / corrupted Whisper output
- Symptom: transcription produces garbage text or all-same tokens
- Cause: MPS backend on macOS ARM
- Fix: always pass `device="cpu"` to `whisper.load_model()` and `model.transcribe()`

### Whisper ffmpeg dependency
Whisper requires `ffmpeg` to decode audio files.
- **macOS**: `brew install ffmpeg`
- **Windows**: download from ffmpeg.org, add to PATH
- **Linux**: `sudo apt install ffmpeg`
