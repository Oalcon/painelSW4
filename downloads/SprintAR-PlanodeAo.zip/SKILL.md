---
name: "Sprint AR - Plano de Ação"
description: "Gera em um único Excel editável (aba única) o relatório combinado de AR — Plano Marketing + AR — Plano Comercial do programa G4 Sprints, incluindo Plano de Ação com 4 ações de marketing, 4 comerciais e 8 espaços vazios. Acionar quando o usuário pedir 'gerar Sprint AR', 'relatório completo AR', 'juntar plano marketing e comercial em um arquivo', 'plano de ação AR', ou fornecer dados dos dois workshops (marketing + comercial) para consolidar em um único relatório."
---

## Objetivo

Gerar um único arquivo Excel (`Sprint AR - Plano de Acao.xlsx`), **uma aba só**, consolidando as seções do AR — Plano Marketing e do AR — Plano Comercial, com Plano de Ação unificado (4 ações Marketing + 4 Comercial + 8 linhas vazias para o cliente completar).

## Paleta de Cores e Fontes

| Token | Hex | Uso |
|---|---|---|
| Azul navy | `#0D2B4E` | Header, títulos de seção, rodapé |
| Azul médio | `#1A3F6F` | Sub-headers, destaques |
| Azul accent | `#2A5298` | Bordas, separadores |
| Azul claro | `#DCE8FB` | Fundo alternado, ICP Campeão |
| Cinza claro | `#F4F7FC` | Fundo neutro |
| Dourado | `#C9A84C` | Separadores, badges |
| Dourado claro | `#FDF3DC` | Destaques (proposta de valor, maturidade) |
| Verde | `#1A6B3A` | KPI para cima / ação Automatizar |
| Vermelho | `#8A1A1A` | KPI para baixo / ação Descontinuar |

Fontes: títulos `Libre Baskerville` (fallback `Georgia`), corpo `Manrope` (fallback `Calibri`).

## Coleta de Dados — Pedir ao Usuário (tudo de uma vez)

Ao ser ativada, solicite os **9 itens** em uma única mensagem:

> Para montar o Sprint AR — Plano de Ação, preciso de 9 itens:
>
> **Bloco Marketing**
> 1. Contexto da empresa
> 2. Perfil do empresário (Guardião, Conquistador, Construtor ou Apostador)
> 3. Tabela do exercício 1.2 ICP (perfis de clientes levantados)
> 4. Exercício 1.3 Proposta de Valor (respostas às 3 perguntas + proposta definida)
> 5. Tabela de Canais & KPIs (aba 2.2)
>
> **Bloco Comercial**
>
> 6. Tabela da Aba 3.1 — Etapas Comerciais & Alavancas (copiar tabela)
>
> 7. Tabela da Aba 3.2 — Planejamento Comercial (meta de receita, ticket médio, funil, estrutura de time se houver, CPL se disponível)
>
> 8. Tabela da Aba 3.3 — Retenção (lista de alertas)
>
> 9. Print do gráfico da Aba 4.1 — Expansão (bubble chart)

### ⛔ GUARDRAIL — Obrigatório

**Nunca gere o Excel sem confirmar que os 9 itens foram recebidos.** Verifique cada item contra o critério mínimo:

| Item | Critério mínimo |
|---|---|
| 1. Contexto da empresa | Texto descrevendo o negócio |
| 2. Perfil do empresário | Um dos quatro nomes válidos |
| 3. Tabela 1.2 ICP | Conteúdo textual da tabela de perfis |
| 4. Proposta de Valor | Respostas às perguntas **e** proposta definida |
| 5. Canais & KPIs | Tabela com canais e KPIs |
| 6. Etapas Comerciais | Tabela copiada da Aba 3.1 com etapas e alavancas |
| 7. Planejamento Comercial | Meta de receita, ticket médio, dados de funil |
| 8. Retenção | Lista de alertas |
| 9. Gráfico de Expansão | Imagem/print do gráfico |

Se algum item faltar, liste apenas os que faltam e peça de uma vez. Repita até ter todos os 9.

## Perfis de Maturidade

| Perfil | Descrição (usar em `DESC_PERFIL`, ≤30 palavras) |
|---|---|
| **Guardião** | Empresa consolidada, perfil conservador. Protege participação de mercado com foco em retenção e eficiência. Investe apenas em canais testados para defender e estabilizar receita. |
| **Conquistador** | Empresa consolidada, perfil arrojado. Expande agressivamente para dominar mercado e tomar fatia dos concorrentes com campanhas de alto impacto e escala. |
| **Construtor** | Empresa incipiente, perfil conservador. Cresce com cautela validando canais e ICP. Prioriza eficiência por real investido antes de acelerar qualquer investimento em marketing. |
| **Apostador** | Empresa incipiente, perfil arrojado. Investe pesado para conquistar território antes da concorrência e criar autoridade de marca no mercado ainda em formação. |

## Interpretação dos Dados

### ICP (Seção 3) — REGRA CRÍTICA
- Receber o conteúdo textual da tabela 1.2 (não imagem)
- **Não listar clientes individuais por nome** — sintetizar em perfis comportamentais
- Gerar exatamente **5 bullets do Perfil Campeão**
- **Cada bullet deve ter no máximo 5 palavras.** Seja telegráfico e objetivo.
  - Bom: "Recompra frequente, ticket alto" (5 palavras)
  - Bom: "Indica novos clientes" (3 palavras)
  - Mau: "Clientes que compram com frequência e possuem ticket médio elevado" (muito longo)

### Proposta de Valor (Exercício 1.3)
3 perguntas orientadas por análise de concorrentes — usar respostas + proposta definida para:
- Extrair a frase final da proposta de valor
- Sintetizar 2 linhas: para quem é, qual dor resolve, o que diferencia

### Canais & KPIs
Selecionar os **5 canais mais relevantes** da tabela 2.2 (maior potencial de receita, priorização do aluno, diversidade estratégica). Para cada canal, escolher **1 KPI** representativo de resultado (não de processo).

### Etapas Comerciais (Comercial) — REGRA CRÍTICA
Na tabela copiada da Aba 3.1 (Etapas Comerciais & Alavancas):
- Listar cada etapa comercial informada (não inventar etapas)
- Para cada etapa, sugerir **1 indicador-mestre** (KPI de resultado, não de processo) com base no nome da etapa e na alavanca associada
- Não repetir a alavanca como indicador — o indicador-mestre deve medir o resultado que a alavanca pretende gerar
- Máximo de 6 etapas na tabela final (se houver mais, priorizar as etapas com alavanca mais relevante para a meta)

### Backward Planning (Comercial)
Todos os cálculos derivam da meta de receita (ver fórmulas no script). Se a empresa não tiver equipe comercial, usar funil simplificado (Leads → Reuniões → Vendas) com 3 blocos em vez de 4.

### Plano de Ação — REGRA CRÍTICA
Gerar exatamente **16 linhas**:
- **4 ações de Marketing** (geradas pelo assistente com base no contexto, perfil e canais)
- **4 ações Comerciais** (geradas pelo assistente com base nas alavancas da Aba 3.1, no funil e na retenção)
- **8 linhas vazias** (sem conteúdo, apenas formatadas) para o cliente preencher depois

Cada ação gerada: macro, até 7 palavras, com Responsável (cargo) e Métrica. Sem coluna "objetivo".

## Fluxo de Execução

1. Coletar os 9 itens (guardrail — não avançar sem todos)
2. Identificar perfil de maturidade e buscar `DESC_PERFIL` na tabela acima
3. Sintetizar ICP em 5 bullets de ≤5 palavras cada
4. Interpretar Proposta de Valor (frase + interpretação em 2 linhas)
5. Selecionar 5 canais/KPIs da tabela 2.2
6. Sintetizar Go-to-Market em até 30 palavras
7. Sintetizar Etapas Comerciais com 1 indicador-mestre sugerido por etapa (usar dados e alavancas da Aba 3.1)
8. Calcular Backward Planning (funil, CPL, CAC, margem, ROI) a partir da meta de receita
9. Gerar as 4 ações de Marketing + 4 Comerciais para o Plano de Ação
10. Verificar `openpyxl`: `python3 -c "import openpyxl" 2>/dev/null || pip install openpyxl -q`
11. Montar o script a partir de [references/template.md](references/template.md), substituindo todos os `{{placeholders}}` pelos dados reais
12. Salvar em `{session_scratch}/gen_sprint_ar.py` — arquivo deve começar com `# -*- coding: utf-8 -*-`
13. Executar com UTF-8 forçado: `PYTHONUTF8=1 python3 {session_scratch}/gen_sprint_ar.py`
14. Capturar o caminho retornado na linha `SAVED:...`

## Entrega

```filecard
{"type":"file_download","path":"{caminho_absoluto}/Sprint AR - Plano de Acao.xlsx","filename":"Sprint AR - Plano de Acao.xlsx","mimeType":"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","size":{bytes},"sizeHuman":"{tamanho}"}
```

> O arquivo está pronto para edição — todos os campos e as 8 linhas vazias do Plano de Ação são editáveis. Abra no Excel ou Google Sheets. Para enviar ao cliente, mova para a pasta da empresa no Google Drive.

## Referência

- Script Python completo (estrutura das 9 seções em aba única): [references/template.md](references/template.md)
