# Script Python — Sprint AR — Plano de Ação (Excel, aba única)

Script base completo. Substitua todos os `{{placeholders}}` pelos dados reais antes de executar.

```python
# -*- coding: utf-8 -*-
import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.utils import get_column_letter
import os

# ── DADOS (substituir pelos dados reais) ──────────────────────────────────────
EMPRESA = "{{EMPRESA}}"
MES_ANO = "{{MES_ANO}}"           # ex: "Junho / 2026"

# Bloco Marketing
PERFIL          = "{{PERFIL}}"            # Guardião | Conquistador | Construtor | Apostador
DESC_PERFIL     = "{{DESCRICAO_PERFIL}}"  # até 30 palavras — ver tabela "Perfis de Maturidade"
PROPOSTA        = "{{PROPOSTA_DE_VALOR}}"
INTERP_PROPOSTA = "{{INTERPRETACAO}}"     # 2 linhas
ICP_CAMPEAO = [  # 5 bullets — CADA UM COM NO MÁXIMO 5 PALAVRAS
    "{{ICP_1}}", "{{ICP_2}}", "{{ICP_3}}", "{{ICP_4}}", "{{ICP_5}}",
]
GTM = "{{GO_TO_MARKET_30_PALAVRAS}}"
CANAIS_KPIS = [  # até 5 canais, 1 KPI cada
    {"canal": "{{CANAL_1}}", "kpi": "{{KPI_1}}", "frequencia": "{{FREQ_1}}", "direcao": "up", "responsavel": "{{RESP_1}}"},
]

# Bloco Comercial
META_RECEITA = "{{META_FORMATADA}}"   # ex: "R$ 2.000.000"
TICKET_MEDIO = "{{TICKET_MEDIO}}"     # ex: "R$ 50.000"
ETAPAS_COMERCIAIS = [  # até 6 etapas da Aba 3.1, cada uma com 1 indicador-mestre sugerido
    {"etapa": "{{ETAPA_1}}", "indicador": "{{INDICADOR_1}}"},
    {"etapa": "{{ETAPA_2}}", "indicador": "{{INDICADOR_2}}"},
    {"etapa": "{{ETAPA_3}}", "indicador": "{{INDICADOR_3}}"},
]
ALERTAS = [{"titulo": "{{TITULO}}", "categoria": "{{CATEGORIA}}"}]  # máx 5

BP_META          = {{META_NUMERICA}}
BP_TICKET        = {{TICKET_NUMERICO}}
BP_VENDAS        = BP_META / BP_TICKET
BP_CONV_LEAD_REU = {{CONV_LEAD_REUNIAO}}     # 0.0–1.0
BP_CONV_REU_VEND = {{CONV_REUNIAO_VENDA}}    # 0.0–1.0
BP_REUNIOES      = BP_VENDAS / BP_CONV_REU_VEND
BP_LEADS         = BP_REUNIOES / BP_CONV_LEAD_REU
BP_LEADS_POR_SDR     = {{LEADS_POR_SDR}}      # None se sem equipe
BP_VENDAS_POR_CLOSER = {{VENDAS_POR_CLOSER}}  # None se sem equipe
BP_SAL_SDR           = {{SALARIO_SDR}}
BP_SAL_CLOSER        = {{SALARIO_CLOSER}}
BP_COMISSAO_PCT      = {{COMISSAO_PCT}}
BP_CPL               = {{CPL}}
BP_MARGEM_PCT        = {{MARGEM_CONTRIBUICAO}}
BP_SDRS     = round(BP_LEADS / BP_LEADS_POR_SDR)     if BP_LEADS_POR_SDR     else None
BP_CLOSERS  = round(BP_VENDAS / BP_VENDAS_POR_CLOSER) if BP_VENDAS_POR_CLOSER else None
BP_FOLHA    = ((BP_SAL_SDR or 0)*(BP_SDRS or 0) + (BP_SAL_CLOSER or 0)*(BP_CLOSERS or 0)) or None
BP_COMISSAO = (BP_META * BP_COMISSAO_PCT) if BP_COMISSAO_PCT else None
BP_INV_MKT  = (BP_CPL * BP_LEADS) if BP_CPL else None
BP_CUSTO_SM = sum(x for x in [BP_FOLHA, BP_COMISSAO, BP_INV_MKT] if x) or None
BP_CAC      = (BP_CUSTO_SM / BP_VENDAS) if BP_CUSTO_SM else None
BP_MRG_VND  = BP_TICKET * BP_MARGEM_PCT
BP_MRG_TOT  = BP_MRG_VND * BP_VENDAS
BP_RESULT   = (BP_MRG_TOT - BP_CUSTO_SM) if BP_CUSTO_SM else BP_MRG_TOT
BP_ROI      = (BP_RESULT / BP_CUSTO_SM * 100) if BP_CUSTO_SM else None

def fmt_brl(v):
    if v is None: return "—"
    if v >= 1_000_000: return f"R$ {v/1_000_000:.1f}M"
    if v >= 1_000: return f"R$ {v:,.0f}".replace(",", ".")
    return f"R$ {v:.0f}"
def fmt_pct(v): return f"{v*100:.1f}%" if v is not None else "—"
def fmt_n(v, d=0): return f"{v:.{d}f}" if v is not None else "—"

# Plano de Ação — 4 Marketing + 4 Comercial + 8 vazias (16 linhas)
PLANO_ACAO = [
    {"frente": "Marketing", "acao": "{{ACAO_MKT_1}}", "responsavel": "{{CARGO_MKT_1}}", "metrica": "{{METRICA_MKT_1}}"},
    {"frente": "Marketing", "acao": "{{ACAO_MKT_2}}", "responsavel": "{{CARGO_MKT_2}}", "metrica": "{{METRICA_MKT_2}}"},
    {"frente": "Marketing", "acao": "{{ACAO_MKT_3}}", "responsavel": "{{CARGO_MKT_3}}", "metrica": "{{METRICA_MKT_3}}"},
    {"frente": "Marketing", "acao": "{{ACAO_MKT_4}}", "responsavel": "{{CARGO_MKT_4}}", "metrica": "{{METRICA_MKT_4}}"},
    {"frente": "Comercial", "acao": "{{ACAO_COM_1}}", "responsavel": "{{CARGO_COM_1}}", "metrica": "{{METRICA_COM_1}}"},
    {"frente": "Comercial", "acao": "{{ACAO_COM_2}}", "responsavel": "{{CARGO_COM_2}}", "metrica": "{{METRICA_COM_2}}"},
    {"frente": "Comercial", "acao": "{{ACAO_COM_3}}", "responsavel": "{{CARGO_COM_3}}", "metrica": "{{METRICA_COM_3}}"},
    {"frente": "Comercial", "acao": "{{ACAO_COM_4}}", "responsavel": "{{CARGO_COM_4}}", "metrica": "{{METRICA_COM_4}}"},
] + [{"frente": "", "acao": "", "responsavel": "", "metrica": ""}] * 8
# ───────────────────────────────────────────────────────────────────────────────

C_NAVY      = "0D2B4E"
C_NAVY_MID  = "1A3F6F"
C_ACCENT    = "2A5298"
C_ACCENT_LT = "DCE8FB"
C_BG2       = "F4F7FC"
C_BRANCO    = "FFFFFF"
C_TEXTO     = "0D2B4E"
C_DOURADO   = "C9A84C"
C_DOURADO_CLR = "FDF3DC"
C_CAMP_BG   = "DCE8FB"
C_VERDE     = "1A6B3A"
C_VERM      = "8A1A1A"

F_TITULO = "Libre Baskerville"
F_CORPO  = "Manrope"

FRENTE_CORES = {"Marketing": ("DCE8FB", "1A3F6F"), "Comercial": ("D4F0E0", "1A6B3C")}
def fc(frente): return FRENTE_CORES.get(frente, (C_BG2, C_NAVY))

wb = openpyxl.Workbook()
ws = wb.active
ws.title = "Plano de Ação"

col_widths = [3, 22, 20, 16, 14, 12, 14, 14, 14, 14, 14, 3]
for i, w in enumerate(col_widths, 1):
    ws.column_dimensions[get_column_letter(i)].width = w

def fill(h): return PatternFill("solid", fgColor=h)
def font(name=F_CORPO, size=10, bold=False, color=C_TEXTO, italic=False):
    return Font(name=name, size=size, bold=bold, color=color, italic=italic)
def align(h="left", v="center", wrap=False): return Alignment(horizontal=h, vertical=v, wrap_text=wrap)
def rh(row, h): ws.row_dimensions[row].height = h
def merge_fill(r1, c1, r2, c2, bg, txt="", fnt=None, aln=None):
    ws.merge_cells(start_row=r1, start_column=c1, end_row=r2, end_column=c2)
    cell = ws.cell(r1, c1); cell.value = txt; cell.fill = fill(bg)
    if fnt: cell.font = fnt
    if aln: cell.alignment = aln
def sep(row, color=C_ACCENT): rh(row, 4); merge_fill(row, 1, row, 12, color, "")
def sec_title(row, label):
    rh(row, 22)
    merge_fill(row, 1, row, 12, C_NAVY_MID, f"   {label}", font(F_TITULO, 11, True, C_BRANCO), align("left", "center"))

# ── HEADER ─────────────────────────────────────────────────────────────────────
rh(1,6); rh(2,32); rh(3,20); rh(4,4); rh(5,8)
merge_fill(2,1,2,12, C_NAVY, f"   Sprint AR — Plano de Ação  |  {EMPRESA}",
    font(F_TITULO,20,True,C_BRANCO), align("left","center"))
merge_fill(3,1,3,9,  C_NAVY, "   G4 Sprints — Aumento de Receita · Marketing + Comercial",
    font(F_CORPO,10,False,"6B8BAF"), align("left","center"))
merge_fill(3,10,3,12,C_NAVY, f"{MES_ANO}   ", font(F_CORPO,10,False,C_DOURADO), align("right","center"))
sep(4, C_DOURADO); cur = 6

# ── SEÇÃO 1: MATURIDADE ────────────────────────────────────────────────────────
sec_title(cur, "1. Estágio de Maturidade"); cur += 1
rh(cur, 26)
merge_fill(cur,1,cur,12, C_NAVY, f"   {PERFIL}", font(F_TITULO,16,True,C_DOURADO), align("left","center"))
cur += 1
for r in range(3): rh(cur+r, 18)
merge_fill(cur,1,cur+2,12, C_DOURADO_CLR, f"   {DESC_PERFIL}", font(F_CORPO,10,False,C_TEXTO), align("left","center",True))
cur += 3
sep(cur,C_ACCENT); cur+=1; rh(cur,6); cur+=1

# ── SEÇÃO 2: PROPOSTA DE VALOR ─────────────────────────────────────────────────
sec_title(cur, "2. Proposta de Valor"); cur += 1
rh(cur,22)
merge_fill(cur,1,cur,12, C_DOURADO_CLR, f'   "{PROPOSTA}"', font(F_TITULO,13,True,C_NAVY), align("left","center",True))
cur += 1
rh(cur,18)
merge_fill(cur,1,cur,12, C_ACCENT_LT, f"   {INTERP_PROPOSTA}", font(F_CORPO,10,False,C_TEXTO), align("left","center",True))
cur += 1
sep(cur,C_ACCENT); cur+=1; rh(cur,6); cur+=1

# ── SEÇÃO 3: ICP — PERFIL CAMPEÃO (bullets ≤5 palavras) ───────────────────────
sec_title(cur, "3. ICP — Perfil Campeão"); cur += 1
icons = ["🔄","📦","📈","💡","🎯"]
for i, txt in enumerate(ICP_CAMPEAO[:5]):
    rh(cur, 18)
    bg = C_CAMP_BG if i % 2 == 0 else C_BRANCO
    merge_fill(cur,1,cur,12, bg, f"   {icons[i]}  {txt}", font(F_CORPO,10,True,C_NAVY_MID), align("left","center"))
    cur += 1
sep(cur,C_ACCENT); cur+=1; rh(cur,6); cur+=1

# ── SEÇÃO 4: GO-TO-MARKET ──────────────────────────────────────────────────────
sec_title(cur, "4. Estratégia Go-to-Market"); cur += 1
rh(cur,22); rh(cur+1,22)
merge_fill(cur,1,cur+1,12, C_DOURADO_CLR, f"   {GTM}", font(F_CORPO,11,False,C_TEXTO), align("left","center",True))
cur += 2
sep(cur,C_ACCENT); cur+=1; rh(cur,6); cur+=1

# ── SEÇÃO 5: CANAIS & KPIs ─────────────────────────────────────────────────────
sec_title(cur, "5. Canais & KPIs de Acompanhamento"); cur += 1
rh(cur,18)
for (c1,c2),label in [((1,2),"Canal"),((3,5),"KPI"),((6,7),"Frequência"),((8,8),"Dir."),((9,12),"Responsável")]:
    merge_fill(cur,c1,cur,c2, C_NAVY, f"  {label}", font(F_CORPO,9,True,C_DOURADO), align("left","center"))
cur += 1
for j, item in enumerate(CANAIS_KPIS[:5]):
    rh(cur,18)
    bg = C_ACCENT_LT if j % 2 == 0 else C_BRANCO
    merge_fill(cur,1,cur,2, C_DOURADO_CLR, f"  {item['canal']}", font(F_CORPO,10,True,C_NAVY_MID), align("left","center"))
    merge_fill(cur,3,cur,5, bg, f"  {item['kpi']}", font(F_CORPO,10,False,C_TEXTO), align("left","center"))
    merge_fill(cur,6,cur,7, bg, f"  {item['frequencia']}", font(F_CORPO,9,False,"666666"), align("left","center"))
    is_up = item["direcao"] == "up"
    c = ws.cell(cur,8); c.value = "↑" if is_up else "↓"
    c.font = font(F_CORPO,14,True, C_VERDE if is_up else C_VERM); c.alignment = align("center","center"); c.fill = fill(bg)
    merge_fill(cur,9,cur,12, C_ACCENT_LT, f"  {item['responsavel']}", font(F_CORPO,9,False,C_NAVY_MID), align("left","center"))
    cur += 1
sep(cur,C_ACCENT); cur+=1; rh(cur,6); cur+=1

# ── SEÇÃO 6: ETAPAS COMERCIAIS ─────────────────────────────────────────────────
sec_title(cur, "6. Etapas Comerciais — Indicadores-Mestre"); cur += 1
rh(cur,18)
for (c1,c2),label in [((1,6),"Etapa Comercial"),((7,12),"Indicador-Mestre Sugerido")]:
    merge_fill(cur,c1,cur,c2, C_NAVY, f"  {label}", font(F_CORPO,9,True,C_BRANCO), align("left","center"))
cur += 1
for j, e in enumerate(ETAPAS_COMERCIAIS[:6]):
    rh(cur,20)
    bg = C_BG2 if j % 2 == 0 else C_BRANCO
    merge_fill(cur,1,cur,6, bg, f"   {e['etapa']}", font(F_CORPO,11,True,C_NAVY), align("left","center"))
    merge_fill(cur,7,cur,12, C_ACCENT_LT, f"   {e['indicador']}", font(F_CORPO,10,False,C_ACCENT), align("left","center"))
    cur += 1
sep(cur,C_ACCENT); cur+=1; rh(cur,6); cur+=1

# ── SEÇÃO 7: PLANO DE RETENÇÃO ────────────────────────────────────────────────
sec_title(cur, "7. Plano de Retenção"); cur += 1
rh(cur,16)
merge_fill(cur,1,cur,9, C_ACCENT_LT, "   Indicador", font(F_CORPO,9,True,C_ACCENT), align("left","center"))
merge_fill(cur,10,cur,12, C_ACCENT_LT, "   Categoria", font(F_CORPO,9,True,C_ACCENT), align("left","center"))
cur += 1
for j, alerta in enumerate(ALERTAS[:5]):
    rh(cur,20)
    bg = C_BG2 if j % 2 == 0 else C_BRANCO
    merge_fill(cur,1,cur,9, bg, f"   {alerta['titulo']}", font(F_CORPO,10,True,C_NAVY), align("left","center"))
    merge_fill(cur,10,cur,12, C_ACCENT_LT, f"  {alerta['categoria']}", font(F_CORPO,9,True,C_ACCENT), align("center","center"))
    cur += 1
sep(cur,C_ACCENT); cur+=1; rh(cur,6); cur+=1

# ── SEÇÃO 8: BACKWARD PLANNING ─────────────────────────────────────────────────
sec_title(cur, "8. Plano Comercial — Backward Planning"); cur += 1
rh(cur,14)
merge_fill(cur,1,cur,12, C_BG2, "   Tudo deriva da meta de receita.  Amarelo = premissa.  Cinza = calculado.",
    font(F_CORPO,9,False,"5A6E8C",True), align("left","center"))
cur += 1; rh(cur,6); cur += 1

rh(cur,14)
merge_fill(cur,1,cur,12, C_NAVY, "   FUNIL", font(F_CORPO,10,True,C_BRANCO), align("left","center"))
cur += 1

tem_equipe = BP_LEADS_POR_SDR is not None
if tem_equipe:
    funil_blocos = [
        ("BDRs / SDRs", str(BP_SDRS) if BP_SDRS else "—", f"{fmt_n(BP_LEADS_POR_SDR)} leads/SDR"),
        ("Reuniões Qualificadas", fmt_n(BP_REUNIOES), f"Conv. {fmt_pct(BP_CONV_LEAD_REU)}"),
        ("Closers", str(BP_CLOSERS) if BP_CLOSERS else "—", f"{fmt_n(BP_VENDAS_POR_CLOSER)} vendas/closer"),
        ("Vendas Fechadas", fmt_n(BP_VENDAS), META_RECEITA),
    ]
else:
    funil_blocos = [
        ("Leads Necessários", fmt_n(BP_LEADS), f"Conv. {fmt_pct(BP_CONV_LEAD_REU)} → reunião"),
        ("Reuniões", fmt_n(BP_REUNIOES), f"Conv. {fmt_pct(BP_CONV_REU_VEND)} → venda"),
        ("Vendas Fechadas", fmt_n(BP_VENDAS), META_RECEITA),
    ]
n_blocos = len(funil_blocos)
cols_por_bloco = 12 // n_blocos
bgs_funil = [C_NAVY, C_ACCENT_LT, C_NAVY, C_ACCENT_LT]
fgs_funil = [C_BRANCO, C_NAVY, C_BRANCO, C_NAVY]
for b_idx, (label, valor, sub) in enumerate(funil_blocos):
    c1 = b_idx * cols_por_bloco + 1
    c2 = c1 + cols_por_bloco - 1
    if b_idx == n_blocos - 1: c2 = 12
    bg = bgs_funil[b_idx % len(bgs_funil)]; fg = fgs_funil[b_idx % len(fgs_funil)]
    sub_fg = C_BRANCO if fg == C_BRANCO else "5A6E8C"
    rh(cur,14); merge_fill(cur,c1,cur,c2, bg, f"  {label}", font(F_CORPO,9,False,sub_fg), align("left","center"))
    rh(cur+1,26); merge_fill(cur+1,c1,cur+1,c2, bg, f"  {valor}", font(F_TITULO,18,True,fg), align("left","center"))
    rh(cur+2,14); merge_fill(cur+2,c1,cur+2,c2, bg, f"  {sub}", font(F_CORPO,9,False,sub_fg), align("left","center"))
cur += 3; rh(cur,6); cur += 1

metricas = [
    ("CPL", fmt_brl(BP_CPL), "Custo por lead"),
    ("CAC", fmt_brl(BP_CAC), "Custo por venda"),
    ("Margem por Venda", fmt_brl(BP_MRG_VND), "Ticket × margem"),
    ("ROI", f"{BP_ROI:.1f}%" if BP_ROI else "—", "Retorno s/ investimento"),
]
met_spans = [(1,3),(4,6),(7,9),(10,12)]
rh(cur,14); rh(cur+1,26); rh(cur+2,14)
for (c1,c2),(label,value,sub) in zip(met_spans, metricas):
    merge_fill(cur,c1,cur,c2, C_ACCENT_LT, f"  {label}", font(F_CORPO,9,False,C_ACCENT), align("left","center"))
    merge_fill(cur+1,c1,cur+1,c2, C_BRANCO, f"  {value}", font(F_TITULO,16,True,C_NAVY), align("left","center"))
    merge_fill(cur+2,c1,cur+2,c2, C_BG2, f"  {sub}", font(F_CORPO,9,False,"5A6E8C"), align("left","center"))
cur += 3
sep(cur,C_ACCENT); cur+=1; rh(cur,6); cur+=1

# ── SEÇÃO 9: PLANO DE AÇÃO (4 Mkt + 4 Comercial + 8 vazias) ──────────────────
sec_title(cur, "9. Plano de Ação"); cur += 1
rh(cur,18)
for (c1,c2),label in [((1,2),"Frente"),((3,6),"Ação (macro)"),((7,9),"Responsável"),((10,12),"Métrica")]:
    merge_fill(cur,c1,cur,c2, C_NAVY, f"  {label}", font(F_CORPO,9,True,C_BRANCO), align("left","center"))
cur += 1
for j, item in enumerate(PLANO_ACAO):
    rh(cur,22)
    is_empty = not item["frente"]
    if is_empty:
        bg_row = C_BRANCO
        merge_fill(cur,1,cur,2, C_BG2, "", font(F_CORPO,10), align("center","center"))
        merge_fill(cur,3,cur,6, bg_row, "", font(F_CORPO,10), align("left","center"))
        merge_fill(cur,7,cur,9, C_BG2, "", font(F_CORPO,9), align("left","center"))
        merge_fill(cur,10,cur,12, bg_row, "", font(F_CORPO,9), align("left","center"))
    else:
        bg_fr, fg_fr = fc(item["frente"])
        bg_row = C_BG2 if j % 2 == 0 else C_BRANCO
        merge_fill(cur,1,cur,2, bg_fr, f"  {item['frente']}", font(F_CORPO,10,True,fg_fr), align("center","center"))
        merge_fill(cur,3,cur,6, bg_row, f"  {item['acao']}", font(F_CORPO,10,False,C_TEXTO), align("left","center",True))
        merge_fill(cur,7,cur,9, bg_fr, f"  {item['responsavel']}", font(F_CORPO,9,True,fg_fr), align("left","center"))
        merge_fill(cur,10,cur,12, C_ACCENT_LT, f"  {item['metrica']}", font(F_CORPO,9,False,C_ACCENT), align("left","center",True))
    cur += 1

# ── FOOTER ─────────────────────────────────────────────────────────────────────
rh(cur,6); cur += 1; rh(cur,22)
merge_fill(cur,1,cur,12, C_NAVY, f"G4 Sprints — Aumento de Receita  ·  Sprint AR — Plano de Ação  ·  {MES_ANO}",
    font(F_TITULO,10,True,"6B8BAF"), align("center","center"))

# ── SALVAR ─────────────────────────────────────────────────────────────────────
output_path = r"{{SESSION_ARTIFACTS}}/Sprint AR - Plano de Acao.xlsx"
os.makedirs(os.path.dirname(output_path), exist_ok=True)
wb.save(output_path)
print(f"SAVED:{output_path}")
```

## Mapeamento de Variáveis

| Variável | Fonte |
|---|---|
| `EMPRESA`, `MES_ANO` | Contexto da empresa |
| `PERFIL`, `DESC_PERFIL` | Nome informado pelo aluno + tabela "Perfis de Maturidade" no SKILL.md |
| `PROPOSTA`, `INTERP_PROPOSTA` | Exercício 1.3 — proposta definida + síntese em 2 linhas |
| `ICP_CAMPEAO` | Tabela 1.2 — 5 bullets, **cada um com no máximo 5 palavras** |
| `GTM` | Síntese de até 30 palavras (perfil + proposta + ICP + canais) |
| `CANAIS_KPIS` | Tabela 2.2 — até 5 canais selecionados, 1 KPI cada |
| `META_RECEITA`, `TICKET_MEDIO`, `BP_*` | Aba 3.2 — valores numéricos para o Backward Planning |
| `ETAPAS_COMERCIAIS` | Aba 3.1 — etapas informadas, cada uma com 1 indicador-mestre sugerido pelo assistente a partir da alavanca |
| `ALERTAS` | Aba 3.3 — máx 5 |
| `PLANO_ACAO` | 4 ações Marketing + 4 Comercial geradas pelo assistente (≤7 palavras) + 8 linhas vazias fixas |
