# Video Export: Exporting HTML Animations to MP4/GIF

Once an animated HTML file is complete, users often ask "can I export this as a video?" This guide provides the complete workflow.

## When to Export

**Export timing**:
- Animation runs completely and has been visually verified (Playwright screenshots confirm correct state at each timestamp)
- User has watched it in the browser at least once and confirmed the result looks good
- **Do not** export while animation bugs are still unfixed — fixing things after export to video is far more costly

**Trigger phrases users might say**:
- "Can you export this as a video?"
- "Convert to MP4"
- "Make it a GIF"
- "60fps"

## Output Specifications

Provide three formats by default and let the user choose:

| Format | Specs | Best For | Typical Size (30s) |
|---|---|---|---|
| MP4 25fps | 1920×1080 · H.264 · CRF 18 | WeChat article embed, Video Account, YouTube | 1-2 MB |
| MP4 60fps | 1920×1080 · minterpolate frame interpolation · H.264 · CRF 18 | High-framerate showcase, Bilibili, portfolio | 1.5-3 MB |
| GIF | 960×540 · 15fps · palette optimized | Twitter/X, README, Slack previews | 2-4 MB |

## Toolchain

Two scripts in `scripts/`:

### 1. `render-video.js` — HTML → MP4

Records a 25fps MP4 base version. Requires globally installed playwright.

```bash
NODE_PATH=$(npm root -g) node /path/to/claude-design/scripts/render-video.js <html-file>
```

Optional parameters:
- `--duration=30` Animation duration (seconds)
- `--width=1920 --height=1080` Resolution
- `--trim=2.2` Seconds to trim from the start of the video (removes reload + font loading time)
- `--fontwait=1.5` Font loading wait time (seconds) — increase when using many fonts

Output: same directory as the HTML file, same name with `.mp4` extension.

### 2. `add-music.sh` — MP4 + BGM → MP4

Mixes background music into a silent MP4. Selects from the built-in BGM library by mood, or use your own audio. Automatically matches duration and adds fade-in/fade-out.

```bash
bash add-music.sh <input.mp4> [--mood=<name>] [--music=<path>] [--out=<path>]
```

**Built-in BGM library** (at `assets/bgm-<mood>.mp3`):

| `--mood=` | Style | Best For |
|-----------|-------|---------|
| `tech` (default) | Apple Silicon / Apple keynote style, minimal synth + piano | Product launches, AI tools, skill promotions |
| `ad` | Upbeat modern electronic with build + drop | Social media ads, product teasers, promotional videos |
| `educational` | Warm and bright, light guitar/electric piano, inviting | Educational content, tutorial intros, course previews |
| `educational-alt` | Alternate in the same category | Same as above |
| `tutorial` | Lo-fi ambient, nearly invisible | Software demos, coding tutorials, long demonstrations |
| `tutorial-alt` | Alternate in the same category | Same as above |

**Behavior**:
- Music is trimmed to match video duration
- 0.3s fade-in + 1s fade-out (avoids hard cuts)
- Video stream uses `-c:v copy` with no re-encoding; audio is AAC 192k
- `--music=<path>` takes priority over `--mood` — you can specify any external audio file directly
- Passing an invalid mood name will list all available options rather than failing silently

**Typical pipeline** (full animation export trio + music):
```bash
node render-video.js animation.html                        # Record screen
bash convert-formats.sh animation.mp4                      # Derive 60fps + GIF
bash add-music.sh animation-60fps.mp4                      # Add default tech BGM
# Or for specific scenarios:
bash add-music.sh tutorial-demo.mp4 --mood=tutorial
bash add-music.sh product-promo.mp4 --mood=ad --out=promo-final.mp4
```

### 3. `convert-formats.sh` — MP4 → 60fps MP4 + GIF

Generates a 60fps version and a GIF from an existing MP4.

```bash
bash /path/to/claude-design/scripts/convert-formats.sh <input.mp4> [gif_width] [--minterpolate]
```

Outputs (in the same directory as input):
- `<name>-60fps.mp4` — defaults to `fps=60` frame duplication (broad compatibility); add `--minterpolate` to enable high-quality frame interpolation
- `<name>.gif` — palette-optimized GIF (default 960px wide, adjustable)

**60fps mode selection**:

| Mode | Command | Compatibility | Use Case |
|---|---|---|---|
| Frame duplication (default) | `convert-formats.sh in.mp4` | QuickTime/Safari/Chrome/VLC all work | General delivery, platform uploads, social media |
| minterpolate interpolation | `convert-formats.sh in.mp4 --minterpolate` | macOS QuickTime/Safari may refuse to play | Bilibili and other platforms requiring true frame interpolation — **must test on target player locally before delivery** |

Why did the default change to frame duplication? The H.264 elementary stream output from minterpolate has a known compat bug — the previous default of minterpolate repeatedly caused "macOS QuickTime won't open" issues. See `animation-pitfalls.md` §14.

`gif_width` parameter:
- 960 (default) — general social platform use
- 1280 — sharper but larger file size
- 600 — Twitter/X optimized loading

## Full Workflow (Standard Recommendation)

After the user says "export video":

```bash
cd <project-directory>

# Assume $SKILL points to the skill's root directory (replace with your install path)

# 1. Record 25fps base MP4
NODE_PATH=$(npm root -g) node "$SKILL/scripts/render-video.js" my-animation.html

# 2. Derive 60fps MP4 and GIF
bash "$SKILL/scripts/convert-formats.sh" my-animation.mp4

# Output files:
# my-animation.mp4         (25fps · 1-2 MB)
# my-animation-60fps.mp4   (60fps · 1.5-3 MB)
# my-animation.gif         (15fps · 2-4 MB)
```

## Technical Details (for debugging)

### Playwright recordVideo gotchas

- Frame rate is fixed at 25fps — cannot record 60fps directly (Chromium headless compositor limit)
- Recording starts from context creation — must use `trim` to cut out the initial loading time
- Default format is webm — requires ffmpeg conversion to H.264 MP4 for universal playback

`render-video.js` already handles all of the above.

### ffmpeg minterpolate parameters

Current config: `minterpolate=fps=60:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1`

- `mi_mode=mci` — motion compensation interpolation
- `mc_mode=aobmc` — adaptive overlapped block motion compensation
- `me_mode=bidir` — bidirectional motion estimation
- `vsbmc=1` — variable size block motion compensation

Works well with CSS **transform animations** (translate/scale/rotate).
May produce slight **ghosting on pure fades** — if the user complains, fall back to simple frame duplication:

```bash
ffmpeg -i input.mp4 -r 60 -c:v libx264 ... output.mp4
```

### Why GIF palette requires two passes

GIF can only use 256 colors. A single-pass GIF compresses the entire animation's colors into a universal 256-color palette, which causes blurring on subtle palettes like beige + orange.

Two passes:
1. `palettegen=stats_mode=diff` — first scans the entire video to generate an **optimal palette specific to this animation**
2. `paletteuse=dither=bayer:bayer_scale=5:diff_mode=rectangle` — encodes using this palette; rectangle diff only updates changed regions, greatly reducing file size

For fade transitions, `dither=bayer` is smoother than `none`, but the file is slightly larger.

## Pre-flight Check (Before Exporting)

30-second self-check before exporting:

- [ ] HTML has run completely in the browser at least once with no console errors
- [ ] Frame 0 of the animation shows a complete initial state (not a blank loading screen)
- [ ] The last frame of the animation is a stable end state (not cut off mid-way)
- [ ] Fonts/images/emoji all render correctly (refer to `animation-pitfalls.md`)
- [ ] Duration parameter matches the actual animation length in the HTML
- [ ] HTML Stage detection `window.__recording` forces loop=false (must check in hand-written Stages; included automatically in `assets/animations.jsx`)
- [ ] The final Sprite has `fadeOut={0}` (last video frame does not fade out)
- [ ] Includes "Created by Huashu-Design" watermark (required for animation scenes only; add "Unofficial · " prefix for third-party branded work. See SKILL.md § "Skill Promotion Watermark")

## Delivery Note Format

Standard delivery note to include with the exported files:

```
**Complete Delivery**

| File | Format | Specs | Size |
|---|---|---|---|
| foo.mp4 | MP4 | 1920×1080 · 25fps · H.264 | X MB |
| foo-60fps.mp4 | MP4 | 1920×1080 · 60fps (motion interpolated) · H.264 | X MB |
| foo.gif | GIF | 960×540 · 15fps · palette optimized | X MB |

**Notes**
- 60fps uses minterpolate motion estimation interpolation — works great for transform animations
- GIF uses palette optimization — a 30s animation can be compressed to ~3MB

Let me know if you need a different size or frame rate.
```

## Common Follow-up Requests

| User says | Response |
|---|---|
| "Too large" | MP4: increase CRF to 23-28; GIF: reduce resolution to 600 or fps to 10 |
| "GIF is too blurry" | Increase `gif_width` to 1280; or suggest using MP4 instead (WeChat Moments supports it too) |
| "Need vertical 9:16" | Change `--width=1080 --height=1920` in the HTML source and re-record |
| "Add watermark" | Use ffmpeg `-vf "drawtext=..."` or `overlay=` with a PNG |
| "Need transparent background" | MP4 does not support alpha; use WebM VP9 + alpha or APNG |
| "Need lossless" | Set CRF to 0 + preset veryslow (file will be 10x larger) |
