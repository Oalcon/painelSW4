# IPIP-50 — Itens em PT-BR

> 50 itens, domínios intercalados E-A-C-N-O. Itens [R] = reversão: `6 − escore_bruto`

| Nº | Domínio | Afirmação |
|----|---------|----------|
| 1 | E+ | "Sou a vida da festa." |
| 2 | A− [R] | "Pouco me importo com os sentimentos dos outros." |
| 3 | C+ | "Estou sempre preparado(a) para o que for necessário." |
| 4 | N+ | "Fico estressado(a) facilmente." |
| 5 | O+ | "Tenho uma imaginação rica e vívida." |
| 6 | E− [R] | "Prefiro ficar em segundo plano nas festas." |
| 7 | A+ | "Simpatizo com os sentimentos dos outros." |
| 8 | C− [R] | "Deixo minhas coisas espalhadas por aí." |
| 9 | N− [R] | "Geralmente sou relaxado(a)." |
| 10 | O− [R] | "Tenho dificuldade em compreender ideias abstratas." |
| 11 | E+ | "Falo com muitas pessoas diferentes nas festas." |
| 12 | A− [R] | "Costumo insultar as pessoas." |
| 13 | C+ | "Presto muita atenção nos detalhes." |
| 14 | N+ | "Fico preocupado(a) com as coisas." |
| 15 | O+ | "Tenho ótimas ideias." |
| 16 | E− [R] | "Prefiro passar despercebido(a) sem chamar atenção." |
| 17 | A+ | "Tenho um coração bondoso." |
| 18 | C− [R] | "Costumo fazer bagunça nas coisas." |
| 19 | N− [R] | "Raramente me sinto para baixo." |
| 20 | O− [R] | "Não tenho uma boa imaginação." |
| 21 | E+ | "Sinto-me à vontade na companhia das pessoas." |
| 22 | A− [R] | "Não me interesso pelos problemas dos outros." |
| 23 | C+ | "Resolvo minhas tarefas assim que possível." |
| 24 | N+ | "Me perturbo com facilidade." |
| 25 | O+ | "Compreendo as coisas rapidamente." |
| 26 | E− [R] | "Tenho pouco a dizer na maioria das situações." |
| 27 | A+ | "Dedico tempo às pessoas quando elas precisam." |
| 28 | C− [R] | "Frequentemente esqueço de guardar as coisas no lugar certo." |
| 29 | N+ | "Fico chateado(a) com facilidade." |
| 30 | O− [R] | "Não aprecio arte." |
| 31 | E+ | "Começo conversas com facilidade." |
| 32 | A− [R] | "Não tenho muito interesse nas pessoas ao meu redor." |
| 33 | C+ | "Gosto de ordem e organização." |
| 34 | N+ | "Me irrito com facilidade." |
| 35 | O+ | "Uso palavras elaboradas e precisas." |
| 36 | E− [R] | "Sou reservado(a) perto de pessoas que não conheço." |
| 37 | A+ | "Sinto as emoções dos outros." |
| 38 | C− [R] | "Evito cumprir minhas obrigações quando possível." |
| 39 | N+ | "Fico com raiva com facilidade." |
| 40 | O− [R] | "Evito materiais de leitura complexos ou difíceis." |
| 41 | E+ | "Não me importo em ser o centro das atenções." |
| 42 | A− [R] | "Sinto pouca preocupação com os outros." |
| 43 | C+ | "Sigo uma agenda ou rotina estabelecida." |
| 44 | N− [R] | "Raramente fico com raiva." |
| 45 | O+ | "Dedico tempo a refletir sobre as coisas." |
| 46 | E− [R] | "Sou quieto(a) e reservado(a) perto de estranhos." |
| 47 | A+ | "Faço as pessoas se sentirem bem e à vontade." |
| 48 | C− [R] | "Não presto atenção suficiente nos detalhes." |
| 49 | N+ | "Frequentemente me sinto para baixo e melancólico(a)." |
| 50 | O− [R] | "Não me interesso por ideias abstratas." |

**Itens diretos E:** 1,11,21,31,41 | **Inversos E:** 6,16,26,36,46
**Itens diretos A:** 7,17,27,37,47 | **Inversos A:** 2,12,22,32,42
**Itens diretos C:** 3,13,23,33,43 | **Inversos C:** 8,18,28,38,48
**Itens diretos N:** 4,14,24,29,34,39,49 | **Inversos N:** 9,19,44
**Itens diretos O:** 5,15,25,35,45 | **Inversos O:** 10,20,30,40,50