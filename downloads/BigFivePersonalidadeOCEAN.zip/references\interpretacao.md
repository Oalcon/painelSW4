# Guia de Interpretação — Big Five OCEAN

## Por Dimensão

### E — Extroversão
**Alto:** Alta energia social, liderança natural, networking fácil. Riscos: dominar conversas, dificuldade com trabalho solitario.
**Médio:** Ambiverso contextual. Adapta nível de engajamento.
**Baixo:** Introvertido — reflexivo, ouvinte, foco profundo. Riscos: visibilidade reduzida.

### A — Amabilidade
**Alto:** Cooperativo, empático, construí confiança. Riscos: dificuldade em dizer não, evitar conflito necessário.
**Médio:** Navega entre cooperação e assertividade.
**Baixo:** Competitivo, cético, direto. Pontos fortes: negociação dura, decisões difíceis.

### C — Conscienciosidade
**Alto:** Organizado, disciplinado, confiável. Riscos: rigidez, perfeccionismo.
**Médio:** Estruturado quando necessário, flexível o suficiente.
**Baixo:** Espontâneo, flexível. Pontos fortes: criatividade, adaptabilidade.

### N — Neuroticismo
**Alto:** Alta sensibilidade emocional. Pontos fortes: empatia, profundidade, motivação por qualidade. Riscos: esgotamento, ansiedade.
**Médio:** Reage proporcionalmente, processa de forma funcional.
**Baixo:** Estabilidade emocional. Pontos fortes: calma sob pressão, decisões em crise. Atenção: pode parecer frio.

### O — Abertura
**Alto:** Curioso, criativo, inovador. Riscos: dispersão, dificuldade com rotinas.
**Médio:** Aprecia novidades mas valoriza o que funciona.
**Baixo:** Pragmático, concreto, confiável. Pontos fortes: execução consistente.

---

## 8 Arquétipos de Combinação

1. **Arquiteto Estratégico** (O+ C+): Ideias grandes executadas sistematicamente
2. **Diplomata Empático** (E+ A+): Conecta e cria confiança, líder relacional
3. **Executor Resiliente** (N- C+): Máquina de execução sob pressão
4. **Catalisador Criativo** (O+ E+): Inspira outros a pensar diferente
5. **Guardião Confiável** (A+ C+): Pilar que sustenta equipes e processos
6. **Analista Independente** (O+ A-): Pensador que desafia consensos
7. **Líder Carismático** (E+ N-): Projeta confiança em turbulência
8. **Explorador Sensível** (O+ N+): Criativo e profundo, intensamente afetado

---

## Liderança por Traço

| Traço | Alto | Baixo |
|---|---|---|
| E | Presente, verbal, decide rápido | Discreto, 1:1, reflete antes |
| A | Consensual, considera impacto humano | Assertivo, decide pelo resultado |
| C | Estruturado, orientado a processo | Flexível, espontâneo |
| N | Intenso, empático às tensões | Calmo em crises, estabilizador |
| O | Visionário, questiona status quo | Executor pragmático |

---

## Comparativo Big Five ↔ MBTI

| Big Five | MBTI aproximado |
|---|---|
| E alto | Preferência E |
| E baixo | Preferência I |
| O alto | Preferência N |
| O baixo | Preferência S |
| A alto | Preferência F |
| A baixo | Preferência T |
| C alto | Preferência J |
| C baixo | Preferência P |
| N alto | Sufixo -T (Turbulent) no 16P |
| N baixo | Sufixo -A (Assertive) no 16P |