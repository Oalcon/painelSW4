# Teoria — Modelo Big Five (OCEAN)

## Origem
Big Five emergiu de pesquisa lexicográfica e psicométrica:
- Lewis Goldberg (1980s): cunhou o termo "Big Five"
- Costa & McCrae: desenvolveram o NEO-PI-R (240 itens)
- Goldberg (1999): criou o IPIP — banco público de itens
- IPIP-50: versão de 50 itens, correlação r=0.85–0.92 com NEO-PI-R

## As 5 Dimensões

**O — Abertura:** Curiosidade intelectual, criatividade, tolerância à ambiguidade
**C — Conscienciosidade:** Autodisciplina, organização, confiabilidade, orientação a objetivos (melhor preditor de desempenho profissional)
**E — Extroversão:** Sociabilidade, assertividade, emoções positivas
**A — Amabilidade:** Cooperação, empatia, altruísmo
**N — Neuroticismo:** Ansiedade, instabilidade emocional, sensibilidade a estresse (score baixo = maior estabilidade)

## Cálculo

### Itens Reversos [R]
`Score corrigido = 6 − score_original` (1→5, 2→4, 3→3, 4→2, 5→1)

### Score por domínio
Somar 10 itens corrigidos. Faixa: **10 a 50**

### Classificação
| Score | Nível |
|---|---|
| 10–22 | Baixo |
| 23–27 | Médio-baixo |
| 28–32 | Médio |
| 33–37 | Médio-alto |
| 38–50 | Alto |

### Percentil Aproximado
`Percentil% ≈ ((Score − 10) / 40) × 100`