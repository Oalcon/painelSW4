---
name: Hierarquia Pré-Vendas Aquisição
description: Estrutura de times Pré-Vendas — squads, gerentes e times filhos. Atualizar aqui quando houver mudanças org.
---

# Hierarquia — Pré-Vendas Aquisição

> ⚠️ Este arquivo documenta a estrutura **atual** para referência. A Query H1 (`production.gold.g4_comercial_people`) é sempre a fonte autoritativa — se divergir, confiar na query.

## Gerente Sênior de Área

| Nome | Cargo |
|------|-------|
| Sérgio Alonso | Gerente Sênior de Pré Vendas |

---

## Squad Titãs

**Gerente:** Ana Costa (`lider_direto = 'Sergio Alonso'`)

| Time Filho | Coordenador |
|------------|-------------|
| Puro Sangue | Catarina Padilha |
| The Sharks | João Victor Funo |
| Time Pedro Cardoso | Pedro Cardoso |

---

## Squad Mavericks

**Gerente:** Lucas Kassai (`lider_direto = 'Sergio Alonso'`)

| Time Filho | Coordenador |
|------------|-------------|
| Cane Corso | Felipe Gargalaka |
| Hornets | Tomas Kalil |
| Time Guima | Guilherme Guimarães |

---

## Regras de Mapeamento (Query H1)

- **Gerente Sênior** = `cargo = 'Gerente de Pré Vendas'` com `lider_direto` = diretoria
- **Gerentes de Squad** = `cargo = 'Gerente de Pré Vendas'`, `lider_direto = 'Sergio Alonso'`
- **Coordenadores de Time** = `cargo = 'Coordenador de Pré Vendas'`, `lider_direto` = gerente do squad
- **SDRs** = `cargo = 'SDR'`, agrupados por `lider_direto`

## Campo Crítico

```
setor = 'Pré Vendas Aquisição'   ← SEM hífen (com hífen retorna 0 rows)
```