---
name: "Daily Routines"
description: "Configure two daily automations — End-of-Day Summary (updates context files) and Morning Briefing (personalized start-of-day brief). Creates scheduled jobs automatically."
icon: "🌅"
---

# Daily Routines

Sets up two recurring daily automations tailored to the user's tools and workflow:

- **End-of-Day Summary** (`--mode=summary`) — Reads the day's session activity and updates all context files automatically.
- **Morning Briefing** (`--mode=briefing`) — Interviews the user once to understand preferences, then generates a personalized daily brief every morning.

After configuring each automation, creates the scheduled jobs via the G4 OS scheduler.

---

## PHASE 0 — Mode Detection

Check how the workflow was triggered:

- Called with `--mode=summary` → skip to **PHASE 2**
- Called with `--mode=briefing` → skip to **PHASE 3**
- Called without arguments → start at **PHASE 1** (interactive setup)

---

## PHASE 1 — Interactive Setup Menu

Present a clear menu to the user:

```
Daily Routines Setup

Which automations do you want to configure?

  [1] End-of-Day Summary — runs at the end of the day, updates all context files
  [2] Morning Briefing — runs in the morning, generates a personalized daily brief
  [3] Both

Reply with 1, 2, or 3.
```

After the user selects, go through each selected automation's configuration. After all configurations are complete, proceed to **PHASE 4** (scheduling).

---

## PHASE 2 — End-of-Day Summary Execution

> This phase runs automatically when triggered by the scheduler with `--mode=summary`.
> It requires no user interaction — execute silently and report what was updated at the end.

### Step 1 — Discover context files

Check which of these files exist in the current working directory:

- `memory/MEMORY.md`
- `workspace-context.md`
- `local-context.md`
- `activity-log.md`
- `session-log.md`
- `last-session.md`

For each file that exists, read its full content. Note files that are missing — they will be created.

### Step 2 — Retrieve today's session activity

Use `lcm_grep` to search the current session history for:
- Decisions made
- Tasks completed
- Projects discussed
- New contacts or people mentioned
- Blockers encountered
- Key insights or patterns

Search with broad terms: "decided", "completed", "project", "update", "blocked", "next", "action".

Also read any `activity-log.md` or `session-log.md` that exists to understand prior days' format.

### Step 3 — Update each context file

Apply the updates described in `knowledge/context-files-guide.md` for each file. Rules:

**`memory/MEMORY.md`**
- Add new stable patterns, key decisions, important people, recurring issues observed today
- Remove or correct any entries that turned out to be wrong
- Keep total file ≤ 200 lines — compress older entries if needed
- If file does not exist: create it using the template in `knowledge/context-files-guide.md`

**`workspace-context.md`**
- Add any new contacts encountered (name, role, contact info if known)
- Update recurring acronyms or terms used today
- Update preferences or patterns observed
- If file does not exist: create it using the template in `knowledge/context-files-guide.md`

**`local-context.md`**
- Update status of projects that were discussed today
- Add new projects or initiatives that emerged
- Remove completed or abandoned projects
- If file does not exist: create it using the template in `knowledge/context-files-guide.md`

**`activity-log.md`**
- Add an entry for today with: date, top 3-5 activities, key decisions, next actions
- Keep only the last 5 days — remove older entries
- If file does not exist: create it with today's entry

**`session-log.md`**
- Add or update today's entry (one entry per day) with a fuller account of the day
- Do NOT remove old entries — this is the permanent log
- If file does not exist: create it with today's entry

**`last-session.md`**
- OVERWRITE completely with a concise summary of today for fast-load tomorrow
- Include: date, what was worked on, key decisions, open items, suggested first action tomorrow
- Keep it ≤ 50 lines
- If file does not exist: create it

### Step 4 — Report

After all updates, present a brief summary in chat:

```
End-of-Day Summary complete — [DATE]

Updated:
- memory/MEMORY.md — [what changed]
- workspace-context.md — [what changed]
- local-context.md — [what changed]
- activity-log.md — entry added
- session-log.md — entry added/updated
- last-session.md — overwritten

Created (new):
- [list any files that were created fresh]
```

---

## PHASE 3 — Morning Briefing

### Step 3a — Check for saved preferences

Check if `daily-briefing-prefs.md` exists in the current working directory.

- **If it exists**: read it, then skip the interview and go directly to **Step 3c** (generate briefing).
- **If it does not exist**: run the interview below (**Step 3b**) to calibrate preferences, then generate the first briefing.

### Step 3b — Preferences Interview (first run only)

Run this interview before generating the first briefing. Ask ONE question at a time and wait for the answer.

---

**Question 1 — What sources do you have connected?**

List the sources currently available in this session. For each, briefly describe what it covers. Ask the user which ones they want included in their morning brief.

Example presentation:
```
I can see these connected sources in your workspace:
- Google Calendar — your events and meetings
- Gmail — email inbox
- Slack — team messages
- Notion — docs and projects
- Databricks — business data (sales, funnels, etc.)

Which of these do you want in your morning brief? You can say "all", list specific ones, or say "none" for sources you don't use.

Note: if a source you want isn't connected yet, I can help you set it up after this interview.
```

If the user mentions a source that isn't connected, note it for later. After the interview completes, offer to help install any missing sources using the appropriate setup skill (e.g., `/setup-slack` for Slack).

---

**Question 2 — Is there any area or project that should always appear?**

```
Is there any project, team, or topic that should always show up in your briefing — even if there's nothing urgent?

For example: "always show me sales pipeline status" or "always include updates on Project X".

You can say "no" if you just want what's relevant each day.
```

---

**Question 3 — How do you prefer the format?**

```
How do you like your morning brief?

  [A] Short — top 3-5 bullets, one line each, no commentary
  [B] Detailed — narrative by area with context and reasoning
  [C] Mixed — short bullets but with 1-2 sentences of context on the most important item

Reply A, B, or C.
```

---

**Question 4 — What time do you want the briefing?**

```
What time do you want your morning brief delivered? (e.g., "7:30am", "8h00")

This will be used to create the scheduled job.
```

---

After all four answers, confirm the preferences back to the user:

```
Got it. Here's what I'll use for your morning brief:

Sources: [list]
Always-on topics: [list or "none"]
Format: [A/B/C]
Time: [time]

Saving these preferences and generating your first briefing now...
```

Save preferences to `daily-briefing-prefs.md` in the current working directory using this format:

```markdown
# Daily Briefing Preferences

**Sources**: [comma-separated list]
**Always-on topics**: [list or none]
**Format**: [short/detailed/mixed]
**Scheduled time**: [time]
**Configured**: [date]
```

---

### Step 3c — Generate the briefing

Read `last-session.md` if it exists (yesterday's context). Then pull data from configured sources based on saved preferences.

For each enabled source, retrieve:

| Source | What to fetch |
|---|---|
| Google Calendar | Events for today — time, title, attendees |
| Gmail | Unread or flagged emails from last 24h — sender, subject, urgency |
| Slack | Unread DMs and mentions from last 24h — channel, sender, summary |
| Notion | Any pages or tasks flagged/updated since yesterday |
| Databricks | Always-on metrics configured in preferences |

Compose the briefing according to the user's format preference:

**Format A (Short)**
```
Morning Brief — [DATE]

Calendar: [N] events — [list times + titles]
Urgent: [top 2-3 items needing attention]
Projects: [1-line status of always-on topics]
From yesterday: [one-liner from last-session.md]
```

**Format B (Detailed)**
Narrative paragraphs per section: Calendar, Inbox, Team (Slack), Projects, Context from yesterday.

**Format C (Mixed)**
Short bullets for all items, but add 2-3 sentences of context on the single most important item.

End every briefing with:
```
Suggested first action: [one concrete next step based on the context]
```

If a source fails or returns no data, skip it silently and note "(no data)" next to that section rather than erroring out.

---

## PHASE 4 — Create Scheduled Jobs

After configuring the selected automations, confirm scheduling with the user before creating jobs.

### Step 1 — Collect times

If the user already provided times during configuration (e.g., morning brief time from the interview), confirm them. For the End-of-Day Summary, ask if not yet collected:

```
Almost done. Let me confirm the schedule:

- Morning Briefing: [time from prefs] ✓
- End-of-Day Summary: what time should this run? (e.g., "18h30", "7pm")
```

### Step 2 — Show final configuration

```
Here's what I'll create:

| Automation | Schedule | Action |
|---|---|---|
| Morning Briefing | [time], daily | /daily-routines --mode=briefing |
| End-of-Day Summary | [time], daily | /daily-routines --mode=summary |

Create these scheduled jobs?
```

Wait for explicit confirmation ("yes", "pode criar", "confirma") before calling `scheduler_create`.

### Step 3 — Create jobs

Call `scheduler_create` for each confirmed automation. Use:
- Recurrence: daily
- Prompt: the exact command shown above (`/daily-routines --mode=briefing` or `--mode=summary`)

### Step 4 — Confirm

After creation, show a confirmation datatable with job name, schedule, and status.

---

## Rules and Guardrails

- Never overwrite `session-log.md` entries from previous days — only append.
- Never delete `memory/MEMORY.md` entries without replacing them with updated content.
- If a source fails during briefing generation, skip it gracefully — do not abort the entire briefing.
- If `daily-briefing-prefs.md` exists, never re-run the full interview — offer to update specific preferences instead.
- Always confirm the schedule before creating scheduler jobs.
- If the user mentions a source that isn't connected, note it and offer setup help after the interview — do not block the workflow.
- For the End-of-Day Summary, keep `memory/MEMORY.md` ≤ 200 lines and `activity-log.md` ≤ 5 days at all times.
