# Context Files Guide

Reference for the End-of-Day Summary. Describes the purpose, update rules, and default templates for each context file.

---

## memory/MEMORY.md

**Purpose**: Persistent cross-session memory. Contains stable patterns, key contacts, architectural decisions, recurring issues. Loaded into every conversation context.

**Update rules**:
- Add entries that are stable and reusable (not session-specific)
- Correct or remove entries that turned out to be wrong
- Keep ≤ 200 lines — compress or remove stale entries as needed
- Organize by topic sections (not chronologically)

**Creation template** (if file doesn't exist):
```markdown
# Memory Index

## User Preferences
[Add preferences observed]

## Key Contacts
[Add contacts encountered]

## Active Projects
[Add key projects]

## Patterns and Decisions
[Add recurring patterns or key decisions]
```

---

## workspace-context.md

**Purpose**: "Who I am" file — contacts, acronyms, preferences, recurring items, team context. Used to personalize responses.

**Update rules**:
- Add new contacts with name, role, and any contact info
- Add new acronyms or terms used regularly
- Update preferences that emerged from the session
- Do not remove contacts unless they are no longer relevant

**Creation template**:
```markdown
# Workspace Context

## About Me
- Name:
- Role:
- Organization:
- Timezone:

## Key Contacts
| Name | Role | Contact |
|------|------|------|

## Acronyms and Terms
| Term | Meaning |
|------|--------|

## Preferences
[Communication style, tool preferences, recurring patterns]

## Recurring Items
[Weekly meetings, recurring reports, standing commitments]
```

---

## local-context.md

**Purpose**: "What's here" file — active projects, paths, project-specific notes for this working directory.

**Update rules**:
- Update project status when work happened (in progress, blocked, completed)
- Add new projects or initiatives mentioned today
- Remove projects marked as done or abandoned
- Keep statuses current — stale entries are worse than no entries

**Creation template**:
```markdown
# Local Context

**Working Directory**: [path]
**Last Updated**: [date]

## Active Projects
| Project | Status | Owner | Notes |
|---------|--------|-------|-------|

## Key Paths
[Important file and directory references]

## Notes
[Any working-directory-specific context]
```

---

## activity-log.md

**Purpose**: Rolling log of recent daily activity. Fast-access reference for the last 5 days.

**Update rules**:
- Add one entry per day with date, activities, decisions, next actions
- Keep only the last 5 days — delete older entries
- Keep each entry concise (5-10 bullets max)

**Entry template**:
```markdown
## [YYYY-MM-DD]

**Focus**: [main theme of the day]

Activities:
- [activity 1]
- [activity 2]

Decisions:
- [decision 1]

Next actions:
- [action 1]
```

---

## session-log.md

**Purpose**: Permanent full log — one entry per day. Never delete entries.

**Update rules**:
- Add or update today's entry (prepend at top)
- Do NOT remove prior entries
- More detailed than activity-log — include context, blockers, and reasoning

**Entry template**:
```markdown
## [YYYY-MM-DD]

**Summary**: [2-3 sentence overview of the day]

### Worked On
- [item 1]
- [item 2]

### Key Decisions
- [decision with brief rationale]

### Blockers
- [any blockers encountered]

### Open Items
- [things left unresolved]
```

---

## last-session.md

**Purpose**: Fast-load summary for the next session. Overwritten completely each day.

**Update rules**:
- Overwrite fully — this is not cumulative
- Keep ≤ 50 lines
- Focus on what's immediately useful tomorrow: context, open items, suggested first action

**Template**:
```markdown
# Last Session Summary

**Date**: [YYYY-MM-DD]
**Duration/Focus**: [brief description]

## What Was Worked On
[3-5 bullet summary]

## Key Decisions Made
[bullet list]

## Open Items (carry forward)
[bullet list — things not finished]

## Context for Tomorrow
[1-2 sentences of narrative context]

## Suggested First Action
[One specific next step]
```
