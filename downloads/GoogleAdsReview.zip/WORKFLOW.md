---
name: Google Ads Review
description: Revisao completa de campanhas Google Ads — performance, negativos, copies, budget e diagnostico. Powered by adloop.
icon: "📊"
alwaysAllow: ["Bash"]
---

# Google Ads Review

Workflow unificado para analise e gestao de campanhas Google Ads da G4 Educacao.
Usa a biblioteca `adloop` com autenticacao OAuth pre-configurada.

## Quando Usar

- Usuario digita `/google-ads-review`
- Usuario pede: "revisao de ads", "analisa campanhas", "mine search terms", "audit de copy", "otimizar budget", "investigar campanha", "weekly review ads"

---

## Fase 0 — Instalacao Automatica (executar silenciosamente na primeira vez)

Antes de qualquer analise, verificar se o ambiente esta configurado. Rodar os checks abaixo via Bash.
Se TUDO ja existe, pular direto para Fase 1 sem mencionar nada ao usuario.
Se algo esta faltando, informar "Configurando Google Ads Review pela primeira vez..." e executar os passos necessarios.

### 0.1 — Instalar adloop (pip package)

```bash
pip show adloop >/dev/null 2>&1 || pip install adloop
```

Se `pip` nao estiver disponivel, tentar `pip3`, `python3 -m pip`, ou o pip do miniconda (`~/miniconda3/bin/pip`).

### 0.2 — Criar config do adloop

Verificar se `~/.adloop/config.yaml` existe. Se nao:

```bash
mkdir -p ~/.adloop
cat > ~/.adloop/config.yaml << 'YAML'
google:
  credentials_path: ~/.adloop/credentials.json
  token_path: ~/.adloop/token.json

ga4:
  property_id: "381992026"

ads:
  developer_token: "_jKpZn7QhPxNcQaO7oRfmw"
  customer_id: "6913662252"
  login_customer_id: "6913662252"

safety:
  max_daily_budget: 500.00
  max_bid_increase_pct: 50
  require_dry_run: true
  log_file: ~/.adloop/audit.log
  blocked_operations: []
YAML
```

### 0.3 — Criar credentials do Google OAuth

Verificar se `~/.adloop/credentials.json` existe. Se nao:

```bash
cat > ~/.adloop/credentials.json << 'JSON'
{
  "installed": {
    "client_id": "950571144462-25naoh81eeub165i957v1rfc6nhee1na.apps.googleusercontent.com",
    "client_secret": "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",
    "redirect_uris": ["http://localhost", "urn:ietf:wg:oauth:2.0:oob"],
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://oauth2.googleapis.com/token"
  }
}
JSON
```

### 0.4 — Autenticar usuario (OAuth)

Verificar se `~/.adloop/token.json` existe. Se nao, o usuario precisa autenticar:

```bash
python3 -m adloop auth
```

Isso abre o navegador para login Google. O usuario precisa usar uma conta @g4educacao.com com acesso ao Google Ads da G4.
Apos autorizar, o `token.json` e criado automaticamente com o refresh_token pessoal do usuario.

Se o comando `adloop auth` nao estiver disponivel, orientar o usuario a rodar:

```bash
python3 -c "
from adloop.auth import authenticate
authenticate()
"
```

**IMPORTANTE:** Cada usuario gera seu proprio token. O `credentials.json` (client_id/secret) e compartilhado — e do projeto OAuth da G4. O `token.json` e pessoal.

### 0.5 — Criar source MCP no G4 OS

Verificar se a pasta `sources/google-ads/` existe no workspace atual. Detectar o workspace path:

```bash
WORKSPACE_DIR=$(find ~/.g4os/workspaces -maxdepth 1 -type d | tail -1)
```

Se a source nao existir:

```bash
mkdir -p "$WORKSPACE_DIR/sources/google-ads"

# Detectar path do python
PYTHON_PATH=$(which python3 2>/dev/null || echo "$HOME/miniconda3/bin/python3")

cat > "$WORKSPACE_DIR/sources/google-ads/config.json" << JSONEOF
{
  "id": "google-ads_a7f3d91c",
  "name": "Google Ads",
  "slug": "google-ads",
  "enabled": true,
  "provider": "google-ads",
  "type": "mcp",
  "icon": "https://img.freepik.com/premium-vector/google-ads-logo_578229-305.jpg",
  "tagline": "Google Ads + GA4 da G4 Educacao — campanhas, keywords, budgets, termos de pesquisa e analytics",
  "mcp": {
    "transport": "stdio",
    "command": "$PYTHON_PATH",
    "args": ["-m", "adloop"],
    "authType": "none"
  },
  "connectionStatus": "connected",
  "isAuthenticated": true,
  "createdAt": $(date +%s)000,
  "updatedAt": $(date +%s)000
}
JSONEOF

cat > "$WORKSPACE_DIR/sources/google-ads/guide.md" << 'GUIDEEOF'
# Google Ads (AdLoop)

Acesso completo ao Google Ads e GA4 da G4 Educacao via AdLoop MCP — ferramentas para analise e gestao de campanhas.

## Escopo

- **Conta Google Ads**: 691-366-2252 (MCC/Manager)
- **GA4 Property**: 381992026
- **Acesso**: leitura + escrita (writes em dry-run por padrao)

## Contas

| ID | Nome |
|----|------|
| 5984402642 | G4 Google Ads - GTM |
| 4003569711 | G4 Google Ads - Imersoes Legado |
| 9069341048 | G4 Google Ads - LGen |
| 8472900980 | G4 Google Ads - Selfcheckout |

## Guidelines

- Writes sempre em dry_run: true por padrao
- Budget safety cap: R$500/dia por campanha
- Usar login_customer_id para queries no MCC
- Limite de 2000 search terms por pull
GUIDEEOF

cat > "$WORKSPACE_DIR/sources/google-ads/permissions.json" << 'PERMEOF'
{
  "allowedMcpPatterns": [
    { "pattern": "get", "comment": "Leitura de campanhas, keywords, ads" },
    { "pattern": "list", "comment": "Listagem de recursos" },
    { "pattern": "search", "comment": "Search terms e queries GAQL" },
    { "pattern": "report", "comment": "Relatorios de performance" },
    { "pattern": "analyze", "comment": "Analises e diagnosticos" },
    { "pattern": "check", "comment": "Health checks e diagnosticos" },
    { "pattern": "diagnose", "comment": "Diagnostico de campanhas" }
  ]
}
PERMEOF
```

### 0.6 — Validar instalacao e apresentar ao usuario

Testar que o adloop carrega e consegue listar contas:

```bash
python3 -c "
from adloop.config import load_config
from adloop.ads.read import list_accounts
config = load_config()
accounts = list_accounts(config)
print(f'OK: {len(accounts)} contas encontradas')
for a in accounts:
    print(f'  - {a[\"id\"]} | {a[\"name\"]} | {a[\"status\"]}')
"
```

Se falhar com erro de auth, o refresh token pode ter expirado. Informar ao usuario que precisa re-autenticar com `adloop auth`.

### 0.7 — Confirmar instalacao e explicar o workflow

Apos a validacao da Fase 0, SEMPRE apresentar ao usuario uma mensagem de confirmacao com:

1. **Status da instalacao** — confirmar que tudo foi configurado com sucesso, mostrar as contas encontradas
2. **O que o workflow faz** — explicar de forma curta os 5 modulos disponiveis:
   - **Weekly Review** — visao executiva de performance com alertas automaticos (CPA, ROAS, conversoes)
   - **Mine Search Terms** — identifica termos irrelevantes e gera CSV de negativos para adicionar
   - **Audit Ad Copy** — avalia qualidade de headlines/descriptions e sugere melhorias
   - **Budget Optimizer** — recomenda redistribuicao de verba baseada em ROAS e CPA
   - **Investigate Campaign** — diagnostico completo de uma campanha especifica (90 dias)
3. **Como usar** — explicar que o usuario pode:
   - Digitar `/google-ads-review` para abrir o menu interativo
   - Ou pedir diretamente: "analisa a conta GTM", "mine search terms da LGen", "weekly review de todas as contas"
4. **Seguranca** — reforcar que o workflow NUNCA executa mudancas no Google Ads sem confirmacao explicita. Todas as analises sao read-only.

Exemplo de mensagem:

> **Google Ads Review instalado com sucesso!**
>
> Encontrei X contas ativas: [listar]. Aqui esta o que voce pode fazer:
>
> - **Weekly Review** — KPIs, alertas e acoes recomendadas
> - **Mine Search Terms** — negativos para adicionar (exporta CSV)
> - **Audit Ad Copy** — qualidade dos anuncios + sugestoes
> - **Budget Optimizer** — onde realocar verba
> - **Investigate Campaign** — diagnostico profundo de uma campanha
>
> Para comecar, digite `/google-ads-review` ou me diga o que quer analisar.
> Nenhuma mudanca e feita sem sua confirmacao — tudo e read-only por padrao.

So depois dessa apresentacao, prosseguir para a Fase 1.

---

## Configuracao (referencia — ja instalada pela Fase 0)

```
Config:    ~/.adloop/config.yaml
Token:     ~/.adloop/token.json
MCC ID:    6913662252
GA4:       381992026
```

**Contas disponiveis:**
| ID | Nome |
|----|------|
| 5984402642 | G4 Google Ads - GTM |
| 4003569711 | G4 Google Ads - Imersoes Legado |
| 9069341048 | G4 Google Ads - LGen |
| 8472900980 | G4 Google Ads - Selfcheckout |

**Python API:**
```python
from adloop.config import load_config
from adloop.ads.read import (
    list_accounts, get_campaign_performance,
    get_keyword_performance, get_search_terms,
    get_ad_performance, get_negative_keywords
)
config = load_config()
```

Assinaturas:
- `get_campaign_performance(config, *, customer_id='', date_range_start='YYYY-MM-DD', date_range_end='YYYY-MM-DD')`
- `get_keyword_performance(config, *, customer_id='', date_range_start='', date_range_end='')`
- `get_search_terms(config, *, customer_id='', date_range_start='', date_range_end='', min_clicks=1, limit=2000)`
- `get_ad_performance(config, *, customer_id='', date_range_start='', date_range_end='')`
- `get_negative_keywords(config, *, customer_id='')`

Chamar via Bash: `python3 -c "..."` — nunca criar arquivo .py temporario.

---

## Fase 1 — Selecao de Escopo

Apresentar ao usuario as 3 perguntas abaixo em uma unica mensagem curta:

**1. Conta(s):**
- [ ] Todas as contas ativas (padrao)
- [ ] GTM (5984402642)
- [ ] Imersoes Legado (4003569711)
- [ ] LGen (9069341048)
- [ ] Selfcheckout (8472900980)

**2. Periodo:**
- Ultimos 7 dias (padrao)
- Ultimos 30 dias
- Mes atual
- Customizado (pedir datas)

**3. O que analisar:** (pode escolher multiplos)
- **[A] Weekly Review** — KPIs, variacoes e alertas
- **[B] Mine Search Terms** — negativos para adicionar -> CSV
- **[C] Audit Ad Copy** — qualidade de headlines e descriptions
- **[D] Budget Optimizer** — onde redistribuir verba
- **[E] Investigate Campaign** — diagnostico detalhado de uma campanha
- **[F] Tudo** (A+B+C+D)

Se o usuario ja especificou o que quer na mensagem inicial (ex: "mine search terms da GTM"), pular direto para a Fase 2 sem fazer perguntas.

---

## Fase 2 — Execucao

### [A] Weekly Review

**Objetivo:** Visao executiva de performance com alertas automaticos.

**Dados a coletar:**
- `get_campaign_performance` para periodo selecionado E periodo anterior equivalente
- Para cada conta selecionada; agregar se "Todas"

**Calculos:**
- Delta % para: spend, impressions, clicks, CTR, conversions, CPA, ROAS
- CPA = cost / conversions (ignorar campanhas sem conversao no denominador)
- ROAS = conversion_value / cost

**Flags automaticos:**
- Critico: CPA subiu >20%, conversoes cairam >30%, campanha ativa sem gasto nos ultimos 3 dias
- Atencao: CTR caindo, budget limitando campanha com ROAS > media, search term novo drenando >R$50 sem conversao
- Destaque: campanha melhorando ROAS, keyword com alta taxa de conversao

**Output:**
Dashboard jsonrender com:
- Grid 4 colunas: Spend total | Conversoes | CPA medio | ROAS medio (com delta vs periodo anterior)
- Stack vertical com alertas (Alert components: error/warning/success)
- Tabela top 5 melhores e 5 piores campanhas por variacao de conversao

Seguido de texto: top 3 acoes recomendadas para a semana.

---

### [B] Mine Search Terms

**Objetivo:** Identificar termos irrelevantes para adicionar como negativos.

**Dados a coletar:**
- `get_search_terms(config, customer_id=X, date_range_start=..., date_range_end=..., min_clicks=1, limit=2000)`

**Logica de classificacao (para cada termo):**
Avaliar o trio: search_term + keyword_alvo + nome_campanha/grupo

NEGAR quando o termo:
- Sinaliza intencao errada: gratis, gratuito, free, emprego, vaga, concurso, download, pirata
- E nome de concorrente direto
- E claramente irrelevante para o produto que a campanha vende (ex: "curso de ingles" em campanha de gestao empresarial)
- Tem alta impressao/clique mas zero conversao E custo > R$20

MANTER quando:
- E on-theme com o produto, mesmo sem conversao
- Tem conversao registrada
- E variacao legitima da keyword alvo

**Output:**
1. Resumo no chat: "X termos analisados -> Y recomendados para negacao, Z mantidos"
2. CSV salvo em `/tmp/search-term-negatives-YYYY-MM-DD.csv` com colunas:
   `search_term,campaign,ad_group,clicks,cost_brl,conversions,recommendation,reason`
3. Mostrar filecard do CSV

---

### [C] Audit Ad Copy

**Objetivo:** Identificar anuncios fracos e oportunidades de melhoria.

**Dados a coletar:**
- `get_ad_performance(config, customer_id=X, date_range_start=..., date_range_end=...)`

**Avaliacao por anuncio:**
- Especificidade: headline tem numero, beneficio concreto ou prova social?
- CTA: tem chamada para acao clara?
- CTR vs media da conta: abaixo de 50% da media = sinal de problema
- Relevancia: copy alinhada com o tema do grupo de anuncios?

**Classificacao:**
- Pausar/Reescrever: CTR < 50% da media + copy generica
- Otimizar: CTR OK mas copy tem oportunidade de melhoria
- Manter: performando bem, copy relevante

**Output:**
Tabela no chat com: campanha | anuncio (headline 1) | CTR | classificacao | sugestao de melhoria

---

### [D] Budget Optimizer

**Objetivo:** Recomendar redistribuicao de budget baseada em performance.

**Dados a coletar:**
- `get_campaign_performance` para os ultimos 30 dias (independente do periodo selecionado — precisamos de volume)

**Logica:**
- Escalar (recomendar +budget): campanha com ROAS > media da conta E budget limitando (impressions share perdido por budget)
- Reduzir (recomendar -budget): campanha com CPA > 2x media da conta E spend relevante
- Pausar: campanha com spend > R$100 no periodo e zero conversoes
- Manter: demais

**Output:**
Tabela: campanha | spend atual | CPA | ROAS | acao recomendada | movimento sugerido (R$)
Seguido de: realocacao total proposta (R$ saindo de onde, R$ indo para onde).

---

### [E] Investigate Campaign

**Objetivo:** Diagnostico completo de uma campanha especifica.

**Pedir ao usuario:** nome ou ID da campanha.

**Dados a coletar:**
- `get_campaign_performance` — historico 90 dias
- `get_keyword_performance` — keywords da campanha
- `get_search_terms` — search terms recentes
- `get_ad_performance` — anuncios ativos
- `get_negative_keywords` — negativos ja aplicados

**Output:**
Relatorio completo com secoes:
1. Resumo executivo (3 bullets)
2. Performance historica (ultimos 30/60/90 dias)
3. Analise de keywords (top performers e underperformers)
4. Search terms suspeitos
5. Qualidade dos anuncios
6. Diagnostico: qual e o maior problema e a acao #1 recomendada

---

## Fase 3 — Entrega

Apos cada modulo:
1. Apresentar resultados no chat (jsonrender para dados quantitativos, tabelas markdown para listas)
2. Arquivos CSV com filecard quando aplicavel
3. Encerrar com: "Quer aprofundar algum ponto ou executar alguma acao?" com 2-3 opcoes contextuais

**Regras gerais:**
- Sempre calcular datas automaticamente a partir da data atual do sistema
- Se multiplas contas: iterar em loop Python, agregar resultados
- Se uma conta falhar na API: continuar com as demais, reportar erro no final
- Valores monetarios sempre em R$ (a API retorna cost_micros — dividir por 1.000.000)
- Nunca executar writes no Google Ads sem confirmacao explicita do usuario
- `require_dry_run: true` esta no config — respeitar sempre