---
name: WBR — Weekly Business Review
description: Preparo completo para a WBR Comercial. Cobre os números quantitativos de Pré-Vendas (MQL, Opp, CR, LRT, headcount) e Vendas (receita por grupo, win rate, ticket médio, receita por Opp, Top AEs).
---

# Ritual: WBR — Weekly Business Review

## Execução — Scripts Python

Este ritual é executado via **2 scripts** pré-validados. **Não montar queries manualmente.**

```bash
python "{workflow-dir}/rituais/wbr_pre_vendas.py"
python "{workflow-dir}/rituais/wbr_vendas.py"
```

Executar em sequência: Script 1 (PV) → Script 2 (Vendas).

---

## O que NÃO é coberto (intencionalmente)

- Comentários operacionais, bloqueios e pedidos de ajuda → inseridos manualmente
- Outbound e Indicação PV → não têm GRID próprio em `db_metas_g4 Plano G4`
- Granularidade semanal → não existe diariação por semana no pipeline atual

---

## Guardrails

1. **`grupo_de_receita = 'Funil de Marketing'`** — filtro obrigatório no realizado de PV. Sem ele, +519 opps indevidas
2. **Selfcheckout sem diariação** — exibir só realizado absoluto, sem GRID
3. **Projetos e Eventos = inclui Aniversário G4** — `grupo_de_receita = 'Projetos e Eventos'`
4. **Meta total Vendas = R$59M** — soma de todos os grupos do Plano G4
5. **`setor = 'Pré Vendas Aquisição'`** — sem hífen; com hífen retorna 0 linhas
6. **Período** — `>= primeiro dia do mês` e `< current_date()`