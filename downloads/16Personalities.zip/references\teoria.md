# Teoria — 16 Personalities

## História e Origem

O modelo 16 Personalities é uma adaptação moderna do Myers-Briggs Type Indicator (MBTI), desenvolvido por **Isabel Briggs Myers** e sua mãe **Katharine Cook Briggs** durante as décadas de 1940 e 1950. Ambas se basearam na teoria dos tipos psicológicos de **Carl Gustav Jung**, publicada em 1921 no livro *Psychological Types*.

Jung propôs que as diferenças de personalidade humana não são aleatórias — elas seguem padrões previsíveis baseados em como as pessoas preferem usar sua mente. Myers e Briggs operacionalizaram essa teoria em um questionário estruturado, criando o MBTI.

O site **16personalities.com**, criado por Nerius Paulius e a equipe da NERIS Analytics, adaptou e expandiu o modelo original MBTI adicionando a **5ª dimensão: Identity (A/T)**, que avalia a estabilidade emocional e a autoconfiança. Essa adição torna o sistema mais nuançado, pois dois indivíduos com o mesmo tipo de 4 letras (ex: INTJ) podem ter perfis comportamentais bastante distintos dependendo de serem Assertivos ou Turbulentes.

---

## As 5 Dimensões

### 1. MIND — Como você interage com o mundo
*Questões 1–12 no teste*

**E — Extrovert (Extrovertido)**
- Ganha energia da interação social e do ambiente externo
- Pensa enquanto fala — processa externamente
- Prefere trabalho em equipe e ambientes dinâmicos
- Rede de relacionamentos ampla, muitos conhecidos
- Sente-se estimulado por variedade e ação
- Pode sentir desconforto com silêncio prolongado ou isolamento

**I — Introvert (Introvertido)**
- Ganha energia da reflexão e do espaço interno
- Pensa antes de falar — processa internamente
- Prefere trabalho independente ou em grupos pequenos
- Rede de relacionamentos profunda, poucos amigos próximos
- Precisa de tempo sozinho para recarregar após interações longas
- Pode sentir desgaste em ambientes de alta estimulação social

> **Atenção:** Introversão não é timidez nem isolamento social. É sobre onde a energia vem — não sobre habilidade ou desejo de socializar.

---

### 2. ENERGY — Como você vê o mundo e processa informação
*Questões 13–24 no teste*

**N — Intuitive (Intuitivo)**
- Foca em padrões, conexões e possibilidades
- Orientado ao futuro — "o que poderia ser"
- Pensa abstratamente, em conceitos e teorias
- Boa capacidade de ver o panorama geral (big picture)
- Aprende melhor pelo todo antes das partes
- Pode ter dificuldade com detalhes rotineiros e tarefas repetitivas

**S — Observant/Sensing (Observador/Sensorial)**
- Foca em fatos, dados concretos e experiências presentes
- Orientado ao presente — "o que é e como funciona"
- Pensa praticamente, com base em evidências tangíveis
- Forte atenção aos detalhes e capacidade de memorização
- Aprende melhor por etapas sequenciais
- Pode ter dificuldade com abstrações e especulações excessivas

---

### 3. NATURE — Como você toma decisões
*Questões 25–36 no teste*

**T — Thinking (Racional/Pensamento)**
- Prioriza lógica, objetividade e consistência
- Decide com base em princípios e análise imparcial
- Busca a verdade mesmo quando desconfortável
- Valoriza eficiência e competência acima de harmonia
- Pode parecer frio ou insensível mesmo sem intenção
- Tende a dar feedback direto e honesto

**F — Feeling (Sentimental/Emocional)**
- Prioriza valores, harmonia e impacto nas pessoas
- Decide considerando como afetará os envolvidos
- Forte empatia e sintonização com emoções alheias
- Valoriza autenticidade e conexão acima de eficiência
- Pode evitar conflitos para preservar relacionamentos
- Tende a personalizar o feedback e considerar o contexto emocional

> **Atenção:** T não significa "sem emoções" e F não significa "irracional". Ambos são formas igualmente válidas de tomar decisões.

---

### 4. TACTICS — Como você lida com estrutura e planejamento
*Questões 37–48 no teste*

**J — Judging (Julgador/Estruturado)**
- Prefere estrutura, planejamento e previsibilidade
- Busca fechamento e tomada de decisão clara
- Trabalha melhor com prazos e listas definidas
- Sente desconforto com situações em aberto ou ambíguas
- Tende a organizar o ambiente ao seu redor
- Pode ser percebido como inflexível ou precipitado nas decisões

**P — Prospecting/Perceiving (Prospector/Perceptivo)**
- Prefere flexibilidade, espontaneidade e adaptação
- Mantém opções em aberto o máximo possível
- Trabalha bem sob pressão, muitas vezes melhor perto do prazo
- Sente restrição com estruturas rígidas e planos fixos
- Tende a adaptar-se ao ambiente conforme necessário
- Pode ser percebido como desorganizado ou procrastinador

---

### 5. IDENTITY — Confiança em si mesmo e resiliência ao estresse
*Questões 49–60 no teste*
*(Dimensão exclusiva do modelo 16personalities — não existe no MBTI clássico)*

**A — Assertive (Assertivo)**
- Alta autoconfiança e estabilidade emocional
- Menos afetado por estresse e pressão externa
- Menor tendência à autocrítica e ruminação
- Satisfeito com seu progresso — menos orientado à perfeição
- Pode subestimar riscos ou deixar de agir por falta de urgência
- Tende a manter a calma em situações de crise

**T — Turbulent (Turbulento)**
- Maior autoconsciência e tendência à autocrítica
- Mais sensível ao estresse, pressão e avaliação dos outros
- Fortemente motivado pela melhoria contínua e excelência
- Menos satisfeito com o status quo — sempre busca fazer melhor
- Pode cair em espirais de preocupação e perfeccionismo
- Em momentos positivos, tem energia e determinação intensas

> **A vs T não é sobre saúde mental.** Turbulent é um motor poderoso de crescimento quando bem gerido. Assertive pode indicar complacência se não houver consciência. Ambos têm vantagens reais.

---

## Os 4 Grupos de Temperamento

Os 16 tipos são agrupados em 4 famílias baseadas nas dimensões Energy (N/S) e Nature (T/F):

### 🔬 ANALYSTS — NT (Intuitivo + Racional)
Visionários estratégicos. Movidos por lógica, competência e ideias complexas. Excelentes na resolução de problemas abstratos e sistemas. Tendem a ser independentes, exigentes e orientados ao futuro.

| Tipo | Nome | Traço central |
|------|------|---------------|
| INTJ | O Arquiteto | Estrategista perfeccionista |
| INTP | O Lógico | Teórico inovador |
| ENTJ | O Comandante | Líder nato determinado |
| ENTP | O Debatedor | Provocador de ideias |

---

### 💚 DIPLOMATS — NF (Intuitivo + Sentimental)
Idealistas empáticos. Movidos por valores, conexão humana e significado. Excelentes em inspirar e entender pessoas. Tendem a ser criativos, altruístas e orientados ao crescimento pessoal.

| Tipo | Nome | Traço central |
|------|------|---------------|
| INFJ | O Advogado | Visionário altruísta |
| INFP | O Mediador | Idealista poético |
| ENFJ | O Protagonista | Líder inspirador |
| ENFP | O Ativista | Espírito livre criativo |

---

### 🛡️ SENTINELS — SJ (Observador + Julgador)
Guardiões práticos. Movidos por responsabilidade, tradição e estabilidade. Excelentes em manter sistemas, cuidar de pessoas e cumprir compromissos. Tendem a ser confiáveis, organizados e orientados à comunidade.

| Tipo | Nome | Traço central |
|------|------|---------------|
| ISTJ | O Inspetor | Executor metódico |
| ISFJ | O Defensor | Cuidador leal |
| ESTJ | O Executivo | Gestor eficiente |
| ESFJ | O Cônsul | Conector social |

---

### 🧭 EXPLORERS — SP (Observador + Prospector)
Aventureiros pragmáticos. Movidos por estímulo, liberdade e habilidade prática. Excelentes em agir no momento presente, adaptar-se e resolver problemas com as mãos. Tendem a ser ousados, espontâneos e orientados à ação.

| Tipo | Nome | Traço central |
|------|------|---------------|
| ISTP | O Virtuoso | Artesão analítico |
| ISFP | O Aventureiro | Artista sensível |
| ESTP | O Empreendedor | Ator dinâmico |
| ESFP | O Animador | Entertainer vibrante |

---

## Mapeamento das Questões por Dimensão

| Dimensão | Polo Positivo (para cálculo) | Polo Negativo | Questões no teste |
|----------|------------------------------|---------------|-------------------|
| Mind | Extrovert (E) | Introvert (I) | 1–12 |
| Energy | Intuitive (N) | Observant (S) | 13–24 |
| Nature | Thinking (T) | Feeling (F) | 25–36 |
| Tactics | Judging (J) | Prospecting (P) | 37–48 |
| Identity | Assertive (A) | Turbulent (T) | 49–60 |

**Fórmula de cálculo:**
- Questões do polo positivo: score direto (1–7)
- Questões do polo negativo: score invertido = 8 − resposta
- Soma dos 12 scores ÷ 84 = porcentagem bruta
- ≥ 50% → polo positivo; < 50% → polo negativo

**Legenda de força:**
| Range | Interpretação |
|-------|---------------|
| 50–60% | Leve preferência |
| 61–75% | Preferência moderada |
| 76–90% | Preferência forte |
| 91–100% | Preferência muito forte |

---

## Limitações e Contexto de Uso

- O modelo 16 Personalities é uma **ferramenta de autoconhecimento**, não um diagnóstico clínico
- Tipos de personalidade são **tendências**, não destinos — as pessoas se adaptam ao contexto
- O teste mede como a pessoa se percebe no momento — humor, fase de vida e contexto influenciam os resultados
- Recomenda-se refazer o teste após grandes mudanças de vida
- **Não use o tipo para:**
  - Tomar decisões de contratação unilateralmente
  - Rotular ou limitar pessoas ("você é X, então não consegue Y")
  - Justificar comportamentos prejudiciais ("sou ENTJ, sou naturalmente agressivo")
- **Use o tipo para:**
  - Ampliar autoconhecimento e consciência de padrões
  - Melhorar comunicação e trabalho em equipe
  - Identificar carreiras e ambientes onde você tende a prosperar
  - Entender diferenças entre pessoas sem julgamento