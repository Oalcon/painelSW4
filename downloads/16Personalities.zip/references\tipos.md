# 16 Tipos de Personalidade — Perfis Completos

> Referência interna da skill 16 Personalities. Use este arquivo para entregar interpretações ricas e personalizadas após calcular o tipo do usuário.

---

## Mapa dos Grupos

| Grupo | Tipos |
|---|---|
| **Analysts** (NT) | INTJ, INTP, ENTJ, ENTP |
| **Diplomats** (NF) | INFJ, INFP, ENFJ, ENFP |
| **Sentinels** (SJ) | ISTJ, ISFJ, ESTJ, ESFJ |
| **Explorers** (SP) | ISTP, ISFP, ESTP, ESFP |

---

# ANALYSTS (NT)
> Lógica, visão sistêmica, inovação e independência intelectual. Valorizam competência acima de tudo.

---

## [INTJ] — O Arquiteto

**Grupo:** Analysts
**Frase característica:** *"Eu não tenho sonhos — tenho planos."*

### Quem Você É
O INTJ é uma das personalidades mais raras e estrategicamente orientadas. Você vê o mundo como um tabuleiro de xadrez: padrões, possibilidades e consequências de longo prazo. Sua mente nunca para — está constantemente modelando futuros possíveis, identificando falhas em sistemas e desenhando soluções antes que os problemas apareçam. Independente, perfeccionista e extremamente exigente — consigo mesmo e com os outros.

### Pontos Fortes
- Pensamento estratégico de longo prazo
- Determinação e autoconfiança
- Capacidade analítica refinada
- Alta exigência com qualidade
- Independência intelectual

### Desafios & Pontos Cegos
- Arrogância intelectual
- Impaciência com o "óbvio"
- Frieza relacional
- Perfeccionismo paralisante
- Isolamento

### Carreira & Ambiente Ideal
Prospera em ambientes que recompensam profundidade, autonomia e visão de longo prazo. Carreiras: Estratégia corporativa, engenharia de sistemas, ciência de dados, arquitetura, medicina (pesquisa), direito corporativo, finanças quantitativas, CTO/CEO.

### Relacionamentos
Seletivo — prefere poucos relacionamentos profundos. Valoriza parceiros intelectualmente estimulantes que respeitem sua autonomia. Leal quando abre emocionalmente. Precisa de diretividade — detesta jogos e subentendidos.

### Variante -A vs -T
- **INTJ-A:** Mais confiante, menos afetado por críticas. Pode subestimar riscos.
- **INTJ-T:** Mais autocrítico, orientado à melhoria contínua. Mais propenso à ruminação.

### Personagens & Referências
Elon Musk, Walter White (Breaking Bad), Tywin Lannister (GoT), Nikola Tesla

---

## [INTP] — O Lógico

**Grupo:** Analysts
**Frase característica:** *"Mas e se a premissa estiver errada desde o início?"*

### Quem Você É
O INTP é o filósofo incansável. Sua mente é uma máquina de geração de hipóteses — questiona premissas, desmonta argumentos e reconstrói frameworks do zero. Curioso de forma quase obsessiva, tende ao perfeccionismo intelectual.

### Pontos Fortes
- Curiosidade intelectual profunda
- Pensamento original e criativo
- Objetividade lógica
- Abertura mental genuína
- Precisão analítica

### Desafios & Pontos Cegos
- Dificuldade de execução
- Procrastinação crônica
- Frieza emocional
- Desorganização prática
- Arrogância velada

### Carreira & Ambiente Ideal
Precisa de liberdade intelectual total. Carreiras: Pesquisa acadêmica, matemática, física, programação, filosofia, economia teórica, análise de dados, engenharia.

### Relacionamentos
Expressa cuidado através de ideias compartilhadas e debates apaixonados. Precisa de parceiro que não exija validação emocional constante.

### Variante -A vs -T
- **INTP-A:** Tranquilo com incertezas. Aceita o "não saber".
- **INTP-T:** Mais ansioso, revisa o próprio trabalho indefinidamente.

### Personagens & Referências
Albert Einstein, Sherlock Holmes, Larry Page, Rick Sanchez (Rick & Morty)

---

## [ENTJ] — O Comandante

**Grupo:** Analysts
**Frase característica:** *"Ineficiência é uma escolha que eu não aceito."*

### Quem Você É
O ENTJ é um líder nato com visão estratégica e vontade de ferro. Não espera que as coisas aconteçam — as faz acontecer. Vê oportunidades onde outros veem obstáculos.

### Pontos Fortes
- Liderança estratégica natural
- Decisividade
- Orientação a resultados
- Visão sistêmica
- Alta capacidade de execução

### Desafios & Pontos Cegos
- Intolerância com a mediocridade
- Dificuldade de escuta
- Impaciência relacional
- Workaholismo
- Arrogância

### Carreira & Ambiente Ideal
Prospera em posições de liderança e ambientes dinâmicos. Carreiras: CEO/COO, empreendedorismo, direito estratégico, consultoria, política, investimento.

### Relacionamentos
Investe profundamente em quem escolhe. Expressa afeto resolvendo problemas e planejando o futuro juntos. Precisa de parceiro que não se intimide com sua intensidade.

### Variante -A vs -T
- **ENTJ-A:** Confiante até a arrogância. Menos receptivo ao feedback.
- **ENTJ-T:** Usa autocrítica como motor. Mais aberto ao crescimento.

### Personagens & Referências
Steve Jobs, Margaret Thatcher, Frank Underwood (House of Cards), Gordon Ramsay

---

## [ENTP] — O Debatedor

**Grupo:** Analysts
**Frase característica:** *"Discordo — mas continue, isso está ficando interessante."*

### Quem Você É
O ENTP é o provocador intelectual por excelência. Não debate para ganhar — debate para pensar melhor. Gerador de possibilidades, desafiador de convenções.

### Pontos Fortes
- Pensamento lateral e criativo
- Carisma intelectual
- Adaptabilidade
- Capacidade de debate e persuasão
- Visão inovadora

### Desafios & Pontos Cegos
- Falta de follow-through
- Provocação desnecessária
- Inconsistência
- Resistência a rotinas
- Subestima sentimentos

### Carreira & Ambiente Ideal
Precisa de variedade e liberdade para experimentar. Carreiras: Empreendedorismo, marketing criativo, consultoria de inovação, direito, design de produto, venture capital.

### Relacionamentos
Intenso e estimulante. Precisa de alguém que aguente debates sem se sentir atacado.

### Variante -A vs -T
- **ENTP-A:** Confiante, debates são diversão pura.
- **ENTP-T:** Mais autocrítico, propenso à síndrome do impostor.

### Personagens & Referências
Leonardo da Vinci, Tyrion Lannister (GoT), Robert Downey Jr./Tony Stark

---

# DIPLOMATS (NF)
> Empatia, significado, conexão e valores.

---

## [INFJ] — O Advogado

**Grupo:** Diplomats
**Frase característica:** *"Eu sei que você não disse isso — mas foi isso que você quis dizer."*

### Quem Você É
O INFJ é o tipo mais raro. Combina profundidade intuitiva com genuína preocupação com o bem-estar humano. Enxerga padrões ocultos em comportamentos, sente o que as pessoas sentem antes que digam.

### Pontos Fortes
- Intuição social profunda
- Visão de longo prazo
- Comprometimento com valores
- Empatia profunda
- Insight e criatividade

### Desafios & Pontos Cegos
- Esgotamento por absorção emocional
- Perfeccionismo
- Tendência ao isolamento
- Dificuldade de limites
- Sensibilidade a críticas

### Carreira & Ambiente Ideal
Precisa de trabalho com significado. Carreiras: Psicologia, escrita criativa, docência, RH (desenvolvimento), medicina, ativismo, consultoria de carreira.

### Relacionamentos
Profundamente dedicado mas difícil de conhecer de verdade. Tem o "door slam" — quando alguém viola seus valores gravemente, fecha a porta permanentemente.

### Variante -A vs -T
- **INFJ-A:** Mais equilibrado, menos propenso à ruminação.
- **INFJ-T:** Mais autocrítico, propenso à ansiedade existencial.

### Personagens & Referências
Nelson Mandela, Martin Luther King Jr., Atticus Finch, Gandhi

---

## [INFP] — O Mediador

**Grupo:** Diplomats
**Frase característica:** *"Eu não preciso que o mundo inteiro me entenda — só preciso que você entenda."*

### Quem Você É
O INFP vive em um universo interior rico e profundamente pessoal. Sente o mundo com intensidade que poucos compreendem. Seus valores são seu núcleo — não são regras externas, são identidade.

### Pontos Fortes
- Autenticidade radical
- Empatia e sensibilidade
- Criatividade e expressão
- Comprometimento com valores
- Profundidade de conexão

### Desafios & Pontos Cegos
- Idealismo irrealista
- Sensibilidade excessiva
- Procrastinação
- Dificuldade com conflitos
- Isolamento

### Carreira & Ambiente Ideal
Precisa de trabalho que ressoe com seus valores. Carreiras: Escrita, psicologia, assistência social, música e artes, educação criativa, ONGs.

### Relacionamentos
Ama profundamente e raramente. Busca a "alma gêmea". Leva tempo para confiar, mas quando confia, é completamente.

### Variante -A vs -T
- **INFP-A:** Aceita sua própria imperfeição com mais graça.
- **INFP-T:** Sentimento crônico de "não ser suficiente". A tensão alimenta obra criativa.

### Personagens & Referências
J.R.R. Tolkien, Anne Frank, Frodo Baggins, Luna Lovegood (Harry Potter)

---

## [ENFJ] — O Protagonista

**Grupo:** Diplomats
**Frase característica:** *"Eu vejo o que você pode se tornar antes que você mesmo veja."*

### Quem Você É
O ENFJ entra numa sala e sabe como cada pessoa está se sentindo. Líder natural movido por valores. Inspira, conecta e desenvolve pessoas com empatia profunda e visão estratégica.

### Pontos Fortes
- Liderança carismática e empática
- Inteligência emocional alta
- Comunicação eloquente
- Comprometimento
- Capacidade de desenvolvimento de pessoas

### Desafios & Pontos Cegos
- Auto-negligência
- Necessidade de aprovação
- Dificuldade com crítica direta
- Controle disfarçado de cuidado
- Sensibilidade a conflitos

### Carreira & Ambiente Ideal
Prospera em liderança com propósito humano. Carreiras: Liderança em RH/educação/ONGs, coaching, psicologia, política progressista, docência.

### Relacionamentos
Intensamente dedicado. Precisa de reciprocidade. Tende a colocar necessidades do parceiro acima das próprias.

### Variante -A vs -T
- **ENFJ-A:** Mais equilibrado, capaz de estabelecer limites.
- **ENFJ-T:** Mais perfeccionista, mais ansioso com o impacto de suas ações.

### Personagens & Referências
Oprah Winfrey, Barack Obama, Morpheus (Matrix), Mufasa (O Rei Leão)

---

## [ENFP] — O Ativista

**Grupo:** Diplomats
**Frase característica:** *"A vida é curta demais para não ser exatamente quem você é."*

### Quem Você É
O ENFP é energia, conexão e possibilidades em forma humana. Movido por entusiasmo genuíno. Charme natural não calculado — se interessa de verdade pelas pessoas.

### Pontos Fortes
- Entusiasmo contagiante
- Empatia e conexão genuína
- Criatividade e originalidade
- Adaptabilidade
- Autenticidade

### Desafios & Pontos Cegos
- Dificuldade com follow-through
- Desorganização
- Hipersensibilidade
- Dificuldade com limites
- Instabilidade emocional

### Carreira & Ambiente Ideal
Precisa de significado, variedade e conexão humana. Carreiras: Marketing criativo, empreendedorismo social, jornalismo, coaching, cinema, ONG.

### Relacionamentos
Intensamente presente e carinhoso. Precisa de liberdade dentro do relacionamento.

### Variante -A vs -T
- **ENFP-A:** Mais tranquilo, menos ansioso com o que os outros pensam.
- **ENFP-T:** Mais intenso, comprometido com crescimento. Propenso à síndrome do impostor.

### Personagens & Referências
Robin Williams, Walt Disney, Phoebe Buffay (Friends)

---

# SENTINELS (SJ)
> Ordem, responsabilidade, tradição e serviço.

---

## [ISTJ] — O Logístico

**Grupo:** Sentinels
**Frase característica:** *"Se vale a pena fazer, vale a pena fazer direito — e dentro do prazo."*

### Quem Você É
O profissional mais confiável. Metódico, responsável e comprometido com a qualidade. Constrói reputação sobre resultados consistentes.

### Pontos Fortes
- Confiabilidade absoluta
- Atenção a detalhes
- Responsabilidade e integridade
- Organização e planejamento
- Paciência e persistência

### Desafios & Pontos Cegos
- Resistência à mudança
- Inflexibilidade
- Dificuldade com ambiguidade
- Frieza emocional percebida
- Excesso de responsabilidade

### Carreira & Ambiente Ideal
Ambientes estáveis com processos claros. Carreiras: Contabilidade, direito (compliance), administração, logística, TI (infraestrutura), auditoria.

### Relacionamentos
Demonstra amor por atos de serviço e confiabilidade. "Eu apareço" é "eu te amo."

### Personagens & Referências
Queen Elizabeth II, George Washington, Hermione Granger, Ned Stark (GoT)

---

## [ISFJ] — O Defensor

**Grupo:** Sentinels
**Frase característica:** *"Eu não preciso de reconhecimento — preciso saber que fiz a diferença."*

### Quem Você É
O coração silencioso das equipes. Nota o que os outros precisam antes que percebam, e age — sem fanfarra, sem pedir crédito.

### Pontos Fortes
- Cuidado genuíno e altruísta
- Atenção às necessidades individuais
- Confiabilidade e dedicação
- Memória afetiva
- Estabilidade e calma

### Desafios & Pontos Cegos
- Dificuldade em dizer não
- Auto-negligência crônica
- Sensibilidade a conflitos
- Resistência a mudanças
- Dificuldade de expressar insatisfação

### Carreira & Ambiente Ideal
Papéis de serviço e cuidado. Carreiras: Enfermagem, educação infantil, assistência social, RH, suporte administrativo.

### Relacionamentos
Parceiro mais dedicado e presente. Precisa aprender a receber tanto quanto dá.

### Personagens & Referências
Madre Teresa, Samwise Gamgee (Senhor dos Anéis), Captain America, Joyce Byers (Stranger Things)

---

## [ESTJ] — O Executivo

**Grupo:** Sentinels
**Frase característica:** *"As regras existem por uma razão — e eu as farei cumprir."*

### Quem Você É
O gestor nato. Pega caos e transforma em ordem, define processos, distribui responsabilidades e cobra resultados.

### Pontos Fortes
- Capacidade organizacional excepcional
- Liderança direta e clara
- Orientação a resultados
- Confiabilidade
- Senso de responsabilidade

### Desafios & Pontos Cegos
- Inflexibilidade
- Frieza percebida
- Autoritarismo
- Resistência à inovação
- Julgamento rápido

### Carreira & Ambiente Ideal
Posições de gestão e liderança operacional. Carreiras: Gestão, direito, militares, finanças, logística, gerência industrial.

### Personagens & Referências
Hillary Clinton, Judge Judy, Monica Geller (Friends)

---

## [ESFJ] — O Cônsul

**Grupo:** Sentinels
**Frase característica:** *"Uma comunidade unida é mais forte que qualquer indivíduo."*

### Quem Você É
O tecido social das comunidades. Lembra do aniversário de todo mundo, organiza encontros, garante que ninguém fique de fora.

### Pontos Fortes
- Construção de comunidade
- Suporte emocional
- Organização social
- Lealdade
- Empatia prática

### Desafios & Pontos Cegos
- Necessidade de aprovação
- Sensibilidade excessiva a críticas
- Dificuldade com limites
- Conformismo
- Intrusividade

### Carreira & Ambiente Ideal
Papéis que combinam serviço e relacionamento. Carreiras: Saúde, educação, RH, vendas consultivas, relações públicas, hotelaria.

### Personagens & Referências
Molly Weasley (Harry Potter), Monica Geller (Friends)

---

# EXPLORERS (SP)
> Pragmatismo, adaptabilidade, presença no momento e ação direta.

---

## [ISTP] — O Virtuoso

**Grupo:** Explorers
**Frase característica:** *"Menos teoria, mais prática — me dê a ferramenta que eu resolvo."*

### Quem Você É
O engenheiro silencioso que resolve o problema enquanto os outros ainda discutem a teoria. Talento nato para entender como as coisas funcionam.

### Pontos Fortes
- Resolução prática de problemas
- Habilidade técnica
- Calma sob pressão
- Adaptabilidade
- Independência

### Desafios & Pontos Cegos
- Dificuldade com compromissos de longo prazo
- Comunicação emocional
- Impaciência com burocracia
- Isolamento
- Atração por risco

### Carreira & Ambiente Ideal
Trabalhos técnicos e manuais. Carreiras: Engenharia, programação, pilotagem, bombeirismo, medicina de emergência, mecânica.

### Personagens & Referências
Clint Eastwood, James Bond, Arya Stark (GoT), Indiana Jones

---

## [ISFP] — O Aventureiro

**Grupo:** Explorers
**Frase característica:** *"Não preciso de aplausos — preciso que o que eu faço seja verdadeiro."*

### Quem Você É
Vive no presente com intensidade silenciosa e sensibilidade estética raramente igualada. Valores muito claros mas raramente os anuncia — age por eles.

### Pontos Fortes
- Sensibilidade estética e artística
- Autenticidade
- Presente no momento
- Flexibilidade
- Empatia silenciosa

### Desafios & Pontos Cegos
- Dificuldade com planejamento
- Conflito evitado
- Auto-expressão verbal
- Hipersensibilidade
- Falta de assertividade

### Carreira & Ambiente Ideal
Expressão pessoal e flexibilidade. Carreiras: Artes visuais, música, fotografia, design de moda, culinária, fisioterapia.

### Personagens & Referências
Bob Ross, Frida Kahlo, Pocahontas, Michael Jackson

---

## [ESTP] — O Empreendedor

**Grupo:** Explorers
**Frase característica:** *"Enquanto você analisa, eu já resolvi."*

### Quem Você É
Energia pura em movimento. Rápido, adaptável, charmoso e orientado à ação. Pensa enquanto faz — não antes.

### Pontos Fortes
- Ação rápida e decisiva
- Leitura de ambiente
- Charme natural
- Criatividade sob pressão
- Energia e entusiasmo

### Desafios & Pontos Cegos
- Impulsividade
- Fuga de comprometimento
- Dificuldade com rotinas
- Sensibilidade emocional limitada
- Foco no curto prazo

### Carreira & Ambiente Ideal
Ação, variedade e visibilidade. Carreiras: Empreendedorismo, vendas de alto valor, negociação, medicina de emergência, trading financeiro.

### Personagens & Referências
Han Solo (Star Wars), Ernest Hemingway, Jordan Belfort (O Lobo de Wall Street)

---

## [ESFP] — O Animador

**Grupo:** Explorers
**Frase característica:** *"A vida é um palco — e eu aproveito cada segundo."*

### Quem Você É
Presença, calor e celebração da vida. Entra num ambiente e imediatamente eleva a energia — genuinamente ama estar com pessoas.

### Pontos Fortes
- Energia e presença
- Generosidade e calor
- Adaptabilidade
- Sensibilidade estética
- Conexão humana

### Desafios & Pontos Cegos
- Fuga de conflitos e problemas sérios
- Dificuldade com planejamento
- Hipersensibilidade a críticas
- Impulsividade financeira
- Dificuldade com tarefas solitárias

### Carreira & Ambiente Ideal
Trabalho dinâmico com pessoas. Carreiras: Entretenimento, vendas, educação infantil, moda, eventos, turismo.

### Personagens & Referências
Freddie Mercury, Marilyn Monroe, Beyoncé, Donkey (Shrek)

---

*Arquivo gerado para a skill 16 Personalities — G4 OS Workspace. Versão 1.0 | Junho 2026.*