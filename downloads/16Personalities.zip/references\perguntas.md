# Perguntas — 16 Personalities (60 Questões)

As 60 afirmações estão organizadas em 5 blocos de 12, uma por dimensão.
O polo de cada afirmação está indicado entre parênteses — use isso para o cálculo.

**Escala de resposta:**
1 = Discordo totalmente · 2 = Discordo · 3 = Discordo levemente · 4 = Neutro · 5 = Concordo levemente · 6 = Concordo · 7 = Concordo totalmente

---

## BLOCO 1 — MIND: Extrovert (E) vs Introvert (I)
*Questões 1 a 12*

1. **(E)** Você se sente energizado e revigorado depois de passar tempo com muitas pessoas.
2. **(I)** Depois de longas interações sociais, você precisa de tempo sozinho para recarregar as energias.
3. **(E)** Você costuma iniciar conversas com pessoas que não conhece sem dificuldade.
4. **(I)** Você prefere se comunicar por escrito — mensagens ou e-mail — em vez de falar ao vivo.
5. **(E)** Em festas ou eventos, você tende a circular e conhecer pessoas novas em vez de ficar com um grupo pequeno.
6. **(I)** Você se sente mais produtivo quando trabalha em silêncio, sem interrupções ou barulho ao redor.
7. **(E)** Você costuma pensar em voz alta — suas ideias ficam mais claras enquanto você fala.
8. **(I)** Quando tem um problema para resolver, você prefere refletir sozinho antes de discutir com alguém.
9. **(E)** Ambientes movimentados, como escritórios abertos ou eventos com muita gente, tendem a estimular você.
10. **(I)** Você tem uma rede de relacionamentos pequena, mas com laços muito próximos e profundos.
11. **(E)** Silêncio prolongado em uma conversa te incomoda — você sente necessidade de preenchê-lo.
12. **(I)** Você tende a observar e escutar mais do que falar em reuniões ou conversas em grupo.

---

## BLOCO 2 — ENERGY: Intuitive (N) vs Observant/Sensing (S)
*Questões 13 a 24*

13. **(N)** Você se interessa muito mais pelas possibilidades futuras do que pela realidade atual.
14. **(S)** Você prefere trabalhar com fatos concretos e dados verificáveis em vez de teorias abstratas.
15. **(N)** Você frequentemente faz conexões entre assuntos aparentemente não relacionados.
16. **(S)** Você tem boa memória para detalhes específicos: datas, nomes, números e eventos passados.
17. **(N)** Você se entedia facilmente com tarefas rotineiras e repetitivas que não envolvem novidade.
18. **(S)** Você prefere aprender um novo assunto por etapas sequenciais e bem definidas.
19. **(N)** Você confia mais na sua intuição do que em evidências concretas quando precisa decidir algo.
20. **(S)** Quando planeja algo, você foca nos detalhes práticos antes de pensar no panorama geral.
21. **(N)** Você tende a pensar no sentido mais amplo e metafórico das coisas, não apenas no literal.
22. **(S)** Você valoriza experiências comprovadas e testadas em vez de apostar em abordagens inovadoras.
23. **(N)** Você se imagina frequentemente em cenários futuros ou alternativos — o "e se...".
24. **(S)** Você prefere instruções claras e específicas a orientações abertas e conceituais.

---

## BLOCO 3 — NATURE: Thinking (T) vs Feeling (F)
*Questões 25 a 36*

25. **(T)** Ao tomar decisões importantes, você prioriza a lógica e a análise objetiva acima de sentimentos.
26. **(F)** Você leva em conta o impacto emocional nas pessoas antes de tomar qualquer decisão relevante.
27. **(T)** Você acredita que ser honesto e direto é mais importante do que preservar os sentimentos de alguém.
28. **(F)** Em conflitos, sua primeira prioridade é restaurar a harmonia e o bem-estar emocional do grupo.
29. **(T)** Você consegue manter a racionalidade e a imparcialidade mesmo quando está pessoalmente envolvido em uma situação.
30. **(F)** Você se preocupa profundamente com o bem-estar das pessoas ao seu redor — mesmo de desconhecidos.
31. **(T)** Você acredita que regras e princípios devem ser aplicados de forma consistente, sem exceções para "casos especiais".
32. **(F)** Você prefere adaptar as regras ao contexto emocional de cada situação do que aplicá-las rigidamente.
33. **(T)** Quando alguém te pede um feedback, você dá uma opinião direta e honesta, mesmo que ela seja difícil de ouvir.
34. **(F)** Você escolhe cuidadosamente como expressar críticas para não magoar desnecessariamente a outra pessoa.
35. **(T)** Em debates, você valoriza a consistência dos argumentos muito mais do que as intenções ou emoções por trás deles.
36. **(F)** Você acha difícil tomar decisões que beneficiam o coletivo mas causam sofrimento a um indivíduo específico.

---

## BLOCO 4 — TACTICS: Judging (J) vs Prospecting (P)
*Questões 37 a 48*

37. **(J)** Você prefere ter um plano detalhado e estruturado antes de começar qualquer projeto ou tarefa.
38. **(P)** Você gosta de manter suas opções em aberto e tomar decisões apenas quando necessário.
39. **(J)** Você sente desconforto quando há muitas tarefas inacabadas ou compromissos não resolvidos.
40. **(P)** Você funciona bem — talvez melhor — quando tem que improvisar ou reagir a mudanças de última hora.
41. **(J)** Listas de tarefas, agendas e cronogramas são ferramentas que você usa consistentemente no dia a dia.
42. **(P)** Você prefere explorar e descobrir o caminho conforme avança em vez de seguir um roteiro predefinido.
43. **(J)** Quando um plano está definido, você sente incômodo se ele muda sem uma boa justificativa.
44. **(P)** Você tende a começar múltiplos projetos ao mesmo tempo e alterna entre eles conforme o interesse ou a urgência.
45. **(J)** Você costuma chegar adiantado ou pontualmente — atrasos o incomodam significativamente.
46. **(P)** Você prefere um ambiente de trabalho flexível, sem regras rígidas sobre como ou quando as coisas devem ser feitas.
47. **(J)** Você se sente aliviado e satisfeito quando completa uma tarefa e pode riscá-la da lista.
48. **(P)** Você frequentemente procrastina decisões finais porque sempre acha que pode surgir uma opção melhor.

---

## BLOCO 5 — IDENTITY: Assertive (A) vs Turbulent (T)
*Questões 49 a 60*

49. **(A)** Você raramente questiona retroativamente se tomou a decisão certa — uma vez decidido, você segue em frente.
50. **(T)** Você frequentemente passa por períodos de dúvida sobre se está no caminho certo na vida.
51. **(A)** Situações de alta pressão raramente afetam seu desempenho — você tende a manter a calma e foco.
52. **(T)** Você é muito sensível a críticas e tende a ficar ruminando sobre elas mesmo tempo depois de recebê-las.
53. **(A)** De modo geral, você está satisfeito com quem você é e com o rumo que sua vida está tomando.
54. **(T)** Você se preocupa com frequência com o que os outros pensam de você — mesmo quando racionalmente sabe que não deveria.
55. **(A)** Erros e fracassos não te abalam por muito tempo — você os processa rapidamente e segue adiante.
56. **(T)** Você tem uma forte tendência ao perfeccionismo — dificilmente sente que algo está "bom o suficiente".
57. **(A)** Você raramente sente inveja ou se compara negativamente a outras pessoas ao ver o sucesso delas.
58. **(T)** Você frequentemente sente que poderia e deveria estar fazendo mais do que está fazendo atualmente.
59. **(A)** Você consegue separar facilmente sua autoestima do resultado do seu trabalho — um fracasso profissional não abala sua confiança pessoal.
60. **(T)** Seu humor tende a variar bastante com os eventos do dia — boas notícias te animam muito e problemas te afetam profundamente.

---

## Tabela Resumo de Polos

| Q | Polo | Q | Polo | Q | Polo | Q | Polo | Q | Polo |
|---|------|---|------|---|------|---|------|---|------|
| 1 | E | 13 | N | 25 | T | 37 | J | 49 | A |
| 2 | I | 14 | S | 26 | F | 38 | P | 50 | T |
| 3 | E | 15 | N | 27 | T | 39 | J | 51 | A |
| 4 | I | 16 | S | 28 | F | 40 | P | 52 | T |
| 5 | E | 17 | N | 29 | T | 41 | J | 53 | A |
| 6 | I | 18 | S | 30 | F | 42 | P | 54 | T |
| 7 | E | 19 | N | 31 | T | 43 | J | 55 | A |
| 8 | I | 20 | S | 32 | F | 44 | P | 56 | T |
| 9 | E | 21 | N | 33 | T | 45 | J | 57 | A |
| 10 | I | 22 | S | 34 | F | 46 | P | 58 | T |
| 11 | E | 23 | N | 35 | T | 47 | J | 59 | A |
| 12 | I | 24 | S | 36 | F | 48 | P | 60 | T |

**Legenda de cálculo:**
- Polo positivo da dimensão (E, N, T, J, A): score = valor respondido (1–7)
- Polo negativo da dimensão (I, S, F, P, T-turbulent): score = 8 − valor respondido
- Soma total ÷ 84 = % → ≥50% = polo positivo vence