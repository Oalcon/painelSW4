# Guia de Interpretação — 16 Personalities

> Referência interna para o agente entregar interpretações ricas, contextualizadas e acionáveis após calcular o tipo do usuário.

---

## 1. Grupos de Temperamento

### Analysts (NT)
- Orientados pela lógica, competência e pensamento sistêmico
- Valorizam ideias e frameworks mais do que tradições ou sentimentos
- Alta autoexigência intelectual
- Comunicação direta, por vezes percebida como fria
- Motivados por domínio intelectual

### Diplomats (NF)
- Motivados por valores, significado e conexão humana genuína
- Empatia como capacidade estrutural
- Orientados ao desenvolvimento humano
- Precisam de propósito — trabalho sem significado é intolerável
- Tendem ao idealismo, à decepção e ao esgotamento

### Sentinels (SJ)
- Orientados pela responsabilidade, tradição e estabilidade
- Valorizam o que foi testado e comprovado
- Alta confiabilidade
- Senso de dever como motivador central
- Tendem a cuidar das estruturas que permitem a vida funcionar

### Explorers (SP)
- Vivem no presente — o momento atual é a única realidade que importa
- Orientados pela ação e experiência direta
- Alta adaptabilidade
- Ficam entediados com abstrações e rotinas fixas

---

## 2. Análise por Dimensão

### Mind (I/E) — Força da Preferência
| Força | Introversão (I) | Extroversão (E) |
|---|---|---|
| 50–60% (leve) | Funciona bem em grupos mas recarrega sozinho. | Gosta de pessoas mas aguenta o silêncio. |
| 61–75% (moderada) | Preferência clara por ambientes menores. | Busca ativamente companhia. |
| 76–90% (forte) | Mundo interno rico e prioritário. Grupos grandes cansam. | Muito enérgico em grupos. |
| 91–100% (muito forte) | Profundamente privado. Interações gerenciadas com cuidado. | Silêncio prolongado é ansioso. |

### Energy (N/S)
| Força | Intuição (N) | Observação (S) |
|---|---|---|
| 50–60% (leve) | Boa ponte entre visionários e práticos. | Prefere o concreto mas pensa abstratamente quando necessário. |
| 61–75% (moderada) | Pensa em padrões e possibilidades. Pode perder detalhes. | Forte orientação a fatos. Pode resistir a visões não comprovadas. |
| 76–90% (forte) | Vive no mundo das ideias. O presente pode ser negligenciado. | Profundamente enraizado no presente. |
| 91–100% (muito forte) | Quase totalmente orientado à abstração. | Totalmente orientado ao concreto e verificável. |

### Nature (T/F)
| Força | Pensamento (T) | Sentimento (F) |
|---|---|---|
| 50–60% (leve) | Lógico com genuína consideração pelo impacto humano. | Orientado a valores mas capaz de decisões lógicas. |
| 61–75% (moderada) | Lógica governa decisões difíceis. | Valores e impacto humano lideram. |
| 76–90% (forte) | Pode ser percebido como frio. | Profundamente afetado pelo estado emocional dos outros. |
| 91–100% (muito forte) | Cegueira quase total para impacto emocional. | Quase incapaz de separar decisões de seu impacto nas pessoas. |

### Tactics (J/P)
| Força | Julgamento (J) | Percepção (P) |
|---|---|---|
| 50–60% (leve) | Aprecia planejamento mas improvisa. | Prefere flexibilidade mas estrutura quando necessário. |
| 61–75% (moderada) | Planejamento é preferência clara. | Forte preferência por manter opções abertas. |
| 76–90% (forte) | Muito organizado. Mudanças de última hora são estressantes. | Muito espontâneo. Prazos são sugestões. |
| 91–100% (muito forte) | Controle total do ambiente é necessidade real. | Qualquer estrutura rígida é sentida como prisão. |

### Identity (A/T)
| Força | Assertivo (-A) | Turbulento (-T) |
|---|---|---|
| 50–60% (leve) | Estável com alguns momentos de autocrítica produtiva. | Autocrítico de forma saudável. |
| 61–75% (moderada) | Confiante, menos afetado por críticas. | Orientado à melhoria com alguma ansiedade. |
| 76–90% (forte) | Alta resistência ao estresse. | Autocrítica intensa como motor. Propenso à ruminação. |
| 91–100% (muito forte) | Quase imperturbável. Pode ignorar feedback importante. | Ansiedade crônica ligada ao desempenho. |

---

## 3. Dimensão Identity em Profundidade

**Assertivo (-A):**
- Mais confiante nas próprias decisões
- Menos afetado por críticas e fracassos
- Aceita imperfeição com facilidade
- Menos propenso à ruminação
- Pode subestimar riscos por excesso de confiança

**Turbulento (-T):**
- Mais autocrítico e perfeccionista
- Propenso à ruminação
- Alta motivação para melhoria contínua
- Mais propenso à síndrome do impostor
- Profundidade emocional e intelectual maior em geral

**IMPORTANTE:** -T não é patologia. É motor de crescimento quando bem gerido. -A não é superioridade — são sombras diferentes.

---

## 4. Principais Zonas de Atrito entre Tipos

- **T vs. F em conflito:** O T resolve o problema; o F processa a emoção do problema. Não há errado — há dessincronia.
- **J vs. P em parceria:** O J quer decidir; o P quer explorar mais.
- **N vs. S em comunicação:** O N fala em metáforas; o S precisa de dados concretos.
- **I vs. E em equipe:** O I precisa processar antes de responder; o E processa falando.

---

## 5. Como Estruturar a Entrega do Resultado

1. Revelar o tipo com contexto: nome, grupo, arquétipo, frase característica
2. Validação emocional: capturar a essência do que o usuário provavelmente sente
3. Pontos fortes: celebrar antes de desafiar
4. Pontos de crescimento: como oportunidade, não como falha
5. Dimensão Identity: como o -A ou -T modifica o tipo base
6. Aplicação ao contexto do usuário
7. Convite ao aprofundamento

---

## 6. Pontos de Atenção (Armadilhas de Interpretação)

1. Não tratar o tipo como destino fixo — são tendências, não tetos
2. Não usar o tipo para justificar fraquezas
3. Considerar o contexto de vida do usuário
4. -T não é patologia
5. -A não é superioridade
6. Pontuação no limite (48–52%): usuário usa os dois polos situacionalmente
7. Respeitar a reação emocional ao resultado — acolher antes de aprofundar

---

*Arquivo gerado para a skill 16 Personalities — G4 OS Workspace. Versão 1.0 | Junho 2026.*