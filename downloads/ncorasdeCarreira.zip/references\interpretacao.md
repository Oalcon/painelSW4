# Guia de Interpretação — Âncoras de Carreira

> Scores: Alto ≥ 25 | Médio 18–24 | Baixo ≤ 17

---

## TF — Competência Técnica/Funcional

**Alto (≥25):** Identidade ligada ao domínio. Busca especialização vertical, não cargo gerencial. Ambiente ideal: trilhas IC (Individual Contributor), centros de excelência, consultorias técnicas.
**Riscos:** Aceitar gestão por pressão social; ficar presa em orgs que não valorizam especialistas.

## GG — Competência Gerencial Geral

**Alto (≥25):** Motivada por liderança ampla e impacto coletivo. Quer P&L e decisão estratégica. Ambiente ideal: grandes empresas com programas de liderança, C-level, diretorias.
**Riscos:** Estagnação em orgs onde único caminho é gerencial sem desafio real.

## AI — Autonomia/Independência

**Alto (≥25):** Liberdade de método, horário e entrega como condição de saúde mental. Ambiente ideal: startups, consultoria independente, remote-first, contratos por projeto.
**Riscos:** Conflito com estruturas corporativas; percepção de "difícil de gerenciar".

## SE — Segurança/Estabilidade

**Alto (≥25):** Previsibilidade e segurança como filtro primário de decisões. Alta lealdade organizacional. Ambiente ideal: setor público, grandes corporações, multinacionais estáveis.
**Riscos:** Ficar presa em empregos insatisfatórios por medo de mudança.

## CE — Criatividade Empreendedora

**Alto (≥25):** Compulsão por criar algo do zero. Alta tolerância ao risco. Ambiente ideal: fundação de startups, intrapreneurship, venture building.
**Riscos:** Burnout por múltiplos negócios sem consolidar nenhum.

## SD — Serviço/Dedicação a uma Causa

**Alto (≥25):** Trabalho precisa ter propósito alinhado com valores. Aceita remuneração menor por missão. Ambiente ideal: ONGs, edtech, healthtech, empresas B Corp.
**Riscos:** Idealism trap; burnout por doação excessiva sem reconhecimento.

## PD — Puro Desafio

**Alto (≥25):** Motivada pela dificuldade em si. Se entedia quando domina. Ambiente ideal: consultoria estratégica, turnaround, bancos de investimento, competições técnicas.
**Riscos:** Vício em adrenalina; dificuldade em fases de execução rotineira.

## EV — Estilo de Vida

**Alto (≥25):** Integração vida-trabalho como condição inegociável. Alta eficiência dentro do horário. Ambiente ideal: remote-first, empresas com cultura de resultados, consultoria por projeto.
**Riscos:** Burnout por aceitar papéis incompatíveis; resentimento acumulado.

---

## Perfis de Combinação Mais Comuns

- **TF + PD** = Especialista Desafiador — resolve o impossível na sua área
- **GG + CE** = Líder Criador — funda e gerencia o que criou
- **AI + EV** = Arquiteto do Próprio Tempo — liberdade total de método e agenda
- **CE + PD** = Fundador Incansável — cria porque o problema é difícil
- **TF + AI** = Mestre Independente — especialista autônomo de alto nível
- **GG + SD** = Líder de Impacto — lidera organizações com propósito
- **SE + TF** = Especialista Confiável — expert estável em grande organização

---

## Co-dominância (diferença ≤ 2 pts)

Quando as duas âncoras dominantes têm diferença ≤ 2 pontos:
- Âncoras complementares: buscar papéis que ativem ambas simultaneamente
- Âncoras tensionadas: gerir conscientemente — saber em qual âncora está operando
- Pergunta-chave: *"Em qual das duas você abre mão mais facilmente quando forçado a escolher?"*

---

*Referência: Edgar H. Schein, Career Anchors (4ª ed.)*