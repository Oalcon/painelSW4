# Teoria das Âncoras de Carreira — Edgar H. Schein

## Contexto Histórico

Edgar Henry Schein (1928–2023) foi professor emérito do MIT Sloan. O modelo emergiu de estudo longitudinal iniciado em 1961 com 44 alunos do MBA do MIT, acompanhados por mais de 12 anos.

**Premissa central:** Uma âncora de carreira não é uma preferência passageira — é a autopercepção consolidada de (1) talentos e habilidades, (2) motivações e necessidades fundamentais, e (3) valores e atitudes. Ela representa o núcleo que uma pessoa *não abre mão* ao tomar decisões importantes de carreira.

---

## As 8 Âncoras de Carreira

### TF — Competência Técnica/Funcional
Identidade profissional construída sobre domínio de área específica. Sucesso = reconhecimento como perito. Progressão gerencial frequentemente indesejada.

### GG — Competência Gerencial Geral
Motivação central é liderar, integrar esforços e ter responsabilidade pelo resultado organizacional. Habilidades T, F e E são ferramentas para exercer poder eficazmente.

### AI — Autonomia/Independência
Necessidade primária é liberdade — de métodos, horários e formas de entrega. Qualquer restrição organizacional excessiva é intolerável.

### SE — Segurança/Estabilidade
Motivação central é reduzir incerteza e garantir continuidade. Alta fidelidade organizacional quando o vínculo é seguro.

### CE — Criatividade Empreendedora
Compulsão é criar algo novo — uma empresa, produto ou serviço. Riqueza é marcador de sucesso, não fim em si.

### SD — Serviço/Dedicação a uma Causa
Trabalho precisa servir a propósito maior. Não aceita trabalhar em contextos que contradizem seus valores centrais.

### PD — Puro Desafio
Motivação é vencer obstáculos aparentemente intransponíveis. Quando o problema está resolvido, o trabalho perde interesse.

### EV — Estilo de Vida
Carreira é apenas uma parte de uma vida maior. Flexibilidade de horário, localização e intensidade é inegociável.

---

## Mapeamento das 40 Perguntas por Âncora

| Âncora | Código | Perguntas |
|--------|--------|----------|
| Competência Técnica/Funcional | TF | 1, 9, 17, 25, 33 |
| Competência Gerencial Geral | GG | 2, 10, 18, 26, 34 |
| Autonomia/Independência | AI | 3, 11, 19, 27, 35 |
| Segurança/Estabilidade | SE | 4, 12, 20, 28, 36 |
| Criatividade Empreendedora | CE | 5, 13, 21, 29, 37 |
| Serviço/Dedicação a uma Causa | SD | 6, 14, 22, 30, 38 |
| Puro Desafio | PD | 7, 15, 23, 31, 39 |
| Estilo de Vida | EV | 8, 16, 24, 32, 40 |

- Máximo por âncora: **30** (5 × 6) | Mínimo: **5** (5 × 1)
- Âncora com maior score = âncora dominante
- Scores ≥ 25 = âncora muito forte
- Diferença ≤ 2 entre primeiros = perfil co-dominante