# Inventário de Âncoras de Carreira — 40 Perguntas (PT-BR)

**Escala:** 1 = Nunca verdade | 2 = Raramente | 3 = Às vezes | 4 = Frequentemente | 5 = Quase sempre | 6 = Sempre verdade

> As perguntas estão intercaladas por âncora na seguinte ordem de ciclos:
> TF(1) → GG(2) → AI(3) → SE(4) → CE(5) → SD(6) → PD(7) → EV(8) — repete 5 vezes (Q1–Q40)

---

## Bloco 1 — Perguntas 1 a 8

**1. (TF)** Sonho em me tornar tão expert na minha área que meu conhecimento seja continuamente buscado e reconhecido por outros.

**2. (GG)** Sinto que minha carreira só é verdadeiramente satisfatória quando consigo coordenar e integrar o trabalho de diferentes pessoas para alcançar resultados coletivos.

**3. (AI)** Acima de tudo, quero organizar meu trabalho e minha carreira de acordo com meus próprios critérios, sem estar sujeito às regras e restrições de uma organização.

**4. (SE)** O que mais me importa na carreira é ter a segurança de que estarei empregado e com boa renda por um longo período no futuro.

**5. (CE)** Sempre fui movido pela vontade de criar um negócio ou empreendimento próprio — algo que leve minha marca e que eu possa construir do zero.

**6. (SD)** Sinto que minha carreira só tem sentido quando posso contribuir de forma significativa para a sociedade ou para causas que considero importantes.

**7. (PD)** Sinto que sou bem-sucedido na carreira somente quando enfrento e supero desafios muito difíceis, que exigem o máximo de mim.

**8. (EV)** Prefiro buscar um equilíbrio entre minha vida profissional e minha vida pessoal a me dedicar inteiramente ao trabalho, mesmo que isso implique abrir mão de oportunidades.

---

## Bloco 2 — Perguntas 9 a 16

**9. (TF)** Prefiro ser reconhecido pela minha competência e profundidade de conhecimento em uma área específica do que por cargos de gestão ou liderança ampla.

**10. (GG)** Tenho um forte desejo de chegar a posições de alta liderança com autonomia para tomar decisões estratégicas e influenciar os rumos da organização.

**11. (AI)** A pior coisa que pode acontecer à minha carreira é depender de outras pessoas ou de políticas organizacionais para decidir como vou trabalhar.

**12. (SE)** Valorizo mais uma carreira que ofereça segurança e previsibilidade do que uma que prometa grandes recompensas, porém com maior risco.

**13. (CE)** Tenho a necessidade de colocar em prática minhas próprias ideias, mesmo que isso signifique abrir mão de estabilidade ou de um salário garantido.

**14. (SD)** Prefiro trabalhar em organizações cujos valores e propósitos estejam alinhados com os meus, mesmo que isso signifique receber menos do que poderia em outro lugar.

**15. (PD)** Me entedio rapidamente quando não há problemas novos e complexos para resolver; preciso de desafios constantes para me manter motivado.

**16. (EV)** Não sacrificaria meu estilo de vida, minha família ou minha saúde em favor de uma promoção ou oportunidade profissional.

---

## Bloco 3 — Perguntas 17 a 24

**17. (TF)** Me orgulha ser reconhecido como especialista na minha área — isso é mais importante para mim do que ter poder formal ou visibilidade executiva.

**18. (GG)** Me sinto realizado quando sou responsável por um negócio, área ou operação completa — onde meu desempenho é medido pelos resultados do todo.

**19. (AI)** Prefiro trabalhar de forma autônoma, definindo meus próprios prazos e métodos, mesmo em contextos corporativos com estrutura formal.

**20. (SE)** Escolheria trabalhar em uma organização conhecida pela solidez e pela segurança que oferece aos seus funcionários, mesmo que as perspectivas de crescimento rápido fossem menores.

**21. (CE)** Identificar e explorar novas oportunidades de negócio me energiza de forma que poucos outros tipos de trabalho conseguem.

**22. (SD)** Para mim, o sucesso profissional está diretamente ligado ao impacto positivo que gero na vida das pessoas ao meu redor ou na sociedade em geral.

**23. (PD)** Sinto que me realizo profissionalmente quando consigo resolver problemas que pareciam insolúveis ou vencer situações de alta competitividade.

**24. (EV)** Busco situações de trabalho que me permitam integrar minhas necessidades pessoais, familiares e profissionais de forma harmoniosa.

---

## Bloco 4 — Perguntas 25 a 32

**25. (TF)** Prefiro ser um especialista de excelência em minha área do que um generalista que precisa abrir mão de profundidade para lidar com responsabilidades administrativas.

**26. (GG)** Fui atraído para posições de liderança porque quero ter poder e responsabilidade para transformar organizações inteiras ou unidades de negócio.

**27. (AI)** Sinto uma necessidade muito forte de executar meu trabalho do meu próprio jeito — sem supervisão excessiva ou processos rígidos que limitem minha liberdade de ação.

**28. (SE)** Sinto que me realizaria plenamente em uma carreira que me permitisse permanecer em uma mesma organização por muito tempo, construindo vínculos sólidos e progressão estável.

**29. (CE)** Sinto uma inquietação constante para criar, construir e fazer algo novo que vá além do que já existe — não consigo me contentar apenas em operar o que outros criaram.

**30. (SD)** Quero usar minhas habilidades e talentos para fazer do mundo um lugar melhor — e não abro mão disso ao tomar decisões de carreira.

**31. (PD)** Me motiva a ideia de enfrentar situações extremamente desafiadoras e provar para mim mesmo que sou capaz de superá-las.

**32. (EV)** Para mim, uma carreira bem-sucedida é aquela que se encaixa na vida que quero levar — e não uma vida adaptada às exigências da carreira.

---

## Bloco 5 — Perguntas 33 a 40

**33. (TF)** Minha maior satisfação profissional vem do desenvolvimento contínuo das minhas habilidades e do aprofundamento do meu domínio técnico ou funcional.

**34. (GG)** Só me sinto verdadeiramente realizado quando assumo responsabilidades que combinam gestão de pessoas, estratégia de negócio e resultados financeiros sob minha liderança.

**35. (AI)** Aceito salários menores ou menos status em troca da liberdade de trabalhar da forma que considero certa, no ritmo que julgo adequado.

**36. (SE)** Prefiro ter menos liberdade de decisão se isso me garantir maior segurança profissional e pessoal no longo prazo.

**37. (CE)** Tenho um forte impulso de criar produtos, serviços ou empresas novas — e ver essas criações prosperarem é o que me dá mais satisfação profissional.

**38. (SD)** Ficaria profundamente insatisfeito se meu trabalho não contribuísse de alguma forma para o bem-estar das pessoas ou para uma causa que considero relevante.

**39. (PD)** A ideia de trabalhar em situações de alta pressão, onde os riscos são grandes e a margem de erro é pequena, me atrai em vez de me assustar.

**40. (EV)** Recusaria uma promoção ou oportunidade de carreira que exigisse comprometer significativamente meu estilo de vida, minha saúde ou minhas relações pessoais.

---

## Resumo do Mapeamento

| Âncora | Qs |
|--------|----|
| TF | 1,9,17,25,33 |
| GG | 2,10,18,26,34 |
| AI | 3,11,19,27,35 |
| SE | 4,12,20,28,36 |
| CE | 5,13,21,29,37 |
| SD | 6,14,22,30,38 |
| PD | 7,15,23,31,39 |
| EV | 8,16,24,32,40 |