---
name: Cortes Virais
description: Transforma entrevistas/podcasts do YouTube em 5-7 cortes verticais (9:16) de 60-90s prontos para Reels, Shorts e TikTok — com hook teaser e legendas dinâmicas
icon: "🎬"
---

# Cortes Virais — Reels & Shorts de Alto Engajamento

Transforma uma entrevista/podcast longo do YouTube em **5-7 cortes verticais (9:16) de 60-90 segundos**, com **hook teaser** nos primeiros 3s e **legendas dinâmicas** palavra-por-palavra com destaque amarelo.

## When to Use

- User says `/cortes-virais` or asks to create vertical cuts from a YouTube video
- User wants to create Reels, Shorts, or TikToks from a long interview/podcast
- User provides a YouTube URL and wants viral clips extracted

---

## Sub-Agent Strategy

This workflow processes large media files and runs multi-step pipelines. **Use Task sub-agents aggressively** to optimize cost, speed, and context management.

### Why Sub-Agents Matter Here

| Problem | Without sub-agents | With sub-agents |
|---------|--------------------|-----------------|
| Transcript analysis (5000+ words) | Floods main context, expensive Opus tokens | Sonnet agent reads transcript, returns only cut definitions |
| Visual frame analysis (6 cuts x 5-8 frames) | 30-48 analyze_image calls clogging main thread | Parallel agents per cut, main context receives only crop_profile.json |
| ffmpeg processing (6 cuts) | Sequential, slow, errors pollute context | Parallel bash agents, main gets only success/fail + file paths |
| QC frame validation | 12-18 image analysis calls in main | Batch in sub-agent, main gets pass/fail summary |

### Model Selection Guide

| Task | Model | Reason |
|------|-------|--------|
| Orchestration | Opus | Complex decisions, multi-step coordination |
| Transcript analysis | Sonnet | Large context, structured output |
| Frame analysis | Sonnet | Vision tasks, parallel |
| ffmpeg scripts | Haiku | Simple bash execution |

---

## Prerequisites

```bash
# macOS
brew install yt-dlp ffmpeg whisper-cpp

# Download whisper medium model (~1.5GB)
mkdir -p ~/.local/share/whisper-models
curl -L https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-medium.bin \
  -o ~/.local/share/whisper-models/ggml-medium.bin
```

---

## Workflow Steps

### Step 0 — Setup Working Directory

```bash
OUTPUT_DIR="/tmp/cortes-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$OUTPUT_DIR"
WORKFLOW_DIR="$HOME/.g4os/workspaces/my-workspace/workflows/cortes-virais"
```

---

### Step 1 — Rough Transcript (for cut selection)

**Preferred method — Google AI summarize_url:**
```
Use Google AI to get a full transcript of: {YOUTUBE_URL}
Return: timestamped text, format "HH:MM:SS text..."
```

**Fallback — Apify YouTube captions:**
```
Use Apify YouTube Transcript scraper on: {YOUTUBE_URL}
```

**Fallback — Whisper base (if video already downloaded):**
```bash
whisper-cli -m ~/.local/share/whisper-models/ggml-base.bin \
  -l pt -otxt -f "$OUTPUT_DIR/audio.wav"
```

> ⚠️ **Do NOT put the full transcript in main context.** Pass it to a Sonnet sub-agent for analysis.

---

### Step 2 — Cut Selection (Sonnet Sub-Agent)

Spawn a **Sonnet sub-agent** with the transcript. Prompt:

```
You are a viral content strategist. Analyze this transcript and select 4-7 segments for vertical video cuts.

For each cut return JSON:
{
  "name": "corte1_tema-em-ingles",
  "hook_start": 1726.07,
  "hook_end": 1729.11,
  "body_start": 1694.20,
  "body_end": 1783.40,
  "hook_preview": "exact hook text",
  "body_preview": "first 2 sentences of body",
  "retention_3s": 8,
  "like_ratio": 7,
  "share_ratio": 8,
  "total_score": 23,
  "hook_archetype": "contradição|claim-audaciosa|número-chocante|confronto-direto|vulnerabilidade|violação-de-status|pensamento-cortado",
  "why": "brief rationale"
}

Selection criteria (from playbook-reference.md):
- Hook must create an open loop — question viewer can't answer without watching
- Hook is a DIFFERENT moment from the body start (the "money shot" pulled forward)
- Body has complete narrative arc in 57-88s
- Score ≥ 20/30 (retention_3s ≥ 7 mandatory)
- 4 great cuts > 7 mediocre cuts

Return ONLY a JSON array, no markdown.
```

**Main agent receives:** JSON array of cut definitions only.

---

### Step 3 — Present Cut Selection to User

Show a summary table:

| # | Name | Hook Preview | Score | Archetype |
|---|------|-------------|-------|-----------|
| 1 | corte1_... | "hook text" | 23/30 | contradição |

Ask: "Approve all cuts, or remove/adjust any?"

---

### Step 4 — Download Segments

After user approval, download only the needed video segments (not the full video):

```bash
# Save cuts JSON to file
echo '[{...cuts array...}]' > "$OUTPUT_DIR/cuts.json"

# Download only needed segments with 60s buffer
bash "$WORKFLOW_DIR/scripts/download_segments.sh" \
  "{YOUTUBE_URL}" \
  "$OUTPUT_DIR" \
  "$OUTPUT_DIR/cuts.json" \
  60
```

Output: `$OUTPUT_DIR/segments/{name}.mp4` + `offset_map.json`

> **Fallback (full download):** Only if download_segments.sh fails:
> ```bash
> bash "$WORKFLOW_DIR/scripts/download.sh" "{YOUTUBE_URL}" "$OUTPUT_DIR"
> ```

---

### Step 5 — Frame Extraction for Crop Analysis

For each cut, extract 1 frame per 5 seconds from the body segment:

```bash
# Adjust timestamps using offset_map
DOWNLOAD_START=$(jq -r '.corte1_tema.download_start' "$OUTPUT_DIR/segments/offset_map.json")
BODY_START_REL=$(echo "$BODY_START - $DOWNLOAD_START" | bc)
BODY_END_REL=$(echo "$BODY_END - $DOWNLOAD_START" | bc)

mkdir -p "$OUTPUT_DIR/frames/corte1_tema"
ffmpeg -y -ss "$BODY_START_REL" -to "$BODY_END_REL" \
  -i "$OUTPUT_DIR/segments/corte1_tema.mp4" \
  -vf "fps=0.2" \
  "$OUTPUT_DIR/frames/corte1_tema/frame_%04d.jpg" 2>/dev/null
```

---

### Step 6 — Crop Profile Analysis (Parallel Sonnet Sub-Agents)

Spawn **one sub-agent per cut** (parallel). Each agent:

1. Receives: frame images for that cut
2. Runs two-pass scene detection (see playbook-reference.md)
3. Returns: `crop_profile.json` fragment for that cut

Merge all responses into `$OUTPUT_DIR/crop_profile.json`:

```json
{
  "video_resolution": "1920x1080",
  "analysis_method": "two_pass_scene_detection",
  "subtitle_margin_v": 280,
  "user_validated": false,
  "cuts": {
    "corte1_tema": {
      "hook_crop": "crop=607:1080:269:0",
      "has_camera_switch": false,
      "crop_confidence": "high",
      "scenes": [{"from_sec": 0, "to_sec": 70, "crop": "crop=607:1080:269:0", "scene_type": "wide_two"}]
    }
  }
}
```

---

### Step 7 — Crop Preview Rendering + User Validation

For each cut, render a 1080x1920 preview frame:

```bash
CROP_FILTER=$(jq -r '.cuts.corte1_tema.scenes[0].crop' "$OUTPUT_DIR/crop_profile.json")
ffmpeg -y -i "$OUTPUT_DIR/frames/corte1_tema/frame_0001.jpg" \
  -vf "${CROP_FILTER},scale=1080:1920" \
  "$OUTPUT_DIR/previews/corte1_tema_preview.jpg" 2>/dev/null
```

**Show all previews to user.** Ask: "Approve crops, or adjust any? (e.g., 'corte2 shift left 10%')"

After approval, set `user_validated: true` in crop_profile.json.

---

### Step 8 — Transcription (Whisper Medium, Per Segment)

For each cut, transcribe body and hook:

```bash
# Read offset_map to get segment file and download_start
SEGMENT_FILE=$(jq -r ".${NAME}.file" "$OUTPUT_DIR/segments/offset_map.json")
DOWNLOAD_START=$(jq -r ".${NAME}.download_start" "$OUTPUT_DIR/segments/offset_map.json")

# Adjust timestamps to segment-relative
BODY_START_REL=$(echo "$BODY_START - $DOWNLOAD_START" | bc)
BODY_END_REL=$(echo "$BODY_END - $DOWNLOAD_START" | bc)
HOOK_START_REL=$(echo "$HOOK_START - $DOWNLOAD_START" | bc)
HOOK_END_REL=$(echo "$HOOK_END - $DOWNLOAD_START" | bc)

bash "$WORKFLOW_DIR/scripts/transcribe_segment.sh" \
  "$OUTPUT_DIR/transcriptions" \
  "$NAME" \
  "$BODY_START_REL" "$BODY_END_REL" \
  "$OUTPUT_DIR/segments/$SEGMENT_FILE" \
  "$HOOK_START_REL" "$HOOK_END_REL"
```

Output: `{name}_body_words.json` and `{name}_hook_words.json` (word-level timestamps)

> ⚠️ Run per-cut to avoid flooding context. Parallel for all cuts.

---

### Step 9 — Transcript Review (Mandatory Checkpoint)

Present ALL transcripts to the user BEFORE generating ASS files:

```
CORTE 1 — corte1_tema
Hook (3s): "FRASE DO HOOK AQUI"
Body: "PRIMEIRA FRASE DO CORPO... SEGUNDA FRASE..."
[⚠️ Flags: CEO, G4, startup]

CORTE 2 — corte2_tema
...
```

Ask: "Any corrections? (e.g., 'corte1 hook: troca seou por CEO')"

Apply corrections by editing `_words.json` files.

---

### Step 10 — Process Cuts (Parallel)

Spawn **one sub-agent per cut** (parallel). Each agent runs `process_cut.sh`:

**Simple path (no camera switch):**
```bash
CROP_FILTER=$(jq -r ".cuts.${NAME}.scenes[0].crop" "$OUTPUT_DIR/crop_profile.json")
MARGIN_V=$(jq -r '.subtitle_margin_v' "$OUTPUT_DIR/crop_profile.json")

bash "$WORKFLOW_DIR/scripts/process_cut.sh" \
  "$OUTPUT_DIR" \
  "$NAME" \
  "$HOOK_START_REL" "$HOOK_END_REL" \
  "$BODY_START_REL" "$BODY_END_REL" \
  "$WORKFLOW_DIR" \
  "$OUTPUT_DIR/transcriptions/${NAME}_body_words.json" \
  "$CROP_FILTER" \
  "$MARGIN_V"
```

**Complex path (has_camera_switch = true):**
For cuts with multiple scenes, manually build the ffmpeg pipeline with per-scene crops, then concatenate all parts (hook + body_part0 + body_part1 + ...).

Output: `$OUTPUT_DIR/final/{name}_final.mp4`

---

### Step 11 — QC Review

Each sub-agent extracts 3 QC frames per cut (hook area, early body, mid body).

Spawn a **QC sub-agent** to review all frames. Check:
- [ ] Correct crop (subject centered, no important content cut off)
- [ ] Subtitles visible and correctly positioned
- [ ] No encoding artifacts
- [ ] Duration within 60-90s range

Present QC results to user. Flag any issues.

---

### Step 12 — Delivery

Show final output summary:

```
✅ Cortes prontos em: {OUTPUT_DIR}/final/

| Corte | Arquivo | Duração | Score |
|-------|---------|---------|-------|
| corte1_tema | corte1_tema_final.mp4 | 72s | 23/30 |
...
```

Present each file as a filecard for easy download.

---

## Quick Reference — Common ffmpeg Filters

```bash
# Vertical crop centered
crop=607:1080:656:0,scale=1080:1920

# Left speaker
crop=607:1080:269:0,scale=1080:1920

# Right speaker  
crop=607:1080:1043:0,scale=1080:1920

# Full process with subtitles
-vf "crop=607:1080:656:0,scale=1080:1920,ass=subtitle.ass"
-c:v libx264 -preset fast -crf 23 -pix_fmt yuv420p
-c:a aac -b:a 128k -ar 44100
```

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Google AI 500/524 on audio | Use whisper-cli (local) |
| Subtitles showing "se ou" | Use whisper medium model |
| Subtitles under Instagram UI | Set margin_v=280 |
| `mkdir /final` error | OUTPUT_DIR must be absolute path |
| SRT comma crash in parser | Use `offsets` field (milliseconds), not timestamps |
| Context collapse after transcript | Always process transcript in sub-agent |
| yt-dlp format error | Use `bestvideo[height<=1080]+bestaudio` |
