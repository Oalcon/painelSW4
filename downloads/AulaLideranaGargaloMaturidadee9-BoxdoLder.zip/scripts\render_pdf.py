#!/usr/bin/env python3
"""
Converte um arquivo HTML em PDF usando Chrome/Edge headless (sem dependencias externas).

Uso:
    python render_pdf.py <caminho_html> <caminho_pdf_saida>

Procura o navegador em caminhos padrao do Windows (Chrome ou Edge). Se nenhum
for encontrado, levanta erro explicando o problema para o agente reportar ao usuario.
"""
import subprocess
import sys
import pathlib

BROWSER_PATHS = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
]


def find_browser():
    for p in BROWSER_PATHS:
        if pathlib.Path(p).exists():
            return p
    return None


def html_to_pdf(html_path: str, pdf_path: str) -> str:
    browser = find_browser()
    if not browser:
        raise RuntimeError(
            "Nenhum Chrome ou Edge encontrado nos caminhos padrao do Windows. "
            "Nao foi possivel gerar o PDF automaticamente."
        )
    html_uri = pathlib.Path(html_path).resolve().as_uri()
    pdf_abs = str(pathlib.Path(pdf_path).resolve())
    cmd = [
        browser,
        "--headless",
        "--disable-gpu",
        "--no-sandbox",
        f"--print-to-pdf={pdf_abs}",
        html_uri,
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if not pathlib.Path(pdf_abs).exists():
        raise RuntimeError(
            f"Falha ao gerar PDF. stdout: {result.stdout} stderr: {result.stderr}"
        )
    return pdf_abs


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Uso: python render_pdf.py <html_path> <pdf_path>")
        sys.exit(1)
    out = html_to_pdf(sys.argv[1], sys.argv[2])
    print(f"PDF gerado: {out}")
