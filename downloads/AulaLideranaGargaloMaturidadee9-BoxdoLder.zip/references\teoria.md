# Teoria — Liderança de Alta Performance e Governança de Gente

Base: aula "Liderança de Alta Performance e Governança de Gente" — Paula Pimenta (PVP Leadership, mentora G4).

## O ciclo do crescimento empresarial

1. **Empresário faz tudo**
2. **Empresário gerencia tudo**
3. **Empresário lidera gestores**
4. **Empresário governa a empresa**

O founder deixa de ser "fazedor" e passa a ser "orquestrador": multiplica resultados delegando. A escala só acontece quando o CEO constrói outros líderes que carregam os valores e a visão da empresa.

**3 sintomas da estagnação:**
1. Decisões centralizadas
2. Falta de líderes estratégicos
3. Processos desestruturados

Referências citadas na aula: Verne Harnish (*Scaling Up*), Jim Collins (*Good to Great* — líderes "Nível 5"), Patrick Lencioni (*The Advantage*).

## O tripé da alta performance

Alta performance = capacidade de alcançar resultados superiores de forma consistente, sustentável e equilibrada.

- **Autoliderança** — lidero a mim mesmo
- **Liderança** — lidero o outro
- **Gestão** — lidero o negócio

## Liderança é transformar estratégia em rotina

Liderança não é cargo, é influência: influenciar pessoas para transformar um propósito em resultados, por meio do exemplo, da clareza e da execução.

- **Criar direção** — clareza sobre onde a equipe precisa chegar, prioridades e o "porquê"
- **Mobilizar pessoas** — engajar em torno de um propósito comum
- **Fazer acontecer** — execução; estratégia sem execução é apenas intenção

## Os 5 níveis de maturidade de um líder

| Nível | Nome | Descrição |
|---|---|---|
| 1 | Opera | Executa — faz bem o próprio trabalho |
| 2 | Analista | Influencia — ajuda colegas, compartilha conhecimento |
| 3 | Coordenador | Coordena — organiza atividades, acompanha entregas |
| 4 | Gerente | Desenvolve pessoas — ensina, dá feedback, forma sucessores |
| 5 | Diretor/CEO | Multiplica líderes — forma outros líderes, cria autonomia, constrói cultura |

## Os 5 pilares / competências do líder

| Pilar | O que envolve |
|---|---|
| **Clareza** | Metas, prioridades, decisão |
| **Comunicação** | Expectativas claras, alinhamento, transparência |
| **Coragem** | Feedback, conflito, decisões difíceis |
| **Desenvolvimento** | Formar sucessores, ensinar, acompanhar |
| **Responsabilidade** | Dono do resultado, dono do problema, dono da solução |

Cada competência é avaliada em 3 níveis: **Abaixo do esperado**, **Esperado**, **Acima do esperado**.

> "Ninguém nasce líder. Líderes são desenvolvidos através de experiência, acompanhamento e prática."
> "O time é reflexo do líder": diagnosticar → desenvolver → acompanhar/dar feedback → evoluir/aumentar autonomia.

## Governança de gente, cultura e performance

Cinco frentes que sustentam o crescimento sem depender do founder: **Performance, Desenvolvimento, Engajamento, Rituais, Estrutura**.

### Gestão de performance

Garantir que cada pessoa tenha metas claras, indicadores definidos e acompanhamento constante. Desdobramento: Meta da empresa → Meta das áreas → Meta das equipes → Meta individual.

**Ciclo de performance:** Planejar → Executar → Medir (KPIs, rituais) → Aprender (feedback) → Ajustar (alinhar expectativas, plano de desenvolvimento e carreira).

### Como estruturar um feedback

1. Agende antecipadamente a reunião de feedback
2. Se prepare para o feedback
3. Prepare o ambiente
4. Seja prático
5. Plano de desenvolvimento

### Matriz 9-Box (Desempenho x Comportamento)

Cruza **Desempenho** (resultado / o quê) com **Comportamento** (atitude / como) em 3 níveis cada (Abaixo / Dentro / Acima da expectativa), gerando 9 quadrantes com uma recomendação de ação cada:

| Comportamento →<br>Desempenho ↓ | Abaixo da expectativa | Dentro da expectativa | Acima da expectativa |
|---|---|---|---|
| **Acima da expectativa** | Aprimorar comportamento | Quase lá / evoluindo | **Destaques** |
| **Dentro da expectativa** | Desenvolver comportamento | Mantém consistência | Aprimorar técnica |
| **Abaixo da expectativa** | **Insuficiente** | Desenvolver técnica | Verificar situação |

> Nota de fidelidade: a grade acima é uma reconstrução best-effort a partir do material da aula (a extração de texto do slide original embaralhou a ordem das 9 células). Ao usar em aula, confirme o mapeamento exato de cada quadrante com o slide/material oficial de Paula Pimenta antes de tratá-lo como definitivo. O que é estável e pode ser usado com confiança: os dois eixos (Desempenho x Comportamento), os 3 níveis por eixo, e a lógica de que canto inferior-esquerdo = zona de risco ("insuficiente") e canto superior-direito = "destaques".

### Ciclo de aprendizagem (William Glasser)

1. Incompetência inconsciente — "não sabe que não sabe"
2. Incompetência consciente — "sabe que não sabe"
3. Competência consciente — "sabe que sabe"
4. Competência inconsciente — "não sabe que sabe"

### Desenvolvimento de líderes — método 70/20/10

- **70%** — Experiência prática
- **20%** — Mentoria e feedback
- **10%** — Treinamento formal

**5 passos de desenvolvimento:**
1. Clareza de metas e comportamentos esperados e acordados
2. Delegação progressiva
3. Reunião quinzenal de desenvolvimento
4. Feedback contínuo
5. Plano de Desenvolvimento Individual (PDI)

### Engajamento

Ambiente de confiança, pertencimento e reconhecimento. Fonte: *How Leaders Build Trust* (Harvard Business Publishing) — equipes com mais confiança apresentam: -74% estresse, +50% produtividade, +106% energia no trabalho, -13% dias de doença, +76% engajamento, +29% satisfação com a vida, -40% burnout.

**eNPS (Employee Net Promoter Score):** "De 0 a 10, o quanto você recomendaria esta empresa como um bom lugar para trabalhar?"
- Promotores: 9–10 | Neutros: 7–8 (fora do cálculo) | Detratores: 0–6
- **eNPS = % Promotores − % Detratores**

Também referenciados: Modelo Gallup de Engajamento e Pirâmide de Maslow (básico → segurança → social → estima → autorrealização), mapeados a: clareza de metas, mensuração de resultados, alinhamento cultural, performance/recompensa, crescimento/carreira.

### Rituais

Pirâmide de rituais para sair do "apagar incêndios":
1. **Semanais** — ex.: daily check-in
2. **Mensais** — ex.: pulse survey + feedback coletivo
3. **Trimestrais** — ex.: OKR review + planejamento estratégico

Tipos: rituais de alinhamento (check-ins, reuniões rápidas), rituais de cultura (políticas de incentivo/reconhecimento), rituais de feedback (1:1, feedforward).

### Estrutura de liderança estratégica

Camadas: CEO/C-Level → Líderes de área → Time. Objetivo: definir papéis, responsabilidades e governança para reduzir zonas cinzentas e aumentar autonomia.

- Revise responsabilidades da equipe; use Matriz RACI ou OKRs para clareza de papéis
- Avalie o estágio de maturidade da empresa e reestruture times conforme a complexidade do momento
- Reforce rituais e símbolos de cultura; crie canais de comunicação claros

**Plano de ação = Meta (onde quero chegar) + Diagnóstico (onde o time está) → estabelecer processos e metas.**

## Takeaways da aula (usar no plano de ação final)

1. Refaça o exercício "Você é o gargalo?" pedindo que o líder responda sobre si mesmo, e compare com a percepção do membro.
2. Posicione esse líder no nível de maturidade atual e defina uma ação concreta para levá-lo ao próximo nível.
3. Agende um 1:1 de desenvolvimento essa semana com pauta de feedback, expectativas e PDI.
4. Meça o eNPS do time este mês — uma pergunta, 10 minutos, um dado real sobre engajamento antes de decisões de estrutura.
