# Verification: Output Verification Process

Some native design-agent environments (e.g., Claude.ai Artifacts) have a built-in `fork_verifier_agent` that spins up a subagent to take iframe screenshots for inspection. Most agent environments (Claude Code / Codex / Cursor / Trae / etc.) don't have this built-in capability — Playwright covers the same verification scenarios manually.

## Verification Checklist

After producing any HTML output, run through this checklist:

### 1. Browser Render Check (Required)

The most basic check: **can the HTML file be opened?** On macOS:

```bash
open -a "Google Chrome" "/path/to/your/design.html"
```

Or use a Playwright screenshot (see next section).

### 2. Console Error Check

The most common issue with HTML files is a JS error causing a blank screen. Run a Playwright pass:

```bash
python ~/.claude/skills/claude-design/scripts/verify.py path/to/design.html
```

This script will:
1. Open the HTML in headless Chromium
2. Save a screenshot to the project directory
3. Capture console errors
4. Report status

See `scripts/verify.py` for details.

### 3. Multi-Viewport Check

For responsive designs, capture multiple viewports:

```bash
python verify.py design.html --viewports 1920x1080,1440x900,768x1024,375x667
```

### 4. Interaction Check

Tweaks, animations, button toggles — these won't show up in static screenshots. **Recommend having the user open it in their browser and click around**, or record with Playwright:

```python
page.video.record('interaction.mp4')
```

### 5. Slide-by-Slide Check

For slide deck HTML, capture each slide:

```bash
python verify.py deck.html --slides 10  # capture first 10 slides
```

Generates `deck-slide-01.png`, `deck-slide-02.png`, etc. for quick review.

## Playwright Setup

First-time setup:

```bash
# If not installed yet
npm install -g playwright
npx playwright install chromium

# Or the Python version
pip install playwright
playwright install chromium
```

If the user already has Playwright installed globally, just use it directly.

## Screenshot Best Practices

### Full-page screenshot

```python
page.screenshot(path='full.png', full_page=True)
```

### Viewport screenshot

```python
page.screenshot(path='viewport.png')  # captures visible area by default
```

### Element screenshot

```python
element = page.query_selector('.hero-section')
element.screenshot(path='hero.png')
```

### High-DPI screenshot

```python
page = browser.new_page(device_scale_factor=2)  # retina
```

### Wait for animations to settle before capturing

```python
page.wait_for_timeout(2000)  # wait 2 seconds for animations to settle
page.screenshot(...)
```

## Sharing Screenshots with the User

### Open local screenshot directly

```bash
open screenshot.png
```

The user will view it in their Preview / Figma / VSCode / browser.

### Upload to an image host to share a link

If remote collaborators need to see it (e.g., via Slack / Lark / WeChat), have the user use their own image hosting tool or MCP to upload:

```bash
python ~/Documents/writing/tools/upload_image.py screenshot.png
```

Returns a permanent ImgBB link that can be pasted anywhere.

## When Verification Fails

### Blank white page

There will be a console error. Check:

1. Whether the React + Babel script tag integrity hashes are correct (see `react-setup.md`)
2. Whether there's a `const styles = {...}` naming conflict
3. Whether cross-file components are exported to `window`
4. JSX syntax errors (babel.min.js may not surface these; swap in the unminified babel.js)

### Animation is choppy

- Record a segment using Chrome DevTools Performance tab
- Look for layout thrashing (frequent reflows)
- Prioritize `transform` and `opacity` for animations (GPU-accelerated)

### Wrong fonts

- Check whether the `@font-face` URL is accessible
- Check fallback fonts
- CJK fonts load slowly: show fallback first, switch when loaded

### Layout misalignment

- Check that `box-sizing: border-box` is applied globally
- Check `* { margin: 0; padding: 0; }` reset
- Open Chrome DevTools and enable gridlines to inspect the actual layout

## Verification = Your Second Set of Eyes

**Always do your own pass through the output.** AI-written code frequently produces:

- Code that looks right but has interaction bugs
- Static screenshots that look fine but break on scroll
- Layouts that look great at wide viewport but collapse at narrow
- Dark mode never tested
- Tweaks that don't trigger a response in some components after toggling

**1 minute of verification can save 1 hour of rework.**

## Common Verification Script Commands

```bash
# Basic: open + screenshot + capture errors
python verify.py design.html

# Multiple viewports
python verify.py design.html --viewports 1920x1080,375x667

# Multiple slides
python verify.py deck.html --slides 10

# Output to specific directory
python verify.py design.html --output ./screenshots/

# headless=false, opens a real browser for you to see
python verify.py design.html --show
```
