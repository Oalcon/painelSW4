---
name: "Baixar Vídeo do YouTube, TikTok e Reels"
description: "Baixa vídeos do YouTube, TikTok, Instagram Reels e outros sites suportados pelo yt-dlp, salvando em pasta do computador na melhor qualidade possível em H.264 (compatível com Premiere Pro). Use sempre que o usuário colar um link do YouTube, TikTok, Instagram ou pedir para baixar, salvar ou extrair áudio de um vídeo — mesmo que não mencione 'skill' ou 'yt-dlp'."
alwaysAllow: ["Bash", "Read", "Write"]
---

# Baixar Vídeo do YouTube, TikTok e Reels

Baixa vídeos, áudios e Reels de YouTube, TikTok, Instagram e outros sites suportados pelo `yt-dlp`, **sempre na melhor qualidade disponível**.

## Fluxo de Trabalho

### 1. Verificar e instalar dependências automaticamente

**SEMPRE executar antes do primeiro download da sessão.**

```bash
echo "=== Verificando dependências ==="

PYTHON_OK=false
if command -v python3 &>/dev/null || command -v python &>/dev/null; then
  PYTHON_OK=true; echo "✓ Python OK"
else
  echo "✗ Python não encontrado"
fi

YTDLP_OK=false
if command -v yt-dlp &>/dev/null; then
  YTDLP_OK=true; echo "✓ yt-dlp OK ($(yt-dlp --version))"
else
  echo "✗ yt-dlp não encontrado"
fi

FFMPEG_WIN=$(powershell -NoProfile -Command \
  "\$r = Get-Command ffmpeg -ErrorAction SilentlyContinue; if (\$r) { \$r.Source }" 2>/dev/null | tr -d '\r')
if [ -z "$FFMPEG_WIN" ]; then
  FFMPEG_WIN=$(powershell -NoProfile -Command \
    "Get-ChildItem -Path 'C:\\Users' -Recurse -Filter 'ffmpeg.exe' -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName" 2>/dev/null | tr -d '\r')
fi
FFMPEG_OK=false
if [ -n "$FFMPEG_WIN" ]; then
  FFMPEG_OK=true; echo "✓ ffmpeg OK"
else
  echo "✗ ffmpeg não encontrado"
fi
```

Se **qualquer dependência estiver faltando**, perguntar ao usuário:

> "É a primeira vez que você usa esta skill. Encontrei dependências faltando: [lista]. Posso instalar tudo automaticamente agora? Basta confirmar com **'sim'**."

Após confirmação, executar:

```bash
# Instalar Python (se necessário)
if [ "$PYTHON_OK" = false ]; then
  echo "Instalando Python..."
  powershell -NoProfile -Command \
    "winget install --id Python.Python.3.12 -e --source winget --accept-source-agreements --accept-package-agreements"
fi

# Instalar yt-dlp (se necessário)
if [ "$YTDLP_OK" = false ]; then
  echo "Instalando yt-dlp..."
  pip install yt-dlp
fi

# Instalar ffmpeg (se necessário)
if [ "$FFMPEG_OK" = false ]; then
  echo "Instalando ffmpeg..."
  powershell -NoProfile -Command \
    "winget install --id Gyan.FFmpeg -e --source winget --accept-source-agreements --accept-package-agreements"
  FFMPEG_WIN=$(powershell -NoProfile -Command \
    "\$r = Get-Command ffmpeg -ErrorAction SilentlyContinue; if (\$r) { \$r.Source }" 2>/dev/null | tr -d '\r')
  if [ -z "$FFMPEG_WIN" ]; then
    FFMPEG_WIN=$(powershell -NoProfile -Command \
      "Get-ChildItem -Path 'C:\\Users' -Recurse -Filter 'ffmpeg.exe' -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName" 2>/dev/null | tr -d '\r')
  fi
fi

echo "✓ Instalação concluída! Prosseguindo com o download..."
```

> Se tudo já estiver instalado, pular direto para o download sem mencionar dependências.

### 2. Preparar variáveis de ambiente

```bash
OUT_DIR=$(powershell -NoProfile -Command \
  "[Environment]::GetFolderPath('UserProfile') + '\\Downloads'" 2>/dev/null \
  | tr -d '\r' | sed 's|\\\\|/|g')
OUT_DIR="${OUT_DIR:-$HOME/Downloads}"

COOKIES="$OUT_DIR/youtube_cookies.txt"

NODE_WIN=$(powershell -NoProfile -Command \
  "\$r = Get-Command node -ErrorAction SilentlyContinue; if (\$r) { \$r.Source }" 2>/dev/null | tr -d '\r')

FFPROBE_WIN=$(echo "$FFMPEG_WIN" | sed 's/ffmpeg\.exe/ffprobe.exe/')
```

### 3. Identificar plataforma

| Plataforma | Exemplos de URL |
|---|---|
| YouTube | `youtube.com/watch`, `youtu.be/`, `youtube.com/shorts/` |
| TikTok | `tiktok.com/@user/video/`, `vm.tiktok.com` |
| Instagram Reels | `instagram.com/reel/`, `instagram.com/p/` |

### 4. Executar o download — sempre na melhor qualidade

**Formato padrão (usar em TODOS os downloads):**

```bash
BEST_FORMAT="bestvideo[vcodec^=avc1][ext=mp4]+bestaudio[ext=m4a]/bestvideo[vcodec^=avc1]+bestaudio/bestvideo[ext=mp4]+bestaudio/bestvideo+bestaudio/best"

yt-dlp \
  --ffmpeg-location "$FFMPEG_WIN" \
  --cookies "$COOKIES" \
  --js-runtimes "node:$NODE_WIN" \
  -f "$BEST_FORMAT" \
  --merge-output-format mp4 \
  --output "$OUT_DIR/%(title)s.%(ext)s" \
  "<URL>"
```

#### TikTok
```bash
yt-dlp \
  --ffmpeg-location "$FFMPEG_WIN" \
  -f "bestvideo[ext=mp4]+bestaudio/bestvideo+bestaudio/best" \
  --merge-output-format mp4 \
  --output "$OUT_DIR/%(uploader)s - %(title)s.%(ext)s" \
  "<URL>"
```

#### Instagram Reels
```bash
yt-dlp \
  --ffmpeg-location "$FFMPEG_WIN" \
  --cookies "$COOKIES" \
  -f "bestvideo[ext=mp4]+bestaudio/bestvideo+bestaudio/best" \
  --merge-output-format mp4 \
  --output "$OUT_DIR/%(uploader)s - %(title)s.%(ext)s" \
  "<URL>"
```

> Para Instagram: exportar cookies com extensão "Get cookies.txt LOCALLY" no Chrome logado, salvar como `youtube_cookies.txt` na pasta Downloads.

#### Somente áudio
```bash
yt-dlp --ffmpeg-location "$FFMPEG_WIN" -x --audio-format mp3 \
  --output "$OUT_DIR/%(title)s.%(ext)s" "<URL>"
```

### 5. Verificar e confirmar resultado

```bash
"$FFPROBE_WIN" -v quiet -select_streams v:0 \
  -show_entries stream=codec_name,width,height -of csv=p=0 "<ARQUIVO>"
```

Informar: nome, codec+resolução (ex: `h264, 1920x1080`), tamanho, pasta destino. Usar `filecard`.

## Tratamento de erros

| Erro | Causa | Solução |
|---|---|---|
| Qualidade baixa (480p-) | ffmpeg não encontrado | Verificar se `$FFMPEG_WIN` não está vazio |
| Arquivos separados (.mp4 + .m4a) | ffmpeg path em formato Cygwin | Usar PowerShell para obter path Windows (`C:\...`) |
| `Sign in to confirm bot` | YouTube bloqueou | Exportar `youtube_cookies.txt` via extensão Chrome logado no YouTube |
| `Requested format not available` | H.264 indisponível | `BEST_FORMAT` já tem fallback automático |
| `Instagram API not granting access` | Sem cookies | Exportar cookies do Chrome logado no Instagram |

## Exemplos de Acionamento

- "Baixa esse vídeo do YouTube: https://youtu.be/xxx"
- "Salva esse Reel: https://www.instagram.com/reel/xxx"
- "Baixa esse TikTok: https://www.tiktok.com/@user/video/xxx"
- "Extrai o áudio desse vídeo"
- "Quero a melhor qualidade desse vídeo"
- "Baixa essa playlist inteira"
