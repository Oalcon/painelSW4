---
name: Report FLG
description: >
  Gera o one-pager executivo do lançamento Founder Led Growth (FLG) — visão compacta de uma página
  com KPIs do dia, acumulado, pace do evento e tempo de processamento em destaque.
  Use sempre que o usuário pedir "one-pager FLG", "report FLG onepage", "relatório resumido FLG",
  "one page Founder Led Growth" ou "/report-flg-onepage".
requiredSources:
  - databricks
---

# Report FLG One-Pager — Founder Led Growth

## Objetivo
Gerar um HTML one-pager executivo do evento FLG, atualizado com dados do Databricks, para compartilhamento rápido (PDF via Ctrl+P, email, Slack).

---

## PRÉ-FLIGHT

1. Chame `mcp__session__activate_sources` com `slugs: ["databricks"]`
2. Se falhar, informe o usuário e pare
3. Obtenha data/hora atual em BRT (use contexto da sessão)
4. Converta BRT → UTC: `hora_utc = hora_brt + 3h`
5. Defina:
   - `DIA_ATUAL` = data hoje BRT (ex: 2026-07-17)
   - `CORTE_UTC` = datetime atual UTC (ex: 2026-07-17 17:25:00)
   - `DIA_FMT` = formato DDMMYYYY para nome do arquivo (ex: 17072026)

---

## METAS FIXAS DO EVENTO (não consultar Databricks)

| Data  | Meta MQL | Meta Wons | Meta Receita |
|-------|----------|-----------|--------------|
| 15/07 | 252  | 16 | R$ 299.535   |
| 16/07 | 641  | 29 | R$ 551.688   |
| 17/07 | 229  | 9  | R$ 180.316   |
| 18/07 | 248  | 9  | R$ 163.698   |
| 19/07 | 141  | 5  | R$ 90.611    |
| 20/07 | 493  | 11 | R$ 196.744   |
| 21/07 | 388  | 12 | R$ 238.506   |
| 22/07 | 943  | 33 | R$ 638.399   |
| **Total** | **3.335** | **124** | **R$ 2.359.497** |

**Ticket médio:** R$ 19.028 · **Meta exclui:** `[ON] Selfcheckout`

---

## QUERIES — Genie Funil (`01f0515b0ca91762a1e2b952861887e1`)

Disparar em paralelo via `genie_start_conversation` → `genie_poll_until_complete` → `genie_get_query_result`.

### Q1 — MQL por dia (15/07 até hoje)
```sql
SELECT DATE(event_timestamp) AS dt, COUNT(DISTINCT deal_id) AS mql
FROM production.diamond.funil_comercial
WHERE event_type = 'realized' AND event = 'MQL'
  AND linha_de_receita_vigente = 'Founder Led Growth'
  AND DATE(event_timestamp) BETWEEN '2026-07-15' AND '{DIA_ATUAL}'
GROUP BY DATE(event_timestamp) ORDER BY dt
```
> Para o dia atual, adicionar: `AND event_timestamp < '{CORTE_UTC}'`

### Q2 — Wons e Receita por dia e canal
```sql
SELECT DATE(closed_at) AS dt,
  CASE WHEN pipeline_name ILIKE '%selfcheckout%' THEN 'Selfcheckout' ELSE 'Aquisição' END AS canal,
  COUNT(DISTINCT deal_id) AS wons, SUM(revenue_max) AS receita
FROM (
  SELECT deal_id, DATE(closed_at) AS closed_at, pipeline_name,
    MAX(revenue) AS revenue_max
  FROM production.diamond.funil_comercial
  WHERE event_type = 'realized' AND status_do_deal = 'Ganho'
    AND linha_de_receita_vigente = 'Founder Led Growth'
    AND DATE(closed_at) BETWEEN '2026-07-15' AND '{DIA_ATUAL}'
  GROUP BY deal_id, DATE(closed_at), pipeline_name
) t
GROUP BY dt, canal ORDER BY dt, canal
```

### Q3 — Opps por dia
```sql
SELECT DATE(event_timestamp) AS dt,
  COUNT(DISTINCT deal_id) AS opps
FROM production.diamond.funil_comercial
WHERE event_type = 'realized' AND event = 'Oportunidade'
  AND linha_de_receita_vigente = 'Founder Led Growth'
  AND DATE(event_timestamp) BETWEEN '2026-07-15' AND '{DIA_ATUAL}'
GROUP BY DATE(event_timestamp) ORDER BY dt
```

### Q4 — Tempo de processamento por origem (leads novos, dia atual)
```sql
SELECT a.origem_do_deal,
  ROUND(AVG(delta_horas),1) AS tempo_medio_horas,
  COUNT(*) AS deals_processados
FROM (
  SELECT a.deal_id, a.event_timestamp, a.origem_do_deal,
    TIMESTAMPDIFF(HOUR, a.event_timestamp, MIN(b.event_timestamp)) AS delta_horas
  FROM production.diamond.funil_comercial a
  JOIN production.diamond.funil_comercial b
    ON a.deal_id = b.deal_id AND b.event_timestamp > a.event_timestamp AND b.event_type = 'realized'
  JOIN production.silver.hubspot_deals hd ON a.deal_id = hd.deal_id
  WHERE a.event_type = 'realized' AND a.event = 'MQL'
    AND a.linha_de_receita_vigente = 'Founder Led Growth'
    AND DATE(a.event_timestamp) = '{DIA_ATUAL}'
    AND DATE(hd.created_at) = '{DIA_ATUAL}'
  GROUP BY a.deal_id, a.event_timestamp, a.origem_do_deal
) a
GROUP BY a.origem_do_deal ORDER BY tempo_medio_horas DESC
```

### Q5 — Em negociação ativa
```sql
SELECT COUNT(DISTINCT deal_id) AS em_negociacao_ativa
FROM production.diamond.funil_comercial
WHERE event_type = 'realized' AND event = 'Negociação'
  AND status_do_deal NOT IN ('Ganho','Perdido')
  AND linha_de_receita_vigente = 'Founder Led Growth'
```

---

## CRUZAMENTO COM METAS

Calcular após coletar dados:
- `atingimento_mql_dia = mql_realizado_hoje / meta_mql_hoje * 100`
- `pace_esperado = meta_mql_hoje * (hora_brt / 24)` — se realizado >= pace: "no pace ✅"
- `atingimento_wons_acum = wons_aquisicao_acum / soma_meta_wons_dias_passados * 100`
- `atingimento_receita_acum = receita_aquisicao_acum / soma_meta_receita_dias_passados * 100`
- `pace_evento_mql = mql_acumulado / 3335 * 100`
- `pace_evento_receita = receita_aquisicao_acum / 2359497 * 100`

---

## GERAÇÃO DO ARQUIVO HTML

**Caminho:** `${WORKSPACE_ROOT}/reports/flg-report-onepage-{DIA_FMT}.html`

> `WORKSPACE_ROOT` é o diretório de trabalho da sessão (ex: `C:\Users\<seu-usuario>\Documents\G4-Workspace`).

### Título do arquivo e header
```
🚀 FLG One-Pager — Founder Led Growth | {DD/MM/YYYY}
```

### Estrutura (uma página, sem scroll)

**1. Header** — título com "One-Pager" no nome, data, horário corte BRT, badge "parcial" se dia em andamento

**2. Card principal — duas linhas horizontais:**
- **Linha 1 — Hoje (DD/MM até HH:MM BRT):** grid 6 KPIs em linha:
  MQL (atingimento + pace) → ⏱️ Processamento (roxo) → Opps → Em Negociação → Wons Aquisição → Receita Aquisição
- **Linha 2 — Acumulado (15/07 a DD/07):** grid 6 KPIs em linha:
  MQL Total → Opps Total → Em Negociação → Wons Aquisição → Receita Aquisição → Ticket Médio

**3. Progress bars (dentro do card, em linha):**
- MQL evento, Wons Aquisição evento, Receita Aquisição evento

**4. Seção em 2 colunas:**
- **Tabela resumo por dia** (apenas dias com dados + dias futuros em cinza)
  - Colunas: Dia · Meta MQL · MQL · Ating. · Wons Aq. · Receita Aq.
- **2 alertas** (vermelho para receita crítica + azul para MQL)

**5. Footer compacto**

---

## PADRÃO VISUAL

```css
body { background: #f4f6f9; font-family: 'Segoe UI', Arial, sans-serif; padding: 16px; }
.header { background: linear-gradient(135deg, #1a1a2e 0%, #16213e 60%, #0f3460 100%); color: white; border-radius: 10px; padding: 14px 22px; }
.card { background: white; border-radius: 10px; padding: 12px 18px; box-shadow: 0 1px 4px rgba(0,0,0,0.07); }
/* KPI processamento: border-color #8b5cf6, background #f5f3ff, valor color #5b21b6 */
/* Badges: green=#d1fae5/#065f46, yellow=#fef3c7/#92400e, red=#fee2e2/#991b1b, blue=#dbeafe/#1e40af */
/* Progress: green=#10b981, yellow=#f59e0b, red=#ef4444 */
```

---

## REGRAS CRÍTICAS

1. **Meta = Aquisição** — Selfcheckout é informativo, nunca entra no atingimento
2. **Deduplicar receita** com `MAX(revenue) GROUP BY deal_id` em subquery
3. **Dia atual = parcial** — sinalizar "(parcial — corte HH:MM BRT)"
4. **KPI Processamento** sempre destacado em roxo com variação vs dia anterior
5. **Exibir filecard** após gerar o arquivo
6. **Resumir** em 2–3 linhas: MQL pace, wons, receita, processamento

---

## SAÍDA

1. Gerar `flg-report-onepage-{DDMMYYYY}.html` no diretório de reports
2. Exibir filecard no chat
3. Resumo de 2–3 linhas com destaques do dia
