# Slide Design System

## Dimensions

- **Width**: 1280px (fixed)
- **Height**: 720px (fixed)
- **Aspect ratio**: 16:9
- **Never use responsive/fluid layouts** — this is a presentation, not a website

## CDN Dependencies

### Fonts (always include)
```html
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
```

### Icons (include when icons are used)
```html
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
```

### Charts (include only when data visualization is needed)
```html
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.2.0"></script>
```

> **Inline preview**: Chat previews use `html-preview` with a sandbox that does **not** execute JavaScript. CSS and static HTML render, but Chart.js and JS-driven effects must be validated in the browser (`open index.html`). For shared-session rendering, include `html` fallback content when previewing local files.

## Base CSS Reset

Include in EVERY slide:

```css
* { margin: 0; padding: 0; box-sizing: border-box; }
body { margin: 0; padding: 0; overflow: hidden; background: #000; }
.slide-container {
    width: 1280px;
    height: 720px;
    font-family: 'Montserrat', sans-serif;
    color: #FFFFFF;
    position: relative;
    overflow: hidden;
}
```

## Color Palette — Dark Theme (Default)

| Token | Hex | RGB | Usage |
|-------|-----|-----|-------|
| `--bg-deep` | `#050B14` | 5, 11, 20 | Darkest areas, body background |
| `--bg-primary` | `#0A1626` | 10, 22, 38 | Main slide background |
| `--bg-secondary` | `#0B182B` | 11, 24, 43 | Gradient end, alternate bg |
| `--bg-card` | `rgba(255,255,255,0.02)` | — | Card backgrounds |
| `--bg-card-hover` | `rgba(255,255,255,0.05)` | — | Card hover / badge bg |
| `--accent` | `#2063AD` | 32, 99, 173 | Borders, highlights, primary bars |
| `--accent-light` | `#BCD6F6` | 188, 214, 246 | Subtitles, secondary text, labels |
| `--accent-glow` | `rgba(32,99,173,0.2)` | — | Highlighted badge bg, card tint |
| `--text-primary` | `#FFFFFF` | 255, 255, 255 | Headings, main text, strong |
| `--text-muted` | `#5A7CA0` | 90, 124, 160 | Footnotes, captions, timestamps |
| `--red` | `#FF5756` | 255, 87, 86 | Call-outs, warnings, accent bars, decline |
| `--red-light` | `#FF8A89` | 255, 138, 137 | Red gradient partner |
| `--green` | `#4CAF50` | 76, 175, 80 | Positive trends, growth, success |
| `--orange` | `#FF9800` | 255, 152, 0 | Caution, medium values, warning |
| `--gray` | `#607D8B` | 96, 125, 139 | Tertiary data, neutral elements |

### Background Gradients

**Radial (for title/cover slides):**
```css
background: radial-gradient(circle at 80% 20%, #1A3A5E 0%, #0A1626 60%, #050B14 100%);
```

**Linear (for content slides):**
```css
background: linear-gradient(135deg, #0A1626 0%, #0B182B 100%);
```

### Card/Border Styles

```css
/* Standard card */
background: rgba(255, 255, 255, 0.02);
border: 1px solid rgba(32, 99, 173, 0.2);
border-radius: 8px;

/* Subtle border line */
border-bottom: 1px solid rgba(255, 255, 255, 0.05);

/* Accent border (for headers) */
border-bottom: 1px solid #2063AD;
```

## Color Palette — Light Theme

| Token | Hex | Usage |
|-------|-----|-------|
| `--bg-primary` | `#FFFFFF` | Main slide background |
| `--bg-secondary` | `#F8FAFC` | Cards, sections |
| `--bg-accent` | `#EEF4FB` | Subtle highlight areas |
| `--accent` | `#2063AD` | Borders, highlights |
| `--text-primary` | `#1A1A2E` | Headings |
| `--text-secondary` | `#4A5568` | Body text |
| `--text-muted` | `#8896A6` | Labels, captions |
| `--border` | `#E2E8F0` | Card borders |

## Typography Scale

| Element | Size | Weight | Color | Line Height |
|---------|------|--------|-------|-------------|
| Cover H1 | 64-72px | 800 | `#FFFFFF` | 1.1 |
| Section Divider Title | 42px | 700 | `#FFFFFF` | 1.2 |
| Slide Title (H1) | 28-36px | 700 | `#FFFFFF` | 1.2 |
| Subtitle | 16-24px | 300-400 | `#BCD6F6` | 1.5 |
| Body Text | 16-18px | 400 | `#FFFFFF` | 1.5 |
| Labels | 12-14px | 600 | `#BCD6F6` | 1.4 |
| Captions/Footnotes | 12px | 400 | `#5A7CA0` | 1.4 |
| Big Stat Number | 48-72px | 700 | `#FFFFFF` | 1.0 |
| Badge Text | 14px | 600 | `#BCD6F6` | 1.0 |
| Card Title | 14px | 700 | `#FFFFFF` | 1.2 |

## Chart.js Theme Config

When using Chart.js, always apply these styles to match the dark theme:

```javascript
{
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
        legend: { display: false },
        datalabels: {
            color: '#FFFFFF',
            font: { family: 'Montserrat', size: 11, weight: 'bold' }
        }
    },
    scales: {
        y: {
            beginAtZero: true,
            grid: { color: 'rgba(255, 255, 255, 0.05)' },
            ticks: { color: '#BCD6F6', font: { family: 'Montserrat', size: 10 } }
        },
        x: {
            grid: { display: false },
            ticks: { color: '#FFFFFF', font: { family: 'Montserrat', size: 10, weight: '600' } }
        }
    }
}
```

Register datalabels plugin:
```javascript
Chart.register(ChartDataLabels);
```
