# Content Guidelines: Anti-AI Slop, Content Standards, and Scale Specs

The easiest traps to fall into in AI-assisted design. This is a "what NOT to do" list — more important than any "what to do" list — because AI slop is the default, and you have to actively avoid it or it will happen.

## AI Slop Complete Blacklist

### Visual Traps

**❌ Aggressive gradient backgrounds**
- Purple → pink → blue full-screen gradients (the signature of AI-generated web pages)
- Rainbow gradients in any direction
- Mesh gradients covering the entire background
- ✅ If you want to use gradients: subtle, monochromatic, and purposeful — e.g., a button hover state

**❌ Rounded cards + left border accent color**
```css
/* This is the signature of an AI-flavored card */
.card {
  border-radius: 12px;
  border-left: 4px solid #3b82f6;
  padding: 16px;
}
```
This card pattern is rampant in AI-generated dashboards. Want to create emphasis? Use more intentional approaches: background color contrast, font weight/size contrast, a plain divider line, or simply no card at all.

**❌ Emoji decoration**
Unless the brand itself uses emoji (e.g., Notion, Slack), don't put emoji in UI. **Especially avoid**:
- 🚀 ⚡️ ✨ 🎯 💡 in headings
- ✅ in feature lists
- → inside CTA buttons (a plain arrow character is fine; emoji arrows are not)

No icons? Use a real icon library (Lucide / Heroicons / Phosphor) or a placeholder.

**❌ SVG imagery**
Don't try to draw people, scenes, devices, objects, or abstract art in SVG. AI-drawn SVG imagery is instantly recognizable — it looks childish and cheap. **A gray rectangle with a text label "Illustration 1200×800" is 100× better than a clumsy SVG hero illustration.**

The only acceptable SVG uses:
- True icons (16×16 to 32×32 scale)
- Geometric shapes as decorative elements
- Charts in data visualization

**❌ Excessive iconography**
Not every heading / feature / section needs an icon. Overusing icons makes the interface look like a toy. Less is more.

**❌ "Data slop"**
Made-up stats as decoration:
- "10,000+ happy customers" (you have no idea if this is true)
- "99.9% uptime" (don't write it without real data)
- Decorative "metric cards" made of icon + number + phrase
- Mock tables full of fake data dressed up to look real

If there's no real data, use a placeholder or ask the user.

**❌ "Quote slop"**
Fabricated user testimonials or celebrity quotes used to decorate pages. Use placeholders and ask the user for real quotes.

### Typography Traps

**❌ Avoid these overused fonts**:
- Inter (the default for AI-generated web pages)
- Roboto
- Arial / Helvetica
- Pure system font stacks
- Fraunces (AI discovered it and overused it)
- Space Grotesk (currently AI's favorite)

**✅ Use distinctive display + body pairings.** Directions for inspiration:
- Serif display + sans-serif body (editorial feel)
- Mono display + sans body (technical feel)
- Heavy display + light body (contrast)
- Variable fonts for weight-animation in hero sections

Font resources:
- Lesser-known good options on Google Fonts (Instrument Serif, Cormorant, Bricolage Grotesque, JetBrains Mono)
- Open-source font sites (sibling fonts to Fraunces, Adobe Fonts)
- Don't invent font names out of thin air

### Color Traps

**❌ Inventing color palettes from scratch**
Don't design an entirely new color palette you're unfamiliar with. It rarely harmonizes.

**✅ Strategy**:
1. Have brand colors → use brand colors; fill missing color tokens using oklch interpolation
2. No brand colors but have a reference → sample colors from a reference product screenshot
3. Starting from zero → pick a known color system (Radix Colors / Tailwind default palette / Anthropic brand) instead of mixing your own

**Defining colors in oklch** is the most modern approach:
```css
:root {
  --primary: oklch(0.65 0.18 25);      /* warm terracotta */
  --primary-light: oklch(0.85 0.08 25); /* lighter shade in same hue */
  --primary-dark: oklch(0.45 0.20 25);  /* darker shade in same hue */
}
```
oklch guarantees hue stays stable when adjusting lightness — better than hsl.

**❌ Adding dark mode by naively inverting colors**
Dark mode is not a simple color inversion. Good dark mode requires re-tuning saturation, contrast, and accent colors. If you don't want to build proper dark mode, don't add it.

### Layout Traps

**❌ Bento grid overuse**
Every AI-generated landing page wants to do bento. Unless your information structure genuinely suits bento, use a different layout.

**❌ Big hero + 3-column features + testimonials + CTA**
This landing page template has been run into the ground. If you want to innovate, actually innovate.

**❌ Card grids where every card looks the same**
Asymmetric, differently-sized cards — some with images, some text-only, some spanning columns — that's what real designer work looks like.

## Content Standards

### 1. Don't add filler content

Every element must earn its place. Empty space is a composition problem — solve it with **layout** (contrast, rhythm, whitespace), **not** by filling it with content.

**Questions to identify filler**:
- If you remove this content, would the design suffer? If not, remove it.
- What real problem does this element solve? If the answer is "fills empty space," delete it.
- Is this stat / quote / feature backed by real data? If not, don't write it.

"One thousand no's for every yes."

### 2. Ask before adding material

Think adding an extra section / slide / block would improve things? Ask the user first, don't add it unilaterally.

Why:
- The user knows their audience better than you do
- Adding content has a cost; the user may not want it
- Adding content unilaterally violates the "junior designer reporting to their manager" relationship

### 3. Create a system up front

After exploring the design context, **verbalize the system you're going to use** and let the user confirm:

```markdown
My design system:
- Color: #1A1A1A primary + #F0EEE6 background + #D97757 accent (from your brand)
- Typography: Instrument Serif for display + Geist Sans for body
- Rhythm: section titles use full-bleed colored background + white text; standard sections use white background
- Images: hero uses full-bleed photo; feature sections use placeholders awaiting your assets
- Max 2 background colors to avoid visual clutter

Confirm this direction and I'll get started.
```

Wait for user confirmation before starting. This check-in prevents "realizing the direction was wrong halfway through."

## Scale Specs

### Slides (1920×1080)

- Body text minimum **24px**, ideal 28–36px
- Headings 60–120px
- Section titles 80–160px
- Hero headlines can go 180–240px
- Never use text smaller than 24px in slide decks

### Print Documents

- Body text minimum **10pt** (≈13.3px), ideal 11–12pt
- Headings 18–36pt
- Captions 8–9pt

### Web and Mobile

- Body text minimum **14px** (16px for accessibility-friendly)
- Mobile body text **16px** (prevents iOS auto-zoom)
- Hit targets (interactive elements) minimum **44×44px**
- Line height 1.5–1.7 (Chinese text: 1.7–1.8)

### Contrast

- Body text vs background **at least 4.5:1** (WCAG AA)
- Large text vs background **at least 3:1**
- Verify using Chrome DevTools accessibility tool

## CSS Power Tools

**Advanced CSS features** are your friend — use them freely:

### Typography

```css
/* Makes headings wrap more naturally, no orphaned single words on last line */
h1, h2, h3 { text-wrap: balance; }

/* Body text wrapping, avoids widows and orphans */
p { text-wrap: pretty; }

/* CJK typography: punctuation compression, line-start/end control */
p { 
  text-spacing-trim: space-all;
  hanging-punctuation: first;
}
```

### Layout

```css
/* CSS Grid + named areas = highly readable layout */
.layout {
  display: grid;
  grid-template-areas:
    "header header"
    "sidebar main"
    "footer footer";
  grid-template-columns: 240px 1fr;
  grid-template-rows: auto 1fr auto;
}

/* Subgrid for aligning card content */
.card { display: grid; grid-template-rows: subgrid; }
```

### Visual Effects

```css
/* Styled scrollbar */
* { scrollbar-width: thin; scrollbar-color: #666 transparent; }

/* Glassmorphism (use sparingly) */
.glass {
  backdrop-filter: blur(20px) saturate(150%);
  background: color-mix(in oklch, white 70%, transparent);
}

/* View Transitions API for smooth page transitions */
@view-transition { navigation: auto; }
```

### Interaction

```css
/* :has() selector makes conditional styles easy */
.card:has(img) { padding-top: 0; } /* cards with images have no top padding */

/* container queries make components truly responsive */
@container (min-width: 500px) { ... }

/* New color-mix function */
.button:hover {
  background: color-mix(in oklch, var(--primary) 85%, black);
}
```

## Quick Decision Guide: When in Doubt

- Thinking of adding a gradient? → Probably don't
- Thinking of adding an emoji? → Don't
- Thinking of adding rounded card + border-left accent? → Don't, find another approach
- Thinking of drawing an SVG hero illustration? → Don't, use a placeholder
- Thinking of adding a decorative quote? → Ask the user if they have a real quote first
- Thinking of adding a row of icon features? → Ask if icons are even needed; they probably aren't
- Using Inter? → Switch to something more distinctive
- Using a purple gradient? → Switch to a grounded color palette

**When you think "adding this would look better" — that's usually a sign of AI slop.** Start with the simplest version. Only add things when the user asks.
