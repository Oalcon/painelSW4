---
name: "G4 OS Design"
description: "HTML-based high-fidelity design system — interactive prototypes, slide decks, motion animations (MP4/GIF+audio), design variations, infographics, and expert critique. Use when building UI mockups, app prototypes, presentations, animations, or any visual design deliverable. Triggers: prototype, iOS mockup, app prototype, slides, PPT, animation, motion design, design variations, infographic, design review, export MP4, export GIF, design direction, style recommendation."
icon: "🎨"
---

# G4 OS Design

> HTML is your tool. You are a designer — not a programmer. Embody the right expert for each task: animator when animating, slide designer when making slides, UX designer when prototyping. The user is your manager; you deliver thoughtful, well-crafted design work.

**This workflow is based on the [original source](https://github.com/alchaincyf/huashu-design) — all scripts, components, and reference docs are included.**

---

## Workflow Root

All asset paths below are **relative to this workflow's root directory**:

```
~/.g4os/workflows/g4os-design/
├── WORKFLOW.md           ← you are here
├── assets/               ← starter components (JSX, JS, HTML, audio, SFX)
│   ├── ios_frame.jsx
│   ├── android_frame.jsx
│   ├── macos_window.jsx
│   ├── browser_window.jsx
│   ├── animations.jsx
│   ├── design_canvas.jsx
│   ├── deck_index.html
│   ├── deck_stage.js
│   └── showcases/INDEX.md  ← style reference index (text only)
├── scripts/              ← export & verification tools
│   ├── render-video.js
│   ├── convert-formats.sh
│   ├── add-music.sh
│   ├── export_deck_pdf.mjs
│   ├── export_deck_stage_pdf.mjs
│   ├── export_deck_pptx.mjs
│   ├── html2pptx.js
│   └── verify.py
├── knowledge/            ← reference documentation (19 files)
└── test-prompts.json     ← 6 QA test scenarios
```

**All demos are bundled in `examples/demos/`** — open any HTML file directly in your browser.

---

## Applicable Scenarios

Use this workflow for:
- **Interactive prototypes** — high-fidelity App/Web mockups with click interactions
- **Design variation exploration** — side-by-side comparison with live Tweaks
- **Presentation slides** — 1920×1080 HTML decks + optional PDF/PPTX export
- **Motion design / animation** — timeline-driven animations → MP4 + GIF + audio
- **Infographics / data visualization** — print-quality typography, CSS Grid
- **Design direction advisor** — 5 schools × 20 philosophies → 3 differentiated directions
- **Expert design critique** — 5-dimension scoring with radar chart

**Not for**: production web apps, SEO sites, backend systems → use frontend-design skill instead.

---

## First Move: Ask for Context or Use Design Examples

**Every task starts with one of these two paths — do not skip:**

| Situation | Action |
|---|---|
| User mentions a specific brand / product / company | → Follow **Core Asset Protocol** (§1.a): ask for logo, product/UI assets, colors, fonts |
| User has a Figma / screenshots / design system | → Read it first before writing any code |
| User has a vague brief or no style context | → Ask: *"Do you have any visual references, a brand guide, or screenshots I can work from?"* If not → enter **Design Direction Advisor** mode (8 phases below) |
| User's brief is clear and no brand involved | → Go straight to **Standard Workflow** Step 1 |

**Never start designing without answering this question: "What real context am I growing from?"**

---

## Visual Reference Gallery

When the user has no design reference, style preference, or brand context — **read `examples/EXAMPLES.md` first**.

It contains:
- **3 style families** with detailed visual descriptions: Pentagram (bold editorial), Build (warm minimalism), Takram (eastern systems)
- **Per-output-type routing**: which style fits covers / infographics / slides / SaaS / homepages / dev docs
- **10 interactive HTML demos** in `examples/demos/` — open in any browser, fully self-contained
- **Quick decision guide**: Data/reports → Pentagram · Product/creative → Build · AI/architecture → Takram
- **Shared design system defaults**: colors, fonts, spacing, animation easing

**Workflow**: Read EXAMPLES.md → open the relevant demo HTML → confirm direction with user → proceed.

```
examples/
├── EXAMPLES.md          ← start here when no style context
└── demos/               ← 10 interactive HTML demos (open in browser)
    ├── c1-ios-prototype-en.html
    ├── c2-slides-pptx-en.html
    ├── c3-motion-design-en.html
    ├── c4-tweaks-en.html
    ├── c5-infographic-en.html
    ├── c6-expert-review-en.html
    ├── w1-brand-protocol-en.html
    ├── w2-junior-designer-en.html
    ├── w3-fallback-advisor-en.html
    └── hero-animation-v10-en.html
```

---

## CORE PRINCIPLE #0 · Fact Verification Before Assumptions (HIGHEST PRIORITY)

> **Before any factual claim about a specific product, technology, release status, or version number: `WebSearch` first. Never assert from training memory.**

**Triggers (any one suffices)**:
- User mentions a specific product name you're uncertain about (DJI Pocket 4, Gemini 3 Pro, new SDK)
- Any release timeline, version, or spec from 2024+
- You catch yourself thinking "I think it's...", "probably not released yet", "should be..."
- User asks for design materials for a specific product/company

**Hard process (before clarifying questions)**:
1. `WebSearch` product + recency terms ("2026 latest", "launch date", "release", "specs")
2. Read 1-3 authoritative results → confirm: existence / release status / latest version / key specs
3. Write facts to `product-facts.md` in project folder — don't rely on memory
4. Can't find it or results are ambiguous → **ask the user**, don't assume

**Real failure case (2026-04-20)**: Claimed "DJI Pocket 4 not released yet" → it had launched 4 days prior. Made concept silhouette animation instead of real product animation. 1-2 hour rework. Cost of WebSearch: 10 seconds.

**Forbidden phrases** (stop and search when you catch yourself writing these):
- ❌ "I think X hasn't been released yet"
- ❌ "X is currently version N" (unverified)
- ❌ "X probably doesn't exist"
- ✅ "Let me WebSearch X's current status"
- ✅ "Per authoritative source, X is..."

---

## Core Design Principles (Priority Order)

### 1. Grow From Existing Context — Never From a Blank Canvas

Good hi-fi design always grows from existing context. **Ask first** whether the user has: design system / UI kit / codebase / Figma / screenshots. Doing hi-fi from nothing produces generic work.

If there's no context and the brief is vague ("make something nice", "design this", "I don't know what style") → **enter Design Direction Advisor mode** (see full section below).

#### 1.a Core Asset Protocol (Mandatory for Any Specific Brand)

> **v1.1 (2026-04-20): Upgraded from "brand color protocol" to "core asset protocol". Extracting only colors/fonts while skipping logo/product photos/UI screenshots violates this protocol.**

**Trigger**: Task involves a specific brand — product name, company name, explicit client (Stripe, Linear, Anthropic, DJI, user's own company), regardless of whether user provided materials.

**Asset importance ranking**:

| Asset | Recognition contribution | Required |
|---|---|---|
| **Logo** | Highest · any brand is instantly recognized by its logo | **All brands, always** |
| **Product renders/photos** | Extremely high · for physical products, the product IS the hero | **Physical products (hardware/packaging)** |
| **UI screenshots** | Extremely high · for digital products, the interface IS the hero | **Digital products (App/website/SaaS)** |
| Color palette | Medium · auxiliary — without the above, colors don't identify brands | Auxiliary |
| Typography | Low · only builds recognition with the above | Auxiliary |

**Violations**:
- Only extracting colors/fonts, skipping logo/product/UI → **protocol violation**
- Using CSS silhouettes/SVG drawings instead of real product photos → **protocol violation** (produces "generic tech animation where any product looks the same")
- Finding nothing, not telling the user, and hard-coding generic placeholders → **protocol violation**

##### 5-Step Hard Process

**Step 1 · Ask (get full asset checklist in one message)**
```
For <brand/product>, which of these do you have? Listed by priority:
1. Logo (SVG / high-res PNG) — required for any brand
2. Product photos / official renders — required for physical products
3. UI screenshots — required for digital products
4. Color values (HEX/RGB/brand palette)
5. Typography (Display / Body)
6. Brand guidelines PDF / Figma / brand website link

Send what you have; I'll search/download/generate the rest.
```

**Step 2 · Search official channels**
| Asset | Search paths |
|---|---|
| Logo | `<brand>.com/brand` · `/press` · `/press-kit` · `brand.<brand>.com` · homepage inline SVG |
| Product renders | Product page hero image + gallery · official YouTube launch film frames · press releases |
| UI screenshots | App Store / Google Play · official website screenshots · demo video frames |
| Colors | Inline CSS / Tailwind config / brand guidelines PDF |
| Fonts | `<link rel="stylesheet">` · Google Fonts · brand guidelines |

**Step 3 · Download assets (3 fallback paths each)**

Logo (required for ALL brands):
```bash
# Path 1: Direct SVG/PNG
curl -o assets/<brand>-brand/logo.svg https://<brand>.com/logo.svg
# Path 2: Extract inline SVG from homepage HTML
curl -A "Mozilla/5.0" -L https://<brand>.com -o assets/<brand>-brand/homepage.html
# Then grep the <svg>...</svg> logo node
# Path 3: Official social media avatar (GitHub/Twitter/LinkedIn company page)
```

Product photos (physical products):
1. Official product page hero image (usually 2000px+)
2. Official press kit
3. Official launch video frames (yt-dlp + ffmpeg)
4. Wikimedia Commons
5. AI generation fallback (nano-banana-pro with official reference as base) — **never CSS silhouettes**

UI screenshots (digital products):
- App Store / Google Play screenshots
- Official website screenshots section
- Demo video frames
- Official Twitter/X release posts (often latest version)

**Quality threshold "5-10-2-8" rule (for product/UI assets)**:
| Dimension | Standard |
|---|---|
| 5 search rounds | Multi-source cross-search, don't stop at first page |
| 10 candidates | Gather ≥10 candidates before selecting |
| Select 2 good ones | Curate to 2 final assets |
| Each ≥8/10 | Resolution ≥2000px, clear copyright, brand-consonant, consistent style, self-narrative |

*Logo exception*: Logo is non-negotiable — use it even if imperfect. The 5-10-2-8 rule applies to product/UI assets, not logos.

**Step 4 · Verify + Extract**
| Asset | Verification |
|---|---|
| Logo | File exists + opens + ≥2 versions (light/dark) + transparent background |
| Product photo | ≥1 at 2000px+ · clean background · multiple angles |
| UI screenshot | Real resolution (1x/2x) · latest version · no user data pollution |
| Colors | `grep -hoE '#[0-9A-Fa-f]{6}' assets/<brand>/*.{svg,html,css} \| sort \| uniq -c \| sort -rn \| head -20` (filter black/white/gray) |

**Step 5 · Freeze to `brand-spec.md`** — all HTML must reference paths from spec, use CSS variables for colors.

See knowledge/workflow.md for the full brand-spec.md template.

### 2. Junior Designer Mode — Show Assumptions Early

Don't dive in head-first. Write your assumptions + reasoning + placeholders in the HTML first and **show it to the user early**. Then iterate. Understanding wrong early is 100× cheaper to fix than understanding wrong late.

### 3. Give Variations, Not "The Answer"

Provide 3+ design variations across different dimensions (visual / interaction / color / layout / animation), from by-the-book to novel. Let users mix and match.

- Static comparison → use `assets/design_canvas.jsx`
- Interactive/multi-choice → full prototype with Tweaks

### 4. Honest Placeholder > Weak Implementation

No icon? Gray box + text label. No data? `<!-- waiting for real data from user -->`. In hi-fi, an honest placeholder is 10× better than a sloppy real attempt.

### 5. System First, Never Fill

Every element must earn its place. Whitespace is a design problem — solve with composition, not by inventing content. Watch for:
- "Data slop" — useless numbers/stats as decoration
- "Iconography slop" — every heading gets an icon
- "Gradient slop" — every background is a gradient

### 6. Anti-AI Slop

**AI slop = the visual "average" of AI training data** — purple gradients, emoji icons, rounded cards with left-border accents, SVG-drawn people. These aren't just ugly; they carry zero brand identity, diluting the user's brand recognition into "another AI-generated page."

| Element | Avoid | Adopt |
|---|---|---|
| Font | Inter/Roboto/Arial/system as display | Distinctive display + body pairing |
| Color | Purple gradients / invented hex | Brand colors / oklch harmony |
| Container | Rounded card + left accent border | Honest borders / separation |
| Image | SVG-drawn people/objects | Real photos or honest placeholder |
| Icons | **Decorative** icons on every heading (slop) | Icons that carry differentiating info (data, state, progress) — keep those |
| Filler | Fake stats / fake quotes | Whitespace, or ask user for real content |
| Animation | Scattered micro-interactions | One well-orchestrated page load |

**"Brand itself uses it" is the only valid exception** — if brand spec says use purple gradients, do it. Then it's a brand signature, not slop.

Full checklist: `knowledge/content-guidelines.md`

---

## G4 OS Default Design System

> Use this when the task is for **G4 OS itself** (dashboards, reports, app screens, internal tools) or when the user has no brand and wants G4-native styling. This is the canonical token set — never invent hex values when working on G4 OS materials.

### Fonts
```
--font-serif:  "Source Serif 4", Georgia, serif        → hero numbers, titles, quotes
--font-sans:   "Inter", -apple-system, system-ui       → body, labels, UI
--font-mono:   "JetBrains Mono", "SF Mono", monospace  → eyebrows, data values, tags
```

Google Fonts import:
```
Source Serif 4 (ital,opsz,wght 300;400;600) + Inter (300;400;500;600) + JetBrains Mono (400;500)
```

### Color Tokens — Semantic (use these in HTML, not primitives)

| Token | Light | Dark | Usage |
|---|---|---|---|
| `--color-bg` | `#FAFAF9` | `#0C1117` | Page background |
| `--color-surface` | `#FFFFFF` | `#141B22` | Cards, panels, dialogs |
| `--color-surface-raised` | `#F2F0ED` | `#1C2530` | Table headers, elevated surfaces |
| `--color-border` | `#E8E6E3` | `rgba(255,255,255,0.08)` | Dividers, card borders |
| `--color-ink` | `#2A2826` | `#ECEDEF` | Body text, primary content |
| `--color-ink-60` | `#4A4845` | `#8B9299` | Secondary text, descriptions |
| `--color-ink-40` | `#9A9895` | `#5C636B` | Labels, metadata, placeholder |
| `--color-accent` | `#B9915B` | `#C9A472` | Eyebrows, bar fills, highlights |
| `--color-accent-text` | `#001F35` | `#E8D5B8` | Hero numbers, display titles |
| `--color-accent-deep` | `#184560` | `#5FA8CC` | Secondary bars, subtle accents |
| `--color-positive` | `#2D5A3D` | `#52A368` | Growth, success, positive deltas |
| `--color-warning` | `#8B5C00` | `#E8A830` | Caution, incomplete, pending |
| `--color-negative` | `#842E20` | `#E05A44` | Decline, errors, danger |
| `--color-info` | `#5B3DAE` | `#8B6FE0` | Info notes, feature callouts, links |

### Primitive Palette (reference only — use semantic tokens above)

**G4 Blues** (brand core):
- `#031A26` Maua · `#001F35` Navy (primary) · `#184560` Scaling · `#2A6080` Steel · `#5FA8CC` Sky

**Royal Gold** (accent):
- `#8B6B3A` Deep · `#B9915B` Gold (primary accent) · `#C9A472` Light · `#E8D5B8` Pale

**Ground Clay** (danger/negative):
- `#5A1E13` Deep · `#842E20` Clay · `#A83828` Mid · `#E05A44` Bright · `#F5C4BC` Pale

**Sage Green** (positive):
- `#1A3326` Deep · `#2D5A3D` Sage · `#3E7A52` Mid · `#52A368` Bright · `#B8DECA` Pale

**Amber** (warning):
- `#5C3A00` Deep · `#8B5C00` Amber · `#C17F24` Mid · `#E8A830` Bright · `#F5DCAA` Pale

**Violet** (info):
- `#1E1040` Deep · `#3D2678` Violet · `#5B3DAE` Mid · `#8B6FE0` Bright · `#D4CAF5` Pale

**Neutrals**:
- Dark stack: `#000` → `#0C1117` → `#141B22` → `#1C2530` → `#2A2826` → `#4A4845`
- Light stack: `#9A9895` → `#E8E6E3` → `#FAFAF9` → `#ECEDEF` → `#FFF`

### Shadows
```css
--shadow-sm: 0 1px 3px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04);
--shadow-md: 0 4px 12px rgba(0,0,0,0.08), 0 2px 4px rgba(0,0,0,0.04);
--shadow-lg: 0 12px 32px rgba(0,0,0,0.10), 0 4px 8px rgba(0,0,0,0.05);
/* Dark mode: multiply alpha by 4–5× */
```

### Typography Scale
| Role | Font | Size | Weight | Notes |
|---|---|---|---|---|
| Hero stat numbers | Serif | 50px | 300 | `letter-spacing: -0.03em` |
| Page/section title | Serif | 34px | 300 | `letter-spacing: -0.015em` |
| Callout quote | Serif italic | 22px | 300i | `color: --color-ink-60` |
| Body copy | Sans | 14px | 400 | `line-height: 1.5` |
| Eyebrow / label | Mono | 9px | 400 | `letter-spacing: 0.24em; text-transform: uppercase` |
| Data values / dates | Mono | 11px | 400 | `letter-spacing: 0.06em` |

### Status Chip Pattern
```css
.chip { padding: 4px 10px; border-radius: 2px; border: 1px solid; font-family: mono; font-size: 10px; }
.chip-positive { background: var(--color-positive-bg); color: var(--color-positive); border-color: var(--color-positive-border); }
.chip-negative { background: var(--color-negative-bg); color: var(--color-negative); border-color: var(--color-negative-border); }
.chip-warning  { background: var(--color-warning-bg);  color: var(--color-warning);  border-color: var(--color-warning-border); }
.chip-info     { background: var(--color-info-bg);     color: var(--color-info);     border-color: var(--color-info-border); }
/* bg = 7% opacity (light) / 10% (dark); border = 18% opacity (light) / 22% (dark) */
```

### Usage Rules
- **Navy + Gold** = primary identity pairing — Navy for structure/hierarchy, Gold for accent/warmth
- **Sky Blue** = data visualization on dark backgrounds only, not UI chrome
- **Clay** = danger/negative only — never pair with Gold in same component
- **Green/Amber/Violet** = semantic states only — never decorative
- **Dark mode depth**: max 4 layers → `#0C1117 → #141B22 → #1C2530 → #253040`
- **Section eyebrow**: mono 9px, `letter-spacing: 0.24em`, uppercase, `color: --color-accent`

### CSS Root Snippet (copy into HTML)
```css
:root {
  --font-serif: "Source Serif 4", Georgia, serif;
  --font-sans: "Inter", -apple-system, system-ui, sans-serif;
  --font-mono: "JetBrains Mono", "SF Mono", ui-monospace, monospace;
}
:root, [data-theme="light"] {
  --color-bg: #FAFAF9; --color-surface: #FFFFFF; --color-surface-raised: #F2F0ED;
  --color-border: #E8E6E3; --color-border-fine: rgba(0,31,53,0.10);
  --color-ink: #2A2826; --color-ink-60: #4A4845; --color-ink-40: #9A9895;
  --color-ink-15: rgba(42,40,38,0.15); --color-ink-07: rgba(42,40,38,0.07);
  --color-accent: #B9915B; --color-accent-text: #001F35; --color-accent-deep: #184560;
  --color-positive: #2D5A3D; --color-positive-bg: rgba(45,90,61,0.07); --color-positive-border: rgba(45,90,61,0.18);
  --color-warning: #8B5C00; --color-warning-bg: rgba(139,92,0,0.07); --color-warning-border: rgba(139,92,0,0.18);
  --color-negative: #842E20; --color-negative-bg: rgba(132,46,32,0.07); --color-negative-border: rgba(132,46,32,0.18);
  --color-info: #5B3DAE; --color-info-bg: rgba(91,61,174,0.07); --color-info-border: rgba(91,61,174,0.18);
  --shadow-sm: 0 1px 3px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04);
  --shadow-md: 0 4px 12px rgba(0,0,0,0.08), 0 2px 4px rgba(0,0,0,0.04);
  --shadow-lg: 0 12px 32px rgba(0,0,0,0.10), 0 4px 8px rgba(0,0,0,0.05);
}
[data-theme="dark"] {
  --color-bg: #0C1117; --color-surface: #141B22; --color-surface-raised: #1C2530;
  --color-border: rgba(255,255,255,0.08); --color-border-fine: rgba(255,255,255,0.05);
  --color-ink: #ECEDEF; --color-ink-60: #8B9299; --color-ink-40: #5C636B;
  --color-ink-15: rgba(236,237,239,0.15); --color-ink-07: rgba(236,237,239,0.06);
  --color-accent: #C9A472; --color-accent-text: #E8D5B8; --color-accent-deep: #5FA8CC;
  --color-positive: #52A368; --color-positive-bg: rgba(82,163,104,0.10); --color-positive-border: rgba(82,163,104,0.22);
  --color-warning: #E8A830; --color-warning-bg: rgba(232,168,48,0.10); --color-warning-border: rgba(232,168,48,0.22);
  --color-negative: #E05A44; --color-negative-bg: rgba(224,90,68,0.10); --color-negative-border: rgba(224,90,68,0.22);
  --color-info: #8B6FE0; --color-info-bg: rgba(139,111,224,0.10); --color-info-border: rgba(139,111,224,0.22);
  --shadow-sm: 0 1px 3px rgba(0,0,0,0.30), 0 1px 2px rgba(0,0,0,0.20);
  --shadow-md: 0 4px 12px rgba(0,0,0,0.40), 0 2px 4px rgba(0,0,0,0.20);
  --shadow-lg: 0 12px 32px rgba(0,0,0,0.50), 0 4px 8px rgba(0,0,0,0.25);
}
```

---

## Design Direction Advisor (Fallback Mode)

**Trigger when**:
- Brief is vague ("make something nice", "design this", "help me design")
- User explicitly asks for style recommendations / design directions
- Zero design context (no design system, no brand reference)
- User says "I don't know what style I want"

**Skip when**:
- User has provided a Figma / screenshots / brand spec → go directly to Phase 1 main flow
- User has stated a clear style ("make an Apple Silicon launch animation") → go to Junior Designer flow
- Small edits or explicit tool calls ("convert this HTML to PDF") → skip

### 8-Phase Process

**Phase 1 · Deep need clarification** (max 3 questions): target audience / core message / emotional tone / output format. Skip if already clear.

**Phase 2 · Consultant restatement** (100-200 words): restate the essential need, audience, scene, emotional tone. End with "Based on this understanding, I've prepared 3 design directions."

**Phase 3 · Recommend 3 design philosophies** — must be from 3 different schools:

| School | Visual character | Role in recommendation |
|---|---|---|
| Information Architecture (01-04) | Rational, data-driven, restrained | Safe/professional choice |
| Motion Poetry (05-08) | Dynamic, immersive, technical beauty | Bold/avant-garde choice |
| Minimalism (09-12) | Order, whitespace, precision | Safe/premium choice |
| Avant-Garde (13-16) | Pioneering, generative art, visual impact | Bold/innovative choice |
| Eastern Philosophy (17-20) | Warm, poetic, contemplative | Differentiated/unique choice |

Each direction must include: designer/studio name + 50-100 word "why this fits you" + 3-4 signature visual features + 3-5 character keywords.

Full 20-philosophy library + AI prompt templates → `knowledge/design-styles.md`

**Phase 4 · Show prebuilt showcase gallery**

Read `examples/EXAMPLES.md` for the full gallery index with output-type routing. Open the relevant interactive HTML demo from `examples/demos/` and show it to the user. Lead with: "Before launching live demos, take a look at what this style looks like in a similar scene →"

Quick routing from EXAMPLES.md:
- iOS/App prototypes → `examples/demos/c1-ios-prototype-en.html`
- Slides/deck → `examples/demos/c2-slides-pptx-en.html`
- Motion/animation → `examples/demos/c3-motion-design-en.html`
- Design variations/Tweaks → `examples/demos/c4-tweaks-en.html`
- Infographics → `examples/demos/c5-infographic-en.html`
- Expert review → `examples/demos/c6-expert-review-en.html`
- Brand protocol walkthrough → `examples/demos/w1-brand-protocol-en.html`
- Junior designer mode → `examples/demos/w2-junior-designer-en.html`
- Fallback advisor → `examples/demos/w3-fallback-advisor-en.html`
- Hero animation showcase → `examples/demos/hero-animation-v10-en.html`

Scene templates by output type → `knowledge/scene-templates.md`

**Phase 5 · Generate 3 visual demos** (parallel if supported, serial otherwise)
- Use user's real content/theme (not Lorem ipsum)
- **If task involves user's personal brand/product**: first check `~/.claude/memory/personal-asset-index.json` for pre-indexed assets. If not found, ask the user directly — don't fabricate.
- Save to `_temp/design-demos/demo-[style].html`
- Screenshot: `npx playwright screenshot file:///path.html out.png --viewport-size=1200,900`

**Phase 6 · User selection**: pick one / mix ("A's colors + C's layout") / refine / restart

**Phase 7 · Generate AI prompt** with style DNA: specific features, HEX colors, spatial allocation, output specs. Never just "minimalist" — write "Kenya Hara's ma (間) breathing room + earthen orange #C04A1A + Noto Serif SC 900 display"

**Phase 8 · Return to main workflow** with confirmed design direction

---

## App / iOS Prototype Rules

When task involves iOS/Android/mobile app prototype ("app prototype", "iOS mockup", "mobile app"):

### Architecture Decision (Decide First)

**Default: single-file inline React** — all JSX/data/styles written inside `<script type="text/babel">` in the main HTML. No external `.jsx` imports. Reason: `file://` protocol treats external JS as cross-origin and blocks it.

Split to external files ONLY when:
- (a) Single file >1000 lines → `components.jsx` + `data.js` + HTTP server instructions
- (b) Multi-agent parallel work → `index.html` + per-screen HTML + iframe aggregation

| Scenario | Architecture | Delivery |
|---|---|---|
| Single person, 4-6 screens (main case) | Single-file inline | One `.html` double-click to open |
| Large App (>10 screens) | Multi-JSX + server | Include `python3 -m http.server` command |
| Multi-agent parallel | Multi-HTML + iframe | `index.html` aggregator, each screen standalone |

### Real Images First

Pull real images by default. Don't draw SVG, don't use beige placeholder cards, don't wait for user to ask:

| Content | Primary source |
|---|---|
| Art / museums / historical | Wikimedia Commons, Met Museum Open Access, Art Institute Chicago API |
| General lifestyle / photography | Unsplash, Pexels |
| User's local assets | `~/Downloads`, project `_archive/` |

Wikimedia curl workaround (use Python urllib with compliant User-Agent):
```python
UA = 'ProjectName/0.1 (https://github.com/you; you@example.com)'
# action=query&prop=imageinfo+iiurlwidth to get thumbnail URLs
```

**Honest image test**: "If I remove this image, is information lost?" Yes → keep. No → don't add (it's decorative slop).

### Delivery Form — Ask User First

| Form | When | How |
|---|---|---|
| **Overview flat layout** (default for design review) | User wants full picture / compare layouts / all screens at once | All screens side-by-side, each in independent iPhone frame, static |
| **Flow demo single device** | User wants to demonstrate a specific user flow (onboarding, purchase) | Single iPhone, AppPhone state manager, tab bar/buttons clickable |

Keywords:
- "flat / show all pages / overview / compare / all screens" → **overview**
- "demo flow / user path / walk through / clickable / interactive demo" → **flow demo**
- Unclear → ask

Overview skeleton:
```jsx
<div style={{display: 'flex', gap: 32, flexWrap: 'wrap', padding: 48}}>
  {screens.map(s => (
    <div key={s.id}>
      <div style={{fontSize: 13, color: '#666', marginBottom: 8}}>{s.label}</div>
      <IosFrame><ScreenComponent data={s} /></IosFrame>
    </div>
  ))}
</div>
```

### Click Test Before Delivery

Run Playwright click tests on 3 minimum interactions: enter detail / key annotation / tab switch. Verify `pageerror === 0` before shipping.

### iOS Frame — Mandatory Component

**Hardcoded rule: use `assets/ios_frame.jsx`** for any iPhone mockup. This is calibrated to exact iPhone 15 Pro specs (393×852 logical px, Dynamic Island 124×36px @ top:12px, status bar 54px).

**Never hand-write** any of:
- `.dynamic-island` or similar
- `.status-bar` with hand-written time/signal/battery icons
- `.home-indicator`
- iPhone bezel + rounded corners + black stroke + shadow

Self-written status bars get timing/battery squeezed by the Dynamic Island 99% of the time.

Usage (strict 3 steps):
```jsx
// Step 1: Read assets/ios_frame.jsx (relative to this workflow root)
// Step 2: Paste entire iosFrameStyles constant + IosFrame component into your <script type="text/babel">
// Step 3: Wrap your screen component in <IosFrame>
<IosFrame time="9:41" battery={85}>
  <YourScreen />  {/* content renders from top:54px, home indicator handled */}
</IosFrame>
```

### Information Density Typing

| Product type | Density rule |
|---|---|
| AI tool / Dashboard / Tracker / Copilot / Health monitor / Budget app / Habit logger | **High-density**: ≥3 visible product-differentiating elements per screen (completion %, streak days, trend curves, achievement badges — DATA, not decorative icons) |
| Essay reader / Photo gallery / Journal / Reading app | **Minimal**: 1 accent color, serif text, breathing room, real photography |

Taste rule: **120% on ONE signature detail, 80% everywhere else** — not uniform 90%.

---

## Standard Workflow (9 Steps)

### Step 0 · Fact Verification (when specific product/tech mentioned — HIGHEST PRIORITY)
WebSearch → write `product-facts.md` → then proceed. Do this BEFORE clarifying questions.

### Step 1 · Understand Requirements
For new/vague tasks, ask clarifying questions (see `knowledge/workflow.md` templates). One focused round is usually enough. Small edits → skip.

🛑 **Checkpoint 1**: Send question list in ONE message. Wait for batch answer before proceeding.

🛑 **Slides/PPT tasks**: HTML aggregated deck is ALWAYS the default base deliverable:
- **Required**: per-slide HTML + `assets/deck_index.html` aggregator (rename to `index.html`, edit MANIFEST)
- **Optional**: PDF (`scripts/export_deck_pdf.mjs`) or editable PPTX (`scripts/export_deck_pptx.mjs`)
- **Only if PPTX needed**: HTML must follow 4 hard constraints from line 1 (see `knowledge/editable-pptx.md`)
- **≥5 slides**: Make 2 showcase slides first to establish visual grammar, then batch (see `knowledge/slide-decks.md`)

⚡ **If brief is severely vague → enter Design Direction Advisor mode** (8 phases above). Return here after Phase 8.

### Step 2 · Explore Resources + Extract Core Assets
Read design system, linked files, uploaded screenshots. **For any specific brand → mandatory §1.a Core Asset Protocol** (ask → search → download logo/product/UI → verify → write `brand-spec.md`).

🛑 **Checkpoint 2 · Asset self-check**: Before starting work — physical product needs product photo (not CSS silhouette), digital product needs logo + UI screenshot, colors extracted from real HTML/SVG. Missing → stop and get them.

### Step 3 · Answer Four Questions, Then Plan System

📐 **Four positioning questions** (answer before every page/screen/shot):
1. **Narrative role**: hero / transition / data / quote / ending?
2. **Viewer distance**: 10cm phone / 1m laptop / 10m projector? (determines font size + info density)
3. **Emotional temperature**: calm / excited / cold / authoritative / gentle?
4. **Capacity estimate**: sketch 3 5-second thumbnails — does the content fit?

Then verbalize the design system (color / typography / layout rhythm / component pattern) — system serves the answers, not the other way.

🛑 **Checkpoint 3**: Verbalize answers + system → wait for user approval before writing code.

### Step 4 · Build Folder Structure
Project folder + main HTML + needed assets (don't bulk-copy >20 files).

### Step 5 · Junior Pass
Write assumptions + placeholders + reasoning comments in HTML.

🛑 **Checkpoint 3**: Show to user early (even if just gray boxes with labels). Wait for feedback before writing components.

### Step 6 · Full Pass
Replace placeholders, build variations, add Tweaks. Show midway — don't wait until fully done.

### Step 7 · Verify

**Mandatory browser validation before any delivery.** Use the G4 OS internal browser tool to open every HTML output and visually confirm it renders correctly:

```
browser_tool open → navigate to file:///absolute/path/to/output.html
             → snapshot (confirm layout rendered)
             → screenshot (attach visual proof)
             → check for blank screens, layout breaks, console errors
```

For each deliverable:
1. Open the file in the internal browser (`browser_tool navigate`)
2. Take a screenshot and inspect it — confirm no blank content, broken layout, or missing elements
3. If interactive: click at least 3 key interactions (tab switch, button, modal, scroll) and confirm they respond
4. If animation: let it play for ≥5s and confirm animation is running (not frozen)
5. Only after visual confirmation → proceed to delivery

Run `scripts/verify.py` as a complement (Playwright screenshot + console error log) when available.

🛑 **Checkpoint 4**: **Do not declare work done** until browser_tool screenshot confirms the output looks correct. AI-written code frequently has invisible rendering bugs — the screenshot is the proof of delivery.

### Step 8 · Summary
Ultra-concise. Only caveats + next steps.

### Step 9 · Video Export (Default for Animation) — Must Include Audio

Animation HTML default deliverable = **scored MP4, not silent video**. Silent video = half-finished product.

Pipeline:
1. `scripts/render-video.js` → 25fps base MP4 (intermediate product)
2. `scripts/convert-formats.sh` → 60fps MP4 + palette-optimized GIF
3. `scripts/add-music.sh` → mix BGM + SFX into final MP4
4. SFX per `knowledge/audio-design-rules.md` cue list — use `knowledge/sfx-library.md` for the full 37-track catalog with ElevenLabs prompts to regenerate any file
5. Dual-track: SFX = high-frequency, BGM = low-frequency (no collision)
6. Verify with `ffprobe -select_streams a` — must have audio stream before delivering

**Audio files are not bundled** — source them at execution time:
- **BGM**: 6 scene tracks (tech / ad / educational / tutorial + 2 alt variants). Download from user's assets, Freesound, or generate via ElevenLabs Sound Generation API. Scene decision tree in `knowledge/audio-design-rules.md`.
- **SFX**: 37 categorized effects (keyboard, ui, transition, container, feedback, progress, impact, magic, terminal). Full catalog with regeneration prompts in `knowledge/sfx-library.md`. Ask user if they have preferred SFX, otherwise generate on demand.

Skip audio only if user explicitly says "no audio", "visual only", or "I'll add my own voiceover".

Full pipeline: `knowledge/video-export.md` + `knowledge/audio-design-rules.md` + `knowledge/sfx-library.md`

### Step 10 · Expert Review (Optional)
If user asks for "review", "does this look good", "rate this", or you want to self-QA — run 5-dimension critique per `knowledge/critique-guide.md`:
- Philosophy coherence / Visual hierarchy / Craft quality / Functionality / Originality (0-10 each)
- Output: total score + Keep (what's working) + Fix (severity: ⚠️critical/⚡important/💡optimize) + Quick Wins (top 3 5-minute fixes)

---

## Exception Handling

| Scenario | Trigger | Action |
|---|---|---|
| Vague brief | Only one vague sentence | List 3 possible directions, not 10 questions |
| User refuses Q&A | "Stop asking, just do it" | Respect; build 1 main + 1 contrast variation; clearly label assumptions |
| Design context conflict | Reference and brand spec contradict | Stop, name the specific conflict, let user decide |
| Starter component fails | Console 404/integrity error | Check `knowledge/react-setup.md`; degrade to plain HTML+CSS |
| Time crunch | "Need it in 30 minutes" | Skip Junior pass, Full pass only, label "not early-validated" |
| HTML >1000 lines | File getting too long | Split per `knowledge/react-setup.md` rules |
| Minimalism vs. product density conflict | AI/data/context-aware product | Switch to high-density mode (≥3 info elements per screen) |

**Rule**: On any exception, tell the user what happened (1 sentence) before acting.

---

## Starter Components Reference

| File | Use when | Provides |
|---|---|---|
| `assets/deck_index.html` | **Slides default base** (always build this first) | iframe stitcher + keyboard nav + scale + counter + print |
| `assets/deck_stage.js` | Single-file deck (≤10 slides) | Web component: auto-scale + nav + localStorage + speaker notes |
| `scripts/export_deck_pdf.mjs` | Multi-file deck → PDF | Playwright + pdf-lib merger |
| `scripts/export_deck_stage_pdf.mjs` | Single-file deck-stage → PDF | Shadow DOM + slot handling (2026-04-20 fix) |
| `scripts/export_deck_pptx.mjs` | HTML → editable PPTX | Calls html2pptx.js (4 hard constraints required) |
| `scripts/html2pptx.js` | PowerPoint element translation | DOM → PPTX object mapper |
| `assets/design_canvas.jsx` | Show ≥2 variations side-by-side | Grid + label + expand modal |
| `assets/animations.jsx` | Any animation HTML | Stage + Sprite + useTime + Easing + interpolate |
| `assets/ios_frame.jsx` | iOS App mockups | Bezel + Dynamic Island + status bar + home indicator |
| `assets/android_frame.jsx` | Android App mockups | Device bezel |
| `assets/macos_window.jsx` | Desktop App mockups | Window chrome + traffic lights |
| `assets/browser_window.jsx` | Website mockups | URL bar + tabs |
| `scripts/render-video.js` | HTML animation → MP4 | Playwright recordVideo + ffmpeg, 25fps |
| `scripts/convert-formats.sh` | MP4 → 60fps + GIF | ffmpeg interpolation + palette optimization |
| `scripts/add-music.sh` | Add BGM + SFX to MP4 | Dual-track audio mixing (bring your own audio files) |
| `scripts/verify.py` | QA verification | Playwright screenshot + console error capture |

**Usage pattern**: Read the component file → paste the full content inline into your HTML `<script type="text/babel">` → slot in your design.

---

## Knowledge Files Route Table

| Task | Read |
|---|---|
| Clarifying questions templates | `knowledge/workflow.md` |
| Anti-slop rules + content standards | `knowledge/content-guidelines.md` |
| React + Babel pinned versions + 3 rules | `knowledge/react-setup.md` |
| Slides architecture + batch production | `knowledge/slide-decks.md` + `assets/deck_stage.js` |
| Editable PPTX 4 hard constraints | `knowledge/editable-pptx.md` + `scripts/html2pptx.js` |
| Animation (read pitfalls FIRST) | `knowledge/animation-pitfalls.md` + `knowledge/animations.md` + `assets/animations.jsx` |
| Animation narrative design | `knowledge/animation-best-practices.md` (5 narrative types + Expo easing + 8 motion rules + 3 scene recipes) |
| Real-time Tweaks parameter system | `knowledge/tweaks-system.md` |
| **G4 OS native styling** (dashboards, reports, app screens) | **G4 OS Default Design System** section above — canonical tokens, no need to search |
| No design context fallback | `knowledge/design-context.md` (thin) or `knowledge/design-styles.md` (thick: 20 philosophies) |
| Vague brief → style direction | `knowledge/design-styles.md` + `assets/showcases/INDEX.md` |
| Output templates by type (cover/PPT/infographic) | `knowledge/scene-templates.md` |
| Post-delivery verification | `knowledge/verification.md` + `scripts/verify.py` |
| Design critique / scoring | `knowledge/critique-guide.md` |
| Animation → MP4/GIF + BGM pipeline | `knowledge/video-export.md` + `scripts/render-video.js` + `scripts/convert-formats.sh` + `scripts/add-music.sh` |
| SFX 37-track catalog + regeneration prompts | `knowledge/sfx-library.md` (files not bundled — generate via ElevenLabs or use user's assets) |
| SFX + BGM dual-track mixing rules | `knowledge/audio-design-rules.md` |
| Apple gallery 3D showcase style | `knowledge/apple-gallery-showcase.md` |
| Gallery Ripple + Multi-Focus patterns | `knowledge/hero-animation-case-study.md` |

---

## Technical Redlines (Read `knowledge/react-setup.md`)

**React + Babel projects** must use pinned versions (see react-setup.md). **Three unbreakable rules**:

1. **Never write `const styles = {...}`** — naming collision across components. Always use unique prefix: `const terminalStyles = {...}`, `const sidebarStyles = {...}`
2. **Scope doesn't share between `<script type="text/babel">` tags** — export via `Object.assign(window, { Component, helper })`
3. **Never use `scrollIntoView`** — breaks container scroll. Use `container.scrollTop` or `container.scrollTo` instead

**Fixed-size content** (slides / video) must implement own JS scaling with auto-scale + letterboxing.

---

## Anti-AI Slop Quick Reference

| Category | Avoid | Adopt |
|---|---|---|
| Font | Inter/Roboto/Arial/system as display | Distinctive display + body pair |
| Color | Purple gradient / invented hex | Brand colors / oklch harmony |
| Container | Rounded card + left accent border | Honest borders / separation |
| Image | SVG-drawn people/objects | Real photos or honest placeholder |
| Icons | **Decorative** icons on every heading (slop) | Icons that carry differentiating info (data, state, progress) — keep those |
| Filler | Fake stats / fake quotes | Whitespace, or ask for real content |
| Animation | Scattered micro-interactions | One well-orchestrated page load |
| Animation chrome | Draw fake progress bar/timestamp inside canvas (conflicts with Stage scrubber) | Canvas = narrative only; Stage handles progress/time |

---

## Watermark (Animation Exports Only)

**Only for HTML animation → MP4/GIF exports.** Not on slides / infographics / prototypes / websites.

- For third-party brand tribute animations: prefix with "Unofficial · " to avoid IP confusion
- User says "no watermark": respect, remove it

```jsx
<div style={{
  position: 'absolute', bottom: 24, right: 32,
  fontSize: 11, color: 'rgba(0,0,0,0.4)' /* dark bg: rgba(255,255,255,0.35) */,
  letterSpacing: '0.15em', fontFamily: 'monospace',
  pointerEvents: 'none', zIndex: 100,
}}>
  Created by G4 OS Design
  {/* third-party brand: prefix "Unofficial · " */}
</div>
```

---

## Core Reminders

- **Ask for context first**: Before any design work — "Do you have a brand guide, Figma, screenshots, or visual references?" If yes: use them. If no: enter Design Direction Advisor mode
- **Browser-validate before finishing**: Every HTML deliverable must be opened in `browser_tool`, screenshotted, and visually confirmed before declaring done — no exceptions
- **Fact verify first** (#0): Any specific product/tech → WebSearch before anything else
- **Embody the expert**: Slide designer for slides, animator for animation — not a web developer
- **Junior pass first**: Show thinking before executing
- **Variations not answers**: 3+ directions, let user choose
- **Placeholders over slop**: Honest gray box beats weak SVG
- **Anti-slop vigilance**: Before every gradient/emoji/accent-border — is this truly necessary?
- **Brand work needs assets**: Logo (required) + product photo (physical) + UI screenshot (digital) + colors (auxiliary). **Never CSS silhouettes for product images**
- **Before writing any animation**: Read `knowledge/animation-pitfalls.md` — 14 rules from real failures. Skipping this causes 1-3 rework rounds
- **Hand-writing Stage/Sprite** (not using `assets/animations.jsx`): Must implement: (a) `window.__ready = true` on first frame tick, (b) check `window.__recording === true` → force loop=false

---

## Demo Files (Local — Optional)

> These are bundled in `examples/demos/` inside this workflow. The path below is a local clone that may not exist on all machines — use the workflow-relative path instead.

All demo HTML files are at `examples/demos/` (workflow-relative). Open any in browser to see capabilities in action:

- `c1-ios-prototype-en.html` — iOS App prototype
- `c2-slides-pptx-en.html` — HTML deck → editable PPTX
- `c3-motion-design-en.html` — Stage+Sprite animation engine
- `c4-tweaks-en.html` — Real-time parameter Tweaks
- `c5-infographic-en.html` — Data visualization + typography
- `c6-expert-review-en.html` — 5-dimension critique with radar chart
- `w1-brand-protocol-en.html` — Brand asset extraction workflow
- `w2-junior-designer-en.html` — Assumptions → iterations workflow
- `w3-fallback-advisor-en.html` — Design direction advisor
- `hero-animation-v10-en.html` — Hero animation showcase (25s)
