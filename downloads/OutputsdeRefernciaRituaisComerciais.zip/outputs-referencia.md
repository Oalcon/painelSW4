---
name: Outputs de Referência — Rituais Comerciais
description: Exemplos reais de output de cada ritual, coletados em 24/05/2026. Usados para documentação e onboarding.
---

# Outputs de Referência — Rituais Comerciais

> Dados reais coletados em **24/05/2026** (maio/2026, MTD 75%).
> Usar como referência de formato e estrutura — os valores mudam a cada execução.

---

## 1. All Hands Pré-Vendas
**Script:** `rituais/all_hands_pv.py` | **Entrega:** 9 blocos (Área + 2 Squads + 6 Times)

```
============================================================
ALL HANDS PRE-VENDAS | MAIO 2026 | Dados ate 24/05
============================================================
## AREA: Sergio Alonso
  Meta: 3.033 opps | GRID: 2.277 (75%) | Realizado: 2.310 | MTD%: 101.4%

### SQUAD: Mavericks (Lucas Kassai)
  Meta: 1.550 | GRID: 1.164 | Realizado: 1.147 | [~] -17 | MTD%: 98.5%

#### TIME: Cane Corso — Coord: Felipe Gargalaka
  Meta: 703 | GRID: 527 | Realizado: 477 | [~] -50 | MTD%: 90.5%
  Ligacoes: 10.724 | CR SAL->Opp: 25.2% | LRT: 24.9h
  Top SDRs: 1. Thiago Ferreira 65 | 2. Rafaela Menezes 50 | 3. Arthur Oliveira 47

[... demais times e squads ...]
============================================================
```

## 2. All Hands Vendas
**Script:** `rituais/all_hands_vendas.py` | **Entrega:** 10 blocos (Área + 2 Squads + 7 Times)

```
============================================================
ALL HANDS VENDAS | MAIO 2026 | Dados ate 24/05 | Diaria: 51%
============================================================
## AREA: Mariana Homem de Mello
  Meta: R$17.7M | GRID: R$9.1M | Realizado: R$2.1M | [!!] MTD%: 22.8%

### SQUAD: Pitbulls (Guilherme Hanada)
  Meta: R$9.9M | GRID: R$5.0M | Realizado: R$1.3M | [!!] MTD%: 25.4%

#### TIME: Mustangs — Coord: Fillipe Oliveira
  Meta: R$3.2M | GRID: R$1.6M | Realizado: R$199K | [!!] MTD%: 12.1%
  Opp abertos: 57 | Deals ganhos: 15 | Win Rate: 26.3%
  Top AEs: 1. Christian Lopes R$75K | 2. Nicolas Miranda R$48K | 3. Leonardo Alencar R$38K

[... demais times e squads ...]
============================================================
```

## 3. Comitê de Receita — Script 1 (Totais PV)
**Script:** `rituais/comite_receita.py`

```
COMITE DE RECEITA | PRE-VENDAS | MAIO 2026 | Diaria: 75%
  Meta: 2.940 | GRID: 2.205 | Realizado: 1.687
  vs GRID: [!!] -518 (76.5%) | vs Meta: [!!] -1.253
  Ritmo necessario: 251 opps/dia | Bench historico: 167/dia [!!]
  Ritmo necessario e 84 opps/dia acima do historico — meta em risco
```

## 4. Comitê de Receita — Script 2 (AGD + Big 7)
**Script:** `rituais/comite_receita_agd.py`

```
  AGD        Meta   GRID  Realizado  MTD%   vs Meta
  Paid      1.584  1.188        810  68.2%     -774
  Social      742    556        440  79.1%     -302
  CRM         432    324        336 103.7%      -96
  Organico    182    136        101  74.3%      -81
  TOTAL     2.940  2.204      1.687  76.5%   -1.253

  BIG 7:
  [IM] Form Facebook Ads  Paid    549
  [IM] Chat               CRM     295
  [IM] Social DM          Social  119
  Form G4 Instagram G4    Social  118
  Form G4 Google          Paid     41
```

## 5. Comitê de Receita — Script 3 (SAL x OPP)
**Script:** `rituais/comite_receita_sal_opp.py`

```
  BLOCO 1 — AGD:
  Paid    SAL:4.077  CR:81%  OPP:816  CR OPP:69%  Gap:-372
  CRM     SAL:1.091  CR:92%  OPP:340  CR OPP:105% Gap:+16

  BLOCO 2 — BIG 7 (razao historica fev-abr/26):
  [IM] Form Facebook Ads  SAL:2.275  Razao:29.3%  Esp:668  Real:550  Gap:-118
  [IM] Chat               SAL:1.021  Razao:25.9%  Esp:264  Real:297  Gap:+33
```

## 6. WBR — Pré-Vendas
**Script:** `rituais/wbr_pre_vendas.py`

```
WBR | PRE-VENDAS | MAIO/2026
[ OPP FMK ] Meta:2.940 | GRID:2.205 | Real:1.687 | [!!] -518 (76.5%)
[ MQL ]     Meta:14.921 | GRID:11.638 | Real:9.768 | [~] -1.870 (83.9%)
[ OPS ]     SALs:6.633 | CR SAL->Opp:23.4% | LRT:24.7h
[ SCO ]     Opps:48 (sem meta Plano G4)
[ GRUPOS ]  FMK:1.687 | PE:465 | TVA:118 | SCO:48 | Total:2.320
[ HC ]      SDRs:63 | Coords:7 | Gers:3 | 3 saidas mapeadas em mai/26
```

## 7. WBR — Vendas
**Script:** `rituais/wbr_vendas.py`

```
WBR | VENDAS | MAIO/2026
[ AREA ]   Total:R$18.1M (1.286 deals) | Meta:R$59.2M | Sem PE:R$15.4M
[ PE ]     Meta:R$17.1M | GRID:R$1.5M | Real:R$2.7M | [+] 185%
[ FMK ]    Meta:R$12.0M | GRID:R$8.2M | Real:R$4.8M | [!!] 58.8%
           Win Rate:13.0% | Ticket:R$20K | Rec/Opp:R$3K
[ TVA ]    Meta:R$5.4M  | GRID:R$2.8M | Real:R$2.1M | [!!] 75.1%
           Win Rate:21.4% | Ticket:R$22K | Rec/Opp:R$5K
[ TOP AEs ] 1.Felice R$907K | 2.Aline R$307K | 3.Gabriel R$213K
[ HC ]     AEs:50 | Coords:7 | Gers:2
```

---

## Legenda dos sinais
| Sinal | Significado |
|---|---|
| `[OK]`/`[+]` | No ritmo ou acima |
| `[~]` | Levemente abaixo (< -20% do GRID) |
| `[!!]` | Significativamente abaixo (≥ -20% do GRID) |