---
name: Databricks — Padrão Técnico de Execução
description: Como executar queries no Databricks deste workspace. Warehouse ID, padrão REST API, errata de campos e lições aprendidas.
---

# Databricks — Padrão Técnico

## Configuração

| Campo | Valor |
|---|---|
| Host | `https://dbc-8acefaf9-a170.cloud.databricks.com` |
| Warehouse ID | `bbae754ea44f67e0` (nome: Production, estado: RUNNING) |
| Servidor MCP | `unitycatalog-mcp` (não expõe tools Genie) |

Token: ler de `~/.g4os/workspaces/trabalho/sources/databricks/config.json` → `mcp.env.DATABRICKS_TOKEN`

---

## Padrão de Execução — REST API SQL

As tools `mcp__databricks__genie_*` **não estão disponíveis** via ToolSearch neste workspace. O servidor é `unitycatalog-mcp` sem Genie spaces configurados. Todas as queries são executadas via **Databricks REST API SQL** usando Python com `urllib.request`.

```python
import urllib.request, json, time, threading

HOST  = 'https://dbc-8acefaf9-a170.cloud.databricks.com'
TOKEN = '<YOUR_DATABRICKS_TOKEN>'  # ler de sources/databricks/config.json
WH    = '<YOUR_WAREHOUSE_ID>'

def run_query(sql):
    body = json.dumps({
        'statement': sql,
        'warehouse_id': WH,
        'wait_timeout': '50s',
        'on_wait_timeout': 'CANCEL'
    }).encode()
    req = urllib.request.Request(
        f'{HOST}/api/2.0/sql/statements', data=body,
        headers={'Authorization': f'Bearer {TOKEN}', 'Content-Type': 'application/json'}
    )
    with urllib.request.urlopen(req, timeout=60) as resp:
        result = json.loads(resp.read())
    state   = result.get('status', {}).get('state', '')
    stmt_id = result.get('statement_id', '')
    for _ in range(60):
        if state in ('SUCCEEDED', 'FAILED', 'CANCELED', 'CLOSED'):
            break
        time.sleep(3)
        req2 = urllib.request.Request(
            f'{HOST}/api/2.0/sql/statements/{stmt_id}',
            headers={'Authorization': f'Bearer {TOKEN}'}
        )
        with urllib.request.urlopen(req2, timeout=30) as resp2:
            result = json.loads(resp2.read())
        state = result.get('status', {}).get('state', '')
    if state != 'SUCCEEDED':
        return None, result.get('status', {}).get('error', {})
    cols = [c['name'] for c in result.get('manifest', {}).get('schema', {}).get('columns', [])]
    rows = result.get('result', {}).get('data_array', []) or []
    return cols, rows
```

**Para queries paralelas**, usar `threading.Thread` + `.join()`:
```python
results = {}
def fetch(label, sql):
    c, r = run_query(sql)
    results[label] = (c, r)

threads = [threading.Thread(target=fetch, args=(lbl, sql)) for lbl, sql in queries]
for t in threads: t.start()
for t in threads: t.join(timeout=240)
```

**Escrever queries em arquivo `.py`** antes de executar via `Bash` — evita problemas de escaping em heredoc.

**Saída com emojis no Windows** — o terminal usa cp1252 por padrão e quebra com emojis. Usar sempre:
```python
import sys
sys.stdout.buffer.write('\n'.join(output).encode('utf-8'))
sys.stdout.buffer.write(b'\n')
```
Nunca usar `print()` direto quando o output contém emojis ou caracteres fora do ASCII.

---

## Path dos Arquivos do Workflow

> ⚠️ O working directory da sessão **não é** o diretório deste workflow.
> Glob e Read relativos ao working directory não encontram esses arquivos.

Usar `{workflow-dir}` para referenciar arquivos do workflow — substituir pelo diretório real do WORKFLOW.md em execução:

```
{workflow-dir}/rituais/<arquivo>.md
{workflow-dir}/knowledge/<arquivo>.md
```

---

## Errata de Campos — Lições Aprendidas

| Problema | Causa | Correção |
|---|---|---|
| `setor = 'Pré-Vendas Aquisição'` → 0 rows | Valor com hífen não existe | Usar `'Pré Vendas Aquisição'` (sem hífen) |
| `grupo_receita` em `funil_comercial` → UNRESOLVED_COLUMN | Campo não existe nessa tabela | Usar `grupo_de_receita` (com `_de_`) na `funil_comercial` |
| `grupo_de_receita` em tabelas de meta → erro | Campo não existe nas metas | Usar `grupo_receita` (sem `_de_`) nas tabelas `sandbox.*` |
| Meta de squad zerada | Somou coord + SDRs do mesmo squad | Usar **apenas a meta do Coordenador** — ela já representa o squad |
| Realizado inflado | M2 filtrava só `grupo_de_receita = 'Funil de Marketing'` | Usar `event='Oportunidade'` na `funil_comercial` sem filtro de grupo |
| Realizado do Comitê com +519 opps indevidas | Sem filtro de `grupo_de_receita` no realizado | Filtrar `grupo_de_receita = 'Funil de Marketing'` no Comitê PV |
| SDR com nomes acentuados não bate no dicionário Python | Acento no dado vs. chave sem acento | Normalizar com `unicodedata.normalize('NFKD', name).encode('ascii','ignore').decode()` |
| Squad desconhecido retornado (ex: "The GOATs") | Time ativo não cadastrado na hierarquia | Ignorar times fora da hierarquia mapeada; logar como aviso |

### Resumo crítico de campos por tabela

| Tabela | Campo correto | Campo incorreto |
|---|---|---|
| `production.diamond.funil_comercial` | `grupo_de_receita` | `grupo_receita` |
| `sandbox.db_metas_g4` | `grupo_receita`, `categoria_meta`, `metrica = '# Opp'` | `grupo_de_receita`; `metrica = 'Opp'` |
| `sandbox.db_diarizacao_metas` | `grupo_receita` | `grupo_de_receita` |
| `production.gold.g4_comercial_people` | `setor = 'Pré Vendas Aquisição'` | `'Pré-Vendas Aquisição'` |

---

## Hierarquia de Dimensões do Funil

```
linha_de_receita_vigente   ← nível mais granular (ex: [IM] Form Facebook Ads)
      ↓
grupo_de_receita           ← agrupamento (Funil de Marketing, Projetos e Eventos…)
      ↓
area_geracao_demanda       ← canal de mídia (Paid, Social, CRM, Orgânico)
```

**Big 7 (linhas estratégicas do Funil de Marketing):**

| `linha_de_receita_vigente` | Área |
|---|---|
| `[IM] Social DM` | Social |
| `Form G4 Instagram G4` | Social |
| `Form G4 Instagram Tallis` | Social |
| `Form G4 Instagram Outros` | Social |
| `[IM] Form Facebook Ads` | Paid |
| `Form G4 Google` | Paid |
| `[IM] Chat` | CRM |

> `area_geracao_demanda = 'Não Definido'` existe como string literal, não é NULL. Tratar com `CASE WHEN area IS NULL OR area = 'Não Definido'` — nunca com `COALESCE`.

---

## Regras de Período

- **MTD realizado**: `event_timestamp >= '${MES}'` AND `< current_date()` — nunca incluir o dia atual
- **Diariação**: `dia <= current_date() - interval 1 day`
- **Faturamento**: sempre via `diamond.funil_comercial.revenue`