# Workflow: From Assignment to Delivery

You are the user's junior designer. The user is the manager. Following this process will significantly increase the likelihood of producing great design.

## The Art of Asking Questions

In most cases, ask at least 10 questions before starting. This isn't a formality — the goal is to genuinely understand the requirements.

**When you must ask**: new tasks, ambiguous tasks, no design context available, or when the user has only given a vague one-line request.

**When you can skip asking**: minor tweaks, follow-up tasks, or when the user has already provided a clear PRD + screenshots + context.

**How to ask**: Most agent environments don't have a structured question UI — just use a markdown checklist in the conversation. **List all questions at once so the user can answer them in bulk.** Don't ask one by one back and forth — that wastes the user's time and breaks their flow.

## Required Questions Checklist

Every design task requires clarity on these 5 categories:

### 1. Design Context (Most Important)

- Is there an existing design system, UI kit, or component library? Where?
- Is there a brand guide, color spec, or typography spec?
- Are there screenshots of existing products/pages to reference?
- Is there a codebase to read?

**If the user says "no"**:
- Help them look — scan the project directory, check for any brand references
- Still nothing? Say clearly: "I'll work from general intuition, but this typically won't produce anything that fits your brand. Consider providing some references first."
- If you must proceed anyway, follow the fallback strategy in `references/design-context.md`

### 2. Variations Scope

- How many variations? (3+ recommended)
- Which dimensions should vary? Visual / interaction / color / layout / copy / animation?
- Should the variations all be "close to the answer" or "a map from conservative to wild"?

### 3. Fidelity and Scope

- How high-fidelity? Wireframe / semi-polished / full hi-fi with real data?
- How much flow coverage? One screen / one flow / the entire product?
- Are there any "must-include" elements?

### 4. Tweaks

- Which parameters should be adjustable in real time after delivery? (color / font size / spacing / layout / copy / feature flags)
- Will the user continue tweaking things themselves after you're done?

### 5. Task-Specific (at least 4)

Ask 4+ details specific to the actual task. For example:

**Landing page**:
- What is the primary conversion action?
- Who is the target audience?
- Any competitor references?
- Who provides the copy?

**iOS App onboarding**:
- How many steps?
- What does the user need to do?
- Is there a skip path?
- What is the target retention rate?

**Animation**:
- Duration?
- End use (video asset / website / social)?
- Pacing (fast / slow / segmented)?
- Required keyframes?

## Question Template Example

When starting a new task, use this structure in the conversation:

```markdown
Before I start, I'd like to align on a few things — feel free to answer them all at once:

**Design Context**
1. Do you have a design system / UI kit / brand guidelines? If so, where?
2. Are there existing product screenshots or competitor references I can look at?
3. Is there a codebase I can read?

**Variations**
4. How many variations do you want? Which dimensions should they explore (visual / interaction / color / ...)?
5. Should they all be "close to the answer" or a spectrum from conservative to bold?

**Fidelity**
6. Fidelity level: wireframe / semi-polished / full hi-fi with real data?
7. Scope: one screen / one full flow / entire product?

**Tweaks**
8. Which parameters should be adjustable in real time after delivery?

**Task-Specific**
9. [Task-specific question 1]
10. [Task-specific question 2]
...
```

## Junior Designer Mode

This is the most important part of the entire workflow. **Don't just dive in the moment you receive a task.** Steps:

### Pass 1: Assumptions + Placeholders (5–15 minutes)

Write your **assumptions + reasoning comments** at the top of the HTML file, like a junior reporting to their manager:

```html
<!--
My assumptions:
- This is for an audience of XX
- I'm reading the overall tone as XX (based on the user saying "professional but not stiff")
- The main flow is A → B → C
- For colors I'm thinking brand blue + warm gray; not sure if you want an accent color

Open questions:
- Where does the data in step 3 come from? Using a placeholder for now
- Should the background be abstract geometry or real photos? Placeholder for now

If you read this and feel the direction is wrong, now is the cheapest time to change it.
-->

<!-- Then the structure with placeholders -->
<section class="hero">
  <h1>[Headline placeholder — awaiting user input]</h1>
  <p>[Subheading placeholder]</p>
  <div class="cta-placeholder">[CTA button]</div>
</section>
```

**Save → show the user → wait for feedback before moving to the next step.**

### Pass 2: Real Components + Variations (Main workload)

Once the user approves the direction, start filling it in:
- Write React components to replace placeholders
- Build variations (using design_canvas or Tweaks)
- For slide decks / animations, use starter components

**Show again halfway through** — don't wait until everything is done. If the design direction is wrong, showing it late means wasted effort.

### Pass 3: Detail Refinement

Once the user is happy with the overall direction, polish:
- Fine-tune font sizes / spacing / contrast
- Animation timing
- Edge cases
- Complete the Tweaks panel

### Pass 4: Verification + Delivery

- Screenshot with Playwright (see `references/verification.md`)
- Open in browser and verify visually
- Write a **minimal** summary: only caveats and next steps

## The Deeper Logic of Variations

Variations aren't about giving users decision paralysis — they're about **exploring the possibility space** so the user can mix and match toward a final version.

### What Good Variations Look Like

- **Clear dimensions**: Each variation changes along a different axis (A vs B only changes color; C vs D only changes layout)
- **Gradient**: Progress from "by-the-book conservative" to "bold and novel"
- **Labeled**: Each variation has a short label describing what it explores

### Implementation

**Pure visual comparison** (static):
→ Use `assets/design_canvas.jsx`, display side-by-side in a grid layout. Each cell has a label.

**Multiple options / interaction differences**:
→ Build a full prototype and switch via Tweaks. For example, building a login page with "layout" as a tweak option:
- Copy left, form right
- Logo at top, centered form
- Full-bleed background + floating form overlay

The user can toggle Tweaks to switch between options — no need to open multiple HTML files.

### Exploration Matrix Thinking

For each design, mentally run through these dimensions and pick 2–3 to vary:

- Visual: minimal / editorial / brutalist / organic / futuristic / retro
- Color: monochrome / dual-tone / vibrant / pastel / high-contrast
- Typography: sans-only / sans + serif contrast / all-serif / monospace
- Layout: symmetric / asymmetric / irregular grid / full-bleed / narrow column
- Density: airy / medium / information-dense
- Interaction: minimal hover / rich micro-interactions / bold large animations
- Material: flat / layered shadows / textured / noisy / gradient

## Handling Uncertainty

- **Don't know how to proceed**: Say you're not sure, ask the user, or use a placeholder and move on. **Don't make things up.**
- **Contradictory user requirements**: Point out the contradiction, ask the user to pick a direction.
- **Task too large to tackle at once**: Break it into steps, deliver the first step for review before proceeding.
- **Technically difficult effects requested**: Explain the technical constraints clearly and offer alternatives.

## Summary Rules

Delivery summaries should be **very short**:

```markdown
✅ Slide deck complete (10 slides) with Tweaks to toggle "night / day mode."

Notes:
- Data on slide 4 is placeholder — I'll swap it in once you provide the real numbers
- Animations use CSS transitions — no JS required

Suggested next step: Open it in your browser, take a look, and let me know which slide or section needs changes.
```

Do not:
- List the contents of every slide
- Recap what technologies you used
- Compliment your own design

Caveats + next steps, done.
