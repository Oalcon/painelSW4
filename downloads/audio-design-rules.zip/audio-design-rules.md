# Audio Design Rules · huashu-design

> Audio recipes for all animation demos. Used alongside `sfx-library.md` (asset inventory).
> Battle-tested: huashu-design hero v1–v9 iterations · Deep Gemini analysis of 3 official Anthropic videos · 8000+ A/B comparisons

---

## Core Principle · Dual-Track Audio (Non-Negotiable)

Animation audio **must be designed as two independent layers**. Never build just one:

| Layer | Role | Time Scale | Relationship to Visuals | Frequency Band |
|---|---|---|---|---|
| **SFX (beat layer)** | Marks each visual beat | 0.2–2 s, brief | **Strong sync** (frame-level alignment) | **High freq 800 Hz+** |
| **BGM (atmosphere base)** | Sets emotional tone, fills the soundscape | Continuous 20–60 s | Loose sync (section-level) | **Mid/low freq <4 kHz** |

**An animation with only BGM is crippled** — viewers subconsciously sense that "things are moving but there's no audio response." This is the root cause of the cheap feeling.

---

## Gold Standard · Golden Ratio Parameters

These values were derived from measured analysis of 3 official Anthropic videos + our own v9 final cut. Use them directly as **engineering hard parameters**:

### Volume
- **BGM volume**: `0.40–0.50` (relative to full scale 1.0)
- **SFX volume**: `1.00`
- **Loudness difference**: BGM peak **6–8 dB lower** than SFX (the distinction comes from the loudness gap, not from raw SFX volume)
- **amix parameter**: `normalize=0` (never use normalize=1 — it compresses dynamic range flat)

### Frequency Isolation (P1 Hard Optimization)
Anthropic's secret is not "loud SFX" — it's **frequency layering**:

```bash
[bgm_raw]lowpass=f=4000[bgm]      # BGM capped at <4kHz mid/low frequencies
[sfx_raw]highpass=f=800[sfx]      # SFX pushed to 800Hz+ mid/high frequencies
[bgm][sfx]amix=inputs=2:duration=first:normalize=0[a]
```

Why: the human ear is most sensitive to the 2–5 kHz range (the "presence band"). If SFX sits in that range while BGM covers the full spectrum, **SFX gets masked by BGM's high-frequency content**. Using highpass to lift SFX + lowpass to push BGM down separates them spectrally, directly improving SFX clarity by a full tier.

### Fade
- BGM in: `afade=in:st=0:d=0.3` (0.3s, avoids hard cut)
- BGM out: `afade=out:st=N-1.5:d=1.5` (1.5s long tail, sense of closure)
- SFX carries its own envelope — no additional fade needed

---

## SFX Cue Design Rules

### Density (how many SFX per 10 seconds)
Measured SFX density from 3 Anthropic videos, three tiers:

| Video | SFX per 10s | Product Personality | Scene |
|---|---|---|---|
| Artifacts (ref-1) | **~9/10s** | Feature-dense, information-heavy | Complex tool demo |
| Code Desktop (ref-2) | **0** | Pure atmosphere, meditative | Developer tool focus state |
| Word (ref-3) | **~4/10s** | Balanced, office cadence | Productivity tool |

**Heuristics**:
- Calm/focused product personality → low SFX density (0–3/10s), BGM-driven
- Energetic/information-dense product personality → high SFX density (6–9/10s), SFX drives the rhythm
- **Don't fill every visual beat** — restraint is more sophisticated than density. **Cutting 30–50% of cues makes the remaining ones more dramatic.**

### Cue Selection Priority
Not every visual beat needs an SFX. Use this priority order:

**P0 — Required** (omitting will feel wrong):
- Typing (terminal/input)
- Click/select (user decision moments)
- Focus shift (transfer of visual protagonist)
- Logo reveal (brand closure)

**P1 — Recommended**:
- Element entry/exit (modal / card)
- Completion/success feedback
- AI generation start/end
- Major transitions (scene cuts)

**P2 — Optional** (too many gets messy):
- hover / focus-in
- Progress tick
- Decorative ambient

### Timestamp Alignment Precision
- **Same-frame alignment** (0 ms offset): click / focus shift / logo landing
- **Pre-roll 1–2 frames** (−33 ms): fast whoosh (gives viewers mental anticipation)
- **Post-roll 1–2 frames** (+33 ms): object landing/impact (matches real physics)

---

## BGM Selection Decision Tree

The huashu-design skill includes 6 BGM tracks (`assets/bgm-*.mp3`):

```
What is the animation's personality?
├─ Product launch / tech demo → bgm-tech.mp3 (minimal synth + piano)
├─ Tutorial / tool walkthrough → bgm-tutorial.mp3 (warm, instructional)
├─ Education / concept explanation → bgm-educational.mp3 (curious, thoughtful)
├─ Marketing / brand promotion → bgm-ad.mp3 (upbeat, promotional)
└─ Need a variation of the same style → bgm-*-alt.mp3 (alternative versions)
```

### When to Use No BGM (worth considering)
Reference Anthropic Code Desktop (ref-2): **0 SFX + pure Lo-fi BGM** can be just as high-end.

**When to choose no BGM**:
- Animation is <10s (not enough time for BGM to establish)
- Product personality is "focused/meditative"
- The scene already has ambient sound or voiceover narration
- SFX density is very high (avoid auditory overload)

---

## Scene Recipes (Ready to Use)

### Recipe A · Product Launch Hero (same as huashu-design v9)
```
Duration: 25 seconds
BGM: bgm-tech.mp3 · 45% · band <4kHz
SFX density: ~6/10s

Cues:
  Terminal typing → type × 4 (0.6s apart)
  Enter key       → enter
  Cards converge  → card × 4 (staggered 0.2s)
  Select          → click
  Ripple          → whoosh
  4 focus shifts  → focus × 4
  Logo            → thud (1.5s)

Volume: BGM 0.45 / SFX 1.0 · amix normalize=0
```

### Recipe B · Tool Feature Demo (reference: Anthropic Code Desktop)
```
Duration: 30–45 seconds
BGM: bgm-tutorial.mp3 · 50%
SFX density: 0–2/10s (very sparse)

Strategy: let BGM + voiceover drive — SFX only at decisive moments (file save / command completion)
```

### Recipe C · AI Generation Demo
```
Duration: 15–20 seconds
BGM: bgm-tech.mp3 or no BGM
SFX density: ~8/10s (high density)

Cues:
  User input         → type + enter
  AI begins process  → magic/ai-process (1.2s loop)
  Generation done    → feedback/complete-done
  Result appears     → magic/sparkle
  
Highlight: ai-process can loop 2–3 times throughout the generation sequence
```

### Recipe D · Pure Atmosphere Long Take (reference: Artifacts)
```
Duration: 10–15 seconds
BGM: none
SFX: 3–5 carefully chosen cues used standalone

Strategy: each SFX is the protagonist — no BGM muddying things together.
Best for: single-product slow shots, close-up showcases
```

---

## ffmpeg Synthesis Templates

### Template 1 · Single SFX Overlay onto Video
```bash
ffmpeg -y -i video.mp4 -itsoffset 2.5 -i sfx.mp3 \
  -filter_complex "[0:a][1:a]amix=inputs=2:normalize=0[a]" \
  -map 0:v -map "[a]" output.mp4
```

### Template 2 · Multi-SFX Timeline Synthesis (aligned to cue timestamps)
```bash
ffmpeg -y \
  -i sfx-type.mp3 -i sfx-enter.mp3 -i sfx-click.mp3 -i sfx-thud.mp3 \
  -filter_complex "\
[0:a]adelay=1100|1100[a0];\
[1:a]adelay=3200|3200[a1];\
[2:a]adelay=7000|7000[a2];\
[3:a]adelay=21800|21800[a3];\
[a0][a1][a2][a3]amix=inputs=4:duration=longest:normalize=0[mixed]" \
  -map "[mixed]" -t 25 sfx-track.mp3
```
**Key parameters**:
- `adelay=N|N`: left channel delay (ms) | right channel delay — write both to ensure stereo alignment
- `normalize=0`: preserves dynamic range — critical!
- `-t 25`: truncates to specified duration

### Template 3 · Video + SFX Track + BGM (with frequency isolation)
```bash
ffmpeg -y -i video.mp4 -i sfx-track.mp3 -i bgm.mp3 \
  -filter_complex "\
[2:a]atrim=0:25,afade=in:st=0:d=0.3,afade=out:st=23.5:d=1.5,\
     lowpass=f=4000,volume=0.45[bgm];\
[1:a]highpass=f=800,volume=1.0[sfx];\
[bgm][sfx]amix=inputs=2:duration=first:normalize=0[a]" \
  -map 0:v -map "[a]" -c:v copy -c:a aac -b:a 192k final.mp4
```

---

## Failure Mode Quick Reference

| Symptom | Root Cause | Fix |
|---|---|---|
| SFX inaudible | BGM high frequencies masking SFX | Add `lowpass=f=4000` to BGM + `highpass=f=800` to SFX |
| Audio effects too loud and harsh | SFX absolute volume too high | Lower SFX volume to 0.7, lower BGM to 0.3, maintain the gap |
| BGM and SFX rhythms clash | Wrong BGM chosen (used music with strong beats) | Switch to ambient / minimal synth BGM |
| BGM cuts abruptly when animation ends | No fade out applied | `afade=out:st=N-1.5:d=1.5` |
| SFX overlapping into mush | Cues too dense + each SFX too long | Keep SFX under 0.5s, cue intervals ≥ 0.2s |
| WeChat mp4 has no sound | WeChat sometimes mutes auto-play | Don't worry — users who tap it will hear sound; GIFs never have sound anyway |

---

## Coordination with Visuals (Advanced)

### SFX Timbre Must Match the Visual Style
- Warm beige/paper visual → SFX with **wooden/soft** timbre (Morse, paper snap, soft click)
- Cold tech/dark visual → SFX with **metallic/digital** timbre (beep, pulse, glitch)
- Hand-drawn/playful visual → SFX with **cartoon/exaggerated** timbre (boing, pop, zap)

The warm beige tone of our current `apple-gallery-showcase.md` → pairs with `keyboard/type.mp3` (mechanical) + `container/card-snap.mp3` (soft) + `impact/logo-reveal-v2.mp3` (cinematic bass)

### SFX Can Guide Visual Rhythm
Advanced technique: **design the SFX timeline first, then adjust the visual animation to align with SFX** (not the other way around).
Because each SFX cue is a "clock tick," visual animation synced to SFX rhythm is very stable — the reverse approach (SFX chasing visuals) often ends up ±1 frame off and feels wrong.

---

## Quality Checklist (Pre-Publish Self-Review)

- [ ] Loudness gap: SFX peak − BGM peak = −6 to −8 dB?
- [ ] Frequency bands: BGM lowpass 4 kHz + SFX highpass 800 Hz?
- [ ] amix normalize=0 (preserving dynamic range)?
- [ ] BGM fade-in 0.3s + fade-out 1.5s?
- [ ] SFX count appropriate for scene personality (density by character)?
- [ ] Each SFX aligned to its visual beat within ±1 frame?
- [ ] Logo reveal sound long enough (recommended 1.5s)?
- [ ] Mute BGM and listen: does SFX alone have sufficient rhythmic feel?
- [ ] Mute SFX and listen: does BGM alone have emotional arc?

Each layer should sound coherent in isolation. If the mix only works when both layers are combined, that means neither layer was done properly.

---

## References

- SFX asset inventory: `sfx-library.md`
- Visual style reference: `apple-gallery-showcase.md`
- Real-world case study reference: `knowledge/hero-animation-case-study.md` (bundled in this workflow)
