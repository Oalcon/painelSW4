# Design Critique In-Depth Guide

> Detailed reference for Phase 7. Covers scoring criteria, scenario-specific focus areas, and a common issues checklist.

---

## Scoring Criteria Explained

### 1. Philosophy Alignment

| Score | Criteria |
|-------|----------|
| 9–10 | Design perfectly embodies the core spirit of the chosen philosophy; every detail has a philosophical basis |
| 7–8 | Overall direction is correct and core characteristics are present; occasional details stray |
| 5–6 | Intent is visible, but execution mixes in other style elements — not pure enough |
| 3–4 | Surface imitation only; the philosophical core is not understood |
| 1–2 | Essentially unrelated to the chosen philosophy |

**Review points**:
- Does it use the signature techniques of this designer / institution?
- Are the colors, typography, and layout consistent with the philosophy's system?
- Are there any self-contradicting elements? (e.g., choosing Kenya Hara but cramming in content)

### 2. Visual Hierarchy

| Score | Criteria |
|-------|----------|
| 9–10 | The user's eye flows naturally along the designer's intended path; information retrieval is frictionless |
| 7–8 | Primary/secondary relationships are clear; 1–2 hierarchy ambiguities at most |
| 5–6 | Headings and body text are distinguishable, but the intermediate levels are confused |
| 3–4 | Information is flat; no clear visual entry point |
| 1–2 | Chaotic; the user doesn't know where to look first |

**Review points**:
- Is the font-size contrast between headings and body text sufficient? (at least 2.5×)
- Do color / weight / size establish 3–4 clear hierarchy levels?
- Is whitespace guiding the eye?
- "Squint test": squint at the design — is the hierarchy still clear?

### 3. Craft Quality

| Score | Criteria |
|-------|----------|
| 9–10 | Pixel-perfect; zero flaws in alignment, spacing, or color |
| 7–8 | Overall polished; 1–2 minor alignment/spacing issues |
| 5–6 | Basically aligned, but spacing is inconsistent and color use is not systematic |
| 3–4 | Obvious alignment errors, chaotic spacing, too many colors |
| 1–2 | Rough; looks like a draft |

**Review points**:
- Is a consistent spacing system used (e.g., 8pt grid)?
- Is spacing between similar elements consistent?
- Is the number of colors controlled? (typically no more than 3–4)
- Is the font family consistent? (typically no more than 2)
- Is edge alignment precise?

### 4. Functionality

| Score | Criteria |
|-------|----------|
| 9–10 | Every design element serves the goal; zero redundancy |
| 7–8 | Clearly function-driven; a small amount of decorative elements that could be removed |
| 5–6 | Basically usable, but decorative elements noticeably distract attention |
| 3–4 | Form over function; users have to work to find information |
| 1–2 | Completely buried in decoration; lost the ability to communicate information |

**Review points**:
- If you removed any given element, would the design suffer? (If not, it should go)
- Are the CTA / key information in the most prominent position?
- Are there any elements added "because they look nice"?
- Does information density match the medium? (Slides should be sparse; PDFs can be denser)

### 5. Originality

| Score | Criteria |
|-------|----------|
| 9–10 | Refreshing; finds a unique expression within the philosophy's framework |
| 7–8 | Has its own ideas; not just applying a template |
| 5–6 | Generic; looks like a template |
| 3–4 | Heavy use of clichés (e.g., gradient spheres to represent AI) |
| 1–2 | Entirely assembled from templates or stock assets |

**Review points**:
- Does it avoid common clichés? (see "Common Issues" below)
- Is there personal expression alongside adherence to the design philosophy?
- Are there any design decisions that are "unexpected but totally right"?

---

## Scenario-Specific Review Focus

Different output types have different review priorities:

| Scenario | Most Important | Secondary | Can Relax |
|----------|---------------|-----------|-----------|
| WeChat/social media cover / article image | Originality, Visual Hierarchy | Philosophy Alignment | Functionality (single image, no interaction) |
| Infographic | Functionality, Visual Hierarchy | Craft Quality | Originality (accuracy first) |
| Slide deck / Keynote | Visual Hierarchy, Functionality | Craft Quality | Originality (clarity first) |
| PDF / whitepaper | Craft Quality, Functionality | Visual Hierarchy | Originality (professionalism first) |
| Landing page / website | Functionality, Visual Hierarchy | Originality | — (all-around requirements) |
| App UI | Functionality, Craft Quality | Visual Hierarchy | Philosophy Alignment (usability first) |
| Xiaohongshu / social post image | Originality, Visual Hierarchy | Philosophy Alignment | Craft Quality (atmosphere first) |

---

## Top 10 Common Design Issues

### 1. AI tech clichés
**Problem**: Gradient spheres, digital rain, blue circuit boards, robot faces
**Why it's a problem**: Users are visually fatigued by these; they can't distinguish you from anyone else
**Fix**: Replace literal symbols with abstract metaphors (e.g., use a "conversation" metaphor rather than a chat bubble icon)

### 2. Insufficient heading size contrast
**Problem**: Heading and body text sizes are too similar (< 2.5× difference)
**Why it's a problem**: Users can't quickly locate key information
**Fix**: Headings should be at least 3× the body size (e.g., body 16px → heading 48–64px)

### 3. Too many colors
**Problem**: Using 5+ colors with no clear hierarchy
**Why it's a problem**: Visual chaos, weak brand identity
**Fix**: Limit to 1 primary + 1 secondary + 1 accent + grays

### 4. Inconsistent spacing
**Problem**: Element spacing is arbitrary with no system
**Why it's a problem**: Looks unprofessional; visual rhythm is broken
**Fix**: Establish an 8pt grid system (use only 8 / 16 / 24 / 32 / 48 / 64px for spacing)

### 5. Insufficient whitespace
**Problem**: Every space filled with content
**Why it's a problem**: Crowded information causes reading fatigue and actually reduces information transfer efficiency
**Fix**: Whitespace should occupy at least 40% of the total area (minimal style: 60%+)

### 6. Too many fonts
**Problem**: Using 3+ typefaces
**Why it's a problem**: Visual noise; weakens coherence
**Fix**: Maximum 2 fonts (1 display + 1 body); use weight and size to create variety

### 7. Inconsistent alignment
**Problem**: Some elements left-aligned, some centered, some right-aligned
**Why it's a problem**: Destroys the sense of visual order
**Fix**: Choose one alignment (left-align recommended) and apply it globally

### 8. Decoration overpowering content
**Problem**: Background patterns / gradients / shadows steal focus from the main content
**Why it's a problem**: Inverted priorities; users come for the information, not the decoration
**Fix**: "If I removed this decoration, would the design suffer?" If not, remove it

### 9. Cyberpunk neon overuse
**Problem**: Dark blue background (#0D1117) + neon glowing effects
**Why it's a problem**: Default aesthetic no-go zone (the taste baseline for this skill), and one of the biggest clichés — users can override with their own brand guidelines
**Fix**: Choose a more distinctive color palette (refer to the 20 style color systems)

### 10. Information density mismatched to medium
**Problem**: A full page of text in a slide deck / 10 elements crammed into a cover image
**Why it's a problem**: Different media have different optimal information densities
**Fix**:
- Slide decks: 1 core idea per slide
- Cover images: 1 visual focal point
- Infographics: layered information presentation
- PDFs: can be denser, but need clear navigation

---

## Critique Output Template

```
## Design Critique Report

**Overall Score**: X.X/10 [Excellent (8+) / Good (6–7.9) / Needs Improvement (4–5.9) / Failing (<4)]

**Dimension Scores**:
- Philosophy Alignment: X/10 [one-line explanation]
- Visual Hierarchy: X/10 [one-line explanation]
- Craft Quality: X/10 [one-line explanation]
- Functionality: X/10 [one-line explanation]
- Originality: X/10 [one-line explanation]

### Strengths (Keep)
- [Point to specific things done well, using design language]

### Issues (Fix)
[Ordered by severity]

**1. [Issue Name]** — ⚠️ Critical / ⚡ Important / 💡 Optimization
- Current state: [describe what's happening]
- Problem: [why this is an issue]
- Fix: [specific action, including numeric values]

### Quick Wins
If you only have 5 minutes, prioritize these 3 things:
- [ ] [Highest-impact fix]
- [ ] [Second most important fix]
- [ ] [Third most important fix]
```

---

**Version**: v1.0
**Last updated**: 2026-02-13
