# Report Template Reference

## File Naming Convention

`pentest_{repo-slug}_{YYYY-MM-DD}.md`

Example: `pentest_ai-diy-clubhouse_2026-04-19.md`

---

## Complete Report Template

```markdown
# Pentest Report — {REPO_NAME}

| Field | Value |
|-------|-------|
| **Performed by:** | {company/team} |
| **Analyst:** | {name} ({email}) |
| **Client:** | {client name} |
| **Repository:** | {owner/repo} |
| **Environment:** | {production URL if known, or "source-only"} |
| **Audit date:** | {DD de Mes de YYYY} |
| **Scope:** | {e.g., "Frontend React/TS + Supabase (N migrations, M Edge Functions)"} |
| **Methodology:** | SAST manual — OWASP Top 10:2025, CWE, ASVS v4.0 |
| **Classification:** | CONFIDENCIAL — uso interno |
| **Project #:** | {N of M} (if multi-repo engagement) |

---

## 1. Sumario Executivo

{2-3 paragraphs describing:}
- What was audited (size, complexity)
- Key conclusion (most impactful cluster of findings)
- Most probable attack vector
- Immediate action items (top 3-5)

**Metricas:**

| Severidade | Quantidade |
|-----------|-----------|
| CRITICAL | {N} |
| HIGH | {N} |
| MEDIUM | {N} |
| LOW | {N} |
| INFO | {N} |
| **Total** | **{N}** |

**Acoes imediatas:**
1. {Most urgent — describe in 1 line}
2. {Second — describe in 1 line}
3. {Third — describe in 1 line}

**Acoes pos-auditoria recomendadas:**
- {Forensic audit suggestion}
- {Token/credential rotation}
- {Monitoring setup}

---

## 2. Metodologia

**Tipo:** Analise estatica de codigo (SAST) e revisao de configuracao — sem execucao de codigo, sem conexao a infraestrutura de producao.

**Standards mapeados:** OWASP ASVS v4.0, OWASP Top 10:2025, CWE.

**Verificacoes realizadas:**

1. Revisao de `.env`, historico Git (`git log -p --all`), `.gitignore` — vazamento de segredos (CWE-540, CWE-200)
2. Auditoria de Row Level Security (RLS) em todas as {N} migrations — politicas `USING (true)`, uso de `SECURITY DEFINER`, tabelas sem RLS
3. Leitura integral de {M} Edge Functions — autenticacao, validacao de input, CORS, HMAC
4. Analise de fluxos de autenticacao — signup, login, invite, reset, tokens
5. Revisao de funcoes `SECURITY DEFINER` — parametros aceitos, validacao de caller
6. Analise de XSS — `dangerouslySetInnerHTML`, `innerHTML`, sanitizadores
7. Revisao de webhooks — validacao de assinatura por servico
8. Inspecao de Storage — buckets publicos, validacao de upload
9. Busca de mass-assignment — `upsert/insert/update` com object spread do cliente
10. Analise de rate-limiting — fail-open, bypass vectors, hash strength

---

## 3. {OPTIONAL: Analise de Fluxo Especifico}

{If a specific flow was the focus (e.g., invite system):}

### 3.1 Modelo de Dados
{Table structure, key fields, relationships}

### 3.2 Pipeline End-to-End
{Step-by-step flow with numbered stages, marking where vulnerabilities exist}

### 3.3 Pontos Criticos
{Numbered list of attack points in the flow}

---

## 4. Resumo Quantitativo

### CRITICAL ({N})

| ID | Titulo | CVSS 3.1 | CWEs | OWASP |
|----|--------|----------|------|-------|
| C1 | {title} | {score} | {CWE-xxx} | {A0x:2021} |

### HIGH ({N})

| ID | Titulo | CVSS 3.1 | CWEs | OWASP |
|----|--------|----------|------|-------|
| H1 | {title} | {score} | {CWE-xxx} | {A0x:2021} |

### MEDIUM ({N})

| ID | Titulo | CVSS 3.1 | CWEs | OWASP |
|----|--------|----------|------|-------|
| M1 | {title} | {score} | {CWE-xxx} | -- |

### LOW ({N})

| ID | Titulo | CVSS 3.1 | CWEs | OWASP |
|----|--------|----------|------|-------|
| L1 | {title} | {score} | {CWE-xxx} | -- |

### INFO ({N})

| ID | Titulo | CWEs |
|----|--------|------|
| I1 | {title} | {CWE-xxx} |

---

## 5. Findings Detalhados

### CRITICAL — C1 — {Titulo}

**CVSS 3.1:** {score} (AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:N)
**CWEs:** CWE-xxx, CWE-yyy
**OWASP:** A0x:2021

**Descricao:**
{Detailed technical description — what the function/endpoint does, why it's vulnerable, what's missing}

**Evidencia:**
```{language}
// File: {path}:{line}
{relevant code snippet}
```

**Proof of Concept (estatico — nao executado em producao):**
```bash
{curl command or code that would exploit}
```

**Impacto:**
{Describe concrete business impact: what data is exposed, what actions an attacker can take, downstream effects}

**Remediacao:**
1. {Step 1 with code}
2. {Step 2 with code}
3. {Forensic/audit action}

```{language}
// Corrected version:
{complete corrected code}
```

**Referencias:**
- CWE-xxx: {title}
- OWASP A0x:2021: {category name}
- {Relevant external docs}

---

{Repeat for each finding...}

---

## 6. Apendice

### 6.1 Edge Functions Auditadas (Matriz de Seguranca)

| Funcao | verify_jwt | Auth interna | CORS | Service Role | Veredito |
|--------|-----------|--------------|------|-------------|----------|
| {name} | true/false | {type or --} | {* or secureCors or allowlist} | sim/nao | OK / VULN(ID) |

### 6.2 Migrations Relevantes (Timeline)

| Data | Migration | Nota |
|------|-----------|------|
| {YYYY-MM-DD} | {timestamp_name} | {what it does, if introduces or fixes vuln} |

### 6.3 Falsos Positivos Descartados

| Cenario | Por que NAO e vulnerabilidade |
|---------|-------------------------------|
| {pattern observado} | {explicacao tecnica} |

**Nota:** Esta secao educa o usuario sobre comportamentos normais que PARECEM vulnerabilidades mas nao sao. Inclua sempre que houver itens que poderiam confundir.

Exemplos comuns:
- Anon key no bundle JS → by design, RLS e a protecao real
- Schema OpenAPI exposto → by design do PostgREST
- `USING(true)` em tabelas de config/enum/cache → read-only compartilhado, sem PII
- Functions sem declaracao em config.toml → default = verify_jwt true (seguro)
- `gen_random_uuid()` para PKs → criptograficamente seguro
- `dangerouslySetInnerHTML` com dados estaticos/config → sem input de usuario

### 6.4 Fora de Escopo Tecnico

- {Item 1 — why out of scope}
- {Item 2}
- {Recommended as separate engagement}

---

*Fim do relatorio*
*{Analyst name} — {Company} — {Date}*
*Distribuicao: confidencial — cliente + equipe interna*
```

---

## Finding ID Convention

- **C1, C2, C3...** — CRITICAL
- **H1, H2, H3...** — HIGH  
- **M1, M2, M3...** — MEDIUM
- **L1, L2, L3...** — LOW
- **I1, I2, I3...** — INFO

For multi-repo engagements with baseline comparison:
- **C0, H0** — NEW findings not in baseline
- Use status labels: CONFIRMADO, MITIGADO, AGRAVADO, SIMILAR, NOVO

---

## Baseline Comparison Table (when applicable)

| Baseline ID | Titulo | Status | Notas |
|------------|--------|--------|-------|
| C1 | {title from previous report} | CONFIRMADO / MITIGADO / AGRAVADO | {what changed} |

Status definitions:
- **CONFIRMADO:** Same vulnerability still present, same severity
- **MITIGADO:** Fix applied, no longer exploitable (or reduced severity)
- **AGRAVADO:** Vulnerability got worse (expanded scope, regression, new attack surface)
- **SIMILAR:** Substantially the same implementation
- **NOVO:** Finding not present in baseline (use C0/H0 prefix)

---

## CVSS 3.1 Vector Reference

Format: `AV:{}/AC:{}/PR:{}/UI:{}/S:{}/C:{}/I:{}/A:{}`

| Component | Values |
|-----------|--------|
| Attack Vector (AV) | N=Network, A=Adjacent, L=Local, P=Physical |
| Attack Complexity (AC) | L=Low, H=High |
| Privileges Required (PR) | N=None, L=Low, H=High |
| User Interaction (UI) | N=None, R=Required |
| Scope (S) | U=Unchanged, C=Changed |
| Confidentiality (C) | N=None, L=Low, H=High |
| Integrity (I) | N=None, L=Low, H=High |
| Availability (A) | N=None, L=Low, H=High |

Common vectors for web app findings:
- Unauthenticated data exposure: `AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N` (7.5)
- Privilege escalation requiring auth: `AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:N` (8.1-9.1)
- Admin function without auth: `AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:L` (8.6)
- CORS bypass: `AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:H/A:N` (7.5)
- Webhook spoofing: `AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:H/A:L` (7.1-7.3)
