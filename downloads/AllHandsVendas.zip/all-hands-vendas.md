---
name: All Hands Vendas
description: Preparo completo para o All Hands de Vendas. Cobre Overview Área (Mariana) + squads Pitbulls e Rottweillers + 7 times filhos, com métricas de meta, GRID, realizado, GAP e destaque operacional (Win Rate).
---

# Ritual: All Hands Vendas

## Execução — Script Python

Este ritual é executado via script Python pré-validado. **Não montar queries manualmente.**

```bash
python "{workflow-dir}/rituais/all_hands_vendas.py"
```

O script executa H1, H2, M1, M2, M3 em paralelo, monta a hierarquia dinamicamente e entrega os 10 blocos formatados (Área + 2 Squads + 7 Times). Apresentar o output ao usuário exatamente como retornado.

---

## Estrutura de Entrega

```
1. Overview Área — Mariana Homem de Mello
2. Overview Squad — Pitbulls (Guilherme Hanada)
3. Overview Squad — Rottweillers (Matheus Raulino)
   [+ 7 times filhos com destaque operacional]
```

Total: **10 blocos** (1 área + 2 squads + 7 times).

---

## Guardrails

1. **Evento correto** — usar `event = 'Ganho'`, não `'Won'`
2. **Campo `grupo_de_receita`** — com `_de_` na `funil_comercial`; filtrar `= 'Time de Vendas - Aquisição'`
3. **Diariação** — `grupo_receita = 'Time de Vendas - Aquisição'`, `tipo_meta = 'receita'`
4. **Meta do squad** — soma das metas dos AEs do squad
5. **Black Ops** — squad `Sales Operations`; ignorar no roll-up
6. **All Blacks** — time pode ter 0 AEs ativos; exibir com aviso, não remover
7. **Deduplicação de deals** — `ROW_NUMBER() OVER (PARTITION BY deal_id ORDER BY event_timestamp DESC) = 1`