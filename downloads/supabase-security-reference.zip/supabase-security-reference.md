# Supabase Security Reference

## Arquitetura de Seguranca do Supabase

### Row Level Security (RLS)
- RLS e o mecanismo principal de seguranca do Supabase
- Quando RLS esta habilitado, TODAS as queries via API sao filtradas pelas policies
- Sem RLS habilitado, qualquer query com anon key retorna todos os dados
- Views herdam RLS das tabelas subjacentes

### Anon Key
- JWT com role "anon" — por design publica, incluida no JS do frontend
- Expira em ~10 anos (padrao Supabase)
- Seguranca NAO depende do sigilo desta key
- Seguranca depende de RLS estar configurado corretamente

### Service Role Key
- JWT com role "service_role" — NUNCA deve ser exposta ao frontend
- Bypassa RLS completamente
- Se encontrada no JS publico = 🔴 CRITICO

### Auth Endpoints
| Endpoint | Funcao | Notas |
|----------|--------|-------|
| `/auth/v1/signup` | Criar conta | `disable_signup` controla se esta aberto |
| `/auth/v1/token?grant_type=password` | Login email+password | |
| `/auth/v1/otp` | Enviar OTP | Rate limit ~60s entre envios |
| `/auth/v1/verify` | Verificar OTP | Codigos expiram apos uso |
| `/auth/v1/user` | Dados do usuario logado | Requer Bearer token |

### Configuracoes Relevantes
| Config | Impacto |
|--------|--------|
| `mailer_autoconfirm: true` | Contas criadas via API sao confirmadas automaticamente |
| `disable_signup: true` | Bloqueia `/auth/v1/signup` |
| `rate_limit.email.period` | Intervalo entre envios de OTP |

## Patterns de Seguranca Comuns

### App Segura (esperado)
- RLS habilitado em todas as tabelas de negocio
- Policies filtrando por `auth.uid()`
- Signup controlado (OTP ou disable_signup)
- Edge functions validando auth e ownership
- Cross-tenant isolation via workspace_id + RLS

### App Vulneravel (red flags)
- Tabelas sem RLS retornando dados com anon key
- Service role key no frontend JS
- Escrita anonima em tabelas criticas
- Signup aberto com auto-confirm + auto-provisioning sem limites
- Edge functions sem validacao de auth

## Fix SQL Patterns

### Habilitar RLS
```sql
ALTER TABLE {tabela} ENABLE ROW LEVEL SECURITY;
```

### Policy somente leitura publica
```sql
CREATE POLICY "public_read" ON {tabela}
  FOR SELECT USING (true);
```

### Policy por usuario autenticado
```sql
CREATE POLICY "user_own_data" ON {tabela}
  FOR ALL USING (auth.uid() = user_id);
```

### Policy por workspace
```sql
CREATE POLICY "workspace_member" ON {tabela}
  FOR ALL USING (
    workspace_id IN (
      SELECT workspace_id FROM workspace_memberships
      WHERE user_id = auth.uid()
    )
  );
```

## CVSS Scoring Reference

| Cenario | Score Estimado |
|---------|---------------|
| PII exposta (milhares de registros) sem auth | 9.1 Critical |
| Escrita anonima em tabela de config (DoS visual) | 6.5 Medium |
| Signup aberto com auto-confirm | 4.3 Medium (depende do contexto) |
| Cross-tenant data access | 8.7 High |
| Service role key exposta | 9.8 Critical |
| Schema OpenAPI visivel | 0 (by design) |
| Tabelas vazias acessiveis | 0 (by design, se RLS funciona) |