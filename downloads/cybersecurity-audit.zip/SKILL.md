---
name: cybersecurity-audit
description: "Full-spectrum security audit — SAST, DAST, SCA, secret scanning, IaC, container hardening, IAM/RBAC review, threat modeling, and API security. Step-by-step investigation with 14 audit phases. Produces triage findings, autofix patches, and a structured report. Source: github.com/cesschneider/cybersec-audit-skill v2.1.0"
triggers:
  - "audit this app / codebase / repo"
  - "find security vulnerabilities"
  - "run a security scan"
  - "SAST / DAST / SCA / static analysis"
  - "security review before deploy"
  - "pentest / vulnerability assessment"
  - "scan this project for security issues"
  - "check security of this code"
  - "DevSecOps audit"
  - "cloud security review"
alwaysAllow:
  - "Bash"
  - "Read"
  - "Write"
---

# Cybersecurity Audit Skill

> **Version:** 2.1.0 | **OWASP:** Top 10 2021 + API Top 10 2023 | **Source:** [github.com/cesschneider/cybersec-audit-skill](https://github.com/cesschneider/cybersec-audit-skill)

## Philosophy

This is a **step-by-step investigation**, not a one-shot scan.
Before running any tool, gather context. Ask what you don't know.
A security audit without context produces noise, not signal.

---

## PHASE 0 — Context Gathering (ALWAYS run this first)

Ask ALL of these before proceeding:

1. **Stack** — Languages and frameworks
2. **Infrastructure** — AWS / GCP / Azure / on-prem / Docker / Kubernetes
3. **Entry points** — REST API, GraphQL, CLI, background jobs, webhooks
4. **Auth model** — JWT, OAuth2, session cookies, API keys, RBAC
5. **Data sensitivity** — PII, financial, PHI, credentials
6. **Compliance** — PCI-DSS, SOC2, ISO 27001, HIPAA, LGPD, GDPR
7. **Deployment pipeline** — GitHub Actions, Jenkins, GitLab CI, Terraform
8. **Previous audits** — Known CVEs, prior pentest findings

Confirm scope before starting.

---

## PHASE 0.5 — Tool Currency Check

```bash
semgrep --update
nuclei -update-templates && nuclei -update
trivy image --download-db-only
pip install --upgrade pip-audit safety checkov
gitleaks version
```

Verify OWASP Top 10 2021, API Top 10 2023, Mobile Top 10 2024 are current.
Check NVD for critical CVEs in the last 7 days relevant to target stack.

---

## PHASE 1 — Threat Modeling

**STRIDE per component:**

| Threat | Question | Example |
|---|---|---|
| Spoofing | Can attacker impersonate? | Forged JWT |
| Tampering | Can data be modified? | Missing integrity checks |
| Repudiation | Can actions be denied? | No audit log |
| Info Disclosure | Can sensitive data leak? | Verbose errors |
| Denial of Service | Can system be unavailable? | No rate limits |
| EoP | Can low-priv gain higher access? | IDOR |

Build attack trees for top 3 high-value targets. Save to `.audit/threat-model-YYYY-MM-DD.md`.

---

## PHASE 2 — Multi-Layer Audit (11 Layers)

### Layer 1 — SAST
```bash
bandit -r ./src -f json -o .audit/sast/bandit.json
semgrep --config=p/owasp-top-ten . --json > .audit/sast/semgrep-owasp.json
njsscan ./src --json > .audit/sast/njsscan.json
```
Targets: CWE-89 SQLi, CWE-78 CMDi, CWE-79 XSS, CWE-22 path traversal, CWE-502 deserialization, CWE-798 hardcoded secrets, CWE-327/330 weak crypto/random, CWE-918 SSRF.

### Layer 2 — SCA
```bash
pip-audit --output json > .audit/sca/pip-audit.json
npm audit --json > .audit/sca/npm-audit.json
```

### Layer 3 — Secret Scanning
```bash
gitleaks detect --source . --report-path .audit/secrets/gitleaks.json --report-format json
detect-secrets scan . > .audit/secrets/baseline.json
```
Check: `.env` committed, AWS credentials (AKIA...), private keys, JWT secrets hardcoded.

### Layer 4 — IaC Security
```bash
checkov -d . --output json > .audit/iac/checkov.json
```
Look for: public S3 buckets, unrestricted security groups (0.0.0.0/0), missing encryption, root IAM keys, wildcard policies.

### Layer 5 — Container Security
```bash
trivy image <image>:<tag> --format json > .audit/containers/trivy-image.json
trivy fs . --format json > .audit/containers/trivy-fs.json
```

### Layer 6 — API Security (OWASP API Top 10)
```bash
spectral lint openapi.yaml --ruleset @stoplight/spectral-owasp-ruleset
```
Check all 10 API security risks: BOLA/IDOR, broken auth, property-level auth, rate limiting, function-level auth, business flow abuse, SSRF, misconfiguration, shadow endpoints, unsafe API consumption.

### Layer 7 — Auth & Authorization
- bcrypt/argon2 (not MD5/SHA1)
- JWT: RS256/ES256 forced, expiry <15 min, refresh rotation
- Session: HttpOnly + Secure + SameSite=Strict
- RBAC/ABAC server-side, object-level ownership check

### Layer 8 — DAST
```bash
docker run --rm ghcr.io/zaproxy/zaproxy:stable zap-baseline.py -t $TARGET_URL -J .audit/dast/zap-baseline.json
nuclei -u $TARGET_URL -t cves/ -t misconfigurations/ -severity critical,high -json -o .audit/dast/nuclei.json
```
Written authorization required. Test environments only. Never against production.

### Layer 9 — Manual Code Review
Focus: auth middleware, DB queries, file upload handlers, eval/exec, crypto, business logic, error handlers.

### Layer 10 — Supply Chain Security
```bash
cyclonedx-py -o .audit/sca/sbom-python.json
osv-scanner --sbom .audit/sca/sbom-python.json --json > .audit/sca/osv-results.json
git log --format="%G? %H %s" | head -20
```
Checklist: pinned deps, SBOM generated, signed commits, GitHub Actions pinned to SHA, Dependabot enabled.

### Layer 11 — Security Headers & TLS
```bash
/opt/testssl/testssl.sh --jsonfile .audit/headers/testssl.json $TARGET_URL
curl -sI $TARGET_URL | grep -iE "strict-transport|content-security|x-frame|x-content-type"
```
Required: HSTS (max-age=31536000;includeSubDomains;preload), CSP, X-Frame-Options: DENY, X-Content-Type-Options: nosniff. Target A+ on securityheaders.com and ssllabs.com.

---

## PHASE 3 — Triage & Classification

Finding schema: `{id, severity, category, cwe, owasp, file, line, description, evidence, impact, recommendation, autofix_ready, status}`

Risk Score: CRITICAL=25, HIGH=10, MEDIUM=3, LOW=1 pts (capped at 100).
0-19 GREEN | 20-49 YELLOW | 50-79 ORANGE | 80-100 RED (do not deploy).

Save to: `.audit/findings-YYYY-MM-DD.json`

---

## PHASE 4 — Autofix Pass

| Vulnerability | CWE | Pattern | Fix |
|---|---|---|---|
| SQL injection | CWE-89 | f-string queries | Parameterized cursor.execute |
| Command injection | CWE-78 | os.system(cmd) | subprocess.run(cmd.split()) |
| Hardcoded secret | CWE-798 | SECRET = "abc123" | os.environ.get("SECRET_KEY") |
| Weak crypto | CWE-327 | hashlib.md5(pw) | bcrypt.hashpw |
| Deserialization | CWE-502 | pickle.loads | json.loads |
| CORS wildcard | CWE-942 | origins="*" | explicit origin list |

Cannot autofix: broken auth (CWE-287), IDOR (CWE-639), CSRF (CWE-352), business logic.

---

## PHASE 5 — Reporting

Outputs: `.audit/report-YYYY-MM-DD.md` + `.audit/findings-YYYY-MM-DD.json`

Report structure:
- Executive summary (risk score, top 5 findings)
- Findings by severity (Critical > High > Medium > Low)
- Remediation roadmap: IMMEDIATE (Day 0-7) | 30-Day Sprint | 60-Day Sprint | 90-Day Backlog
- Compliance mapping: PCI-DSS, ISO 27001, SOC2

---

## PHASE 6 — Incident Response Readiness

Must log: auth events, authorization failures, privilege escalation, PII access, config changes.
Never log: passwords, credit cards, session tokens, API keys.
IR Score (0-100): structured logging + alerting + SIEM + IR runbook + revocation. Under 40 = critical gap.

---

## PHASE 7 — DevSecOps Pipeline Review

- Pre-commit: secret scanning (gitleaks), signed commits
- PR: SAST + SCA + secret scanning, build fails on CRITICAL/HIGH
- Deploy: artifacts signed, secrets injected at runtime, rollback verified

---

## PHASE 8 — Cloud IAM Deep Dive

```bash
prowler aws --compliance cis_aws_3.0.0 --output-formats json html
scout aws --report-dir .audit/cloud-iam/scoutsuite
```

IAM checklist: no root access keys, MFA all users, keys rotated <90d, no wildcard policies, GuardDuty + CloudTrail enabled.
Privilege escalation paths: iam:CreatePolicyVersion, iam:AttachUserPolicy, iam:PassRole+ec2:RunInstances.

---

## PHASE 9 — Mobile & Frontend Security

React/SPA: no dangerouslySetInnerHTML, no secrets in JS bundles, SRI hashes on external scripts, no PII in localStorage.
Mobile (iOS/Android): certificate pinning, no secrets in APK/IPA, no debug flags in prod, backup disabled.

---

## PHASE 10 — Evidence Collection

- CRITICAL: HTTP request+response capture, PoC code, screenshot, impact statement
- HIGH: code snippet with line number, tool output, exploitation path
- Naming: `.audit/evidence/{SEVERITY}-{ID}-{type}.{ext}`
- PoC must be marked: # SECURITY RESEARCH ONLY — DO NOT DEPLOY

---

## PHASE 11 — False Positive Triage

4-step per finding: read in context > is it exploitable? > classify > document.
Classifications: confirmed | false_positive | informational | out_of_scope
FP rates: Bandit ~25%, Semgrep ~32%, Trivy ~88% (base-image OS CVEs).

---

## PHASE 12 — Retest & Verification

Every patched finding must be retested with the exact tool/check that identified it.
Issue attestation statement: "Risk score reduced from XX to XX (N% improvement). Findings fixed: N/total."

---

## PHASE 13 — Scope & Exclusions

Document IN SCOPE (codebase commit SHA, environments, entry points, layers applied), OUT OF SCOPE (production DB, third-party SaaS, physical), AUTHORIZATION (authorized by name + emergency stop contact).

---

## PHASE 14 — Git Workflow

```bash
git checkout -b security/audit-fixes-YYYY-MM-DD
git commit -m "fix(security): CWE-89 parameterized queries in src/db.py"
```
One commit per finding. Status: fixed | partial_fix | open | accepted_risk.

---

## Environment Bootstrap

```bash
sudo apt-get update -y && sudo apt-get install -y python3-pip nodejs npm curl
pip3 install bandit semgrep njsscan pip-audit detect-secrets checkov cyclonedx-bom
npm install -g @stoplight/spectral-cli @cyclonedx/cyclonedx-npm
curl -sfL https://raw.githubusercontent.com/aquasecurity/trivy/main/contrib/install.sh | sh -s -- -b ~/.local/bin
export PATH=$PATH:~/.local/bin
bandit --version && semgrep --version && checkov --version && trivy --version && gitleaks version
```

## Pitfalls

- Never skip Phase 0 — tools without context generate hundreds of false positives
- Auth + IDOR are always paired — fix auth architecture first
- Secret scanning must check git history, not just current tree
- IaC misconfigs are often more critical than code bugs
- SAST has high FP rates — always manually verify before reporting
- Container base image CVEs: mostly OS layer, prioritize app-layer CVEs
- alg:none JWT attacks — always verify library forces algorithm validation
- Compliance does not equal Security — flag both separately