# Animation Pitfalls: Bugs and Rules from HTML Animation Work

The most common bugs encountered when building animations and how to avoid them. Every rule here comes from a real failure.

Read this before writing any animation — it will save you a full iteration cycle.

## 1. Stacked Layout — `position: relative` Is a Default Obligation

**The trap**: a sentence-wrap element contained 3 bracket-layers (`position: absolute`). No `position: relative` was set on sentence-wrap, so the absolute brackets used `.canvas` as their coordinate system and floated to 200px below the bottom of the screen.

**Rules**:
- Any container with `position: absolute` children **must** have an explicit `position: relative`
- Even if there's no visual "offset" needed, write `position: relative` as the coordinate system anchor
- Any time you write `.parent { ... }` and its children have `.child { position: absolute }`, reflexively add relative to the parent

**Quick check**: for every `position: absolute`, count up to its ancestors — confirm the nearest positioned ancestor is the coordinate system *you intend*.

## 2. Character Traps — Don't Rely on Rare Unicode

**The trap**: wanted to use `␣` (U+2423 OPEN BOX) to visualize "space token." Noto Serif SC / Cormorant Garamond both lack this glyph — it renders as blank/tofu, completely invisible to the audience.

**Rules**:
- **Every character that appears in an animation must exist in your chosen font**
- Common rare-character blacklist: `␣ ␀ ␐ ␋ ␨ ↩ ⏎ ⌘ ⌥ ⌃ ⇧ ␦ ␖ ␛`
- To represent meta-characters like "space / return / tab," use **CSS-constructed semantic boxes**:
  ```html
  <span class="space-key">Space</span>
  ```
  ```css
  .space-key {
    display: inline-flex;
    padding: 4px 14px;
    border: 1.5px solid var(--accent);
    border-radius: 4px;
    font-family: monospace;
    font-size: 0.3em;
    letter-spacing: 0.2em;
    text-transform: uppercase;
  }
  ```
- Also validate emoji: some emoji fall back to gray boxes in fonts other than Noto Emoji — best to use the `emoji` font-family or SVG

## 3. Data-Driven Grid/Flex Templates

**The trap**: code has `const N = 6` tokens, but CSS is hardcoded as `grid-template-columns: 80px repeat(5, 1fr)`. The 6th token has no column, causing the entire matrix to misalign.

**Rules**:
- When count comes from a JS array (`TOKENS.length`), the CSS template should also be data-driven
- Option A: inject via CSS variable from JS
  ```js
  el.style.setProperty('--cols', N);
  ```
  ```css
  .grid { grid-template-columns: 80px repeat(var(--cols), 1fr); }
  ```
- Option B: use `grid-auto-flow: column` to let the browser expand automatically
- **Ban the "hardcoded number + JS constant" combination** — if N changes, CSS won't sync

## 4. Transition Gaps — Scene Switches Must Be Continuous

**The trap**: zoom1 (13–19s) → zoom2 (19.2–23s) — the main sentence is already hidden, and zoom1 fade-out (0.6s) + zoom2 fade-in (0.6s) + stagger delay (0.2s+) = roughly 1 second of pure blank canvas. Viewers assume the animation froze.

**Rules**:
- For sequential scene switches, fade-out and fade-in must **cross-overlap**, not: "first one fully disappears, then next one starts"
  ```js
  // Bad:
  if (t >= 19) hideZoom('zoom1');      // 19.0s out
  if (t >= 19.4) showZoom('zoom2');    // 19.4s in → 0.4s blank in between

  // Good:
  if (t >= 18.6) hideZoom('zoom1');    // start fade-out 0.4s early
  if (t >= 18.6) showZoom('zoom2');    // fade-in at the same time (cross-fade)
  ```
- Or use an "anchor element" (like the main sentence) as a visual connector between scenes — it briefly reappears during the zoom switch
- Calculate CSS transition durations carefully to avoid triggering the next transition before the current one finishes

## 5. Pure Render Principle — Animation State Should Be Seekable

**The trap**: using `setTimeout` + `fireOnce(key, fn)` chains to trigger animation states. Normal playback works fine, but for frame-by-frame recording / seeking to any timestamp, the previous setTimeouts have already fired and there is no way to "go back."

**Rules**:
- The `render(t)` function ideally is a **pure function**: given t, it outputs a unique DOM state
- If side effects are necessary (e.g., class toggling), use a `fired` set with explicit reset:
  ```js
  const fired = new Set();
  function fireOnce(key, fn) { if (!fired.has(key)) { fired.add(key); fn(); } }
  function reset() { fired.clear(); /* clear all .show classes */ }
  ```
- Expose `window.__seek(t)` for Playwright / debugging:
  ```js
  window.__seek = (t) => { reset(); render(t); };
  ```
- Animation-related setTimeouts should not span >1 second — otherwise seeking backwards will cause chaos

## 6. Measuring Before Fonts Are Loaded = Measuring Wrong

**The trap**: calling `charRect(idx)` to measure bracket positions right at `DOMContentLoaded` — fonts haven't loaded yet, every character width is the fallback font's width, positions are all wrong. Once the font loads (~500ms later), the bracket `left: Xpx` values are still the old values — permanently offset.

**Rules**:
- Any layout code that depends on DOM measurement (`getBoundingClientRect`, `offsetWidth`) **must** be wrapped in `document.fonts.ready.then()`
  ```js
  document.fonts.ready.then(() => {
    requestAnimationFrame(() => {
      buildBrackets(...);  // fonts are ready, measurements are accurate
      tick();              // animation starts
    });
  });
  ```
- The extra `requestAnimationFrame` gives the browser one frame to commit the layout
- If using Google Fonts CDN, add `<link rel="preconnect">` to accelerate initial load

## 7. Recording Readiness — Keep Handles Ready for Video Export

**The trap**: Playwright `recordVideo` defaults to 25fps and starts recording from the moment the context is created. Page loading and font loading in the first 2 seconds all get recorded. The delivered video has 2 seconds of blank/white flash at the beginning.

**Rules**:
- Provide a `render-video.js` tool that handles: warmup navigate → reload to restart animation → wait duration → ffmpeg trim head + convert to H.264 MP4
- The **frame 0** of the animation must be the complete initial state with layout already in place (not blank or loading)
- Want 60fps? Post-process with ffmpeg `minterpolate` — don't rely on the browser's source frame rate
- Want GIF? Two-phase palette (`palettegen` + `paletteuse`) — for 30s 1080p animations this can compress to 3MB

See `video-export.md` for the complete script calling instructions.

## 8. Batch Export — tmp Directory Must Include PID to Prevent Concurrency Conflicts

**The trap**: using `render-video.js` with 3 processes recording 3 HTML files in parallel. Because `TMP_DIR` was named with `Date.now()` only, 3 processes starting within the same millisecond shared the same tmp directory. The first process to finish cleaned up tmp — the other two got `ENOENT` when reading the directory, and all crashed.

**Rules**:
- Any temporary directory that may be shared by multiple processes must be named with **PID or a random suffix**:
  ```js
  const TMP_DIR = path.join(DIR, '.video-tmp-' + Date.now() + '-' + process.pid);
  ```
- If you genuinely want to parallelize multiple files, use shell `&` + `wait` rather than forking from a single node script
- For batch recording of multiple HTML files, the conservative approach: **run serially** (2 at most in parallel — 3 or more should queue)

## 9. Progress Bar / Replay Button in Recording — Chrome Elements Polluting the Video

**The trap**: the animation HTML had a `.progress` bar, `.replay` button, and `.counter` timestamp for human debugging during playback. When exported to MP4 for delivery, these elements appeared at the bottom of the video — like developer tools had been screen-captured.

**Rules**:
- Separate management of human-facing "chrome elements" (progress bar / replay button / footer / masthead / counter / phase labels) from the core video content
- **Adopt a naming convention** `.no-record`: any element with this class is automatically hidden by the recording script
- The recording script (`render-video.js`) injects CSS by default to hide common chrome class names:
  ```
  .progress .counter .phases .replay .masthead .footer .no-record [data-role="chrome"]
  ```
- Inject via Playwright's `addInitScript` (takes effect before each navigate, stable across reloads too)
- To view original HTML with chrome elements, add a `--keep-chrome` flag

## 10. Repeated Animation at Recording Start — Warmup Frame Leakage

**The trap**: the old `render-video.js` workflow was `goto → wait fonts 1.5s → reload → wait duration`. Recording starts from context creation — the animation has already played partway through during warmup. After reload it restarts from 0. The result: the video's first few seconds show "mid-animation + cut + animation starting from 0" — noticeably repetitive.

**Rules**:
- **Warmup and Record must use separate contexts**:
  - Warmup context (no `recordVideo` option): only responsible for loading the URL, waiting for fonts, then closing
  - Record context (with `recordVideo`): fresh state, animation recorded starting from t=0
- ffmpeg `-ss trim` can only cut a tiny bit of Playwright's startup latency (~0.3s) — **it cannot** mask warmup frames; the source must be clean
- Record context closing = the webm file is written to disk — that is Playwright's constraint
- Relevant code pattern:
  ```js
  // Phase 1: warmup (throwaway)
  const warmupCtx = await browser.newContext({ viewport });
  const warmupPage = await warmupCtx.newPage();
  await warmupPage.goto(url, { waitUntil: 'networkidle' });
  await warmupPage.waitForTimeout(1200);
  await warmupCtx.close();

  // Phase 2: record (fresh)
  const recordCtx = await browser.newContext({ viewport, recordVideo });
  const page = await recordCtx.newPage();
  await page.goto(url, { waitUntil: 'networkidle' });
  await page.waitForTimeout(DURATION * 1000);
  await page.close();
  await recordCtx.close();
  ```

## 11. Don't Draw "Fake Chrome" in the Canvas — Decorative Player UI Clashes with Real Chrome

**The trap**: the animation used a `Stage` component that already had a scrubber + timecode + pause button (these are `.no-record` chrome, hidden automatically on export). I also drew a decorative "magazine page number" progress bar at the bottom reading `00:60 ──── CLAUDE-DESIGN / ANATOMY`. It seemed polished. **Result**: users saw two progress bars — one from Stage's controls, one I drew. Visually they completely clashed; it was flagged as a bug. "Why does the video have a progress bar inside it?"

**Rules**:

- Stage already provides: scrubber + timecode + pause/replay button. **Do not draw** progress indicators, current timecodes, copyright attribution bars, or chapter counters inside the canvas — they either clash with chrome or are filler slop (violating the "earn its place" principle).
- "Page number feel," "magazine feel," "bottom attribution bar" — these are **high-frequency filler decorations** that AI adds automatically. Every time one appears, be suspicious — does it communicate something irreplaceable? Or is it just filling empty space?
- If you truly believe a bottom strip must exist (e.g., the animation's subject is a player UI itself), it must be **narratively necessary** and **visually distinct from the Stage scrubber** (different position, different form, different tone).

**Element ownership test** (every element drawn into the canvas must be able to answer this):

| It belongs to what | Action |
|------------|------|
| The narrative content of a specific scene | OK, keep it |
| Global chrome (for control / debugging) | Add `.no-record` class, hidden on export |
| **Neither a scene's narrative content nor chrome** | **Delete.** This is an ownerless element — it is invariably filler slop |

**Self-check (3 seconds before delivery)**: take a static screenshot and ask yourself —

- Is there anything in the frame "that looks like video player UI" (horizontal progress bar, timecode, control button shapes)?
- If yes: does removing it damage the narrative? If not — delete it.
- Is the same type of information (progress/time/attribution) appearing twice? Consolidate into chrome.

**Counter-examples**: drawing `00:42 ──── PROJECT NAME` at the bottom, "CH 03 / 06" chapter counter at the lower right, version number "v0.3.1" at the frame edge — all are fake chrome filler.

## 12. Recording Blank Lead-In + Recording Start Offset — The `__ready` × tick × lastTick Triple Trap

**Trap A (blank lead-in)**: 60-second animation exported as MP4 has 2–3 seconds of blank at the start. `ffmpeg --trim=0.3` can't cut it out.

**Trap B (start offset, 2026-04-20 real incident)**: exported a 24-second video; user perception was "video only starts playing at 19 seconds." In reality, the animation started recording from t=5, recorded to t=24, then looped back to t=0 and recorded another 5 seconds to end — so the last 5 seconds of the video were actually the true beginning of the animation.

**Root cause** (both traps share one root cause):

Playwright `recordVideo` starts writing WebM from the moment `newContext()` is called — at this point Babel/React/font loading takes L seconds (2–6s). The recording script waits for `window.__ready = true` as the anchor for "animation starts here" — this must be strictly paired with animation `time = 0`. Two common mistakes:

| Mistake | Symptom |
|------|------|
| `__ready` is set in `useEffect` or sync setup phase (before the first tick frame) | Recording script thinks animation started, but WebM is still recording a blank page → **blank lead-in** |
| tick's `lastTick = performance.now()` initialized at the **script top level** | Font loading L seconds counted as the first-frame `dt`, `time` instantly jumps to L → entire recording is delayed L seconds → **start offset** |

**✅ The Complete Correct Starter Tick Template** (required skeleton for all hand-written animations):

```js
// ━━━━━━ state ━━━━━━
let time = 0;
let playing = false;   // ❗ Default not playing — start only when fonts are ready
let lastTick = null;   // ❗ sentinel — first tick frame forces dt to 0 (don't use performance.now())
const fired = new Set();

// ━━━━━━ tick ━━━━━━
function tick(now) {
  if (lastTick === null) {
    lastTick = now;
    window.__ready = true;   // ✅ pair: "recording start" and "animation t=0" on the same frame
    render(0);               // render once more to ensure DOM is ready (fonts are ready now)
    requestAnimationFrame(tick);
    return;
  }
  const dt = (now - lastTick) / 1000;   // dt only advances after the first frame
  lastTick = now;

  if (playing) {
    let t = time + dt;
    if (t >= DURATION) {
      t = window.__recording ? DURATION - 0.001 : 0;  // don't loop during recording; keep 0.001s to retain final frame
      if (!window.__recording) fired.clear();
    }
    time = t;
    render(time);
  }
  requestAnimationFrame(tick);
}

// ━━━━━━ boot ━━━━━━
// Don't immediately rAF at the top level — wait for fonts before starting
document.fonts.ready.then(() => {
  render(0);                 // draw the initial frame first (fonts are ready)
  playing = true;
  requestAnimationFrame(tick);  // first tick will pair __ready + t=0
});

// ━━━━━━ seek interface (for render-video defensive correction) ━━━━━━
window.__seek = (t) => { fired.clear(); time = t; lastTick = null; render(t); };
```

**Why this template is correct**:

| Step | Why it must be this way |
|------|-------------|
| `lastTick = null` + first-frame `return` | Prevents L seconds between "script load" and "tick first run" from being counted as animation time |
| `playing = false` default | During font loading, even if `tick` runs it won't advance time — prevents rendering misalignment |
| `__ready` set in first tick frame | Recording script starts counting from this moment — the corresponding frame is the true t=0 of the animation |
| tick only starts inside `document.fonts.ready.then(...)` | Prevents font fallback width measurements and first-frame font jumps |
| `window.__seek` exists | Lets `render-video.js` make active corrections — second line of defense |

**Corresponding recording script defenses**:
1. Inject `window.__recording = true` via `addInitScript` (before page goto)
2. `waitForFunction(() => window.__ready === true)`, record offset at this moment for ffmpeg trim
3. **Additionally**: after `__ready`, proactively `page.evaluate(() => window.__seek && window.__seek(0))` to force-reset any HTML time drift to zero — this is the second line of defense against HTML that doesn't strictly follow the starter template

**Verification method**: after exporting MP4
```bash
ffmpeg -i video.mp4 -ss 0 -vframes 1 frame-0.png
ffmpeg -i video.mp4 -ss $DURATION-0.1 -vframes 1 frame-end.png
```
First frame must be animation t=0 initial state (not mid-animation, not black). Last frame must be animation final state (not some moment in a second loop).

**Reference implementation**: `assets/animations.jsx`'s Stage component and `scripts/render-video.js` both implement this protocol. Hand-written HTML must use the starter tick template — every line is a defense against a specific real bug.

## 13. Disable Loop During Recording — `window.__recording` Signal

**The trap**: animation Stage defaults to `loop=true` (convenient for browser preview). `render-video.js` waited an extra 300ms buffer after `duration` seconds before stopping — this 300ms caused Stage to enter the next loop cycle. When ffmpeg `-t DURATION` cut the output, the last 0.5–1s fell into the next loop cycle — the video ending suddenly jumped back to the first frame (Scene 1), making viewers think there was a bug. "Why does the video end back at the beginning?"

**Root cause**: no "I'm recording" handshake protocol between the recording script and HTML. HTML doesn't know it's being recorded and continues looping as it would in a browser session.

**Rules**:

1. **Recording script**: inject `window.__recording = true` in `addInitScript` (before page goto):
   ```js
   await recordCtx.addInitScript(() => { window.__recording = true; });
   ```

2. **Stage component**: recognize this signal and force loop=false:
   ```js
   const effectiveLoop = (typeof window !== 'undefined' && window.__recording) ? false : loop;
   // ...
   if (next >= duration) return effectiveLoop ? 0 : duration - 0.001;
   //                                                       ↑ keep 0.001 to prevent Sprite end=duration from being turned off
   ```

3. **Ending Sprite fadeOut**: during recording, set `fadeOut={0}` — otherwise the video will fade to transparent/dark at the end. Users expect a clean final frame to hold, not a fade-out. Recommended: always use `fadeOut={0}` on ending Sprites in hand-written HTML.

**Reference implementation**: `assets/animations.jsx`'s Stage and `scripts/render-video.js` both have built-in handshakes. Hand-written Stage must implement `__recording` detection — otherwise recording will invariably hit this trap.

**Verification**: after exporting MP4, `ffmpeg -ss 19.8 -i video.mp4 -frames:v 1 end.png` — check that the last 0.2 seconds is still the expected final frame, without a sudden switch to another scene.

## 14. 60fps Video Defaults to Frame Duplication — minterpolate Has Poor Compatibility

**The trap**: `convert-formats.sh` using `minterpolate=fps=60:mi_mode=mci...` generates 60fps MP4 that cannot be opened on some versions of macOS QuickTime / Safari (black screen or outright rejected). VLC / Chrome can open it.

**Root cause**: minterpolate produces H.264 elementary streams with SEI / SPS fields that some players have trouble parsing.

**Rules**:

- Default 60fps uses simple `fps=60` filter (frame duplication) — wide compatibility (QuickTime/Safari/Chrome/VLC all work)
- High-quality frame interpolation uses `--minterpolate` flag explicitly — but **must be locally tested** on the target player before delivery
- The value of the 60fps label is **platform algorithm recognition** (Bilibili / YouTube tag 60fps content for preferential streaming) — actual perceived smoothness improvement for CSS animations is minimal
- Add `-profile:v high -level 4.0` to improve general H.264 compatibility

**`convert-formats.sh` now defaults to compatibility mode.** If you need frame interpolation quality, add the `--minterpolate` flag:
```bash
bash convert-formats.sh input.mp4 --minterpolate
```

## 15. `file://` + External `.jsx` CORS Trap — Single-File Delivery Must Inline the Engine

**The trap**: animation HTML used `<script type="text/babel" src="animations.jsx"></script>` to load the engine externally. Open locally by double-clicking (`file://` protocol) → Babel Standalone makes an XHR request for `.jsx` → Chrome reports `Cross origin requests are only supported for protocol schemes: http, https, chrome, chrome-extension...` → the entire page is black, doesn't report `pageerror` — only reports a console error — easily misdiagnosed as "animation didn't trigger."

Starting an HTTP server may not help either — with a global proxy on the local machine, `localhost` may also go through the proxy and return 502 / connection failed.

**Rules**:

- **Single-file delivery (HTML that works by double-click)** → `animations.jsx` must be **inlined** into `<script type="text/babel">...</script>` — don't use `src="animations.jsx"`
- **Multi-file project (using an HTTP server for demo)** → external loading is fine, but clearly document the `python3 -m http.server 8000` command in the delivery
- Decision criterion: is the delivery to the user "an HTML file" or "a project directory with a server"? Former uses inline
- Stage component / animations.jsx is often 200+ lines — embedding it in an HTML `<script>` block is completely fine; don't worry about the size

**Minimum validation**: double-click the HTML you generated — **do not** open through any server. Only if Stage correctly displays the animation's first frame does it pass.

## 16. Cross-Scene Color Inversion Context — Don't Hardcode Colors in Canvas Elements

**The trap**: in a multi-scene animation, elements that **appear across all scenes** — `ChapterLabel` / `SceneNumber` / `Watermark` etc. — have `color: '#1A1A1A'` (dark text) hardcoded in the component. The first 4 scenes with light backgrounds were fine; in the 5th dark-background scene, "05" and the watermark became invisible — no error, no check triggered, critical information hidden.

**Rules**:

- **Canvas elements reused across multiple scenes** (chapter labels / scene numbers / timecodes / watermarks / copyright bars) **must not have hardcoded color values**
- Use one of three approaches instead:
  1. **`currentColor` inheritance**: element only writes `color: currentColor`; parent scene container sets the `color` as a computed value
  2. **invert prop**: component accepts `<ChapterLabel invert />` to manually toggle between light/dark
  3. **Auto-calculate based on background**: `color: contrast-color(var(--scene-bg))` (CSS 4 new API, or determine via JS)
- Before delivery, use Playwright to capture **a representative frame for each scene**, then visually verify that "cross-scene elements" are visible in every scene

The hidden nature of this trap is that **there is no bug alarm**. Only a human eye or OCR can detect it.

## Quick Self-Check (5 Seconds Before Starting Work)

- [ ] Does every `position: absolute` element have a `position: relative` parent?
- [ ] Do all special characters in the animation (`␣` `⌘` `emoji`) exist in the chosen font?
- [ ] Does the Grid/Flex template's count match the JS data's length?
- [ ] Is there a cross-fade between scene switches with no >0.3s blank gap?
- [ ] Is DOM measurement code wrapped in `document.fonts.ready.then()`?
- [ ] Is `render(t)` pure, or does it have an explicit reset mechanism?
- [ ] Is frame 0 the complete initial state, not blank?
- [ ] Is there no "fake chrome" decoration in the canvas (progress bar/timecode/bottom attribution bar clashing with Stage scrubber)?
- [ ] Is `window.__ready = true` set synchronously in the animation tick's first frame? (use animations.jsx built-in; add it yourself in hand-written HTML)
- [ ] Does Stage detect `window.__recording` and force loop=false? (must add for hand-written HTML)
- [ ] Is the ending Sprite's `fadeOut` set to 0 (video ends on a clean final frame)?
- [ ] Does 60fps MP4 default to frame duplication mode (compatibility) — use `--minterpolate` only for high-quality frame interpolation?
- [ ] After export, is frame 0 + the final frame verified as animation initial/final state?
- [ ] If involving specific brands (Stripe/Anthropic/Lovart/...): has the "brand asset protocol" been completed (SKILL.md §1.a five steps)? Has `brand-spec.md` been written?
- [ ] For single-file delivery HTML: is `animations.jsx` inlined, not `src="..."`? (external .jsx under file:// causes CORS black screen)
- [ ] Do elements appearing across scenes (chapter labels/watermarks/scene numbers) have no hardcoded colors? Are they visible against every scene background?
