# Value Proposition Canvas — Definições dos Quadrantes

## SEGMENTO DE CLIENTES (Lado Direito — O Perfil)

### Tarefas do Cliente (Customer Jobs)
Coisas que os clientes tentam realizar no trabalho ou na vida:
- **Funcionais**: tarefas concretas (ex: preparar um relatório, tomar uma decisão)
- **Sociais**: como querem ser vistos pelos outros (ex: parecer competente, ganhar status)
- **Emocionais**: como querem se sentir (ex: segurança, confiança, tranquilidade)
- **Necessidades básicas**: conforto, higiene, bem-estar

### Dores (Pains)
Qualquer coisa que incomode antes, durante ou depois de tentar realizar uma tarefa:
- **Resultados indesejados**: resultados ruins, falhas, retrabalho
- **Obstáculos**: o que impede de iniciar ou concluir a tarefa
- **Riscos**: o que pode dar errado (financeiro, social, reputacional)
- **Sentimentos negativos**: frustração, medo, preocupação

### Ganhos (Gains)
Resultados e benefícios que os clientes desejam:
- **Exigidos**: mínimo esperado para a solução funcionar
- **Esperados**: padrão razoável esperado (mesmo sem ser explícito)
- **Desejados**: vão além do esperado, seriam ótimos de ter
- **Inesperados**: surpresas positivas que encantam

---

## PROPOSTA DE VALOR (Lado Esquerdo — O Mapa de Valor)

### Produtos e Serviços
Lista tangível de tudo sobre o que a proposta de valor se baseia. O que ajuda o cliente a concluir suas tarefas.

### Analgésicos (Pain Relievers)
Como os produtos/serviços aliviam as dores específicas do perfil:
- Eliminam ou reduzem incômodos, riscos e obstáculos
- Cada analgésico deve mapear para uma dor listada no perfil

### Criadores de Ganhos (Gain Creators)
Como os produtos/serviços geram os ganhos do perfil:
- Produzem resultados e benefícios esperados ou surpreendentes
- Cada criador deve mapear para um ganho listado no perfil

---

## Critérios de Fit (Encaixe)

O **Product-Market Fit** acontece quando:
- Analgésicos resolvem as **dores mais críticas** (não apenas as menores)
- Criadores de ganhos entregam os **ganhos essenciais** (não apenas os desejados)
- Há correspondência clara entre cada elemento do Mapa de Valor e o Perfil

**Lacunas comuns:**
- Dor grave sem analgésico → risco de abandono
- Ganho esperado sem criador → promessa não cumprida
- Produto sem job correspondente → feature órfã