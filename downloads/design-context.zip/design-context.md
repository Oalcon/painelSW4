# Design Context: Starting from What Already Exists

**This is the single most important thing about this skill.**

Great hi-fi design always grows from existing design context. **Designing hi-fi from scratch is a last resort and will always produce generic work.** So at the start of every design task, the first question is: is there anything to reference?

## What Is Design Context

In descending order of priority:

### 1. User's Design System / UI Kit
Component libraries, color tokens, typography specs, and icon systems that already exist in the user's product. **The ideal scenario.**

### 2. User's Codebase
If the user provides a codebase, there are live component implementations inside it. Read those component files:
- `theme.ts` / `colors.ts` / `tokens.css` / `_variables.scss`
- Specific components (Button.tsx, Card.tsx)
- Layout scaffolds (App.tsx, MainLayout.tsx)
- Global stylesheets

**Read the code and copy the exact values**: hex codes, spacing scale, font stack, border radius. Don't redraw from memory.

### 3. User's Published Product
If the user has a live product but didn't provide code, use Playwright or ask the user to provide screenshots.

```bash
# Screenshot a public URL with Playwright
npx playwright screenshot https://example.com screenshot.png --viewport-size=1920,1080
```

This reveals the real visual vocabulary.

### 4. Brand Guidelines / Logo / Existing Assets
The user may have: logo files, brand color specs, marketing materials, slide templates. All of these are context.

### 5. Competitor References
The user says "something like XX's website" — ask them to provide the URL or a screenshot. **Don't** work from a vague impression in your training data.

### 6. Known Design Systems (fallback)
If none of the above are available, use a recognized design system as a base:
- Apple HIG
- Material Design 3
- Radix Colors (color palette)
- shadcn/ui (components)
- Tailwind default palette

Tell the user explicitly what you're using, so they know this is a starting point, not a final decision.

## Process for Gathering Context

### Step 1: Ask the user

The required checklist at the start of any task (from `workflow.md`):

```markdown
1. Do you have an existing design system / UI kit / component library? Where is it?
2. Do you have a brand guide, color spec, or typography spec?
3. Can you give me screenshots or a URL of your existing product?
4. Is there a codebase I can read?
```

### Step 2: When the user says "no," help them look

Don't give up immediately. Try:

```markdown
Let me see if there are any clues:
- Do any previous projects have relevant design work?
- What colors / fonts does your company's marketing website use?
- What style is your product logo? Can you send me an image?
- Are there any products you admire that could serve as reference?
```

### Step 3: Read everything you can find

If the user provides a codebase path, read:
1. **List the file structure first**: look for style / theme / component-related files
2. **Read theme / token files**: lift specific hex/px values
3. **Read 2–3 representative components**: understand the visual vocabulary (hover states, shadows, borders, padding patterns)
4. **Read the global stylesheet**: base resets, font loading
5. **If there's a Figma link / screenshot**: look at it, but **trust the code more**

**Important**: **Don't** glance at something and then work from impression. You need to walk away with 30+ specific values before you've truly absorbed the context.

### Step 4: Vocalize the system you'll use

After reviewing the context, tell the user the system you're going to work with:

```markdown
Based on your codebase and product screenshots, here's the design system I've extracted:

**Colors**
- Primary: #C27558 (from tokens.css)
- Background: #FDF9F0
- Text: #1A1A1A
- Muted: #6B6B6B

**Typography**
- Display: Instrument Serif (from @font-face in global.css)
- Body: Geist Sans
- Mono: JetBrains Mono

**Spacing** (from your scale system)
- 4, 8, 12, 16, 24, 32, 48, 64

**Shadow pattern**
- `0 1px 2px rgba(0,0,0,0.04)` (subtle card)
- `0 10px 40px rgba(0,0,0,0.1)` (elevated modal)

**Border-radius**
- Small components: 4px, cards: 12px, buttons: 8px

**Component vocabulary**
- Button: filled primary, outlined secondary, ghost tertiary — all 8px border-radius
- Card: white background, subtle shadow, no border

I'll start building with this system. Does this look right to you?
```

Wait for user confirmation before starting.

## Designing Without Context (Fallback)

**Strong warning**: Output quality drops significantly in this situation. Tell the user clearly.

```markdown
You don't have design context, so I can only work from general intuition.
The output will be "looks OK but lacks distinctiveness."
Do you want to continue, or would you like to find some reference material first?
```

If the user insists on proceeding, make decisions in this order:

### 1. Choose an aesthetic direction
Don't produce a generic result. Pick a clear direction:
- brutally minimal
- editorial/magazine
- brutalist/raw
- organic/natural
- luxury/refined
- playful/toy
- retro-futuristic
- soft/pastel

Tell the user which one you've chosen.

### 2. Choose a known design system as the skeleton
- Use Radix Colors for the color palette (https://www.radix-ui.com/colors)
- Use shadcn/ui for component vocabulary (https://ui.shadcn.com)
- Use Tailwind spacing scale (multiples of 4)

### 3. Choose a distinctive font pairing

Don't use Inter/Roboto. Suggested combinations (all free via Google Fonts):
- Instrument Serif + Geist Sans
- Cormorant Garamond + Inter Tight
- Bricolage Grotesque + Söhne (paid)
- Fraunces + Work Sans (note: Fraunces has been overused by AI)
- JetBrains Mono + Geist Sans (technical feel)

### 4. Give reasoning for every key decision

Don't make decisions silently. Write in the HTML comments:

```html
<!--
Design decisions:
- Primary color: warm terracotta (oklch 0.65 0.18 25) — fits the "editorial" direction  
- Display: Instrument Serif for humanist, literary feel
- Body: Geist Sans for cleanness contrast
- No gradients — committed to minimal, no AI slop
- Spacing: 8px base, golden ratio friendly (8/13/21/34)
-->
```

## Import Strategy (When User Provides a Codebase)

If the user says "use this codebase as reference":

### Small (< 50 files)
Read everything; internalize the context.

### Medium (50–500 files)
Focus on:
- `src/components/` or `components/`
- All style / token / theme-related files
- 2–3 representative full-page components (Home.tsx, Dashboard.tsx)

### Large (> 500 files)
Ask the user to narrow the focus:
- "I'm building the settings page" → read existing settings-related files
- "I'm building a new feature" → read the overall shell + closest reference
- Don't try to be comprehensive; be precise

## Working with Figma / Design Mockups

If the user provides a Figma link:

- **Don't** expect to "convert Figma to HTML" directly — that requires additional tools
- Figma links are usually not publicly accessible
- Ask the user to: export as **screenshots** and send them to you + tell you the specific color/spacing values

If you only receive a Figma screenshot, tell the user:
- I can see the visuals, but can't extract precise values
- Please share key numbers (hex, px) with me, or export as code (Figma supports this)

## Final Reminder

**The quality ceiling of a project's design is determined by the quality of the context you have.**

Spending 10 minutes gathering context is more valuable than spending 1 hour designing hi-fi from scratch.

**When you don't have context, ask the user for it first — don't just push through.**
