---
name: Radar de Mercado G4
slug: radar-mercado
description: >
  Gera o Radar de Mercado G4: pesquisa concorrentes por tema de produto G4 e entrega
  o relatório completo como HTML no chat com identidade visual G4 (Navy Blue + Royal Golden + Manrope).
  Use sempre que o usuário digitar /radar-mercado ou pedir para gerar, rodar ou ver o radar de mercado G4.
triggers:
  - /radar-mercado
---

# Radar de Mercado G4

## O que esta skill faz

1. Pergunta o tema/foco da pesquisa (ou usa o que o usuário já pediu)
2. Pesquisa movimentos de concorrentes, novos entrantes, notícias e tendências por tema de produto G4
3. Consulta o Supabase para puxar dados reais de CSAT/NPS dos últimos 90 dias
4. Gera relatório HTML interativo com identidade visual G4 e entrega no chat via `web-app-preview` + `filecard`

## Quando usar

- Usuário digita `/radar-mercado`
- Usuário pede para "gerar o radar", "rodar a análise de mercado" ou "ver o relatório de mercado"

---

## Fluxo de execução

### PASSO 1 — Entender o pedido

Se o usuário não especificou o tema, perguntar:
> "Quer o Radar completo dos 8 temas G4 ou uma análise focada em um tema específico?"

Se o usuário já informou o tema ou pediu o radar completo, seguir direto para o PASSO 2.

Usar **sempre as últimas 2 semanas** como período implícito da pesquisa.

---

### PASSO 2 — Pesquisar concorrentes (5 agentes paralelos)

Lance **5 subagentes em paralelo** simultaneamente (subagent_run), cada um com WebSearch + WebFetch. Aguarde todos retornarem antes de continuar.

| Agente | Temas |
|--------|-------|
| Agente 1 | Vendas & Receita + Marketing & Growth |
| Agente 2 | Gestão Financeira + Planejamento & Gestão |
| Agente 3 | IA & Tecnologia |
| Agente 4 | Pessoas & Cultura + Customer Experience |
| Agente 5 | Mentoring & Comunidade |

**Concorrentes por tema:**

| Tema | Produtos G4 | Concorrentes |
|------|-------------|--------------|
| Vendas & Receita | G4 Sales, G4 Sprints Receita, G4 Founder-led Growth | Growth Machine, IEV, VENDE-C, Winning Sales |
| Marketing & Growth | G4 Marketing & Growth, G4 Traction | RD Station, HubSpot Academy, Rock Content/Analog HQ |
| Gestão Financeira | G4 Sprint em Finanças | Treasy, CFO4U, Nibo, Omie |
| Planejamento & Gestão | G4 Gestão Empresarial, G4 na Prática, Sprints Planejamento | Endeavor, FDC, Sebrae |
| IA & Tecnologia | G4 Academia de IA | FIA, Sebrae+, Alura, Rocketseat |
| Pessoas & Cultura | G4 Sprints Cultura, G4 Gestão de Pessoas, G4 Academia Liderança | Conquer, GPTW, Gupy |
| Customer Experience | G4 Customer Experience | CS Academy, Track.co |
| Mentoring & Comunidade | G4 Mentoring Anual, G4 Consulting, G4 Network | EO, YPO, B55 |

Cada agente deve retornar para cada tema:
- Movimentos dos concorrentes (o que lançaram/mudaram + **URL exata da notícia ou anúncio** como fonte)
- Novos entrantes (o que entregam + qual produto G4 concorre + **URL da fonte**)
- Tendências (Consolidado / Chegando / Inicial — cada uma com **URL de pelo menos 1 fonte**)
- SWOT resumido (Forças / Fraquezas / Oportunidades / Ameaças)
- Oportunidades de produto (Gap + Evidência quantitativa + Posição G4)

**Regra de fontes:** nunca incluir um movimento, entrante ou tendência sem uma URL real que o comprove. Se não houver fonte verificável, não incluir o item.

---

### PASSO 2b — Puxar dados de CSAT/NPS do Supabase

Consultar a tabela `feedback_metrics_fct` para obter métricas reais de satisfação dos últimos 90 dias.

```python
import urllib.request, json, sys
from datetime import datetime, timedelta
sys.stdout.reconfigure(encoding='utf-8')

BASE = 'https://qhxrusvthenhajybhdyv.supabase.co'
with open(r'C:\Users\w.estevam_g4educacao\.g4os-public\workspaces\my-workspace\sources\supabase-api\config.json', encoding='utf-8') as f:
    cfg = json.load(f)
TOKEN = cfg['api']['token']

HEADERS = {
    'Authorization': f'Bearer {TOKEN}',
    'apikey': TOKEN,
    'Content-Type': 'application/json'
}

start_date = (datetime.now() - timedelta(days=90)).strftime('%Y-%m-%d')

url = (
    f'{BASE}/rest/v1/feedback_metrics_fct?'
    f'select=csat_mentor_nota,csat_mentor_relevancia,csat_mentor_clareza,'
    f'csat_mentor_aplicabilidade,csat_mentor_inovacao,'
    f'csat_onboarding_aula_inaugural,csat_onboarding_clareza_qualidade,'
    f'csat_onboarding_atendimento,csat_org_estrutura,csat_org_alimentacao,'
    f'csat_org_atendimento,csat_org_entregaveis,nps_score,turma'
    f'&responded_at=gte.{start_date}'
    f'&is_test=eq.false&is_duplicate=eq.false'
    f'&limit=3000'
)
req = urllib.request.Request(url, headers=HEADERS)
with urllib.request.urlopen(req) as r:
    data = json.loads(r.read().decode())

def avg(field):
    vals = [d[field] for d in data if d.get(field) is not None]
    return round(sum(vals) / len(vals), 2) if vals else None

nps_scores = [d['nps_score'] for d in data if d.get('nps_score') is not None]
if nps_scores:
    promoters = sum(1 for n in nps_scores if n >= 9)
    detractors = sum(1 for n in nps_scores if n <= 6)
    nps = round((promoters - detractors) / len(nps_scores) * 100)
else:
    nps = None

supabase_metrics = {
    'periodo': f'{start_date} a hoje',
    'total_respostas': len(data),
    'turmas_cobertas': len(set(d['turma'] for d in data if d.get('turma'))),
    'atributos': {
        'Qualidade dos Mentores': avg('csat_mentor_nota'),
        'Relev\u00e2ncia do Conte\u00fado': avg('csat_mentor_relevancia'),
        'Clareza de Ensino': avg('csat_mentor_clareza'),
        'Aplicabilidade Pr\u00e1tica': avg('csat_mentor_aplicabilidade'),
        'Inova\u00e7\u00e3o': avg('csat_mentor_inovacao'),
        'Onboarding / Aula Inaugural': avg('csat_onboarding_aula_inaugural'),
        'Clareza & Qualidade': avg('csat_onboarding_clareza_qualidade'),
        'Atendimento': avg('csat_onboarding_atendimento'),
        'Estrutura / Organiza\u00e7\u00e3o': avg('csat_org_estrutura'),
        'Entreg\u00e1veis': avg('csat_org_entregaveis'),
    },
    'nps_geral': nps
}

print(f"Supabase: {supabase_metrics['total_respostas']} respostas de {supabase_metrics['turmas_cobertas']} turmas")
for attr, val in supabase_metrics['atributos'].items():
    status = '\u2705' if val and val >= 4.5 else '\u26a0\ufe0f' if val and val >= 4.0 else '\u274c'
    print(f"  {status} {attr}: {val}")
print(f"  NPS geral: +{nps}")
```

Usar `supabase_metrics` no PASSO 3 para popular o slide "CSAT & NPS" com dados reais.

**Regra de cores:**
- ≥ 4.5 → `tag-green` / ✅ Forte
- 4.0–4.49 → `tag-yellow` / ⚠️ Atenção
- < 4.0 → `tag-red` / ❌ Fraco

---

### PASSO 3 — Gerar o HTML e entregar no chat

Salvar o arquivo em:
```
C:\Users\w.estevam_g4educacao\.g4os-public\workspaces\my-workspace\main\radar_[tema]_[mes][ano].html
```

Exibir com `web-app-preview` + `filecard`.

**Modelo de referência obrigatório:** `main/radar-template-v2.html` — copiar INTEGRALMENTE o `<style>` e o bloco JavaScript desse arquivo como base.

---

#### Estrutura padrão v2

| # | Slide | Conteúdo |
|---|-------|----------|
| 01 | **Cover** | Título, período, badges |
| 02 | **Sinais Executivos** | 3 caixas: 🔴 Ameaça · 🟡 Atenção · 🟢 Oportunidade |
| 03 | **Tamanho do Mercado** | Funil TAM + barras |
| 04 | **Novos Entrantes** | Tabela consolidada com urgência |
| 05–20 | **Temas — 2 slides por tema** | Intel + Posição |
| N-1 | **CSAT & NPS** | Dados Supabase reais |
| N | **Síntese & Recomendações** | 6 impl-cards |

**2 slides por tema:** Slide A (movimentos + tabela comparativa) · Slide B (tendências + SWOT + oportunidades).

**Modo Temático** — 2–4 temas relevantes ao pedido.
**Modo Completo** — 8 temas fixos (~22 slides total).

---

#### Layout — identidade visual G4

- Fundo: `#F5F4F3` · Borda slides: `4px solid #B9915B` · Cover: `#011422`
- Tipografia: Manrope, 13px, `#011422`
- Títulos de slide = **conclusões analíticas**, nunca rótulos genéricos

#### Componentes (CSS de `main/radar-template-v2.html`)

`.nav-sidebar` · `.exec-signal.threat/watch/opp` · `.intel-movements` · `.trend-pill.consolidado/chegando/inicial` · `.opp-card.alta/media/baixa` · `.funnel` · `.bar-row` · `.matrix-wrap` · `.impl-cards` · `tr.row-urgent` · `tr.row-g4` · `.two-col/.three-col/.four-col`

Sidebar: todo slide precisa de `id` + `data-nav` + `data-nav-section`. O JS do template constrói automaticamente.

---

## Regras de qualidade

- Todo movimento/entrante/tendência precisa de URL real verificável. Sem fonte = sem item
- Links apontam para a página específica — nunca o domínio raiz
- Novos entrantes: o que prometem + qual produto G4 concorre
- Oportunidades: Gap / Evidência quantitativa / Posição G4
- CSAT: ordenar por nota decrescente, omitir atributo Preço
- Python: sempre `encoding='utf-8'` e `sys.stdout.reconfigure(encoding='utf-8')`
- Scripts com acentos: salvar em `.py` e executar via Bash
