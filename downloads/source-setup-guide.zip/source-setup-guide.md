# Source Setup Guide

Reference for the Morning Briefing interview. Maps each data source to its G4 OS integration and setup path.

---

## Available Sources and What They Provide

| Source | What it covers | G4 OS Integration |
|--------|---------------|-------------------|
| Google Calendar | Events, meetings, reminders | `google-workspace-api` or Google Workspace MCP |
| Gmail | Inbox, threads, sent email | `google-workspace-api` or Google Workspace MCP |
| Slack | DMs, channel messages, mentions | Slack MCP source |
| Notion | Docs, databases, tasks, projects | `notion` |
| Databricks | Business data — sales, funnels, pipeline, people | `databricks-sql` |
| Google Drive | Files, documents, shared folders | `google-workspace-api` or Google Workspace MCP |

---

## Checking What's Connected

During the briefing interview, check the session's available sources. Present only those that are connected (status=ready) to the user. Do not suggest sources that are not configured in the workspace.

---

## Handling Missing Sources

If the user wants a source that isn't connected:

1. Note it during the interview — do not block the rest of the setup.
2. After saving preferences, offer to set it up:

```
You mentioned [source] but it's not connected yet. Want me to help set it up now?
```

### Setup paths by source

**Slack**
- Use skill: `setup-slack`
- Invoke: `/setup-slack`
- What it does: Installs the Slack MCP server, configures OAuth, and creates the source in the workspace.

**Google Calendar / Gmail / Drive**
- Source slug: `google-workspace-api`
- Guide: available in your workspace at `sources/google-workspace-api/guide.md` once configured
- Auth: OAuth via `source_google_oauth_trigger`

**Notion**
- Source slug: `notion`
- Auth: OAuth or integration token
- Activate in session: `activate_sources` with slug `notion`

**Databricks**
- Source slug: `databricks-sql`
- Guide: available in your workspace at `sources/databricks-sql/guide.md` once configured
- Used for business metrics — requires credentials from your Databricks admin

---

## MCP Tool Reference for Briefing

When generating the briefing, use these tools per source:

| Source | Tool to use | What to fetch |
|--------|-------------|---------------|
| Google Calendar | `google-workspace-api` — `events.list` | Today's events (`timeMin`=today 00:00, `timeMax`=today 23:59) |
| Gmail | `google-workspace-api` — `messages.list` | Unread from last 24h, label `INBOX` |
| Slack | `mcp__<your-slack-source>__conversations_history` | Unread DMs + `search_messages` for mentions |
| Notion | `mcp__notion__API-post-search` | Pages updated since yesterday |
| Databricks | `mcp__databricks-sql__api_databricks-sql` | Query per always-on topic in preferences |

> Replace `<your-slack-source>` with the slug of your Slack source (e.g. `slack` or `slack-workspace`).

---

## Graceful Degradation

If a source is configured but fails during briefing generation:
- Log `(source unavailable)` next to that section
- Continue generating the briefing with the remaining sources
- Do not abort or show an error to the user
- Suggest re-checking the source connection at the end of the briefing if multiple sources fail
