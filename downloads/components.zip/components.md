# Reusable Component Patterns

Smaller building blocks that go inside slide layouts.

---

## Accent Bar

```html
<div style="width: 80px; height: 8px; background: linear-gradient(90deg, #FF5756, #FF8A89); margin-bottom: 40px; border-radius: 4px;"></div>
```

Small variant:
```html
<div style="width: 60px; height: 6px; background: linear-gradient(90deg, #FF5756, #FF8A89); border-radius: 3px;"></div>
```

---

## Badge / Tag

**Highlighted:**
```html
<div style="background: rgba(32,99,173,0.2); border: 1px solid #2063AD; padding: 10px 20px; border-radius: 30px; font-size: 14px; font-weight: 600; color: #FFFFFF; letter-spacing: 1px; text-transform: uppercase;">Label</div>
```

**Default:**
```html
<div style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); padding: 10px 20px; border-radius: 30px; font-size: 14px; font-weight: 600; color: #BCD6F6; letter-spacing: 1px; text-transform: uppercase;">Label</div>
```

---

## Highlight Box

```html
<div style="background: rgba(32,99,173,0.1); border-left: 3px solid #2063AD; padding: 15px; border-radius: 0 4px 4px 0;">
    <div style="font-size: 12px; color: #BCD6F6; line-height: 1.4;">
        <strong style="color: #FFFFFF;">Key Point:</strong> Description here.
    </div>
</div>
```

Red variant (for warnings/alerts):
```html
<div style="background: rgba(255,87,86,0.1); border-left: 3px solid #FF5756; padding: 15px; border-radius: 0 4px 4px 0;">
    ...
</div>
```

---

## CSS Bar Chart

```html
<div style="display: flex; flex-direction: column; gap: 5px;">
    <div style="display: flex; justify-content: space-between; font-size: 12px; color: #BCD6F6; font-weight: 600;">
        <span>Label</span><span>75%</span>
    </div>
    <div style="height: 6px; background: rgba(255,255,255,0.05); border-radius: 3px; overflow: hidden;">
        <div style="width: 75%; height: 100%; background: #2063AD; border-radius: 3px;"></div>
    </div>
</div>
```

---

## Big Stat Number

```html
<div>
    <div style="font-size: 56px; font-weight: 700; color: #FFFFFF; line-height: 1;">57%</div>
    <div style="font-size: 14px; color: #BCD6F6; font-weight: 500;">Stat Label</div>
    <div style="font-size: 12px; color: #5A7CA0; margin-top: 5px;">
        <i class="fas fa-arrow-up" style="color: #4CAF50;"></i> +2.4pp vs previous
    </div>
</div>
```

---

## KPI Card

```html
<div style="flex: 1; background: rgba(32,99,173,0.1); padding: 15px 20px; border-radius: 4px; position: relative; overflow: hidden;">
    <div style="font-size: 12px; color: #BCD6F6; text-transform: uppercase; margin-bottom: 5px;">KPI Label</div>
    <div style="font-size: 36px; font-weight: 700;">Value</div>
    <div style="font-size: 12px; margin-top: 5px; color: #4CAF50; display: flex; align-items: center; gap: 5px;">
        <i class="fas fa-arrow-up"></i> +X.X pp vs 2025
    </div>
    <!-- Right accent stripe -->
    <div style="position: absolute; right: 0; top: 0; bottom: 0; width: 4px; background: #4CAF50;"></div>
</div>
```

---

## Question Box

```html
<div style="background: rgba(32,99,173,0.15); border-left: 3px solid #BCD6F6; padding: 10px 15px; font-style: italic; color: #BCD6F6; font-size: 12px;">
    <span style="font-weight: 700; color: #FFFFFF; font-style: normal; text-transform: uppercase; margin-right: 5px;">Pergunta:</span>
    "The survey question text here?"
</div>
```

---

## Card Header (with icon)

```html
<div style="display: flex; align-items: center; gap: 10px; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid rgba(255,255,255,0.05);">
    <div style="width: 32px; height: 32px; background: rgba(32,99,173,0.2); border-radius: 6px; display: flex; align-items: center; justify-content: center; color: #BCD6F6; font-size: 14px;">
        <i class="fas fa-icon"></i>
    </div>
    <div style="font-size: 14px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">Card Title</div>
</div>
```

---

## Decorative Background Circles

```html
<div style="position: absolute; border-radius: 50%; border: 1px solid rgba(255,255,255,0.05); width: 600px; height: 600px; top: -100px; right: -100px; pointer-events: none;"></div>
<div style="position: absolute; border-radius: 50%; border: 1px solid rgba(255,255,255,0.03); width: 800px; height: 800px; top: -200px; right: -200px; pointer-events: none;"></div>
<div style="position: absolute; border-radius: 50%; border: 1px solid rgba(32,99,173,0.1); width: 400px; height: 400px; bottom: -100px; left: -100px; pointer-events: none;"></div>
```

---

## Slide Page Header

Standard header used on content slides:

```html
<div style="margin-bottom: 30px; border-bottom: 1px solid #2063AD; padding-bottom: 15px;">
    <h1 style="font-size: 32px; font-weight: 700; margin-bottom: 5px;">Slide Title</h1>
    <div style="font-size: 16px; color: #BCD6F6; font-weight: 400;">Subtitle or context</div>
</div>
```

---

## Trend Indicator

**Positive:**
```html
<div style="font-size: 12px; color: #4CAF50; display: flex; align-items: center; gap: 5px;">
    <i class="fas fa-arrow-up"></i> +X.X pp vs previous
</div>
```

**Negative:**
```html
<div style="font-size: 12px; color: #FF5756; display: flex; align-items: center; gap: 5px;">
    <i class="fas fa-arrow-down"></i> -X.X pp vs previous
</div>
```

---

## Custom Chart Legend

```html
<div style="display: flex; justify-content: flex-end; gap: 20px; margin-bottom: 10px;">
    <div style="display: flex; align-items: center; gap: 8px; font-size: 12px; color: #BCD6F6;">
        <div style="width: 12px; height: 12px; border-radius: 2px; background: #2063AD;"></div>
        <span>Series A</span>
    </div>
    <div style="display: flex; align-items: center; gap: 8px; font-size: 12px; color: #BCD6F6;">
        <div style="width: 12px; height: 12px; border-radius: 2px; background: #FF5756;"></div>
        <span>Series B</span>
    </div>
</div>
```

---

## Browser Navigator Template (`index.html`)

Create this as `index.html` after all slides are finalized. Opens in the browser via `open index.html`. Uses nested `<iframe src="slide-XX.html">` to load individual slide files from disk.

Features:
- Arrow key + swipe navigation (NO click-to-advance)
- Speaker notes panel (toggle with "N" key)
- Fullscreen support ("F" key)
- Dot indicators + slide counter
- Auto-scales to viewport

**IMPORTANT**: No click handlers on the slide area. Arrow keys and swipe only.

> **Note**: This template is browser-first. For chat checks, prefer a single `html-preview` with `items` (multiple slides) to get inline arrow navigation in chat. For shared URLs, include `html` fallback content when possible; otherwise local `src` paths show an explicit unavailable message.

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{Presentation Title}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { background: #050B14; font-family: 'Montserrat', sans-serif; color: #fff; overflow: hidden; }

        /* Main layout */
        .presenter {
            width: 100vw; height: 100vh;
            display: flex;
        }

        /* Slide viewer */
        .viewer {
            flex: 1;
            display: flex; align-items: center; justify-content: center;
            position: relative;
        }
        iframe {
            width: 1280px; height: 720px;
            border: none;
            transform-origin: center center;
            background: #0A1626;
        }

        /* Navigation arrows */
        .nav-btn {
            position: absolute; top: 50%; transform: translateY(-50%);
            background: rgba(32,99,173,0.2); border: 1px solid rgba(32,99,173,0.4);
            color: #BCD6F6; font-size: 24px; padding: 15px 20px;
            cursor: pointer; z-index: 100; border-radius: 8px;
            transition: all 0.2s; opacity: 0;
        }
        .viewer:hover .nav-btn { opacity: 1; }
        .nav-btn:hover { background: rgba(32,99,173,0.5); color: #fff; }
        .prev { left: 20px; }
        .next { right: 20px; }

        /* Bottom bar */
        .bottom-bar {
            position: fixed; bottom: 0; left: 0; right: 0;
            display: flex; align-items: center; justify-content: center;
            gap: 20px; padding: 15px 20px;
            background: rgba(5,11,20,0.9);
            z-index: 200;
        }
        .counter { font-size: 13px; color: #5A7CA0; }
        .thumbnails { display: flex; gap: 6px; }
        .thumb {
            width: 10px; height: 10px; border-radius: 50%;
            background: rgba(255,255,255,0.15); cursor: pointer;
            transition: all 0.2s;
        }
        .thumb.active { background: #2063AD; transform: scale(1.3); }
        .thumb:hover { background: rgba(32,99,173,0.6); }

        /* Keyboard hints */
        .hints {
            position: fixed; top: 15px; right: 15px;
            font-size: 11px; color: #5A7CA0;
            opacity: 0; transition: opacity 0.3s;
            z-index: 200;
        }
        body:hover .hints { opacity: 1; }
        kbd {
            background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.15);
            padding: 2px 6px; border-radius: 3px; font-family: 'Montserrat', sans-serif;
            font-size: 10px;
        }

        /* Speaker notes panel */
        .notes-panel {
            width: 0; overflow: hidden;
            background: #0A1626; border-left: 1px solid rgba(32,99,173,0.3);
            transition: width 0.3s ease;
            display: flex; flex-direction: column;
        }
        .notes-panel.open { width: 380px; }
        .notes-header {
            padding: 20px; border-bottom: 1px solid rgba(32,99,173,0.2);
            font-size: 13px; font-weight: 600; color: #BCD6F6;
            text-transform: uppercase; letter-spacing: 1px;
            display: flex; justify-content: space-between; align-items: center;
        }
        .notes-close {
            background: none; border: none; color: #5A7CA0;
            cursor: pointer; font-size: 16px;
        }
        .notes-content {
            padding: 20px; flex: 1; overflow-y: auto;
            font-size: 14px; color: #BCD6F6; line-height: 1.6;
        }
        .notes-content h3 { color: #FFFFFF; font-size: 15px; margin-bottom: 10px; }
        .notes-content ul { padding-left: 18px; margin-bottom: 15px; }
        .notes-content li { margin-bottom: 6px; }
        .notes-content .timing {
            font-size: 12px; color: #5A7CA0; font-style: italic;
            border-top: 1px solid rgba(32,99,173,0.15); padding-top: 12px; margin-top: 12px;
        }

        /* Progress bar */
        .progress-bar {
            position: fixed; top: 0; left: 0; height: 3px;
            background: linear-gradient(90deg, #2063AD, #FF5756);
            transition: width 0.3s ease; z-index: 300;
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="progress-bar" id="progress"></div>

    <div class="hints">
        <kbd>←</kbd> <kbd>→</kbd> navigate &nbsp;
        <kbd>N</kbd> notes &nbsp;
        <kbd>F</kbd> fullscreen
    </div>

    <div class="presenter">
        <div class="viewer">
            <button class="nav-btn prev" onclick="navigate(-1)">&#8249;</button>
            <iframe id="slideFrame"></iframe>
            <button class="nav-btn next" onclick="navigate(1)">&#8250;</button>
        </div>

        <div class="notes-panel" id="notesPanel">
            <div class="notes-header">
                <span>Speaker Notes</span>
                <button class="notes-close" onclick="toggleNotes()">✕</button>
            </div>
            <div class="notes-content" id="notesContent">
                <p style="color: #5A7CA0;">Press <kbd>N</kbd> to toggle speaker notes.</p>
            </div>
        </div>
    </div>

    <div class="bottom-bar">
        <div class="counter" id="counter"></div>
        <div class="thumbnails" id="thumbs"></div>
    </div>

    <script>
        // === CONFIGURATION ===
        const slides = [/* REPLACE_WITH_SLIDE_FILES */];

        // Optional: speaker notes per slide (HTML strings)
        // If no notes provided, the notes panel shows "No notes for this slide"
        const notes = [/* REPLACE_WITH_NOTES */];

        // === STATE ===
        let current = 0;
        let notesOpen = false;
        let transitioning = false;

        // === DOM REFS ===
        const frame = document.getElementById('slideFrame');
        const counter = document.getElementById('counter');
        const thumbs = document.getElementById('thumbs');
        const notesPanel = document.getElementById('notesPanel');
        const notesContent = document.getElementById('notesContent');
        const progress = document.getElementById('progress');

        // === SCALE ===
        function scaleFrame() {
            const viewer = document.querySelector('.viewer');
            const scaleW = viewer.clientWidth / 1280;
            const scaleH = viewer.clientHeight / 720;
            const scale = Math.min(scaleW, scaleH) * 0.88;
            frame.style.transform = `scale(${scale})`;
        }

        // === NAVIGATION ===
        function show(idx) {
            if (transitioning) return;
            const target = Math.max(0, Math.min(slides.length - 1, idx));
            if (target === current && frame.src) return;

            transitioning = true;
            current = target;
            frame.src = slides[current];
            counter.textContent = `${current + 1} / ${slides.length}`;
            progress.style.width = `${((current + 1) / slides.length) * 100}%`;

            // Update dots
            document.querySelectorAll('.thumb').forEach((t, i) => {
                t.classList.toggle('active', i === current);
            });

            // Update notes
            if (notes[current]) {
                notesContent.innerHTML = notes[current];
            } else {
                notesContent.innerHTML = '<p style="color: #5A7CA0;">No notes for this slide.</p>';
            }

            setTimeout(() => { transitioning = false; }, 200);
        }

        function navigate(dir) { show(current + dir); }

        function toggleNotes() {
            notesOpen = !notesOpen;
            notesPanel.classList.toggle('open', notesOpen);
            setTimeout(scaleFrame, 350); // rescale after panel animation
        }

        // === BUILD DOTS ===
        slides.forEach((_, i) => {
            const dot = document.createElement('div');
            dot.className = 'thumb';
            dot.onclick = () => show(i);
            thumbs.appendChild(dot);
        });

        // === KEYBOARD ===
        document.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowRight' || e.key === ' ') { e.preventDefault(); navigate(1); }
            if (e.key === 'ArrowLeft') { e.preventDefault(); navigate(-1); }
            if (e.key === 'Home') { e.preventDefault(); show(0); }
            if (e.key === 'End') { e.preventDefault(); show(slides.length - 1); }
            if (e.key === 'n' || e.key === 'N') { e.preventDefault(); toggleNotes(); }
            if (e.key === 'f' || e.key === 'F') {
                e.preventDefault();
                if (document.fullscreenElement) {
                    document.exitFullscreen();
                } else {
                    document.documentElement.requestFullscreen?.();
                }
            }
        });

        // === SWIPE (touch devices) ===
        let touchStartX = 0;
        document.addEventListener('touchstart', (e) => { touchStartX = e.touches[0].clientX; });
        document.addEventListener('touchend', (e) => {
            const diff = touchStartX - e.changedTouches[0].clientX;
            if (Math.abs(diff) > 60) navigate(diff > 0 ? 1 : -1);
        });

        // === INIT ===
        window.addEventListener('resize', scaleFrame);
        scaleFrame();
        show(0);
    </script>
</body>
</html>
```

**Configuration:**

Replace `/* REPLACE_WITH_SLIDE_FILES */` with an array of filenames:
```javascript
const slides = ["slide-01-cover.html", "slide-02-mentor.html", ...];
```

Replace `/* REPLACE_WITH_NOTES */` with an array of HTML strings (one per slide):
```javascript
const notes = [
    `<h3>Cover</h3><ul><li>Welcome the audience</li><li>Set expectations for the session</li></ul><div class="timing">~1 min</div>`,
    `<h3>The Mentor</h3><ul><li>Brief intro, keep it under 2 minutes</li><li>Connect personal experience to the topic</li></ul><div class="timing">~2 min</div>`,
    // ... one entry per slide, or null for slides without notes
];
```

If speaker notes were not requested, use an empty array: `const notes = [];`

---

## Optional Embedded Navigator (`presentation.html`, browser only)

Self-contained navigator that embeds all slides directly in one file. Useful for local browser distribution when a single artifact is needed, but **not** the primary workflow output and not required for chat preview.

Features:
- Arrow key + dot navigation (NO click-to-advance on slide area)
- Slide counter + progress bar
- Fullscreen support ("F" key) — proxied to the parent via postMessage
- Swipe support for touch devices
- All slides embedded as hidden divs, toggled by JS

**IMPORTANT**: No click handlers on the slide area. Arrow keys, dots, and nav buttons only.

**How to build this file**: Read each `slide-XX.html`, extract the `.slide-container` div (the `<body>` content), and embed it as a `<div class="slide" data-slide="N">`. Include all CDN dependencies (Google Fonts, Font Awesome, Chart.js) once in the `<head>`.

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{Presentation Title}</title>
    <!-- Include all CDN deps used by any slide -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <!-- Include Chart.js only if any slide uses charts -->
    <!-- <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1"></script> -->
    <!-- <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.2.0"></script> -->
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            background: #050B14;
            font-family: 'Montserrat', sans-serif;
            color: #fff;
            overflow: hidden;
            width: 100vw;
            height: 100vh;
        }

        /* Slide wrapper — scales 1280x720 to fit viewport */
        .slide-viewport {
            width: 100vw;
            height: calc(100vh - 50px); /* leave room for bottom bar */
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }
        .slide-scaler {
            width: 1280px;
            height: 720px;
            transform-origin: center center;
            position: relative;
        }
        .slide {
            display: none;
            width: 1280px;
            height: 720px;
            position: absolute;
            top: 0;
            left: 0;
        }
        .slide.active { display: block; }

        /* Navigation arrows */
        .nav-btn {
            position: absolute; top: 50%; transform: translateY(-50%);
            background: rgba(32,99,173,0.2); border: 1px solid rgba(32,99,173,0.4);
            color: #BCD6F6; font-size: 24px; padding: 15px 20px;
            cursor: pointer; z-index: 100; border-radius: 8px;
            transition: all 0.2s; opacity: 0;
        }
        .slide-viewport:hover .nav-btn { opacity: 1; }
        .nav-btn:hover { background: rgba(32,99,173,0.5); color: #fff; }
        .prev { left: 20px; }
        .next { right: 20px; }

        /* Bottom bar */
        .bottom-bar {
            position: fixed; bottom: 0; left: 0; right: 0;
            height: 50px;
            display: flex; align-items: center; justify-content: center;
            gap: 20px; padding: 0 20px;
            background: rgba(5,11,20,0.95);
            z-index: 200;
        }
        .counter { font-size: 13px; color: #5A7CA0; white-space: nowrap; }
        .thumbnails { display: flex; gap: 6px; flex-wrap: wrap; justify-content: center; }
        .thumb {
            width: 10px; height: 10px; border-radius: 50%;
            background: rgba(255,255,255,0.15); cursor: pointer;
            transition: all 0.2s; border: none;
        }
        .thumb.active { background: #2063AD; transform: scale(1.3); }
        .thumb:hover { background: rgba(32,99,173,0.6); }

        /* Keyboard hints */
        .hints {
            position: fixed; top: 10px; right: 10px;
            font-size: 11px; color: #5A7CA0;
            opacity: 0; transition: opacity 0.3s;
            z-index: 200;
        }
        body:hover .hints { opacity: 1; }
        kbd {
            background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.15);
            padding: 2px 6px; border-radius: 3px; font-family: 'Montserrat', sans-serif;
            font-size: 10px;
        }

        /* Progress bar */
        .progress-bar {
            position: fixed; top: 0; left: 0; height: 3px;
            background: linear-gradient(90deg, #2063AD, #FF5756);
            transition: width 0.3s ease; z-index: 300;
        }
    </style>
</head>
<body>
    <div class="progress-bar" id="progress"></div>

    <div class="hints">
        <kbd>←</kbd> <kbd>→</kbd> navigate &nbsp;
        <kbd>F</kbd> fullscreen
    </div>

    <div class="slide-viewport">
        <button class="nav-btn prev" onclick="navigate(-1)">&#8249;</button>

        <div class="slide-scaler" id="scaler">
            <!-- REPLACE: Paste each slide's .slide-container here, wrapped in a .slide div -->
            <!-- Example:
            <div class="slide" data-slide="0">
                <div class="slide-container" style="...">
                    ... slide 1 content ...
                </div>
            </div>
            <div class="slide" data-slide="1">
                <div class="slide-container" style="...">
                    ... slide 2 content ...
                </div>
            </div>
            -->
        </div>

        <button class="nav-btn next" onclick="navigate(1)">&#8250;</button>
    </div>

    <div class="bottom-bar">
        <div class="counter" id="counter"></div>
        <div class="thumbnails" id="thumbs"></div>
    </div>

    <script>
        // === STATE ===
        var allSlides = document.querySelectorAll('.slide');
        var total = allSlides.length;
        var current = 0;

        var counter = document.getElementById('counter');
        var thumbs = document.getElementById('thumbs');
        var progress = document.getElementById('progress');
        var scaler = document.getElementById('scaler');

        // === SCALE ===
        function scaleToFit() {
            var vp = document.querySelector('.slide-viewport');
            var sw = vp.clientWidth / 1280;
            var sh = vp.clientHeight / 720;
            var s = Math.min(sw, sh) * 0.92;
            scaler.style.transform = 'scale(' + s + ')';
        }

        // === SHOW SLIDE ===
        function show(idx) {
            var target = Math.max(0, Math.min(total - 1, idx));
            current = target;
            allSlides.forEach(function(s, i) {
                s.classList.toggle('active', i === current);
            });
            counter.textContent = (current + 1) + ' / ' + total;
            progress.style.width = (((current + 1) / total) * 100) + '%';
            document.querySelectorAll('.thumb').forEach(function(t, i) {
                t.classList.toggle('active', i === current);
            });
        }

        function navigate(dir) { show(current + dir); }

        // === BUILD DOTS ===
        for (var i = 0; i < total; i++) {
            var dot = document.createElement('button');
            dot.className = 'thumb';
            dot.setAttribute('data-i', i);
            dot.onclick = function() { show(parseInt(this.getAttribute('data-i'))); };
            thumbs.appendChild(dot);
        }

        // === KEYBOARD ===
        document.addEventListener('keydown', function(e) {
            if (e.key === 'ArrowRight' || e.key === ' ') { e.preventDefault(); navigate(1); }
            if (e.key === 'ArrowLeft') { e.preventDefault(); navigate(-1); }
            if (e.key === 'Home') { e.preventDefault(); show(0); }
            if (e.key === 'End') { e.preventDefault(); show(total - 1); }
            if (e.key === 'f' || e.key === 'F') {
                e.preventDefault();
                if (document.fullscreenElement) {
                    document.exitFullscreen();
                } else {
                    document.documentElement.requestFullscreen();
                }
            }
        });

        // === SWIPE ===
        var touchStartX = 0;
        document.addEventListener('touchstart', function(e) { touchStartX = e.touches[0].clientX; });
        document.addEventListener('touchend', function(e) {
            var diff = touchStartX - e.changedTouches[0].clientX;
            if (Math.abs(diff) > 60) navigate(diff > 0 ? 1 : -1);
        });

        // === INIT ===
        window.addEventListener('resize', scaleToFit);
        scaleToFit();
        show(0);
    </script>
</body>
</html>
```

**How to populate the slides**:

Read each slide file and extract its body content. Wrap each in a `.slide` div:

```html
<div class="slide" data-slide="0">
    <!-- Content from slide-01-cover.html body -->
    <div class="slide-container" style="background: radial-gradient(...);">
        ...
    </div>
</div>
<div class="slide" data-slide="1">
    <!-- Content from slide-02-context.html body -->
    <div class="slide-container" style="background: linear-gradient(...);">
        ...
    </div>
</div>
```

If any slides use Chart.js, include the `<script>` tags in `<head>` and place each chart's initialization script inline inside its `.slide` div. Validate this in a browser, since `html-preview` does not execute JavaScript.

**Fullscreen note**: Validate fullscreen behavior in browser-based navigation (`index.html`), not in `html-preview`.
