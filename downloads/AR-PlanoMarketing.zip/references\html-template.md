# Referência de Design — One Pager Sprint (Excel)

> Este arquivo substituiu o template HTML anterior. O one-pager agora é gerado como `.xlsx` via `openpyxl`.

## Mapeamento de Quadrantes

| Perfil | Posição | Eixo Risco | Eixo Maturidade |
|---|---|---|---|
| Guardião | top-left | Conservador | Consolidado |
| Conquistador | top-right | Arrojado | Consolidado |
| Construtor | bottom-left | Conservador | Incipiente |
| Apostador | bottom-right | Arrojado | Incipiente |

## Descrições Sugeridas por Perfil

**Conquistador** — Empresário com perfil de risco arrojado à frente de uma empresa em fase de consolidação. Foco recomendado: acelerar geração de demanda, firmar recorrência com clientes campeões e construir autoridade de marca antes de escalar a operação.

**Guardião** — Perfil conservador em empresa consolidada. Foco: proteger e otimizar o que já funciona, aumentar eficiência operacional e extrair mais valor da base atual de clientes.

**Construtor** — Perfil conservador em empresa incipiente. Foco: validar modelo de negócio com baixo risco, construir processos básicos e gerar primeiras recorrências antes de ampliar escala.

**Apostador** — Perfil arrojado em empresa incipiente. Foco: testar canais rapidamente, iterar com agilidade e buscar product-market fit com velocidade, aceitando maior risco experimental.

## Ícones Sugeridos por Canal

| Canal | Ícone |
|---|---|
| Instagram Orgânico | 📸 |
| Meta Ads | 📣 |
| Google Ads | 🔍 |
| WhatsApp | 💬 |
| Email Marketing | 📧 |
| YouTube | 🎥 |
| TikTok | 🎵 |
| LinkedIn | 💼 |

## Script Python Completo

```python
# -*- coding: utf-8 -*-
import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter
import os

# ── DADOS (substituir pelos dados do usuário) ──────────────────────────────────
EMPRESA         = "{{EMPRESA}}"
MES_ANO         = "{{MES_ANO}}"           # ex: "Junho / 2026"
PERFIL          = "{{PERFIL}}"            # ex: "Conquistador"
RISCO           = "{{RISCO}}"             # ex: "Arrojado"
MATURIDADE      = "{{MATURIDADE}}"        # ex: "Consolidado"
DESC_PERFIL     = "{{DESCRICAO_PERFIL}}"  # 2-3 linhas
PROPOSTA        = "{{PROPOSTA_DE_VALOR}}" # frase da proposta definida
INTERP_PROPOSTA = "{{INTERPRETACAO}}"     # 2 linhas sintetizando diferencial
CAMPEAO = [
    "{{BULLET_CAMPIAO_1}}",
    "{{BULLET_CAMPIAO_2}}",
    "{{BULLET_CAMPIAO_3}}",
    "{{BULLET_CAMPIAO_4}}",
    "{{BULLET_CAMPIAO_5}}",
]
GTM             = "{{GO_TO_MARKET_30_PALAVRAS}}"  # resumo da estratégia em até 30 palavras
# Lista de dicts: {canal, kpis: [{nome, frequencia, direcao ("up"/"down"), responsavel}]}
CANAIS_KPIS = [
    {
        "canal": "{{CANAL_1}}",
        "kpis": [
            {"nome": "{{KPI_1}}", "frequencia": "{{FREQ}}", "direcao": "up", "responsavel": "{{RESP}}"},
        ]
    },
]
# ───────────────────────────────────────────────────────────────────────────────

# Cores
C_AZUL        = "003366"
C_AZUL_MED    = "1A5276"
C_AZUL_CLARO  = "D6E4F0"
C_DOURADO     = "C9A84C"
C_DOURADO_CLR = "FDF3DC"
C_BRANCO      = "FFFFFF"
C_TEXTO       = "1C1C1C"
C_CAMP_BG     = "D6E4F0"
C_VERDE       = "1A6B3A"
C_VERM        = "8A1A1A"

F_TITULO = "Libre Baskerville"
F_CORPO  = "Manrope"

wb = openpyxl.Workbook()
ws = wb.active
ws.title = "Plano Marketing"

col_widths = [3, 24, 24, 20, 16, 3, 24, 24, 20, 16]
for i, w in enumerate(col_widths, 1):
    ws.column_dimensions[get_column_letter(i)].width = w

def fill(hex_color):
    return PatternFill("solid", fgColor=hex_color)

def font(name=F_CORPO, size=10, bold=False, color=C_TEXTO, italic=False):
    return Font(name=name, size=size, bold=bold, color=color, italic=italic)

def align(h="left", v="center", wrap=False):
    return Alignment(horizontal=h, vertical=v, wrap_text=wrap)

def rh(row, h):
    ws.row_dimensions[row].height = h

def merge_fill(r1, c1, r2, c2, bg, txt="", fnt=None, aln=None):
    ws.merge_cells(start_row=r1, start_column=c1, end_row=r2, end_column=c2)
    cell = ws.cell(r1, c1)
    cell.value = txt
    cell.fill = fill(bg)
    if fnt: cell.font = fnt
    if aln: cell.alignment = aln

# ── HEADER ─────────────────────────────────────────────────────────────────────
rh(1, 6); rh(2, 32); rh(3, 20); rh(4, 4); rh(5, 8)

merge_fill(2, 1, 2, 10, C_AZUL,
    f"   {EMPRESA}",
    font(F_TITULO, 20, True, C_BRANCO),
    align("left", "center"))
merge_fill(3, 1, 3, 7, C_AZUL,
    "   Resumo Estratégico — G4 Sprints · Aumento de Receita",
    font(F_CORPO, 10, False, "A8B4C8"),
    align("left", "center"))
merge_fill(3, 8, 3, 10, C_AZUL,
    f"{MES_ANO}   ",
    font(F_CORPO, 10, False, C_DOURADO),
    align("right", "center"))
merge_fill(4, 1, 4, 10, C_DOURADO, "")

# ── SEÇÃO 1: MATURIDADE ────────────────────────────────────────────────────────
rh(6, 8); rh(7, 22)
merge_fill(7, 1, 7, 10, C_AZUL_MED,
    "   ESTÁGIO DE MATURIDADE",
    font(F_TITULO, 11, True, C_BRANCO),
    align("left", "center"))

rh(8, 22)
merge_fill(8, 1, 8, 5, C_AZUL,
    f"   Perfil: {PERFIL}",
    font(F_TITULO, 14, True, C_DOURADO),
    align("left", "center"))
merge_fill(8, 6, 8, 10, C_AZUL_CLARO,
    f"   Risco: {RISCO}  ·  Maturidade: {MATURIDADE}",
    font(F_CORPO, 10, False, C_AZUL_MED),
    align("left", "center"))

mat_map = {
    "Guardião":     (9,  1),
    "Conquistador": (9,  3),
    "Construtor":   (11, 1),
    "Apostador":    (11, 3),
}
for rh_row in (9, 10, 11, 12): rh(rh_row, 20)

for q_name, (qr, qc) in mat_map.items():
    is_active = q_name == PERFIL
    bg = C_AZUL if is_active else C_AZUL_CLARO
    fg = C_BRANCO if is_active else C_AZUL_MED
    label = ("★  " if is_active else "") + q_name
    merge_fill(qr, qc, qr+1, qc+1, bg, label,
        font(F_CORPO, 10, is_active, fg),
        align("center", "center", True))

rh(13, 14)
merge_fill(13, 1, 13, 4, C_BRANCO,
    "◄  Conservador                                Arrojado  ►",
    font(F_CORPO, 8, False, "999999", True),
    align("center", "center"))

merge_fill(9, 5, 13, 10, C_DOURADO_CLR,
    f"   {DESC_PERFIL}",
    font(F_CORPO, 10, False, C_TEXTO),
    align("left", "top", True))

rh(14, 4); merge_fill(14, 1, 14, 10, C_DOURADO, "")
rh(15, 8)

# ── SEÇÃO 2: PROPOSTA DE VALOR ─────────────────────────────────────────────────
rh(16, 22)
merge_fill(16, 1, 16, 10, C_AZUL_MED,
    "   PROPOSTA DE VALOR",
    font(F_TITULO, 11, True, C_BRANCO),
    align("left", "center"))

for r in (17, 18, 19): rh(r, 24)
merge_fill(17, 1, 19, 10, C_DOURADO_CLR,
    f'   "{PROPOSTA}"',
    font(F_TITULO, 14, True, C_AZUL),
    align("left", "center", True))

for r in (20, 21): rh(r, 20)
merge_fill(20, 1, 21, 10, C_AZUL_CLARO,
    f"   {INTERP_PROPOSTA}",
    font(F_CORPO, 10, False, C_TEXTO),
    align("left", "center", True))

rh(22, 4); merge_fill(22, 1, 22, 10, C_DOURADO, "")
rh(23, 8)

# ── SEÇÃO 3: ICP — PERFIL CAMPEÃO ─────────────────────────────────────────────
rh(24, 22)
merge_fill(24, 1, 24, 10, C_AZUL_MED,
    "   ICP — PERFIL CAMPEÃO",
    font(F_TITULO, 11, True, C_BRANCO),
    align("left", "center"))

rh(25, 18)
merge_fill(25, 1, 25, 10, C_CAMP_BG,
    "   ✓  Com quem crescer — clientes que geram mais resultado",
    font(F_CORPO, 10, True, C_AZUL_MED),
    align("left", "center"))

icons_camp = ["🔄", "📦", "📈", "💡", "🎯"]
for i, c_txt in enumerate(CAMPEAO):
    row = 26 + i
    rh(row, 22)
    bg = C_CAMP_BG if i % 2 == 0 else C_BRANCO
    merge_fill(row, 1, row, 10, bg,
        f"   {icons_camp[i]}  {c_txt}",
        font(F_CORPO, 10, False, C_TEXTO),
        align("left", "center", True))

rh(31, 4); merge_fill(31, 1, 31, 10, C_DOURADO, "")
rh(32, 8)

# ── SEÇÃO 4: GO-TO-MARKET ──────────────────────────────────────────────────────
rh(33, 22)
merge_fill(33, 1, 33, 10, C_AZUL_MED,
    "   ESTRATÉGIA GO-TO-MARKET",
    font(F_TITULO, 11, True, C_BRANCO),
    align("left", "center"))

for r in (34, 35): rh(r, 24)
merge_fill(34, 1, 35, 10, C_DOURADO_CLR,
    f"   {GTM}",
    font(F_CORPO, 11, False, C_TEXTO),
    align("left", "center", True))

rh(36, 4); merge_fill(36, 1, 36, 10, C_DOURADO, "")
rh(37, 8)

# ── SEÇÃO 5: CANAIS & KPIs ─────────────────────────────────────────────────────
rh(38, 22)
merge_fill(38, 1, 38, 10, C_AZUL_MED,
    "   CANAIS & KPIs DE ACOMPANHAMENTO",
    font(F_TITULO, 11, True, C_BRANCO),
    align("left", "center"))

hdr = 39
rh(hdr, 18)
hdr_data = [
    ((hdr, 1,  hdr, 2),  "Canal"),
    ((hdr, 3,  hdr, 5),  "KPI"),
    ((hdr, 6,  hdr, 7),  "Frequência"),
    ((hdr, 8,  hdr, 8),  "Dir."),
    ((hdr, 9,  hdr, 10), "Responsável"),
]
for (r1, c1, r2, c2), label in hdr_data:
    merge_fill(r1, c1, r2, c2, C_AZUL,
        f"  {label}",
        font(F_CORPO, 9, True, C_DOURADO),
        align("left", "center"))

cur = hdr + 1
for canal_data in CANAIS_KPIS:
    canal_name = canal_data["canal"]
    kpis = canal_data["kpis"]
    for j, kpi in enumerate(kpis):
        rh(cur, 18)
        bg = C_AZUL_CLARO if j % 2 == 0 else C_BRANCO
        canal_label = f"  {canal_name}" if j == 0 else ""
        canal_bg = C_DOURADO_CLR if j == 0 else C_BRANCO
        merge_fill(cur, 1, cur, 2, canal_bg,
            canal_label,
            font(F_CORPO, 10, j == 0, C_AZUL_MED),
            align("left", "center"))
        merge_fill(cur, 3, cur, 5, bg,
            f"  {kpi['nome']}",
            font(F_CORPO, 10, False, C_TEXTO),
            align("left", "center"))
        merge_fill(cur, 6, cur, 7, bg,
            f"  {kpi['frequencia']}",
            font(F_CORPO, 9, False, "666666"),
            align("left", "center"))
        is_up = kpi["direcao"] == "up"
        dir_sym   = "↑" if is_up else "↓"
        dir_color = C_VERDE if is_up else C_VERM
        c = ws.cell(cur, 8)
        c.value = dir_sym
        c.font  = font(F_CORPO, 14, True, dir_color)
        c.alignment = align("center", "center")
        c.fill = fill(bg)
        merge_fill(cur, 9, cur, 10, C_AZUL_CLARO,
            f"  {kpi['responsavel']}",
            font(F_CORPO, 9, False, C_AZUL_MED),
            align("left", "center"))
        cur += 1

# ── FOOTER ─────────────────────────────────────────────────────────────────────
rh(cur, 6); cur += 1
rh(cur, 24)
merge_fill(cur, 1, cur, 10, C_AZUL,
    "G4 Sprints — Aumento de Receita",
    font(F_TITULO, 11, True, C_DOURADO),
    align("center", "center"))

# ── SALVAR ─────────────────────────────────────────────────────────────────────
output_path = r"{{SESSION_ARTIFACTS}}/plano-marketing.xlsx"
os.makedirs(os.path.dirname(output_path), exist_ok=True)
wb.save(output_path)
print(f"SAVED:{output_path}")
```
