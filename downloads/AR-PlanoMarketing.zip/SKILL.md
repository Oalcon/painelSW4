---
name: "AR - Plano Marketing"
description: "Gera um one-pager Excel editável para o programa G4 Sprints - Aumento de Receita. Acionar quando o usuário pedir 'criar one pager', 'gerar one pager sprint', 'montar resumo estratégico G4', 'AR plano marketing', ou fornecer dados de workshop de sprint (maturidade, proposta de valor, ICP, canais e KPIs) para formatar."
---

## Objetivo

Gerar um arquivo Excel editável (`plano-marketing.xlsx`) com 5 seções estratégicas, formatado com as cores e tipografia G4 Sprints, e entregar ao usuário via filecard.

## Paleta de Cores

| Token | Hex | Uso |
|---|---|---|
| Azul primário | `#003366` | Cabeçalhos, títulos de seção, header |
| Azul médio | `#1A5276` | Sub-headers, destaques |
| Azul claro | `#D6E4F0` | Fundo de linhas alternadas, ICP Campeão |
| Dourado primário | `#C9A84C` | Bordas de destaque, separadores, badges |
| Dourado claro | `#FDF3DC` | Fundo de células dourado suave |
| Branco | `#FFFFFF` | Fundo geral |
| Texto escuro | `#1C1C1C` | Corpo de texto principal |
| Verde escuro | `#1A6B3A` | Direção KPI para cima (↑) |
| Vermelho escuro | `#8A1A1A` | Direção KPI para baixo (↓) |

## Fontes

- **Títulos / cabeçalhos**: `Libre Baskerville` (se não disponível localmente, usar `Georgia` como fallback)
- **Corpo / dados**: `Manrope` (se não disponível localmente, usar `Calibri` como fallback)

> O Excel aplica as fontes por nome — se o usuário não tiver instaladas, o sistema fará fallback automático.

## Coleta de Dados — Pedir ao Usuário

Ao ser ativada, solicite **tudo de uma vez** com esta mensagem:

> Para montar o one-pager, preciso de 5 itens:
>
> 1. **Contexto da empresa** — breve descrição do que a empresa faz
> 2. **Imagem do exercício 1.1 Maturidade** — print do gráfico ao final da aba (mostra o ponto plotado na matriz 2x2)
> 3. **Tabela do exercício 1.2 ICP** — copiar o conteúdo da segunda tabela da aba (perfis de clientes levantados)
> 4. **Exercício 1.3 Proposta de Valor** — respostas do aluno às 3 perguntas + proposta de valor definida
> 5. **Tabela de Canais & KPIs** — copiar o conteúdo da aba 2.2 KPIs

### ⛔ GUARDRAIL — Obrigatório

**NUNCA gere o Excel sem confirmar que os 5 itens foram recebidos.**

Após receber a resposta do usuário, verifique cada item:

| Item | Critério mínimo para considerar recebido |
|------|------------------------------------------|
| 1. Contexto da empresa | Texto descrevendo o negócio |
| 2. Imagem 1.1 Maturidade | Arquivo de imagem anexado |
| 3. Tabela 1.2 ICP | Conteúdo textual da tabela de perfis |
| 4. Exercício 1.3 Proposta de Valor | Respostas às perguntas **e** proposta de valor definida |
| 5. Tabela Canais & KPIs | Tabela com canais e KPIs listados |

Se **qualquer item estiver faltando**, responda listando exatamente o que falta, por exemplo:

> Ainda preciso de:
> - **Item 2** — imagem do gráfico de maturidade
> - **Item 4** — as respostas às 3 perguntas do exercício 1.3

Repita esse ciclo até ter **todos os 5 itens** antes de prosseguir.

## Interpretação das Imagens e Exercícios

### Imagem 1.1 — Maturidade
- Analisar onde o ponto está plotado na matriz para determinar o quadrante ativo
- Eixo horizontal: Conservador (esquerda) ↔ Arrojado (direita) — **perfil de risco do empresário**
- Eixo vertical: Consolidado (topo) ↔ Incipiente (base) — **nível de maturidade da empresa**
- Quadrantes: Guardião (sup-esq), Conquistador (sup-dir), Construtor (inf-esq), Apostador (inf-dir)

### Tabela 1.2 — ICP
- Receber o conteúdo textual da segunda tabela da aba 1.2 (não imagem)
- **NÃO listar clientes individuais por nome** — sintetizar em perfis comportamentais
- Extrair padrões e gerar **5 bullets de Perfil Campeão** apenas (sem Perfil a Evitar)

### Exercício 1.3 — Proposta de Valor
O exercício tem 3 perguntas orientadas pela análise de concorrentes:

| # | Pergunta | Como usar |
|---|---|---|
| 1 | Olhando seus concorrentes, qual público você atende melhor do que eles? | Compare o que os clientes falam de bom e a principal fortaleza de cada concorrente — onde sua entrega se diferencia, para quem? |
| 2 | Qual o resultado concreto que você entrega e nenhum concorrente entrega igual? | Olhe sua fortaleza vs. a deles — o que só você faz, ou faz melhor? Traduza em resultado pro cliente. |
| 3 | Qual a reclamação mais comum dos concorrentes que você resolve? | Use a coluna "Reclamação mais comum" dos concorrentes — essa é a dor que você alivia. |

Com base nas respostas do aluno às 3 perguntas **e** na proposta de valor definida:
- Extrair a frase da proposta de valor final (campo "Proposta de Valor Definida" do exercício)
- Sintetizar em 2 linhas de interpretação: para quem é, qual dor resolve, o que diferencia
- Identificar o público-alvo principal e o resultado prometido

## Geração do Excel — Script Python

Gerar o arquivo executando um script Python com `openpyxl`. Use a ferramenta Bash para executar o script.

### Estrutura da Planilha

O arquivo terá **uma única aba** chamada `One Pager`. Layout em linhas sequenciais:

```
Linha 1-4:    HEADER (empresa, tagline, data)
Linha 6-7:    SEÇÃO 1 — Estágio de Maturidade
Linha 8-15:   Conteúdo da Maturidade (matriz + perfil + descrição)
Linha 17-18:  SEÇÃO 2 — Proposta de Valor
Linha 19-24:  Conteúdo da Proposta de Valor (frase + interpretação)
Linha 26-27:  SEÇÃO 3 — ICP — Perfil Campeão
Linha 28-33:  5 bullets do Perfil Campeão (largura total)
Linha 35-36:  SEÇÃO 4 — Go-to-Market
Linha 37-38:  Resumo em até 30 palavras
Linha 40-41:  SEÇÃO 5 — Canais & KPIs
Linha 42+:    Tabela de KPIs (uma linha por KPI, agrupada por canal)
Linha final:  FOOTER
```

### Script Python Base

Consulte `references/html-template.md` para o script Python completo com todas as seções.

## Seleção de Canais & KPIs para o Relatório

O usuário pode fornecer muitos canais na tabela 2.2. **Selecione apenas os 5 canais mais relevantes** para o negócio descrito, com base no contexto da empresa e no perfil de maturidade identificado.

Critérios de seleção (use seu julgamento):
- Canais com maior potencial de geração de receita para o perfil/setor da empresa
- Canais que o próprio aluno priorizou (maior número de KPIs ou ênfase na tabela)
- Diversidade estratégica (ex: não selecionar 5 canais digitais se houver canais offline relevantes)

**Para cada um dos 5 canais selecionados, escolha exatamente 1 KPI** — o mais representativo do canal, preferencialmente voltado a resultado (receita, conversão, volume) e não a processo.

Se a tabela do usuário tiver menos de 5 canais, use todos os canais disponíveis.

## Fluxo de Execução

1. Coletar os 5 itens do usuário (guardrail ativo — não avançar sem todos)
2. Interpretar imagem 1.1 com ferramenta de visão; interpretar tabela 1.2 como texto
3. Interpretar exercício 1.3: extrair proposta definida + sintetizar interpretação (2 linhas) a partir das respostas às 3 perguntas
4. **Selecionar os 5 canais principais** da tabela 2.2 e escolher 1 KPI por canal (conforme regra acima)
5. Sintetizar Go-to-Market em até 30 palavras com base nos dados coletados (perfil + proposta + ICP + canais selecionados)
6. Montar o dicionário de dados com todos os campos
7. Substituir todos os `{{placeholders}}` no script com os dados reais
8. Salvar o script em `{session_scratch}/gen_onepager.py` — o arquivo deve começar com `# -*- coding: utf-8 -*-`
9. Executar via Bash com UTF-8 forçado: `PYTHONUTF8=1 python3 {session_scratch}/gen_onepager.py`
10. Capturar o caminho retornado na linha `SAVED:...`
11. Retornar **filecard** ao usuário:

```filecard
{"type":"file_download","path":"{caminho_absoluto}/plano-marketing.xlsx","filename":"plano-marketing.xlsx","mimeType":"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","size":{bytes},"sizeHuman":"{tamanho}"}
```

12. Adicionar mensagem:

> O arquivo está pronto para edição. Abra no Excel ou Google Sheets — todos os campos são editáveis. Para enviar ao cliente, mova para a pasta da empresa no Google Drive.

## Tratamento de Dependências

Antes de executar, verificar se `openpyxl` está disponível:

```bash
python3 -c "import openpyxl" 2>/dev/null || pip install openpyxl -q
```

## Referências

- Script Python completo: [references/html-template.md](references/html-template.md)
- Guia de upload para o Drive: [references/drive-upload.md](references/drive-upload.md)
