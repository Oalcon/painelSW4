# Upload de Arquivo para Google Drive via Google Workspace API

## 1. Ativar a Source

```
activate_sources({ sources: ["google-workspace-api"] })
```

Se já estiver ativa, prosseguir diretamente.

## 2. Extrair o folderId do link

O usuário fornece um link no formato:
- `https://drive.google.com/drive/folders/1AbCdEfGhIjKlMnOpQrStUvWxYz`
- `https://drive.google.com/drive/u/0/folders/1AbCdEfGhIjKlMnOpQrStUvWxYz`

Extrair a parte após `/folders/` — esse é o `folderId`.

## 3. Fazer upload do arquivo

Usar a ferramenta de upload da Google Workspace API (tool name conforme exposto pela source ativa). O arquivo a enviar é `onepager.html` salvo localmente na pasta da sessão.

Parâmetros típicos:
- `name`: `"onepager.html"`
- `mimeType`: `"text/html"`
- `parents`: `["{folderId}"]\`
- Conteúdo: ler o arquivo local e enviar

## 4. Confirmar ao usuário

Após upload bem-sucedido, informar:
> ✅ `onepager.html` salvo na pasta do Drive da empresa. [Abrir pasta]({link_fornecido_pelo_usuário})

Se a source não estiver autenticada, orientar o usuário a conectar via OAuth antes de continuar.
