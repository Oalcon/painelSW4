---
name: "AR — Plano Comercial"
description: "Gera um relatório Excel editável de plano comercial (AR - Plano Comercial). Acionar quando o usuário pedir 'gerar AR', 'criar relatório de plano comercial', 'montar AR plano comercial', 'gerar relatório AR', ou quiser criar um relatório de estratégia comercial com análise de produtos, plano de retenção e estrutura de equipe."
---

## Paleta de Cores

| Token | Hex | Uso |
|---|---|---|
| Azul navy | `#0D2B4E` | Header, títulos de seção, rodapé |
| Azul médio | `#1A3F6F` | Sub-headers, destaques |
| Azul accent | `#2A5298` | Bordas, separadores, badges |
| Azul claro | `#DCE8FB` | Fundo de linhas alternadas, KPI strip |
| Cinza claro | `#F4F7FC` | Fundo de células neutro |
| Amarelo entrada | `#FFF9E6` | Premissas (usuário preenche) no Backward Planning |
| Cinza calculado | `#EFEFEF` | Valores calculados no Backward Planning |
| Branco | `#FFFFFF` | Fundo geral |
| Verde ação | `#1A6B3C` | Badge Automatizar |
| Vermelho ação | `#8B1A14` | Badge Descontinuar |
| Dourado ação | `#7A4F00` | Badge Focar |

## Fontes

- **Títulos / cabeçalhos**: `Libre Baskerville` (fallback: `Georgia`)
- **Corpo / dados**: `Manrope` (fallback: `Calibri`)

## Fluxo de Execução

### Passo 1 — Coleta de Dados (tudo de uma vez)

> Para gerar o AR — Plano Comercial, preciso de 4 itens:
>
> 1. **Tabela da Aba 3.1 — Modelo de Conversão** — Colunas: Produto/Linha, Pontos de contato, Tempo comercial, Ticket Médio, Ação
> 2. **Tabela da Aba 3.2 — Planejamento Comercial** — Meta de receita, ticket médio, dados do funil (conversão leads→reuniões→vendas), estrutura de time se houver (SDRs, closers, salários, comissão), CPL se disponível
> 3. **Tabela da Aba 3.3 — Retenção** — lista de alertas
> 4. **Print do gráfico da Aba 4.1 — Expansão** — bubble chart

Aguarde o usuário enviar tudo. Se algum item estiver faltando, liste apenas os que faltam e peça de uma vez.

---

### Passo 2 — Gerar o Excel

**Estrutura da planilha** (aba única chamada `Plano Comercial`):

```
Bloco 1 — HEADER
Separador dourado
Bloco 2 — KPI STRIP (Meta | Ticket Médio | Vendas Necessárias | CAC)
Separador
Bloco 3 — SEÇÃO 1: TOP 3 PRODUTOS
           Tabela com os 3 produtos de maior ticket médio da aba 3.1
           Colunas: Produto | Ticket Médio | Ação
Separador
Bloco 4 — SEÇÃO 2: PLANO DE RETENÇÃO
           até 5 alertas: Indicador + Categoria
Separador
Bloco 5 — SEÇÃO 3: PLANO COMERCIAL — BACKWARD PLANNING
           Nota: "Tudo deriva da meta de receita."

           FUNIL — diagrama em blocos horizontais lado a lado:
           [BDRs/SDRs | nº | subtexto] → [Reuniões | nº | conv%] → [Closers | nº | subtexto] → [Vendas | nº | receita]
           Blocos alternados navy/azul claro, valores grandes no centro
           Se empresa não tem equipe: mostrar só [Leads | nº] → [Vendas | nº]

           MÉTRICAS — faixa horizontal com 4 KPIs lado a lado:
           [CPL | valor | subtexto] [CAC | valor | subtexto] [Margem por Venda | valor | subtexto] [ROI | valor | subtexto]
           Mesmo visual do KPI strip do topo (label / valor grande / sub)
Separador
Bloco 6 — SEÇÃO 4: PLANO DE AÇÃO — 30 DIAS
           6 ações: 3 Marketing + 3 Comercial
           Colunas: Frente | Ação (macro — máx 7 palavras) | Responsável (cargo) | Métrica
Separador
FOOTER: "G4 Sprints — Aumento de Receita · AR Plano Comercial · {MÊS ANO}"
```

**Regras importantes:**

- **Seção 1 (Top 3 Produtos)**: ordenar pela coluna Ticket Médio da aba 3.1 (maior para menor), mostrar apenas os 3 primeiros
- **Funil (Seção 3)**: diagrama em blocos horizontais lado a lado — mesmo formato do output anterior. Cada bloco tem: label (topo), valor grande (centro), subtexto (base). Alternância de fundo navy/azul claro. Sem colunas de "como é calculado" ou "volume necessário" — apenas os números macro
- **Backward Planning**: amarelo = premissa, cinza = calculado. Python faz todos os cálculos antes de gerar o arquivo
- **Plano de Ação**: ação em até 7 palavras, sem coluna "objetivo"
- Se empresa não tem equipe comercial: funil simplificado com 3 blocos (Leads → Reuniões → Vendas)

**Fluxo de execução:**
1. `python3 -c "import openpyxl" 2>/dev/null || pip install openpyxl -q`
2. Montar dados como variáveis Python reais
3. Salvar script em `{session_scratch}/gen_ar_comercial.py` — o arquivo deve começar com `# -*- coding: utf-8 -*-`
4. Executar com UTF-8 forçado: `PYTHONUTF8=1 python3 {session_scratch}/gen_ar_comercial.py`
5. Capturar `SAVED:...`

---

### Passo 3 — Entrega

```filecard
{"type":"file_download","path":"{caminho}/AR - Plano Comercial.xlsx","filename":"AR - Plano Comercial.xlsx","mimeType":"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","size":{bytes},"sizeHuman":"{tamanho}"}
```

> O arquivo está pronto para edição. Abra no Excel ou Google Sheets. Para enviar ao cliente, mova para a pasta da empresa no Google Drive.

## Referências

- Script Python completo: [references/template.md](references/template.md)
