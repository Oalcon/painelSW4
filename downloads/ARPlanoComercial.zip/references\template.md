# Script Python — AR Plano Comercial (Excel)

Script base completo. Substitua todas as variáveis pelos dados reais antes de executar.

```python
# -*- coding: utf-8 -*-
import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.utils import get_column_letter
import os

# ── DADOS (substituir pelos dados reais) ──────────────────────────────────────
EMPRESA = "{{EMPRESA}}"
MES_ANO = "{{MÊS}} / {{ANO}}"

META_RECEITA = "{{META_FORMATADA}}"    # ex: "R$ 2.000.000"
TICKET_MEDIO = "{{TICKET_MEDIO}}"     # ex: "R$ 50.000"

# Seção 1 — Top 3 produtos por ticket médio (já ordenados, maior primeiro)
TOP3_PRODUTOS = [
    {"produto": "{{PRODUTO_1}}", "ticket": "{{TICKET_1}}", "acao": "{{ACAO_1}}"},
    {"produto": "{{PRODUTO_2}}", "ticket": "{{TICKET_2}}", "acao": "{{ACAO_2}}"},
    {"produto": "{{PRODUTO_3}}", "ticket": "{{TICKET_3}}", "acao": "{{ACAO_3}}"},
]

# Seção 2 — Alertas de retenção (máx 5)
ALERTAS = [
    {"titulo": "{{TITULO}}", "categoria": "{{CATEGORIA}}"},
]

# Seção 3 — Backward Planning
BP_META          = {{META_NUMERICA}}         # ex: 2000000
BP_TICKET        = {{TICKET_NUMERICO}}       # ex: 50000
BP_VENDAS        = BP_META / BP_TICKET
BP_CONV_LEAD_REU = {{CONV_LEAD_REUNIAO}}     # ex: 0.50
BP_CONV_REU_VEND = {{CONV_REUNIAO_VENDA}}    # ex: 0.50
BP_REUNIOES      = BP_VENDAS / BP_CONV_REU_VEND
BP_LEADS         = BP_REUNIOES / BP_CONV_LEAD_REU

# Time (None se empresa não tiver equipe comercial)
BP_LEADS_POR_SDR     = {{LEADS_POR_SDR}}      # ex: 30 | None
BP_VENDAS_POR_CLOSER = {{VENDAS_POR_CLOSER}}  # ex: 10 | None
BP_SAL_SDR           = {{SALARIO_SDR}}        # ex: 2500 | None
BP_SAL_CLOSER        = {{SALARIO_CLOSER}}     # ex: 5000 | None
BP_COMISSAO_PCT      = {{COMISSAO_PCT}}       # ex: 0.05 | None
BP_CPL               = {{CPL}}               # ex: 2500 | None
BP_MARGEM_PCT        = {{MARGEM_CONTRIBUICAO}} # ex: 0.80

# Derivados de time
BP_SDRS     = round(BP_LEADS / BP_LEADS_POR_SDR)     if BP_LEADS_POR_SDR     else None
BP_CLOSERS  = round(BP_VENDAS / BP_VENDAS_POR_CLOSER) if BP_VENDAS_POR_CLOSER else None
BP_HC       = (BP_SDRS or 0) + (BP_CLOSERS or 0)
BP_FOLHA    = ((BP_SAL_SDR or 0)*(BP_SDRS or 0) + (BP_SAL_CLOSER or 0)*(BP_CLOSERS or 0)) or None
BP_COMISSAO = (BP_META * BP_COMISSAO_PCT) if BP_COMISSAO_PCT else None
BP_INV_MKT  = (BP_CPL * BP_LEADS) if BP_CPL else None
BP_CUSTO_SM = sum(x for x in [BP_FOLHA, BP_COMISSAO, BP_INV_MKT] if x) or None
BP_CAC      = (BP_CUSTO_SM / BP_VENDAS) if BP_CUSTO_SM else None
BP_MRG_VND  = BP_TICKET * BP_MARGEM_PCT
BP_MRG_TOT  = BP_MRG_VND * BP_VENDAS
BP_RESULT   = (BP_MRG_TOT - BP_CUSTO_SM) if BP_CUSTO_SM else BP_MRG_TOT
BP_ROI      = (BP_RESULT / BP_CUSTO_SM * 100) if BP_CUSTO_SM else None
BP_PAYBACK  = (BP_CAC / BP_TICKET) if BP_CAC else None

def fmt_brl(v):
    if v is None: return "—"
    if v >= 1_000_000: return f"R$ {v/1_000_000:.1f}M"
    if v >= 1_000: return f"R$ {v:,.0f}".replace(",",".")
    return f"R$ {v:.0f}"

def fmt_pct(v):
    return f"{v*100:.1f}%" if v is not None else "—"

def fmt_n(v, d=0):
    return f"{v:.{d}f}" if v is not None else "—"

# Seção 4 — Plano de Ação 30 dias (ação = máx 7 palavras)
PLANO_ACAO = [
    {"frente": "Marketing", "acao": "{{ACAO_MKT_1}}", "responsavel": "{{CARGO_MKT_1}}", "metrica": "{{METRICA_MKT_1}}"},
    {"frente": "Marketing", "acao": "{{ACAO_MKT_2}}", "responsavel": "{{CARGO_MKT_2}}", "metrica": "{{METRICA_MKT_2}}"},
    {"frente": "Marketing", "acao": "{{ACAO_MKT_3}}", "responsavel": "{{CARGO_MKT_3}}", "metrica": "{{METRICA_MKT_3}}"},
    {"frente": "Comercial", "acao": "{{ACAO_COM_1}}", "responsavel": "{{CARGO_COM_1}}", "metrica": "{{METRICA_COM_1}}"},
    {"frente": "Comercial", "acao": "{{ACAO_COM_2}}", "responsavel": "{{CARGO_COM_2}}", "metrica": "{{METRICA_COM_2}}"},
    {"frente": "Comercial", "acao": "{{ACAO_COM_3}}", "responsavel": "{{CARGO_COM_3}}", "metrica": "{{METRICA_COM_3}}"},
]
# ─────────────────────────────────────────────────────────────────────────────

C_NAVY      = "0D2B4E"
C_NAVY_MID  = "1A3F6F"
C_ACCENT    = "2A5298"
C_ACCENT_LT = "DCE8FB"
C_BG2       = "F4F7FC"
C_BRANCO    = "FFFFFF"
C_TEXTO     = "0D2B4E"
C_DOURADO   = "C9A84C"
C_AMARELO   = "FFF9E6"
C_CINZA_C   = "EFEFEF"

F_TITULO = "Libre Baskerville"
F_CORPO  = "Manrope"

ACAO_CORES = {
    "Automatizar":     ("D4F0E0", "1A6B3C"),
    "Aumentar Ticket": ("DCE8FB", "1A3F6F"),
    "Descontinuar":    ("FDE8E6", "8B1A14"),
    "Focar":           ("FFF3D6", "7A4F00"),
    "Investir":        ("FFF3D6", "7A4F00"),
}
FRENTE_CORES = {
    "Marketing": ("DCE8FB", "1A3F6F"),
    "Comercial": ("D4F0E0", "1A6B3C"),
}

def ac(acao):
    for k, v in ACAO_CORES.items():
        if k.lower() in acao.lower(): return v
    return ("DCE8FB", "1A3F6F")

def fc(frente):
    return FRENTE_CORES.get(frente, ("F4F7FC", "0D2B4E"))

wb = openpyxl.Workbook()
ws = wb.active
ws.title = "Plano Comercial"

col_widths = [3, 22, 20, 16, 14, 12, 14, 14, 14, 14, 14, 3]
for i, w in enumerate(col_widths, 1):
    ws.column_dimensions[get_column_letter(i)].width = w

def fill(h): return PatternFill("solid", fgColor=h)
def font(name=F_CORPO, size=10, bold=False, color=C_TEXTO, italic=False):
    return Font(name=name, size=size, bold=bold, color=color, italic=italic)
def align(h="left", v="center", wrap=False):
    return Alignment(horizontal=h, vertical=v, wrap_text=wrap)
def rh(row, h): ws.row_dimensions[row].height = h
def merge_fill(r1, c1, r2, c2, bg, txt="", fnt=None, aln=None):
    ws.merge_cells(start_row=r1, start_column=c1, end_row=r2, end_column=c2)
    cell = ws.cell(r1, c1)
    cell.value = txt; cell.fill = fill(bg)
    if fnt: cell.font = fnt
    if aln: cell.alignment = aln
def sep(row, color=C_ACCENT):
    rh(row, 4); merge_fill(row, 1, row, 12, color, "")
def sec_title(row, label):
    rh(row, 22)
    merge_fill(row, 1, row, 12, C_NAVY_MID, f"   {label}",
        font(F_TITULO, 11, True, C_BRANCO), align("left", "center"))

# ── HEADER ─────────────────────────────────────────────────────────────────────
rh(1,6); rh(2,32); rh(3,20); rh(4,4); rh(5,8)
merge_fill(2,1,2,12, C_NAVY, f"   AR — Plano Comercial  |  {EMPRESA}",
    font(F_TITULO,20,True,C_BRANCO), align("left","center"))
merge_fill(3,1,3,9,  C_NAVY, "   Análise estratégica de portfólio, estrutura comercial e retenção",
    font(F_CORPO,10,False,"6B8BAF"), align("left","center"))
merge_fill(3,10,3,12,C_NAVY, f"{MES_ANO}   ",
    font(F_CORPO,10,False,C_DOURADO), align("right","center"))
sep(4, C_DOURADO)

# ── KPI STRIP ──────────────────────────────────────────────────────────────────
rh(6,8); rh(7,14); rh(8,28); rh(9,16); rh(10,8)
kpis = [
    ("Meta de Receita",    META_RECEITA,        "Período"),
    ("Ticket Médio",       TICKET_MEDIO,        "Por contrato"),
    ("Vendas Necessárias", fmt_n(BP_VENDAS),    "Meta ÷ Ticket"),
    ("CAC Estimado",       fmt_brl(BP_CAC),     "Custo por venda"),
]
for (c1,c2),(label,value,sub) in zip([(1,3),(4,6),(7,9),(10,12)], kpis):
    merge_fill(7,c1,7,c2, C_ACCENT_LT, f"  {label}", font(F_CORPO,9,False,C_ACCENT), align("left","center"))
    merge_fill(8,c1,8,c2, C_BRANCO,    f"  {value}", font(F_TITULO,18,True,C_NAVY),  align("left","center"))
    merge_fill(9,c1,9,c2, C_BG2,       f"  {sub}",   font(F_CORPO,9,False,"5A6E8C"), align("left","center"))
sep(11,C_ACCENT); rh(12,8)

# ── SEÇÃO 1: TOP 3 PRODUTOS ────────────────────────────────────────────────────
sec_title(13, "1. Top 3 Produtos por Ticket Médio")
rh(14,18)
for (c1,c2),label in [((1,4),"Produto / Linha"),((5,7),"Ticket Médio"),((8,12),"Ação")]:
    merge_fill(14,c1,14,c2, C_NAVY, f"  {label}",
        font(F_CORPO,9,True,C_BRANCO), align("left","center"))
cur = 15
for j, p in enumerate(TOP3_PRODUTOS):
    rh(cur,20)
    bg = C_BG2 if j%2==0 else C_BRANCO
    bg_hex, fg_hex = ac(p["acao"])
    merge_fill(cur,1,cur,4,  bg,     f"   {p['produto']}", font(F_CORPO,11,True,C_NAVY),  align("left","center"))
    merge_fill(cur,5,cur,7,  bg,     f"   {p['ticket']}",  font(F_CORPO,11,False,C_TEXTO), align("left","center"))
    merge_fill(cur,8,cur,12, bg_hex, f"   {p['acao']}",    font(F_CORPO,10,True,fg_hex),   align("center","center"))
    cur+=1

sep(cur,C_ACCENT); cur+=1; rh(cur,8); cur+=1

# ── SEÇÃO 2: PLANO DE RETENÇÃO ────────────────────────────────────────────────
sec_title(cur,"2. Plano de Retenção"); cur+=1
rh(cur,16)
merge_fill(cur,1,cur,9,  C_ACCENT_LT,"   Indicador", font(F_CORPO,9,True,C_ACCENT),align("left","center"))
merge_fill(cur,10,cur,12,C_ACCENT_LT,"   Categoria", font(F_CORPO,9,True,C_ACCENT),align("left","center"))
cur+=1
for j,alerta in enumerate(ALERTAS[:5]):
    rh(cur,20)
    bg = C_BG2 if j%2==0 else C_BRANCO
    merge_fill(cur,1,cur,9,  bg,          f"   {alerta['titulo']}",   font(F_CORPO,10,True,C_NAVY),   align("left","center"))
    merge_fill(cur,10,cur,12,C_ACCENT_LT, f"  {alerta['categoria']}", font(F_CORPO,9,True,C_ACCENT),  align("center","center"))
    cur+=1

sep(cur,C_ACCENT); cur+=1; rh(cur,8); cur+=1

# ── SEÇÃO 3: PLANO COMERCIAL — BACKWARD PLANNING ──────────────────────────────
sec_title(cur,"3. Plano Comercial — Backward Planning"); cur+=1
rh(cur,14)
merge_fill(cur,1,cur,12, C_BG2,
    "   Tudo deriva da meta de receita.  Amarelo = premissa.  Cinza = calculado.",
    font(F_CORPO,9,False,"5A6E8C",True), align("left","center"))
cur+=1; rh(cur,8); cur+=1

# ─── FUNIL ────────────────────────────────────────────────────────────────────
rh(cur,14)
merge_fill(cur,1,cur,12, C_NAVY, "   FUNIL",
    font(F_CORPO,10,True,C_BRANCO), align("left","center"))
cur+=1

tem_equipe = BP_LEADS_POR_SDR is not None
if tem_equipe:
    funil_blocos = [
        ("BDRs / SDRs",          str(BP_SDRS) if BP_SDRS else "—",    f"{fmt_n(BP_LEADS_POR_SDR)} leads/SDR"),
        ("Reuniões Qualificadas", fmt_n(BP_REUNIOES),                   f"Conv. {fmt_pct(BP_CONV_LEAD_REU)}"),
        ("Closers",               str(BP_CLOSERS) if BP_CLOSERS else "—",f"{fmt_n(BP_VENDAS_POR_CLOSER)} vendas/closer"),
        ("Vendas Fechadas",       fmt_n(BP_VENDAS),                     META_RECEITA),
    ]
else:
    funil_blocos = [
        ("Leads Necessários",  fmt_n(BP_LEADS),    f"Conv. {fmt_pct(BP_CONV_LEAD_REU)} → reunião"),
        ("Reuniões",           fmt_n(BP_REUNIOES), f"Conv. {fmt_pct(BP_CONV_REU_VEND)} → venda"),
        ("Vendas Fechadas",    fmt_n(BP_VENDAS),   META_RECEITA),
    ]

n_blocos = len(funil_blocos)
cols_por_bloco = 12 // n_blocos
bgs_funil = [C_NAVY, C_ACCENT_LT, C_NAVY, C_ACCENT_LT]
fgs_funil  = [C_BRANCO, C_NAVY, C_BRANCO, C_NAVY]

for b_idx, (label, valor, sub) in enumerate(funil_blocos):
    c1 = b_idx * cols_por_bloco + 1
    c2 = c1 + cols_por_bloco - 1
    if b_idx == n_blocos - 1: c2 = 12
    bg = bgs_funil[b_idx % len(bgs_funil)]
    fg = fgs_funil[b_idx % len(fgs_funil)]
    sub_fg = C_BRANCO if fg == C_BRANCO else "5A6E8C"
    rh(cur,   14); merge_fill(cur,   c1,cur,   c2, bg, f"  {label}", font(F_CORPO,9,False,sub_fg), align("left","center"))
    rh(cur+1, 28); merge_fill(cur+1, c1,cur+1, c2, bg, f"  {valor}", font(F_TITULO,20,True,fg),    align("left","center"))
    rh(cur+2, 14); merge_fill(cur+2, c1,cur+2, c2, bg, f"  {sub}",   font(F_CORPO,9,False,sub_fg), align("left","center"))

cur+=3; rh(cur,8); cur+=1

# ─── MÉTRICAS HORIZONTAIS ─────────────────────────────────────────────────────
metricas = [
    ("CPL",            fmt_brl(BP_CPL),                          "Custo por lead"),
    ("CAC",            fmt_brl(BP_CAC),                          "Custo por venda"),
    ("Margem por Venda", fmt_brl(BP_MRG_VND),                   "Ticket × margem"),
    ("ROI",            f"{BP_ROI:.1f}%" if BP_ROI else "—",      "Retorno s/ investimento"),
]
met_spans = [(1,3),(4,6),(7,9),(10,12)]
rh(cur,14); rh(cur+1,28); rh(cur+2,16)
for (c1,c2),(label,value,sub) in zip(met_spans, metricas):
    merge_fill(cur,  c1,cur,  c2, C_ACCENT_LT, f"  {label}", font(F_CORPO,9,False,C_ACCENT),  align("left","center"))
    merge_fill(cur+1,c1,cur+1,c2, C_BRANCO,    f"  {value}", font(F_TITULO,18,True,C_NAVY),   align("left","center"))
    merge_fill(cur+2,c1,cur+2,c2, C_BG2,       f"  {sub}",   font(F_CORPO,9,False,"5A6E8C"),  align("left","center"))
cur+=3

sep(cur,C_ACCENT); cur+=1; rh(cur,8); cur+=1

# ── SEÇÃO 4: PLANO DE AÇÃO 30 DIAS ────────────────────────────────────────────
sec_title(cur,"4. Plano de Ação — 30 Dias"); cur+=1
rh(cur,18)
for (c1,c2),label in [((1,2),"Frente"),((3,6),"Ação (macro)"),((7,9),"Responsável"),((10,12),"Métrica")]:
    merge_fill(cur,c1,cur,c2, C_NAVY, f"  {label}",
        font(F_CORPO,9,True,C_BRANCO), align("left","center"))
cur+=1

for j, item in enumerate(PLANO_ACAO):
    rh(cur,22)
    bg_fr, fg_fr = fc(item["frente"])
    bg_row = C_BG2 if j%2==0 else C_BRANCO
    merge_fill(cur,1,cur,2,  bg_fr,       f"  {item['frente']}",      font(F_CORPO,10,True,fg_fr),    align("center","center"))
    merge_fill(cur,3,cur,6,  bg_row,      f"  {item['acao']}",         font(F_CORPO,10,False,C_TEXTO), align("left","center",True))
    merge_fill(cur,7,cur,9,  bg_fr,       f"  {item['responsavel']}",  font(F_CORPO,9,True,fg_fr),     align("left","center"))
    merge_fill(cur,10,cur,12,C_ACCENT_LT, f"  {item['metrica']}",      font(F_CORPO,9,False,C_ACCENT), align("left","center",True))
    cur+=1

# ── FOOTER ─────────────────────────────────────────────────────────────────────
rh(cur,6); cur+=1; rh(cur,22)
merge_fill(cur,1,cur,12, C_NAVY,
    f"G4 Sprints — Aumento de Receita  ·  AR Plano Comercial  ·  {MES_ANO}",
    font(F_TITULO,10,True,"6B8BAF"), align("center","center"))

# ── SALVAR ─────────────────────────────────────────────────────────────────────
output_path = r"{{SESSION_ARTIFACTS}}/AR - Plano Comercial.xlsx"
os.makedirs(os.path.dirname(output_path), exist_ok=True)
wb.save(output_path)
print(f"SAVED:{output_path}")
```

## Mapeamento de Variáveis

| Variável | Fonte |
|---|---|
| `EMPRESA`, `MES_ANO` | Contexto da empresa |
| `BP_META`, `BP_TICKET` | Aba 3.2 — valores numéricos para cálculo |
| `BP_CONV_LEAD_REU`, `BP_CONV_REU_VEND` | Aba 3.2 — taxas de conversão (0.0–1.0) |
| `BP_LEADS_POR_SDR`, `BP_VENDAS_POR_CLOSER` | Aba 3.2 — produtividade de time (`None` se sem equipe) |
| `BP_SAL_SDR`, `BP_SAL_CLOSER`, `BP_COMISSAO_PCT` | Aba 3.2 — custos de time (`None` se sem equipe) |
| `BP_CPL` | Aba 3.2 — custo por lead (`None` se não informado) |
| `BP_MARGEM_PCT` | Aba 3.2 — margem de contribuição (0.0–1.0) |
| `TOP3_PRODUTOS` | Aba 3.1 — 3 maiores tickets, já ordenados |
| `ALERTAS` | Aba 3.3 — máx 5 |
| `PLANO_ACAO` | Gerado pelo assistente (ação ≤ 7 palavras) |
