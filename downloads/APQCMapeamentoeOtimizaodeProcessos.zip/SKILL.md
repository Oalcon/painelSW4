---
name: "APQC — Mapeamento e Otimização de Processos"
description: "Mapeia processos operacionais do usuário, cria POPs e Playbooks, define indicadores de Quantidade/Qualidade/Custo e entrega plano de otimização com automações — usando o APQC PCF v8.0 como referência. Use quando o usuário pedir para mapear processos, criar POPs, documentar operação, definir indicadores operacionais, identificar automações, otimizar rotinas, ou usar APQC/PCF."
---

# APQC — Mapeamento e Otimização de Processos

## Quando usar

- `/apqc-processos` ou `/apqc`
- usuário pede para mapear processos, criar POPs ou Playbooks
- usuário quer documentar operação ou rotinas da equipe
- usuário quer definir indicadores operacionais (Quantidade, Qualidade, Custo)
- usuário quer identificar automações ou otimizar processos
- usuário menciona APQC, PCF ou benchmarking de processos

## Idioma

Responda sempre no idioma do usuário.

## Passo 0 — Carregar o APQC PCF

Antes de iniciar a entrevista, localize ou baixe a planilha de referência:

1. Verifique se o arquivo já existe no working directory ou em qualquer subpasta (procure por `APQC_PCF*.xlsx` ou `apqc*.xlsx`).
2. Se encontrado localmente, use esse arquivo.
3. Se **não encontrado**, baixe do repositório oficial:

```
https://raw.githubusercontent.com/Gestao-Quatro-Ponto-Zero/g4os-docs/main/use-cases/datasets/APQC_PCF_Cross-Industry_v8.0.xlsx
```

Processe as abas da planilha para ter em contexto:
- As 13 categorias principais (Hierarchy ID 1.0 a 13.0)
- Os subprocessos de até nível 3 relevantes para o contexto do usuário
- As definições de cada processo para usar no mapeamento da Fase 4

Se o download falhar, continue a entrevista mas avise o usuário que o mapeamento da Fase 4 (Hierarchy IDs) será baseado no conhecimento interno do PCF v8.0 sem referência ao arquivo.

Confirme o carregamento com uma mensagem curta antes de iniciar a entrevista.

---

## FASE 1 — Mapeamento (entrevista guiada)

Faça **uma pergunta por vez**. Aguarde a resposta antes de continuar. Não agrupe perguntas.

**Pergunta 1 — Contexto**
> Me conta sobre seu negócio e seu papel. Qual é a empresa, o que ela faz, e qual é a sua função no dia a dia operacional?

**Pergunta 2 — Áreas de dor**
> Das 13 áreas do APQC — Estratégia, Produtos, Marketing/Vendas, Supply Chain, Serviços, Atendimento ao Cliente, RH, TI, Financeiro, Ativos, Risco/Compliance, Relações Externas e Capacidades Organizacionais — quais consomem mais tempo ou geram mais dor hoje?

**Pergunta 3 — Processo crítico**
> Me descreve o processo mais crítico ou doloroso que você executa hoje. Como ele funciona passo a passo, quem participa e quais ferramentas ou sistemas usa?

**Pergunta 4 — Gargalo**
> Onde está o maior gargalo nesse processo? Retrabalho, dependência de pessoa-chave, falta de padrão, integração manual entre ferramentas, ou outra coisa?

**Pergunta 5 — Objetivo**
> Qual é o objetivo principal da melhoria: reduzir tempo de execução, reduzir custo, aumentar qualidade/confiabilidade, escalar sem contratar, ou outro?

Ao final da Fase 1, faça um **resumo confirmativo** dos processos identificados antes de avançar:
> "Entendi. Vou trabalhar com os seguintes processos: [lista]. Seguindo para a Fase 2 — documentação."

---

## FASE 2 — Documentação (POPs e Playbooks)

Para cada processo crítico identificado na Fase 1, produza:

### POP — Procedimento Operacional Padrão

```
PROCESSO: [nome]
PCF REF: [será preenchido na Fase 4]

OBJETIVO
[Uma frase descrevendo o propósito do processo]

RESPONSÁVEL: [cargo ou função]
GATILHO DE INÍCIO: [o que dispara o processo]
CRITÉRIO DE ENCERRAMENTO: [o que define que o processo terminou]

PASSO A PASSO
1. [ação]
2. [ação]
...

EXCEÇÕES E COMO TRATAR
• [cenário]: [ação a tomar]
```

### Playbook

```
PLAYBOOK: [nome]

CONTEXTO E PROPÓSITO
[Por que este processo existe e qual valor entrega]

PRÉ-REQUISITOS
• [recurso, acesso ou informação necessária]

FLUXO PRINCIPAL
[Fluxo com pontos de decisão: "Se X → faça Y, senão → faça Z"]

VARIAÇÕES E CASOS ESPECIAIS
• [caso]: [como tratar]

CHECKLIST DE EXECUÇÃO
☐ [item]
☐ [item]
```

---

## FASE 3 — Indicadores (Quantidade, Qualidade, Custo)

Para cada processo documentado, proponha indicadores nas 3 dimensões:

| Indicador | Dimensão | Meta sugerida | Método de coleta |
|-----------|----------|--------------|-----------------|
| [nome] | Quantidade | [valor] | [onde/como medir] |
| [nome] | Qualidade | [valor] | [onde/como medir] |
| [nome] | Custo | [valor] | [onde/como medir] |

**Dimensões:**
- **Quantidade** — volume e velocidade: nº de execuções/período, tempo de ciclo, capacidade
- **Qualidade** — conformidade e acerto: taxa de retrabalho, % de erros, SLA cumprido, NPS interno
- **Custo** — recursos por unidade: custo por processo, horas por entrega, custo de exceção

Inclua sempre: nome do indicador, dimensão, meta sugerida com base em contexto, e método de coleta (ferramenta ou fonte de dado).

---

## FASE 4 — Otimização

### 4a — Mapeamento no PCF

Para cada processo mapeado, cite:
- **Hierarchy ID** (ex: `3.5.1.2`)
- **Nome oficial** no PCF
- **Definição padrão** APQC
- **Gap identificado** entre o processo atual do usuário e o padrão APQC

### 4b — Plano de ação priorizado

Organize por impacto × esforço em 4 categorias:

| Categoria | Prazo | O que inclui |
|-----------|-------|-------------|
| **Quick wins** | < 2 semanas | Simplificações, eliminação de etapas desnecessárias, padronização de templates |
| **Automações com IA** | 1–4 semanas | Processos repetitivos que o G4 OS pode executar diretamente hoje |
| **Integrações e streamlines** | 1–3 meses | Eliminar handoffs manuais entre ferramentas, conectar sistemas |
| **Redesenho de processo** | 3+ meses | Quando a estrutura atual é o problema — reengenharia |

Para cada item do plano inclua:
- Processo APQC (Hierarchy ID + nome)
- Ação concreta
- Responsável sugerido
- Prazo estimado
- Métrica de sucesso

### 4c — Automações com G4 OS

Destaque especificamente quais processos o G4 OS pode automatizar agora, sem integração adicional (ex: geração de relatórios, envio de comunicações, análise de dados, criação de documentos, pesquisa).

---

## Salvar outputs

Ao final, ofereça salvar os artefatos gerados:
- POPs e Playbooks como arquivos `.md` no working directory
- Indicadores como tabela exportável
- Plano de ação como arquivo `.md`

Pergunte: "Quer que eu salve os POPs, indicadores e plano de ação como arquivos? Se sim, informe o nome do projeto ou área."

Se o usuário confirmar, salve em:
```
[working_directory]/processos/[nome-area]/
  ├── POP-[nome-processo].md
  ├── Playbook-[nome-processo].md
  ├── Indicadores-[nome-area].md
  └── Plano-Otimizacao-[nome-area].md
```

---

## Regras

1. **Uma pergunta por vez** na Fase 1 — nunca agrupe perguntas.
2. **Confirme o entendimento** ao final da Fase 1 antes de avançar.
3. **Cite sempre o Hierarchy ID** do PCF ao mapear processos na Fase 4.
4. **Não invente métricas** — se não há referência suficiente, indique "a definir com time" na meta.
5. **Seja prático** — POPs e Playbooks devem ser usáveis por quem executa, não por quem leu um livro de gestão.
6. **Priorize automações reais** — só indique automação com G4 OS se o processo for genuinamente automatizável hoje.
