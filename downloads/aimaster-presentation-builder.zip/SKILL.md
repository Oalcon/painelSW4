---
name: "aimaster-presentation-builder"
description: "Criação de apresentações executivas HTML com identidade visual G4, geração de PDF de alta qualidade e exportação para compartilhamento. Use quando o usuário pedir para criar uma apresentação, deck, slides, ou proposta executiva — especialmente para CPTO, diretoria ou stakeholders externos. Cobre: estruturação narrativa, cálculo de métricas financeiras, layout responsivo com design G4 (Navy Blue + Royal Gold + Manrope), e exportação PDF via Puppeteer. Não cobre apresentações em PowerPoint/Google Slides nem relatórios sem estrutura de slides."
alwaysAllow: ["Read", "Write", "Edit", "Bash", "Glob"]
---

# Presentation Builder

Criação de apresentações executivas HTML com identidade visual G4 — da narrativa ao PDF compartilhável.

## Processo padrão

### Passo 1 — Entender o contexto

Antes de criar qualquer slide, colete:
- **Audiência**: quem vai ver? (CPTO, diretoria, cliente externo?)
- **Objetivo**: decisão, aprovação, alinhamento, informação?
- **Dados disponíveis**: números, métricas, datas que o usuário já tem
- **Tom**: executivo-direto (padrão G4) ou técnico?

Se o usuário forneceu dados suficientes, avance sem perguntar. Faça no máximo **uma pergunta** se algo crítico estiver faltando.

### Passo 2 — Estruturar a narrativa

Estrutura padrão para apresentações executivas G4:

| Slide | Tipo | Conteúdo |
|-------|------|----------|
| 1 | Capa | Título do tema, subtítulo com contexto, autor(es), data |
| 2 | Contexto/Dados históricos | O que existe hoje — números reais, histórico |
| 3 | Situação atual | Custo/problema atual detalhado |
| 4 | Solução proposta | O que muda, nova estrutura de custos |
| 5 | Comparativo | Tabela lado a lado: antes vs. depois |
| 6 | Projeção financeira | Economia acumulada, gráfico de barras por período |
| 7 | Cronograma | Timeline de implementação em fases |
| 8 | Riscos & Premissas | O que assumimos + o que pode dar errado |
| 9 | Próximos passos | Call to action, checklist de ações |

Adapte conforme contexto — remova slides desnecessários, adicione se houver dados ricos.

**Princípios narrativos:**
- Dados reais sempre preferíveis a estimativas — pergunte se o usuário tem histórico
- Picos/outliers em séries históricas: sinalize e explique, nunca omita
- Footnotes com ressalvas em todo slide com números estimados
- Linguagem executiva: orientada a resultado, sem jargão técnico desnecessário

### Passo 3 — Construir o HTML

O arquivo deve ser um único HTML auto-contido com navegação por teclado (← →) e botões. Consulte a seção **Design System G4** abaixo.

**Estrutura do arquivo:**
```
sessions/{session-id}/artifacts/apresentacao-{tema}.html
```

**Comportamentos obrigatórios:**
- Cada slide ocupa 100vw × 100vh
- Padding: `48px 72px 64px` (bottom maior para não cortar footnotes)
- Navegação: setas do teclado + botões fixos no canto inferior direito
- Header com logo G4 em todo slide
- Footnotes com `*` em itálico no rodapé de slides com estimativas

### Passo 4 — Exportar PDF

Após o HTML aprovado, gerar PDF via Puppeteer + pdf-lib. Consulte a seção **Script de exportação PDF** abaixo.

**Caminho de saída:**
```
sessions/{session-id}/artifacts/apresentacao-{tema}.pdf
```

O PDF deve ter exatamente o mesmo número de slides que o HTML. Conferir se footnotes não estão cortadas antes de entregar.

---

## Design System G4

### Paleta de cores (CSS variables)

```css
/* Brand Primary — Navy Blue */
--brand-950: #011422;   /* fundo principal dos slides */
--brand-900: #031b26;
--brand-800: #06243c;   /* cards brand */
--brand-700: #0c2e48;
--brand-600: #123a54;
--brand-500: #184560;   /* bordas, destaques */
--brand-400: #326c89;
--brand-300: #6692a8;   /* textos secundários */
--brand-200: #99b7c7;   /* textos de corpo */
--brand-100: #ccdce6;
--brand-50:  #e6eef3;

/* Brand Secondary — Royal Gold */
--gold-500: #b9915b;    /* eyebrows, linhas divisórias, CTAs */
--gold-400: #c5a06e;    /* números em destaque, KPIs */
--gold-300: #d8bf9b;
--gold-100: #ecdfce;

/* Semânticas */
--success-500: #17b26a;
--warning-500: #f79009;
--white: #ffffff;

/* Aliases para uso em slides */
--red-highlight: #f87171;    /* valores negativos, custos altos */
--green-highlight: #4ade80;  /* economia, valores positivos */
```

### Tipografia

```css
font-family: 'Manrope', -apple-system, 'Segoe UI', sans-serif;
/* Importar via: @import url('https://fonts.googleapis.com/css2?family=Manrope:wght@300;400;500;600;700;800&display=swap') */
```

Hierarquia:
- `h1`: 800 weight, clamp(36px, 4.5vw, 56px), letter-spacing -1.2px
- `h2`: 700 weight, clamp(24px, 3vw, 36px), letter-spacing -0.5px
- Eyebrow: 11px, 700, uppercase, letter-spacing 2px, cor `--gold-500`
- KPI value: 800 weight, clamp(22px, 2.8vw, 32px)
- Body: 15px, cor `--brand-200`
- Footnote: 11px, itálico, cor `--brand-400`

### Componentes reutilizáveis

**Card base:**
```css
background: rgba(255,255,255,0.04);
border: 1px solid rgba(255,255,255,0.08);
border-radius: 12px;
padding: 24px;
```

Variantes: `.card-accent` (borda gold), `.card-success` (borda verde), `.card-brand` (fundo brand-800)

**Gold line (divisor):**
```css
width: 48px; height: 3px;
background: var(--gold-500);
border-radius: 2px; margin-bottom: 24px;
```

**Badge:**
```css
display: inline-flex; padding: 4px 12px;
border-radius: 100px; font-size: 11px; font-weight: 700;
text-transform: uppercase; letter-spacing: 0.5px;
```
Variantes: `badge-gold`, `badge-success`, `badge-warning`

**KPI block:**
```html
<div class="kpi-label">LABEL</div>
<div class="kpi-value gold">R$ 132k</div>
<div class="kpi-sub">descrição complementar</div>
```

**Tabela comparativa:**
- Header: 11px, uppercase, letter-spacing 1.5px, `--brand-300`
- Células: 14px, padding 14px 16px, border-bottom sutil
- Linha total: font-weight 800, border-top destacada
- Valores negativos/altos: `#f87171` | Valores positivos/economia: `#4ade80` | Destaque: `--gold-400`

**Timeline (3 fases):**
```html
<div class="timeline"> <!-- display:flex -->
  <div class="timeline-item"> <!-- flex:1 -->
    <div class="timeline-phase current"> <!-- ou .future -->
      <div class="phase-num">Mês 1 · Mês/Ano</div>
      <div class="phase-title">Nome da fase</div>
      <div class="phase-desc">· Item 1<br>· Item 2</div>
      <div class="phase-tag"><span class="badge badge-gold">Em andamento</span></div>
    </div>
  </div>
</div>
```

**Barra de progresso (ROI/economia):**
```html
<div class="roi-bar-row">
  <div class="roi-bar-label">Mês 6</div>
  <div class="roi-bar-track">
    <div class="roi-bar-fill green" style="width: 75%;">≈ R$ 530k</div>
  </div>
</div>
```

**Step list (próximos passos):**
```html
<div class="step-row">
  <div class="step-num done">✓</div>  <!-- ou .active ou .pending -->
  <div class="step-text">
    <h4>Título da ação</h4>
    <p>Detalhe e prazo</p>
  </div>
</div>
```

### Efeitos decorativos de fundo

Cada slide tem dois pseudo-elementos com radial-gradient sutil:
- `::before`: top-right, azul `rgba(24,69,96,0.35)`
- `::after`: bottom-left, gold `rgba(185,145,91,0.12)`

---

## Script de exportação PDF

**Dependências:** `puppeteer` e `pdf-lib` instalados globalmente via npm no G4 OS.

```
NODE_PATH: C:/Users/{user}/AppData/Local/Programs/G4 OS/resources/vendor/node/node_modules
```

Verificar disponibilidade antes de usar:
```bash
NODE_PATH="..." node -e "require('puppeteer'); console.log('ok')"
NODE_PATH="..." node -e "require('pdf-lib'); console.log('ok')"
```

Se não instalados:
```bash
npm install -g puppeteer
npm install -g pdf-lib
```

**Script padrão** — salvar em `sessions/{id}/scratch/export-pdf.js`:

```javascript
const puppeteer = require('puppeteer');
const { PDFDocument } = require('pdf-lib');
const fs = require('fs');

const HTML_PATH = 'C:\\caminho\\para\\apresentacao.html';
const OUT_PATH  = 'C:\\caminho\\para\\apresentacao.pdf';
const SLIDE_W = 1280;
const SLIDE_H = 720;
const TOTAL_SLIDES = 9; // ajustar conforme número de slides

(async () => {
  const browser = await puppeteer.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--font-render-hinting=none'],
  });

  const mainDoc = await PDFDocument.create();

  for (let i = 0; i < TOTAL_SLIDES; i++) {
    const page = await browser.newPage();
    await page.setViewport({ width: SLIDE_W, height: SLIDE_H, deviceScaleFactor: 2 });

    const fileUrl = 'file:///' + HTML_PATH.replace(/\\/g, '/');
    await page.goto(fileUrl, { waitUntil: 'networkidle0', timeout: 30000 });

    await page.evaluate((idx) => {
      document.querySelectorAll('.slide').forEach(s => s.classList.remove('active'));
      document.querySelectorAll('.slide')[idx].classList.add('active');
      const nav = document.querySelector('.nav');
      if (nav) nav.style.display = 'none';
    }, i);

    await new Promise(r => setTimeout(r, 400));

    const pdfBytes = await page.pdf({
      width: `${SLIDE_W}px`,
      height: `${SLIDE_H}px`,
      printBackground: true,
      margin: { top: 0, right: 0, bottom: 0, left: 0 },
    });

    const slidePdf = await PDFDocument.load(pdfBytes);
    const [slidePage] = await mainDoc.copyPages(slidePdf, [0]);
    mainDoc.addPage(slidePage);
    await page.close();
    console.log(`Slide ${i + 1}/${TOTAL_SLIDES} done`);
  }

  fs.writeFileSync(OUT_PATH, await mainDoc.save());
  console.log('PDF saved:', OUT_PATH);
  await browser.close();
})().catch(err => { console.error(err); process.exit(1); });
```

**Executar:**
```bash
NODE_PATH="C:/Users/{user}/AppData/Local/Programs/G4 OS/resources/vendor/node/node_modules" \
  node sessions/{id}/scratch/export-pdf.js
```

**Checklist pós-geração:**
- Conferir se footnotes (linhas com `*`) não estão cortadas
- Confirmar que o número de páginas do PDF bate com o total de slides
- Verificar renderização de gradientes e fontes no preview

---

## Contexto G4

- Audiência primária deste workspace: CPTO (João Vitor) e equipe de AI Master
- Tom padrão: executivo, orientado a resultado, sem jargão técnico desnecessário
- Autoria: `Jurandir & Ferrari · G4`
- Apresentações ficam em `sessions/{id}/artifacts/`
- Nomenclatura de arquivo: `apresentacao-{tema-kebab-case}.html` / `.pdf`
