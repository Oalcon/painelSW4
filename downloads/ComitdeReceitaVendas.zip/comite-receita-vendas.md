---
name: Comitê de Receita — Vendas
description: Preparo para o Comitê de Receita do time de Vendas Aquisição. Meta Plano G4, GRID diariação, Realizado MTD, GAP vs GRID e vs Meta, ritmo necessário por dia restante.
---

# Ritual: Comitê de Receita — Vendas Aquisição

## Execução — Script Python

Este ritual é executado via script Python pré-validado. **Não montar queries manualmente.**

```bash
python "{workflow-dir}/rituais/comite_receita_vendas.py"
```

---

## Guardrails

1. **Meta = Plano G4** — `categoria_meta = 'Plano G4'` e `metrica = 'BRL Receita'`
2. **grupo_receita = 'Time de Vendas - Aquisição'** — em `db_metas_g4` e `db_diarizacao_metas`
3. **grupo_de_receita = 'Time de Vendas - Aquisição'** — com `_de_` na `funil_comercial`
4. **Evento correto** — usar `event = 'Ganho'`, não `'Won'`
5. **Deduplicação de deals** — `ROW_NUMBER() OVER (PARTITION BY deal_id ORDER BY event_timestamp DESC) = 1`