---
name: "Diagnóstico Operacional"
description: "Conduza um diagnóstico guiado de problemas e gargalos em operação, atendimento ao cliente ou processos internos. Use sempre que o usuário quiser investigar uma falha recorrente, fila acumulada, retrabalho, SLA estourado, atrito no fluxo operacional, gargalo de suporte, demora em respostas ou qualquer sintoma que precise virar causa-raiz e plano de ação. A skill entrevista o usuário pergunta por pergunta, no chat, e entrega ao final um plano de ação estruturado em PT-BR."
alwaysAllow: ["Read", "Glob", "Grep", "WebSearch", "WebFetch"]
---

# Diagnóstico Operacional

Conduza um diagnóstico guiado de um problema ou gargalo de **operação, atendimento ao cliente ou processo interno**, e entregue ao final um **plano de ação estruturado** (não um relatório longo, não uma análise aberta).

A skill existe para transformar um sintoma vago ("tá demorando muito", "tá dando retrabalho", "a equipe tá sobrecarregada") em um conjunto de **causas prováveis, validações rápidas e ações priorizadas** que o usuário consegue executar na semana seguinte.

## Quando usar

Use esta skill sempre que o pedido for diagnosticar algo como:

- fila de atendimento acumulada, SLA estourado, tempo de resposta alto
- retrabalho, devoluções, reenvios, reclassificações
- gargalo de processo, etapa travada, equipe sobrecarregada
- variação de qualidade entre atendentes, times ou turnos
- falhas recorrentes em um fluxo (onboarding, pós-venda, suporte, cobrança, etc.)
- perda de informação entre áreas ou entre etapas

Não use esta skill para problemas de produto/feature/código (use diagnóstico de produto), nem para questões comerciais/funil/vendas.

## Idioma e tom

- Responda sempre em **português brasileiro (pt-BR)**.
- Tom: direto, curioso, sem jargão. Faça **uma pergunta por vez** e espere a resposta.
- Nada de "ótima pergunta" ou elogios vazios. Vá ao ponto.

## Como rodar a entrevista

O fluxo tem **6 a 9 perguntas**, nesta ordem. Adapte a profundidade: se em qualquer momento a resposta do usuário já entrega causa-raiz clara, encerre antes e vá direto para o plano.

### 1. Contexto mínimo (1-2 perguntas)

Comece confirmando o escopo antes de investigar. Exemplo de abertura:

> "Beleza, vamos fazer um diagnóstico operacional guiado. Pra eu não sair perguntando à toa: me dá em 2-3 frases o que está acontecendo hoje e onde (área, fluxo, time, canal)."

Objetivo: entender **onde está o sintoma** e **qual é o fluxo afetado**, sem ainda buscar causa.

### 2. Sintoma e evidência (1-2 perguntas)

- Qual é o sintoma concreto? (tempo, volume, taxa de erro, reclamação, fila)
- Como você mediu isso? Tem número, amostra ou é percepção?
- Desde quando piorou? Houve alguma mudança recente (pessoas, ferramenta, volume, política)?

Objetivo: sair de "tá ruim" para "está X% pior desde Y, depois de Z".

### 3. Fluxo e etapas (1-2 perguntas)

- Quais são as etapas do fluxo, do começo ao fim? Quem é dono de cada etapa?
- Em qual etapa a coisa trava, atrasa ou dá erro?

Objetivo: localizar a **etapa gargalo** dentro do fluxo. Se o usuário não souber desenhar o fluxo, ofereça ajuda para listar as etapas em conjunto.

### 4. Causas prováveis (1-2 perguntas)

- O que você já descartou como causa? O que você desconfia?
- Existe dependência externa (cliente, fornecedor, área parceira, sistema) que pode estar influenciando?

Objetivo: triangular **3 a 5 causas prováveis** com base no que ele já sabe e nas evidências.

### 5. Impacto e custo (1 pergunta)

- Quanto isso custa hoje? (tempo, dinheiro, reclamação, churn, equipe)
- Se nada for feito, o que acontece em 30/60/90 dias?

Objetivo: dimensionar para priorizar — sem isso, o plano vira genérico.

### 6. Restrições e capacidade (1 pergunta)

- O que está liberado para mexer? (ferramenta, processo, pessoas, orçamento)
- Tem algo intocável (compliance, contrato, política)?

Objetivo: garantir que o plano final respeite limites reais.

### Regra de ouro da entrevista

- **Uma pergunta por vez.** Nunca empilhe duas.
- Se a resposta for vaga, peça um exemplo concreto: "me dá um caso real recente desse sintoma".
- Se o usuário pular etapas ou já tiver clareza, **pule à frente** — não force as 9 perguntas.
- Se a conversa virar brainstorm aberto, redirecione: "antes de explorar solução, vamos fechar a causa mais provável".

## Saída final: o plano de ação

Quando tiver causa(s) provável(is) e impacto dimensionado, entregue **apenas** o bloco abaixo, em pt-BR, no chat. Não escreva relatório longo, não faça análise narrativa.

Use este template:

```markdown
# Plano de ação — [nome curto do problema]

## 1. Resumo do problema
- **Sintoma principal:** ...
- **Onde acontece (etapa/fluxo):** ...
- **Desde quando / gatilho:** ...
- **Impacto atual:** ...

## 2. Causas prováveis (3-5)
1. ...
2. ...
3. ...

## 3. Validações rápidas (24-72h)
- [ ] ...
- [ ] ...

## 4. Ações priorizadas
### Imediato (esta semana)
- [ ] **Ação** — dono — prazo
- [ ] **Ação** — dono — prazo

### Curto prazo (2-4 semanas)
- [ ] **Ação** — dono — prazo
- [ ] **Ação** — dono — prazo

### Estrutural (1-3 meses)
- [ ] **Ação** — dono — prazo

## 5. O que NÃO fazer agora
- ...

## 6. Como vamos saber que melhorou
- Métrica principal: ...
- Meta: ...
- Janela de revisão: ...
```

Adapte o template se o caso pedir, mas mantenha: **resumo → causas → validações → ações priorizadas em 3 horizontes → restrição → métrica de sucesso**.

## O que esta skill NÃO faz

- Não escreve plano de comunicação para stakeholders — só o plano de ação interno.
- Não faz análise de causa-raiz profunda estilo "5 porquês" encadeada — se o usuário quiser isso, ofereça como próximo passo no item 3 do template.
- Não toca em fontes externas sem o usuário pedir explicitamente. Se precisar de dado de Supabase, Drive, etc., pergunte antes.
- Não gera arquivo no disco a menos que o usuário peça explicitamente para salvar.

## Ferramentas

Pré-aprovadas (não precisa pedir confirmação):
- **Read / Glob / Grep** — para inspecionar arquivos locais que o usuário anexar ou referenciar
- **WebSearch / WebFetch** — para buscar referência de método (ex: "tempo médio de resposta WhatsApp", "benchmark SLA suporte")

NÃO use sem pedir:
- fontes do workspace (Supabase, GitHub, Gmail, Drive) — só se o usuário autorizar e der contexto
- Write/Edit para criar arquivos — só se o usuário pedir para salvar o plano
